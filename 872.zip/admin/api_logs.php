<?php
require_once '../config/config.php';

if (!isset($_SESSION['admin_id'])) {
    redirect(ADMIN_URL . '/login.php');
}

$db = Database::getInstance()->getConnection();

// Get filter parameters
$date_from = $_GET['date_from'] ?? date('Y-m-d', strtotime('-7 days'));
$date_to = $_GET['date_to'] ?? date('Y-m-d');
$api_type = $_GET['api_type'] ?? '';
$status = $_GET['status'] ?? '';
$search = $_GET['search'] ?? '';

// Build query
$where_conditions = ['DATE(created_at) BETWEEN ? AND ?'];
$params = [$date_from, $date_to];

if ($api_type) {
    $where_conditions[] = "api_type = ?";
    $params[] = $api_type;
}

if ($status) {
    $where_conditions[] = "status = ?";
    $params[] = $status;
}

if ($search) {
    $where_conditions[] = "(endpoint LIKE ? OR request_data LIKE ? OR response_data LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

$where_clause = 'WHERE ' . implode(' AND ', $where_conditions);

// Get logs with pagination
$page = (int)($_GET['page'] ?? 1);
$per_page = 50;
$offset = ($page - 1) * $per_page;

$count_query = "SELECT COUNT(*) as total FROM api_logs $where_clause";
$stmt = $db->prepare($count_query);
$stmt->execute($params);
$total_logs = $stmt->fetch()['total'];
$total_pages = ceil($total_logs / $per_page);

$logs_query = "
    SELECT * FROM api_logs 
    $where_clause
    ORDER BY created_at DESC 
    LIMIT $per_page OFFSET $offset
";

$stmt = $db->prepare($logs_query);
$stmt->execute($params);
$logs = $stmt->fetchAll();

// Get statistics
$stats_query = "
    SELECT 
        COUNT(*) as total_requests,
        SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successful_requests,
        SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as failed_requests,
        AVG(response_time) as avg_response_time,
        api_type,
        COUNT(*) as type_count
    FROM api_logs 
    WHERE DATE(created_at) BETWEEN ? AND ?
    GROUP BY api_type
    ORDER BY type_count DESC
";

$stmt = $db->prepare($stats_query);
$stmt->execute([$date_from, $date_to]);
$api_stats = $stmt->fetchAll();

// Get overall stats
$overall_stats_query = "
    SELECT 
        COUNT(*) as total_requests,
        SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successful_requests,
        SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as failed_requests,
        AVG(response_time) as avg_response_time
    FROM api_logs 
    WHERE DATE(created_at) BETWEEN ? AND ?
";

$stmt = $db->prepare($overall_stats_query);
$stmt->execute([$date_from, $date_to]);
$overall_stats = $stmt->fetch();

// Get API types
$api_types = [
    'charging' => 'شحن المنتجات',
    'payment' => 'الدفع',
    'wallet' => 'المحفظة',
    'verification' => 'التحقق',
    'notification' => 'الإشعارات',
    'other' => 'أخرى'
];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سجلات API - فاست ستار</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
    <style>
        .log-details {
            max-height: 200px;
            overflow-y: auto;
            background: #f8f9fa;
            padding: 10px;
            border-radius: 5px;
            font-family: monospace;
            font-size: 12px;
        }
        .status-success { color: #28a745; }
        .status-error { color: #dc3545; }
        .status-pending { color: #ffc107; }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">سجلات API</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button class="btn btn-outline-secondary me-2" onclick="exportLogs()">
                            <i class="fas fa-download me-2"></i>تصدير
                        </button>
                        <button class="btn btn-outline-danger me-2" onclick="clearOldLogs()">
                            <i class="fas fa-trash me-2"></i>مسح القديم
                        </button>
                        <button class="btn btn-primary" onclick="refreshLogs()">
                            <i class="fas fa-sync-alt me-2"></i>تحديث
                        </button>
                    </div>
                </div>
                
                <!-- Statistics -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-right-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col me-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">إجمالي الطلبات</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($overall_stats['total_requests']) ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-server fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-right-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col me-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">ناجحة</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($overall_stats['successful_requests']) ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-right-danger shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col me-2">
                                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">فاشلة</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($overall_stats['failed_requests']) ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-times-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-right-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col me-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">متوسط الاستجابة</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($overall_stats['avg_response_time'], 2) ?>ms</div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-clock fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- API Types Statistics -->
                <div class="row mb-4">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">إحصائيات حسب نوع API</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <?php foreach ($api_stats as $stat): ?>
                                    <div class="col-md-4 mb-3">
                                        <div class="card border-left-primary">
                                            <div class="card-body">
                                                <h6><?= $api_types[$stat['api_type']] ?? $stat['api_type'] ?></h6>
                                                <p class="mb-1">الطلبات: <strong><?= number_format($stat['type_count']) ?></strong></p>
                                                <p class="mb-1">النجاح: <strong><?= number_format($stat['successful_requests']) ?></strong></p>
                                                <p class="mb-0">الفشل: <strong><?= number_format($stat['failed_requests']) ?></strong></p>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Filters -->
                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-2">
                                <label class="form-label">من تاريخ</label>
                                <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($date_from) ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">إلى تاريخ</label>
                                <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($date_to) ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">نوع API</label>
                                <select name="api_type" class="form-select">
                                    <option value="">جميع الأنواع</option>
                                    <?php foreach ($api_types as $type => $type_name): ?>
                                        <option value="<?= $type ?>" <?= $api_type === $type ? 'selected' : '' ?>><?= $type_name ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">الحالة</label>
                                <select name="status" class="form-select">
                                    <option value="">جميع الحالات</option>
                                    <option value="success" <?= $status === 'success' ? 'selected' : '' ?>>نجح</option>
                                    <option value="error" <?= $status === 'error' ? 'selected' : '' ?>>فشل</option>
                                    <option value="pending" <?= $status === 'pending' ? 'selected' : '' ?>>معلق</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">البحث</label>
                                <input type="text" name="search" class="form-control" placeholder="نقطة النهاية أو البيانات" value="<?= htmlspecialchars($search) ?>">
                            </div>
                            <div class="col-md-2 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary me-2">
                                    <i class="fas fa-search me-1"></i>بحث
                                </button>
                                <a href="api_logs.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-times me-1"></i>مسح
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Logs Table -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th>الوقت</th>
                                        <th>نوع API</th>
                                        <th>نقطة النهاية</th>
                                        <th>الحالة</th>
                                        <th>وقت الاستجابة</th>
                                        <th>IP</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($logs as $log): ?>
                                    <tr>
                                        <td>
                                            <small><?= date('H:i:s', strtotime($log['created_at'])) ?></small><br>
                                            <small class="text-muted"><?= date('Y-m-d', strtotime($log['created_at'])) ?></small>
                                        </td>
                                        <td>
                                            <span class="badge bg-info"><?= $api_types[$log['api_type']] ?? $log['api_type'] ?></span>
                                        </td>
                                        <td>
                                            <code><?= htmlspecialchars($log['endpoint']) ?></code><br>
                                            <small class="text-muted"><?= strtoupper($log['method']) ?></small>
                                        </td>
                                        <td>
                                            <span class="status-<?= $log['status'] ?>">
                                                <i class="fas fa-<?= $log['status'] === 'success' ? 'check' : ($log['status'] === 'error' ? 'times' : 'clock') ?>"></i>
                                                <?= $log['status'] === 'success' ? 'نجح' : ($log['status'] === 'error' ? 'فشل' : 'معلق') ?>
                                            </span>
                                            <?php if ($log['http_code']): ?>
                                                <br><small class="text-muted"><?= $log['http_code'] ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($log['response_time']): ?>
                                                <span class="badge bg-<?= $log['response_time'] < 1000 ? 'success' : ($log['response_time'] < 3000 ? 'warning' : 'danger') ?>">
                                                    <?= number_format($log['response_time']) ?>ms
                                                </span>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <small><?= htmlspecialchars($log['ip_address']) ?></small>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-info" onclick="viewLogDetails(<?= $log['id'] ?>)">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-center">
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                    <a class="page-link" href="?page=<?= $i ?>&date_from=<?= urlencode($date_from) ?>&date_to=<?= urlencode($date_to) ?>&api_type=<?= urlencode($api_type) ?>&status=<?= urlencode($status) ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                                </li>
                                <?php endfor; ?>
                            </ul>
                        </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <!-- Log Details Modal -->
    <div class="modal fade" id="logDetailsModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تفاصيل السجل</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="logDetailsContent">
                        <div class="text-center">
                            <div class="spinner-border" role="status">
                                <span class="visually-hidden">جاري التحميل...</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function viewLogDetails(logId) {
            const modal = new bootstrap.Modal(document.getElementById('logDetailsModal'));
            modal.show();
            
            // Load log details via AJAX
            fetch(`get_log_details.php?id=${logId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const log = data.log;
                        document.getElementById('logDetailsContent').innerHTML = `
                            <div class="row">
                                <div class="col-md-6">
                                    <h6>معلومات عامة</h6>
                                    <table class="table table-sm">
                                        <tr><td><strong>الوقت:</strong></td><td>${log.created_at}</td></tr>
                                        <tr><td><strong>نوع API:</strong></td><td>${log.api_type}</td></tr>
                                        <tr><td><strong>نقطة النهاية:</strong></td><td><code>${log.endpoint}</code></td></tr>
                                        <tr><td><strong>الطريقة:</strong></td><td>${log.method}</td></tr>
                                        <tr><td><strong>الحالة:</strong></td><td>${log.status}</td></tr>
                                        <tr><td><strong>كود HTTP:</strong></td><td>${log.http_code || '-'}</td></tr>
                                        <tr><td><strong>وقت الاستجابة:</strong></td><td>${log.response_time ? log.response_time + 'ms' : '-'}</td></tr>
                                        <tr><td><strong>عنوان IP:</strong></td><td>${log.ip_address}</td></tr>
                                    </table>
                                </div>
                                <div class="col-md-6">
                                    <h6>بيانات الطلب</h6>
                                    <div class="log-details">${log.request_data || 'لا توجد بيانات'}</div>
                                    
                                    <h6 class="mt-3">بيانات الاستجابة</h6>
                                    <div class="log-details">${log.response_data || 'لا توجد بيانات'}</div>
                                    
                                    ${log.error_message ? `<h6 class="mt-3">رسالة الخطأ</h6><div class="alert alert-danger">${log.error_message}</div>` : ''}
                                </div>
                            </div>
                        `;
                    } else {
                        document.getElementById('logDetailsContent').innerHTML = `
                            <div class="alert alert-danger">حدث خطأ في تحميل تفاصيل السجل</div>
                        `;
                    }
                })
                .catch(error => {
                    document.getElementById('logDetailsContent').innerHTML = `
                        <div class="alert alert-danger">حدث خطأ في الاتصال</div>
                    `;
                });
        }
        
        function exportLogs() {
            const params = new URLSearchParams(window.location.search);
            params.set('export', '1');
            window.location.href = 'export_api_logs.php?' + params.toString();
        }
        
        function clearOldLogs() {
            if (confirm('هل أنت متأكد من حذف السجلات القديمة (أكثر من 30 يوم)؟')) {
                fetch('clear_old_logs.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({action: 'clear_old'})
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('تم حذف السجلات القديمة بنجاح');
                        location.reload();
                    } else {
                        alert('حدث خطأ: ' + data.message);
                    }
                });
            }
        }
        
        function refreshLogs() {
            location.reload();
        }
        
        // Auto refresh every 30 seconds
        setInterval(function() {
            if (document.visibilityState === 'visible') {
                location.reload();
            }
        }, 30000);
    </script>
</body>
</html>
