<?php
require_once '../config/config.php';

if (!isset($_SESSION['admin_id'])) {
    redirect(ADMIN_URL . '/login.php');
}

$db = Database::getInstance()->getConnection();
$message = '';

// Handle backup actions
if ($_POST) {
    if (verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $action = $_POST['action'] ?? '';
        
        if ($action === 'create_backup') {
            $backup_type = $_POST['backup_type'] ?? 'database';
            $backup_manager = new BackupManager();
            
            try {
                $result = $backup_manager->createBackup($backup_type, $_SESSION['admin_id']);
                $message = '<div class="alert alert-success">تم إنشاء النسخة الاحتياطية بنجاح: ' . $result['filename'] . '</div>';
            } catch (Exception $e) {
                $message = '<div class="alert alert-danger">فشل في إنشاء النسخة الاحتياطية: ' . $e->getMessage() . '</div>';
            }
        }
        
        elseif ($action === 'restore_backup') {
            $backup_id = $_POST['backup_id'] ?? 0;
            $backup_manager = new BackupManager();
            
            try {
                $backup_manager->restoreBackup($backup_id);
                $message = '<div class="alert alert-success">تم استعادة النسخة الاحتياطية بنجاح</div>';
            } catch (Exception $e) {
                $message = '<div class="alert alert-danger">فشل في استعادة النسخة الاحتياطية: ' . $e->getMessage() . '</div>';
            }
        }
        
        elseif ($action === 'delete_backup') {
            $backup_id = $_POST['backup_id'] ?? 0;
            $backup_manager = new BackupManager();
            
            try {
                $backup_manager->deleteBackup($backup_id);
                $message = '<div class="alert alert-success">تم حذف النسخة الاحتياطية بنجاح</div>';
            } catch (Exception $e) {
                $message = '<div class="alert alert-danger">فشل في حذف النسخة الاحتياطية: ' . $e->getMessage() . '</div>';
            }
        }
        
        elseif ($action === 'schedule_backup') {
            $schedule_type = $_POST['schedule_type'] ?? 'daily';
            $backup_type = $_POST['backup_type'] ?? 'database';
            $time = $_POST['time'] ?? '02:00';
            
            $stmt = $db->prepare("
                INSERT INTO backup_schedules (type, backup_type, schedule_time, status, admin_id)
                VALUES (?, ?, ?, 'active', ?)
                ON DUPLICATE KEY UPDATE 
                backup_type = VALUES(backup_type),
                schedule_time = VALUES(schedule_time),
                status = 'active',
                updated_at = NOW()
            ");
            $stmt->execute([$schedule_type, $backup_type, $time, $_SESSION['admin_id']]);
            
            $message = '<div class="alert alert-success">تم جدولة النسخ الاحتياطي بنجاح</div>';
        }
    }
}

// Get backups list
$stmt = $db->prepare("
    SELECT b.*, a.username as admin_name
    FROM backups b
    LEFT JOIN admins a ON b.admin_id = a.id
    ORDER BY b.created_at DESC
    LIMIT 50
");
$stmt->execute();
$backups = $stmt->fetchAll();

// Get backup schedules
$stmt = $db->prepare("
    SELECT bs.*, a.username as admin_name
    FROM backup_schedules bs
    LEFT JOIN admins a ON bs.admin_id = a.id
    WHERE bs.status = 'active'
    ORDER BY bs.type, bs.schedule_time
");
$stmt->execute();
$schedules = $stmt->fetchAll();

// Get backup statistics
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_backups,
        SUM(size) as total_size,
        COUNT(CASE WHEN status = 'completed' THEN 1 END) as successful_backups,
        COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_backups,
        COUNT(CASE WHEN DATE(created_at) = CURDATE() THEN 1 END) as today_backups
    FROM backups
");
$stmt->execute();
$stats = $stmt->fetch();

class BackupManager {
    private $db;
    private $backup_dir;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->backup_dir = dirname(__DIR__) . '/backups/';
        
        if (!is_dir($this->backup_dir)) {
            mkdir($this->backup_dir, 0755, true);
        }
    }
    
    public function createBackup($type = 'database', $admin_id = null) {
        $filename = $this->generateBackupFilename($type);
        $filepath = $this->backup_dir . $filename;
        
        // Create backup record
        $stmt = $this->db->prepare("
            INSERT INTO backups (filename, type, status, admin_id)
            VALUES (?, ?, 'pending', ?)
        ");
        $stmt->execute([$filename, $type, $admin_id]);
        $backup_id = $this->db->lastInsertId();
        
        try {
            switch ($type) {
                case 'database':
                    $this->createDatabaseBackup($filepath);
                    break;
                case 'files':
                    $this->createFilesBackup($filepath);
                    break;
                case 'full':
                    $this->createFullBackup($filepath);
                    break;
                default:
                    throw new Exception('Invalid backup type');
            }
            
            $size = filesize($filepath);
            
            // Update backup record
            $stmt = $this->db->prepare("
                UPDATE backups 
                SET status = 'completed', size = ?, completed_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$size, $backup_id]);
            
            return [
                'id' => $backup_id,
                'filename' => $filename,
                'size' => $size,
                'type' => $type
            ];
            
        } catch (Exception $e) {
            // Update backup record as failed
            $stmt = $this->db->prepare("
                UPDATE backups 
                SET status = 'failed', completed_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$backup_id]);
            
            // Clean up partial backup file
            if (file_exists($filepath)) {
                unlink($filepath);
            }
            
            throw $e;
        }
    }
    
    private function createDatabaseBackup($filepath) {
        $config = [
            'host' => DB_HOST,
            'username' => DB_USER,
            'password' => DB_PASS,
            'database' => DB_NAME
        ];
        
        $command = sprintf(
            'mysqldump --host=%s --user=%s --password=%s --single-transaction --routines --triggers %s > %s',
            escapeshellarg($config['host']),
            escapeshellarg($config['username']),
            escapeshellarg($config['password']),
            escapeshellarg($config['database']),
            escapeshellarg($filepath)
        );
        
        $output = [];
        $return_code = 0;
        exec($command, $output, $return_code);
        
        if ($return_code !== 0) {
            throw new Exception('Database backup failed: ' . implode("\n", $output));
        }
        
        // Compress the backup
        $this->compressFile($filepath);
    }
    
    private function createFilesBackup($filepath) {
        $source_dir = dirname(__DIR__);
        $exclude_dirs = ['backups', 'logs', 'cache', 'tmp'];
        
        $zip = new ZipArchive();
        if ($zip->open($filepath, ZipArchive::CREATE) !== TRUE) {
            throw new Exception('Cannot create zip file');
        }
        
        $this->addDirectoryToZip($zip, $source_dir, '', $exclude_dirs);
        $zip->close();
    }
    
    private function createFullBackup($filepath) {
        // Create database backup first
        $db_backup_file = $this->backup_dir . 'temp_db_' . time() . '.sql';
        $this->createDatabaseBackup($db_backup_file);
        
        // Create zip with both database and files
        $zip = new ZipArchive();
        if ($zip->open($filepath, ZipArchive::CREATE) !== TRUE) {
            throw new Exception('Cannot create zip file');
        }
        
        // Add database backup to zip
        $zip->addFile($db_backup_file, 'database.sql');
        
        // Add files
        $source_dir = dirname(__DIR__);
        $exclude_dirs = ['backups', 'logs', 'cache', 'tmp'];
        $this->addDirectoryToZip($zip, $source_dir, 'files/', $exclude_dirs);
        
        $zip->close();
        
        // Clean up temporary database backup
        unlink($db_backup_file);
    }
    
    private function addDirectoryToZip($zip, $source, $prefix = '', $exclude_dirs = []) {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $file) {
            $relative_path = str_replace($source . DIRECTORY_SEPARATOR, '', $file->getPathname());
            
            // Skip excluded directories
            $skip = false;
            foreach ($exclude_dirs as $exclude_dir) {
                if (strpos($relative_path, $exclude_dir . DIRECTORY_SEPARATOR) === 0) {
                    $skip = true;
                    break;
                }
            }
            
            if ($skip) continue;
            
            if ($file->isDir()) {
                $zip->addEmptyDir($prefix . $relative_path);
            } else {
                $zip->addFile($file->getPathname(), $prefix . $relative_path);
            }
        }
    }
    
    private function compressFile($filepath) {
        $compressed_filepath = $filepath . '.gz';
        
        $file_content = file_get_contents($filepath);
        $compressed_content = gzencode($file_content, 9);
        
        file_put_contents($compressed_filepath, $compressed_content);
        unlink($filepath);
        
        // Update filename in database
        $old_filename = basename($filepath);
        $new_filename = basename($compressed_filepath);
        
        $stmt = $this->db->prepare("UPDATE backups SET filename = ? WHERE filename = ?");
        $stmt->execute([$new_filename, $old_filename]);
    }
    
    public function restoreBackup($backup_id) {
        $stmt = $this->db->prepare("SELECT * FROM backups WHERE id = ? AND status = 'completed'");
        $stmt->execute([$backup_id]);
        $backup = $stmt->fetch();
        
        if (!$backup) {
            throw new Exception('Backup not found');
        }
        
        $filepath = $this->backup_dir . $backup['filename'];
        
        if (!file_exists($filepath)) {
            throw new Exception('Backup file not found');
        }
        
        switch ($backup['type']) {
            case 'database':
                $this->restoreDatabaseBackup($filepath);
                break;
            case 'files':
                $this->restoreFilesBackup($filepath);
                break;
            case 'full':
                $this->restoreFullBackup($filepath);
                break;
            default:
                throw new Exception('Invalid backup type');
        }
    }
    
    private function restoreDatabaseBackup($filepath) {
        // Decompress if needed
        if (pathinfo($filepath, PATHINFO_EXTENSION) === 'gz') {
            $decompressed_file = str_replace('.gz', '', $filepath);
            $compressed_content = file_get_contents($filepath);
            $content = gzdecode($compressed_content);
            file_put_contents($decompressed_file, $content);
            $filepath = $decompressed_file;
        }
        
        $config = [
            'host' => DB_HOST,
            'username' => DB_USER,
            'password' => DB_PASS,
            'database' => DB_NAME
        ];
        
        $command = sprintf(
            'mysql --host=%s --user=%s --password=%s %s < %s',
            escapeshellarg($config['host']),
            escapeshellarg($config['username']),
            escapeshellarg($config['password']),
            escapeshellarg($config['database']),
            escapeshellarg($filepath)
        );
        
        $output = [];
        $return_code = 0;
        exec($command, $output, $return_code);
        
        if ($return_code !== 0) {
            throw new Exception('Database restore failed: ' . implode("\n", $output));
        }
        
        // Clean up decompressed file if created
        if (isset($decompressed_file) && file_exists($decompressed_file)) {
            unlink($decompressed_file);
        }
    }
    
    private function restoreFilesBackup($filepath) {
        $zip = new ZipArchive();
        if ($zip->open($filepath) !== TRUE) {
            throw new Exception('Cannot open backup file');
        }
        
        $extract_path = dirname(__DIR__);
        $zip->extractTo($extract_path);
        $zip->close();
    }
    
    private function restoreFullBackup($filepath) {
        $zip = new ZipArchive();
        if ($zip->open($filepath) !== TRUE) {
            throw new Exception('Cannot open backup file');
        }
        
        // Extract database backup
        $temp_db_file = $this->backup_dir . 'temp_restore_' . time() . '.sql';
        $zip->extractTo($this->backup_dir, 'database.sql');
        rename($this->backup_dir . 'database.sql', $temp_db_file);
        
        // Restore database
        $this->restoreDatabaseBackup($temp_db_file);
        
        // Extract files
        $extract_path = dirname(__DIR__);
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $filename = $zip->getNameIndex($i);
            if (strpos($filename, 'files/') === 0) {
                $zip->extractTo($extract_path, $filename);
                // Move from files/ subdirectory to root
                $source = $extract_path . '/' . $filename;
                $destination = $extract_path . '/' . substr($filename, 6); // Remove 'files/' prefix
                if (file_exists($source)) {
                    rename($source, $destination);
                }
            }
        }
        
        $zip->close();
        
        // Clean up
        unlink($temp_db_file);
        $this->removeDirectory($extract_path . '/files');
    }
    
    public function deleteBackup($backup_id) {
        $stmt = $this->db->prepare("SELECT * FROM backups WHERE id = ?");
        $stmt->execute([$backup_id]);
        $backup = $stmt->fetch();
        
        if (!$backup) {
            throw new Exception('Backup not found');
        }
        
        $filepath = $this->backup_dir . $backup['filename'];
        
        if (file_exists($filepath)) {
            unlink($filepath);
        }
        
        $stmt = $this->db->prepare("DELETE FROM backups WHERE id = ?");
        $stmt->execute([$backup_id]);
    }
    
    private function generateBackupFilename($type) {
        $timestamp = date('Y-m-d_H-i-s');
        $site_name = strtolower(str_replace(' ', '_', SITE_NAME));
        
        switch ($type) {
            case 'database':
                return "{$site_name}_database_{$timestamp}.sql";
            case 'files':
                return "{$site_name}_files_{$timestamp}.zip";
            case 'full':
                return "{$site_name}_full_{$timestamp}.zip";
            default:
                return "{$site_name}_backup_{$timestamp}";
        }
    }
    
    private function removeDirectory($dir) {
        if (!is_dir($dir)) return;
        
        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            is_dir($path) ? $this->removeDirectory($path) : unlink($path);
        }
        rmdir($dir);
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نظام النسخ الاحتياطي - فاست ستار</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">
                        <i class="fas fa-database me-2"></i>نظام النسخ الاحتياطي
                    </h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createBackupModal">
                            <i class="fas fa-plus me-2"></i>إنشاء نسخة احتياطية
                        </button>
                    </div>
                </div>
                
                <?= $message ?>
                
                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card bg-primary text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4><?= number_format($stats['total_backups']) ?></h4>
                                        <p class="mb-0">إجمالي النسخ</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-database fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-success text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4><?= number_format($stats['successful_backups']) ?></h4>
                                        <p class="mb-0">نسخ ناجحة</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-check-circle fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-danger text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4><?= number_format($stats['failed_backups']) ?></h4>
                                        <p class="mb-0">نسخ فاشلة</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-times-circle fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-info text-white">
                            <div class="card-body">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h4><?= formatBytes($stats['total_size'] ?? 0) ?></h4>
                                        <p class="mb-0">إجمالي الحجم</p>
                                    </div>
                                    <div class="align-self-center">
                                        <i class="fas fa-hdd fa-2x"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Backup Schedules -->
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-clock me-2"></i>جدولة النسخ الاحتياطي
                        </h5>
                        <button class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#scheduleBackupModal">
                            <i class="fas fa-calendar-plus me-1"></i>إضافة جدولة
                        </button>
                    </div>
                    <div class="card-body">
                        <?php if (empty($schedules)): ?>
                            <div class="text-center text-muted py-4">
                                <i class="fas fa-calendar-times fa-3x mb-3"></i>
                                <p>لا توجد جدولة للنسخ الاحتياطي</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>النوع</th>
                                            <th>نوع النسخة</th>
                                            <th>الوقت</th>
                                            <th>آخر تشغيل</th>
                                            <th>المسؤول</th>
                                            <th>الحالة</th>
                                            <th>الإجراءات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($schedules as $schedule): ?>
                                            <tr>
                                                <td>
                                                    <span class="badge bg-info">
                                                        <?= $schedule['type'] === 'daily' ? 'يومي' : ($schedule['type'] === 'weekly' ? 'أسبوعي' : 'شهري') ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-secondary">
                                                        <?= $schedule['backup_type'] === 'database' ? 'قاعدة البيانات' : ($schedule['backup_type'] === 'files' ? 'الملفات' : 'كامل') ?>
                                                    </span>
                                                </td>
                                                <td><?= date('H:i', strtotime($schedule['schedule_time'])) ?></td>
                                                <td>
                                                    <?= $schedule['last_run'] ? date('Y-m-d H:i', strtotime($schedule['last_run'])) : 'لم يتم التشغيل' ?>
                                                </td>
                                                <td><?= htmlspecialchars($schedule['admin_name'] ?? 'غير محدد') ?></td>
                                                <td>
                                                    <span class="badge bg-<?= $schedule['status'] === 'active' ? 'success' : 'secondary' ?>">
                                                        <?= $schedule['status'] === 'active' ? 'نشط' : 'غير نشط' ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <button class="btn btn-sm btn-outline-danger" onclick="deleteSchedule(<?= $schedule['id'] ?>)">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Backups List -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-list me-2"></i>قائمة النسخ الاحتياطية
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($backups)): ?>
                            <div class="text-center text-muted py-4">
                                <i class="fas fa-database fa-3x mb-3"></i>
                                <p>لا توجد نسخ احتياطية</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>اسم الملف</th>
                                            <th>النوع</th>
                                            <th>الحجم</th>
                                            <th>الحالة</th>
                                            <th>تاريخ الإنشاء</th>
                                            <th>المسؤول</th>
                                            <th>الإجراءات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($backups as $backup): ?>
                                            <tr>
                                                <td>
                                                    <i class="fas fa-file-archive me-2"></i>
                                                    <?= htmlspecialchars($backup['filename']) ?>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?= $backup['type'] === 'database' ? 'primary' : ($backup['type'] === 'files' ? 'info' : 'success') ?>">
                                                        <?= $backup['type'] === 'database' ? 'قاعدة البيانات' : ($backup['type'] === 'files' ? 'الملفات' : 'كامل') ?>
                                                    </span>
                                                </td>
                                                <td><?= $backup['size'] ? formatBytes($backup['size']) : '-' ?></td>
                                                <td>
                                                    <span class="badge bg-<?= $backup['status'] === 'completed' ? 'success' : ($backup['status'] === 'failed' ? 'danger' : 'warning') ?>">
                                                        <?= $backup['status'] === 'completed' ? 'مكتمل' : ($backup['status'] === 'failed' ? 'فاشل' : 'معلق') ?>
                                                    </span>
                                                </td>
                                                <td><?= date('Y-m-d H:i', strtotime($backup['created_at'])) ?></td>
                                                <td><?= htmlspecialchars($backup['admin_name'] ?? 'النظام') ?></td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <?php if ($backup['status'] === 'completed'): ?>
                                                            <button class="btn btn-outline-success" onclick="downloadBackup('<?= $backup['filename'] ?>')" title="تحميل">
                                                                <i class="fas fa-download"></i>
                                                            </button>
                                                            <button class="btn btn-outline-warning" onclick="restoreBackup(<?= $backup['id'] ?>)" title="استعادة">
                                                                <i class="fas fa-undo"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                        <button class="btn btn-outline-danger" onclick="deleteBackup(<?= $backup['id'] ?>)" title="حذف">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <!-- Create Backup Modal -->
    <div class="modal fade" id="createBackupModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إنشاء نسخة احتياطية جديدة</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                        <input type="hidden" name="action" value="create_backup">
                        
                        <div class="mb-3">
                            <label class="form-label">نوع النسخة الاحتياطية</label>
                            <select name="backup_type" class="form-select" required>
                                <option value="database">قاعدة البيانات فقط</option>
                                <option value="files">الملفات فقط</option>
                                <option value="full">نسخة كاملة (قاعدة البيانات + الملفات)</option>
                            </select>
                            <div class="form-text">
                                <small>
                                    <strong>قاعدة البيانات:</strong> جميع البيانات والجداول<br>
                                    <strong>الملفات:</strong> جميع ملفات الموقع والصور<br>
                                    <strong>نسخة كاملة:</strong> قاعدة البيانات + الملفات (الأكثر أماناً)
                                </small>
                            </div>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            <strong>ملاحظة:</strong> قد تستغرق عملية إنشاء النسخة الاحتياطية بعض الوقت حسب حجم البيانات.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-database me-2"></i>إنشاء النسخة الاحتياطية
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Schedule Backup Modal -->
    <div class="modal fade" id="scheduleBackupModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">جدولة النسخ الاحتياطي</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                        <input type="hidden" name="action" value="schedule_backup">
                        
                        <div class="mb-3">
                            <label class="form-label">نوع الجدولة</label>
                            <select name="schedule_type" class="form-select" required>
                                <option value="daily">يومي</option>
                                <option value="weekly">أسبوعي</option>
                                <option value="monthly">شهري</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">نوع النسخة الاحتياطية</label>
                            <select name="backup_type" class="form-select" required>
                                <option value="database">قاعدة البيانات فقط</option>
                                <option value="files">الملفات فقط</option>
                                <option value="full">نسخة كاملة</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">وقت التنفيذ</label>
                            <input type="time" name="time" class="form-control" value="02:00" required>
                            <div class="form-text">يُنصح بتحديد وقت خلال ساعات قليلة الاستخدام</div>
                        </div>
                        
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>تنبيه:</strong> تأكد من إعداد Cron Job على الخادم لتنفيذ الجدولة التلقائية.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-calendar-plus me-2"></i>حفظ الجدولة
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function downloadBackup(filename) {
            window.location.href = 'download_backup.php?file=' + encodeURIComponent(filename);
        }
        
        function restoreBackup(backupId) {
            if (confirm('هل أنت متأكد من استعادة هذه النسخة الاحتياطية؟\n\nتحذير: سيتم استبدال البيانات الحالية!')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                    <input type="hidden" name="action" value="restore_backup">
                    <input type="hidden" name="backup_id" value="${backupId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function deleteBackup(backupId) {
            if (confirm('هل أنت متأكد من حذف هذه النسخة الاحتياطية؟\n\nلا يمكن التراجع عن هذا الإجراء!')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                    <input type="hidden" name="action" value="delete_backup">
                    <input type="hidden" name="backup_id" value="${backupId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        function deleteSchedule(scheduleId) {
            if (confirm('هل أنت متأكد من حذف هذه الجدولة؟')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                    <input type="hidden" name="action" value="delete_schedule">
                    <input type="hidden" name="schedule_id" value="${scheduleId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Auto refresh backup status every 30 seconds
        setInterval(function() {
            const pendingBackups = document.querySelectorAll('.badge:contains("معلق")');
            if (pendingBackups.length > 0) {
                location.reload();
            }
        }, 30000);
    </script>
</body>
</html>

<?php
function formatBytes($size, $precision = 2) {
    if ($size == 0) return '0 B';
    $base = log($size, 1024);
    $suffixes = array('B', 'KB', 'MB', 'GB', 'TB');
    return round(pow(1024, $base - floor($base)), $precision) . ' ' . $suffixes[floor($base)];
}
?>
