<?php
require_once '../config/config.php';

if (!isAdminLoggedIn()) {
    redirect('login.php');
}

$db = Database::getInstance()->getConnection();
$success = '';
$error = '';

// معالجة إضافة/تعديل الفئة
if ($_POST) {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add' || $action === 'edit') {
        $category_id = $_POST['category_id'] ?? 0;
        $name = trim($_POST['name'] ?? '');
        $name_ar = trim($_POST['name_ar'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $icon = trim($_POST['icon'] ?? 'gamepad');
        $status = $_POST['status'] ?? 'active';
        
        if (empty($name) || empty($name_ar)) {
            $error = 'يرجى ملء جميع الحقول المطلوبة';
        } else {
            if ($action === 'add') {
                $stmt = $db->prepare("INSERT INTO categories (name, name_ar, description, icon, status) VALUES (?, ?, ?, ?, ?)");
                if ($stmt->execute([$name, $name_ar, $description, $icon, $status])) {
                    $success = 'تم إضافة الفئة بنجاح';
                } else {
                    $error = 'حدث خطأ أثناء إضافة الفئة';
                }
            } else {
                $stmt = $db->prepare("UPDATE categories SET name = ?, name_ar = ?, description = ?, icon = ?, status = ? WHERE id = ?");
                if ($stmt->execute([$name, $name_ar, $description, $icon, $status, $category_id])) {
                    $success = 'تم تحديث الفئة بنجاح';
                } else {
                    $error = 'حدث خطأ أثناء تحديث الفئة';
                }
            }
        }
    }
    
    if ($action === 'delete') {
        $category_id = $_POST['category_id'] ?? 0;
        // التحقق من وجود منتجات في هذه الفئة
        $stmt = $db->prepare("SELECT COUNT(*) FROM products WHERE category_id = ?");
        $stmt->execute([$category_id]);
        $product_count = $stmt->fetchColumn();
        
        if ($product_count > 0) {
            $error = 'لا يمكن حذف هذه الفئة لأنها تحتوي على منتجات';
        } else {
            $stmt = $db->prepare("DELETE FROM categories WHERE id = ?");
            if ($stmt->execute([$category_id])) {
                $success = 'تم حذف الفئة بنجاح';
            } else {
                $error = 'حدث خطأ أثناء حذف الفئة';
            }
        }
    }
}

// جلب الفئات
$stmt = $db->query("SELECT c.*, COUNT(p.id) as product_count FROM categories c LEFT JOIN products p ON c.id = p.category_id GROUP BY c.id ORDER BY c.created_at DESC");
$categories = $stmt->fetchAll();

// جلب فئة للتعديل
$edit_category = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_category = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الفئات - <?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .navbar { background: linear-gradient(45deg, #f39c12, #e67e22); }
        .card { border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-star me-2"></i>لوحة تحكم <?= SITE_NAME ?>
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php"><i class="fas fa-home me-1"></i>الرئيسية</a>
                <a class="nav-link" href="products.php"><i class="fas fa-box me-1"></i>المنتجات</a>
                <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i>خروج</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle me-2"></i><?= $success ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <!-- نموذج إضافة/تعديل الفئة -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-plus me-2"></i><?= $edit_category ? 'تعديل الفئة' : 'إضافة فئة جديدة' ?></h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="<?= $edit_category ? 'edit' : 'add' ?>">
                            <?php if ($edit_category): ?>
                                <input type="hidden" name="category_id" value="<?= $edit_category['id'] ?>">
                            <?php endif; ?>
                            
                            <div class="mb-3">
                                <label class="form-label">الاسم (إنجليزي) *</label>
                                <input type="text" name="name" class="form-control" required value="<?= htmlspecialchars($edit_category['name'] ?? '') ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">الاسم (عربي) *</label>
                                <input type="text" name="name_ar" class="form-control" required value="<?= htmlspecialchars($edit_category['name_ar'] ?? '') ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">الوصف</label>
                                <textarea name="description" class="form-control" rows="3"><?= htmlspecialchars($edit_category['description'] ?? '') ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">الأيقونة</label>
                                <select name="icon" class="form-select">
                                    <option value="gamepad" <?= ($edit_category && $edit_category['icon'] === 'gamepad') ? 'selected' : '' ?>>🎮 gamepad</option>
                                    <option value="mobile-alt" <?= ($edit_category && $edit_category['icon'] === 'mobile-alt') ? 'selected' : '' ?>>📱 mobile-alt</option>
                                    <option value="comments" <?= ($edit_category && $edit_category['icon'] === 'comments') ? 'selected' : '' ?>>💬 comments</option>
                                    <option value="music" <?= ($edit_category && $edit_category['icon'] === 'music') ? 'selected' : '' ?>>🎵 music</option>
                                    <option value="video" <?= ($edit_category && $edit_category['icon'] === 'video') ? 'selected' : '' ?>>🎥 video</option>
                                    <option value="shopping-cart" <?= ($edit_category && $edit_category['icon'] === 'shopping-cart') ? 'selected' : '' ?>>🛒 shopping-cart</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">الحالة</label>
                                <select name="status" class="form-select">
                                    <option value="active" <?= ($edit_category && $edit_category['status'] === 'active') ? 'selected' : '' ?>>نشط</option>
                                    <option value="inactive" <?= ($edit_category && $edit_category['status'] === 'inactive') ? 'selected' : '' ?>>غير نشط</option>
                                </select>
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-save me-2"></i><?= $edit_category ? 'تحديث' : 'إضافة' ?>
                            </button>
                            
                            <?php if ($edit_category): ?>
                                <a href="categories.php" class="btn btn-secondary w-100 mt-2">إلغاء</a>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- قائمة الفئات -->
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5><i class="fas fa-tags me-2"></i>الفئات</h5>
                        <span class="badge bg-primary"><?= count($categories) ?> فئة</span>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>الأيقونة</th>
                                        <th>الاسم</th>
                                        <th>الوصف</th>
                                        <th>المنتجات</th>
                                        <th>الحالة</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($categories as $category): ?>
                                    <tr>
                                        <td><?= $category['id'] ?></td>
                                        <td><i class="fas fa-<?= $category['icon'] ?> fa-2x text-primary"></i></td>
                                        <td>
                                            <strong><?= htmlspecialchars($category['name_ar']) ?></strong><br>
                                            <small class="text-muted"><?= htmlspecialchars($category['name']) ?></small>
                                        </td>
                                        <td><?= htmlspecialchars($category['description']) ?></td>
                                        <td><span class="badge bg-info"><?= $category['product_count'] ?></span></td>
                                        <td>
                                            <span class="badge bg-<?= $category['status'] === 'active' ? 'success' : 'warning' ?>">
                                                <?= $category['status'] === 'active' ? 'نشط' : 'غير نشط' ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="?edit=<?= $category['id'] ?>" class="btn btn-outline-primary" title="تعديل">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <?php if ($category['product_count'] == 0): ?>
                                                <form method="POST" style="display: inline;" onsubmit="return confirm('هل أنت متأكد من حذف هذه الفئة؟')">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="category_id" value="<?= $category['id'] ?>">
                                                    <button type="submit" class="btn btn-outline-danger" title="حذف">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
