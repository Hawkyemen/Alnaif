<?php
require_once '../config/config.php';

if (!isAdmin()) {
    redirect('login.php');
}

$message = '';
$error = '';

// إضافة API جديد
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_api'])) {
    try {
        $name = sanitize($_POST['name']);
        $code = sanitize($_POST['code']);
        $url = sanitize($_POST['url']);
        $api_key = sanitize($_POST['api_key']);
        $secret_key = sanitize($_POST['secret_key']);
        $method = sanitize($_POST['method']);
        $timeout = (int)$_POST['timeout'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        $config = json_encode([
            'url' => $url,
            'api_key' => $api_key,
            'secret_key' => $secret_key,
            'method' => $method,
            'timeout' => $timeout
        ]);
        
        $stmt = $pdo->prepare("
            INSERT INTO charging_apis (name, code, config, is_active) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$name, $code, $config, $is_active]);
        
        $message = 'تم إضافة API الشحن بنجاح';
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// تحديث API
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_api'])) {
    try {
        $id = (int)$_POST['api_id'];
        $name = sanitize($_POST['name']);
        $url = sanitize($_POST['url']);
        $api_key = sanitize($_POST['api_key']);
        $secret_key = sanitize($_POST['secret_key']);
        $method = sanitize($_POST['method']);
        $timeout = (int)$_POST['timeout'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        $config = json_encode([
            'url' => $url,
            'api_key' => $api_key,
            'secret_key' => $secret_key,
            'method' => $method,
            'timeout' => $timeout
        ]);
        
        $stmt = $pdo->prepare("
            UPDATE charging_apis 
            SET name = ?, config = ?, is_active = ?, updated_at = NOW() 
            WHERE id = ?
        ");
        $stmt->execute([$name, $config, $is_active, $id]);
        
        $message = 'تم تحديث API الشحن بنجاح';
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// حذف API
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    try {
        $id = (int)$_GET['delete'];
        $stmt = $pdo->prepare("DELETE FROM charging_apis WHERE id = ?");
        $stmt->execute([$id]);
        
        $message = 'تم حذف API الشحن بنجاح';
    } catch (Exception $e) {
        $error = 'لا يمكن حذف API الشحن. قد يكون مرتبط بمنتجات موجودة';
    }
}

// جلب APIs الشحن
$stmt = $pdo->query("SELECT * FROM charging_apis ORDER BY name");
$apis = $stmt->fetchAll();

// إنشاء APIs افتراضية إذا لم تكن موجودة
if (empty($apis)) {
    $default_apis = [
        [
            'name' => 'PUBG Mobile API',
            'code' => 'pubg',
            'config' => json_encode([
                'url' => 'https://api.pubgmobile.com/charge',
                'api_key' => '',
                'secret_key' => '',
                'method' => 'POST',
                'timeout' => 30
            ])
        ],
        [
            'name' => 'Free Fire API',
            'code' => 'freefire',
            'config' => json_encode([
                'url' => 'https://api.freefire.com/topup',
                'api_key' => '',
                'secret_key' => '',
                'method' => 'POST',
                'timeout' => 30
            ])
        ],
        [
            'name' => 'Bigo Live API',
            'code' => 'bigo',
            'config' => json_encode([
                'url' => 'https://api.bigo.tv/recharge',
                'api_key' => '',
                'secret_key' => '',
                'method' => 'POST',
                'timeout' => 30
            ])
        ],
        [
            'name' => 'TikTok API',
            'code' => 'tiktok',
            'config' => json_encode([
                'url' => 'https://api.tiktok.com/coins',
                'api_key' => '',
                'secret_key' => '',
                'method' => 'POST',
                'timeout' => 30
            ])
        ]
    ];
    
    foreach ($default_apis as $api) {
        $stmt = $pdo->prepare("
            INSERT INTO charging_apis (name, code, config, is_active) 
            VALUES (?, ?, ?, 0)
        ");
        $stmt->execute([$api['name'], $api['code'], $api['config']]);
    }
    
    // إعادة جلب APIs
    $stmt = $pdo->query("SELECT * FROM charging_apis ORDER BY name");
    $apis = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة APIs الشحن - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">إدارة APIs الشحن</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addApiModal">
                            <i class="fas fa-plus me-2"></i>إضافة API جديد
                        </button>
                    </div>
                </div>

                <?php if ($message): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- جدول APIs الشحن -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>اسم API</th>
                                        <th>الكود</th>
                                        <th>الرابط</th>
                                        <th>الطريقة</th>
                                        <th>المهلة الزمنية</th>
                                        <th>الحالة</th>
                                        <th>آخر تحديث</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($apis as $api): ?>
                                    <?php $config = json_decode($api['config'], true); ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold"><?php echo htmlspecialchars($api['name']); ?></div>
                                        </td>
                                        <td><code><?php echo htmlspecialchars($api['code']); ?></code></td>
                                        <td>
                                            <small class="text-muted">
                                                <?php echo htmlspecialchars(substr($config['url'] ?? '', 0, 50)); ?>...
                                            </small>
                                        </td>
                                        <td>
                                            <span class="badge bg-info">
                                                <?php echo htmlspecialchars($config['method'] ?? 'POST'); ?>
                                            </span>
                                        </td>
                                        <td><?php echo ($config['timeout'] ?? 30); ?>s</td>
                                        <td>
                                            <span class="badge bg-<?php echo $api['is_active'] ? 'success' : 'secondary'; ?>">
                                                <?php echo $api['is_active'] ? 'مفعل' : 'معطل'; ?>
                                            </span>
                                        </td>
                                        <td><?php echo $api['updated_at'] ? date('Y-m-d H:i', strtotime($api['updated_at'])) : 'لم يحدث'; ?></td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <button type="button" class="btn btn-outline-primary" 
                                                        onclick="editApi(<?php echo htmlspecialchars(json_encode($api)); ?>)">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button type="button" class="btn btn-outline-success" 
                                                        onclick="testApi(<?php echo $api['id']; ?>)">
                                                    <i class="fas fa-vial"></i>
                                                </button>
                                                <a href="?delete=<?php echo $api['id']; ?>" 
                                                   class="btn btn-outline-danger"
                                                   onclick="return confirm('هل أنت متأكد من حذف هذا API؟')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- مودال إضافة API -->
    <div class="modal fade" id="addApiModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إضافة API شحن جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="name" class="form-label">اسم API *</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="code" class="form-label">كود API *</label>
                                <input type="text" class="form-control" id="code" name="code" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="url" class="form-label">رابط API *</label>
                            <input type="url" class="form-control" id="url" name="url" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="api_key" class="form-label">API Key</label>
                                <input type="text" class="form-control" id="api_key" name="api_key">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="secret_key" class="form-label">Secret Key</label>
                                <input type="password" class="form-control" id="secret_key" name="secret_key">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="method" class="form-label">طريقة الطلب</label>
                                <select class="form-select" id="method" name="method">
                                    <option value="POST">POST</option>
                                    <option value="GET">GET</option>
                                    <option value="PUT">PUT</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="timeout" class="form-label">المهلة الزمنية (ثانية)</label>
                                <input type="number" class="form-control" id="timeout" name="timeout" value="30" min="5" max="120">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_active" name="is_active">
                                <label class="form-check-label" for="is_active">
                                    تفعيل API
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" name="add_api" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>حفظ API
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- مودال تعديل API -->
    <div class="modal fade" id="editApiModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تعديل API الشحن</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="editApiForm">
                    <input type="hidden" id="edit_api_id" name="api_id">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_name" class="form-label">اسم API *</label>
                                <input type="text" class="form-control" id="edit_name" name="name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_code" class="form-label">كود API *</label>
                                <input type="text" class="form-control" id="edit_code" name="code" readonly>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_url" class="form-label">رابط API *</label>
                            <input type="url" class="form-control" id="edit_url" name="url" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_api_key" class="form-label">API Key</label>
                                <input type="text" class="form-control" id="edit_api_key" name="api_key">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_secret_key" class="form-label">Secret Key</label>
                                <input type="password" class="form-control" id="edit_secret_key" name="secret_key">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_method" class="form-label">طريقة الطلب</label>
                                <select class="form-select" id="edit_method" name="method">
                                    <option value="POST">POST</option>
                                    <option value="GET">GET</option>
                                    <option value="PUT">PUT</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_timeout" class="form-label">المهلة الزمنية (ثانية)</label>
                                <input type="number" class="form-control" id="edit_timeout" name="timeout" min="5" max="120">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="edit_is_active" name="is_active">
                                <label class="form-check-label" for="edit_is_active">
                                    تفعيل API
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" name="update_api" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>حفظ التغييرات
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editApi(api) {
            const config = JSON.parse(api.config);
            
            document.getElementById('edit_api_id').value = api.id;
            document.getElementById('edit_name').value = api.name;
            document.getElementById('edit_code').value = api.code;
            document.getElementById('edit_url').value = config.url || '';
            document.getElementById('edit_api_key').value = config.api_key || '';
            document.getElementById('edit_secret_key').value = config.secret_key || '';
            document.getElementById('edit_method').value = config.method || 'POST';
            document.getElementById('edit_timeout').value = config.timeout || 30;
            document.getElementById('edit_is_active').checked = api.is_active == 1;
            
            new bootstrap.Modal(document.getElementById('editApiModal')).show();
        }

        function testApi(apiId) {
            if (confirm('هل تريد اختبار هذا API؟')) {
                fetch('test_api.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `api_id=${apiId}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('نجح الاختبار: ' + data.message);
                    } else {
                        alert('فشل الاختبار: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('خطأ في الاختبار: ' + error.message);
                });
            }
        }
    </script>
</body>
</html>
