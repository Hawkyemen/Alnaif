<?php
// ملف إنشاء مدير جديد
require_once '../config/config.php';

echo "<h2>إنشاء مدير جديد - فاست ستار</h2>";

try {
    $db = Database::getInstance()->getConnection();
    
    // حذف المدير القديم
    $stmt = $db->prepare("DELETE FROM admin_users WHERE username = 'admin'");
    $stmt->execute();
    echo "<p style='color: orange;'>🗑️ تم حذف المدير القديم</p>";
    
    // إنشاء كلمة مرور جديدة
    $username = 'admin';
    $password = 'faststar2024';
    $email = 'admin@faststarone.com';
    $full_name = 'مدير النظام';
    $role = 'super_admin';
    
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // إدراج المدير الجديد
    $stmt = $db->prepare("INSERT INTO admin_users (username, password, email, full_name, role, status) VALUES (?, ?, ?, ?, ?, 'active')");
    $result = $stmt->execute([$username, $hashed_password, $email, $full_name, $role]);
    
    if ($result) {
        echo "<div style='background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0;'>";
        echo "<h3>✅ تم إنشاء المدير بنجاح!</h3>";
        echo "<p><strong>اسم المستخدم:</strong> $username</p>";
        echo "<p><strong>كلمة المرور:</strong> $password</p>";
        echo "<p><strong>البريد الإلكتروني:</strong> $email</p>";
        echo "<p><strong>الدور:</strong> $role</p>";
        echo "</div>";
        
        // اختبار تسجيل الدخول
        echo "<h3>اختبار تسجيل الدخول:</h3>";
        if (password_verify($password, $hashed_password)) {
            echo "<p style='color: green;'>✅ كلمة المرور تعمل بشكل صحيح</p>";
        } else {
            echo "<p style='color: red;'>❌ مشكلة في كلمة المرور</p>";
        }
        
        echo "<p><a href='login.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>انتقل إلى صفحة تسجيل الدخول</a></p>";
        
    } else {
        echo "<p style='color: red;'>❌ فشل في إنشاء المدير</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ خطأ: " . $e->getMessage() . "</p>";
}
?>
