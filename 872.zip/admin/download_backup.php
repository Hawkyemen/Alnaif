<?php
session_start();
require_once '../config/config.php';

// Check admin authentication
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['file']) || empty($_GET['file'])) {
    die('ملف غير محدد');
}

$filename = basename($_GET['file']);
$backup_dir = '../backups/';
$file_path = $backup_dir . $filename;

// Security check - ensure file exists and is in backup directory
if (!file_exists($file_path) || !is_file($file_path)) {
    die('الملف غير موجود');
}

// Verify file is actually a backup file
if (!preg_match('/^backup_\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}\.(sql|zip|tar\.gz)$/', $filename)) {
    die('نوع ملف غير مسموح');
}

// Log download activity
$db = Database::getInstance()->getConnection();
$stmt = $db->prepare("
    INSERT INTO backup_logs (backup_id, action, status, admin_id, details)
    SELECT b.id, 'download', 'completed', ?, CONCAT('Downloaded by admin: ', a.username)
    FROM backups b, admins a
    WHERE b.filename = ? AND a.id = ?
");
$stmt->execute([$_SESSION['admin_id'], $filename, $_SESSION['admin_id']]);

// Set headers for file download
$file_size = filesize($file_path);
$file_extension = pathinfo($filename, PATHINFO_EXTENSION);

// Determine content type
$content_types = [
    'sql' => 'application/sql',
    'zip' => 'application/zip',
    'gz' => 'application/gzip',
    'tar' => 'application/x-tar'
];

$content_type = $content_types[$file_extension] ?? 'application/octet-stream';

// Clear any previous output
if (ob_get_level()) {
    ob_end_clean();
}

// Set download headers
header('Content-Type: ' . $content_type);
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . $file_size);
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Prevent timeout for large files
set_time_limit(0);

// Read and output file in chunks to handle large files
$handle = fopen($file_path, 'rb');
if ($handle === false) {
    die('خطأ في قراءة الملف');
}

while (!feof($handle)) {
    $chunk = fread($handle, 8192); // 8KB chunks
    echo $chunk;
    
    // Flush output to browser
    if (ob_get_level()) {
        ob_flush();
    }
    flush();
}

fclose($handle);
exit;
?>
