<?php
$admin = getCurrentAdmin();
$notifications_count = 0;

// جلب عدد الإشعارات غير المقروءة
try {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM notifications WHERE admin_id IS NULL AND is_global = 1 AND is_read = 0");
    $result = $stmt->fetch();
    $notifications_count = $result['count'];
} catch (PDOException $e) {
    logError("Header notifications error: " . $e->getMessage());
}
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="dashboard.php">
            <i class="fas fa-star me-2"></i>
            <?php echo SITE_NAME; ?> - لوحة التحكم
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">
                        <i class="fas fa-home me-1"></i>الرئيسية
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="ordersDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-shopping-cart me-1"></i>الطلبات
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="orders.php">جميع الطلبات</a></li>
                        <li><a class="dropdown-item" href="orders.php?status=pending">طلبات معلقة</a></li>
                        <li><a class="dropdown-item" href="orders.php?status=processing">قيد المعالجة</a></li>
                        <li><a class="dropdown-item" href="orders.php?status=completed">مكتملة</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="productsDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-box me-1"></i>المنتجات
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="products.php">إدارة المنتجات</a></li>
                        <li><a class="dropdown-item" href="categories.php">الفئات</a></li>
                        <li><a class="dropdown-item" href="charging_apis.php">APIs الشحن</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="users.php">
                        <i class="fas fa-users me-1"></i>المستخدمين
                    </a>
                </li>
            </ul>
            
            <ul class="navbar-nav">
                <!-- الإشعارات -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle position-relative" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-bell"></i>
                        <?php if ($notifications_count > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                <?php echo $notifications_count; ?>
                            </span>
                        <?php endif; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" style="width: 300px;">
                        <li><h6 class="dropdown-header">الإشعارات</h6></li>
                        <li><hr class="dropdown-divider"></li>
                        <?php if ($notifications_count > 0): ?>
                            <li><a class="dropdown-item" href="notifications.php">عرض جميع الإشعارات</a></li>
                        <?php else: ?>
                            <li><span class="dropdown-item-text text-muted">لا توجد إشعارات جديدة</span></li>
                        <?php endif; ?>
                    </ul>
                </li>
                
                <!-- ملف المدير -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="adminDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i>
                        <?php echo htmlspecialchars($admin['full_name']); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="profile.php">
                            <i class="fas fa-user me-2"></i>الملف الشخصي
                        </a></li>
                        <li><a class="dropdown-item" href="settings.php">
                            <i class="fas fa-cog me-2"></i>الإعدادات
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="../index.php" target="_blank">
                            <i class="fas fa-external-link-alt me-2"></i>عرض الموقع
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>تسجيل الخروج
                        </a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<style>
    body {
        padding-top: 56px;
    }
    
    .navbar-brand {
        font-weight: bold;
    }
    
    .dropdown-menu {
        border: none;
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    }
    
    .dropdown-item:hover {
        background-color: #f8f9fa;
    }
    
    .badge {
        font-size: 0.6em;
    }
</style>
