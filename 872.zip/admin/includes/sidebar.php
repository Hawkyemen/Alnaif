<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>

<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php">
                    <i class="fas fa-home me-2"></i>
                    لوحة التحكم
                </a>
            </li>
            
            <li class="nav-item">
                <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                    <span>إدارة المحتوى</span>
                </h6>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'categories.php' ? 'active' : ''; ?>" href="categories.php">
                    <i class="fas fa-tags me-2"></i>
                    الفئات
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'products.php' ? 'active' : ''; ?>" href="products.php">
                    <i class="fas fa-box me-2"></i>
                    المنتجات
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'charging_apis.php' ? 'active' : ''; ?>" href="charging_apis.php">
                    <i class="fas fa-plug me-2"></i>
                    APIs الشحن
                </a>
            </li>
            
            <li class="nav-item">
                <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                    <span>إدارة الطلبات</span>
                </h6>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'orders.php' ? 'active' : ''; ?>" href="orders.php">
                    <i class="fas fa-shopping-cart me-2"></i>
                    الطلبات
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'wallet_transactions.php' ? 'active' : ''; ?>" href="wallet_transactions.php">
                    <i class="fas fa-wallet me-2"></i>
                    معاملات المحفظة
                </a>
            </li>
            
            <li class="nav-item">
                <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                    <span>إدارة المستخدمين</span>
                </h6>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'users.php' ? 'active' : ''; ?>" href="users.php">
                    <i class="fas fa-users me-2"></i>
                    المستخدمين
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'support_tickets.php' ? 'active' : ''; ?>" href="support_tickets.php">
                    <i class="fas fa-headset me-2"></i>
                    تذاكر الدعم
                </a>
            </li>
            
            <li class="nav-item">
                <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                    <span>التقارير والإحصائيات</span>
                </h6>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'reports.php' ? 'active' : ''; ?>" href="reports.php">
                    <i class="fas fa-chart-bar me-2"></i>
                    التقارير
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'analytics.php' ? 'active' : ''; ?>" href="analytics.php">
                    <i class="fas fa-analytics me-2"></i>
                    التحليلات
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'api_logs.php' ? 'active' : ''; ?>" href="api_logs.php">
                    <i class="fas fa-code me-2"></i>
                    سجل API
                </a>
            </li>
            
            <li class="nav-item">
                <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                    <span>النظام</span>
                </h6>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'settings.php' ? 'active' : ''; ?>" href="settings.php">
                    <i class="fas fa-cog me-2"></i>
                    إعدادات النظام
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'security_settings.php' ? 'active' : ''; ?>" href="security_settings.php">
                    <i class="fas fa-shield-alt me-2"></i>
                    إعدادات الأمان
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'payment_gateways.php' ? 'active' : ''; ?>" href="payment_gateways.php">
                    <i class="fas fa-credit-card me-2"></i>
                    بوابات الدفع
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'backup_system.php' ? 'active' : ''; ?>" href="backup_system.php">
                    <i class="fas fa-database me-2"></i>
                    النسخ الاحتياطي
                </a>
            </li>
            
            <?php if ($admin['role'] == 'super_admin'): ?>
            <li class="nav-item">
                <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                    <span>إدارة المديرين</span>
                </h6>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'admin_users.php' ? 'active' : ''; ?>" href="admin_users.php">
                    <i class="fas fa-user-shield me-2"></i>
                    المديرين
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo $current_page == 'system_logs.php' ? 'active' : ''; ?>" href="system_logs.php">
                    <i class="fas fa-file-alt me-2"></i>
                    سجلات النظام
                </a>
            </li>
            <?php endif; ?>
        </ul>
        
        <div class="mt-4 px-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h6 class="card-title">
                        <i class="fas fa-info-circle me-2"></i>
                        معلومات النظام
                    </h6>
                    <p class="card-text small">
                        الإصدار: 1.0.0<br>
                        آخر تحديث: <?php echo date('Y-m-d'); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</nav>

<style>
    .sidebar {
        position: fixed;
        top: 56px;
        bottom: 0;
        left: 0;
        z-index: 100;
        padding: 0;
        box-shadow: inset -1px 0 0 rgba(0, 0, 0, .1);
        overflow-y: auto;
    }

    .sidebar-heading {
        font-size: .75rem;
        text-transform: uppercase;
    }

    .sidebar .nav-link {
        font-weight: 500;
        color: #333;
        padding: 0.75rem 1rem;
        border-radius: 0;
        transition: all 0.3s ease;
    }

    .sidebar .nav-link:hover {
        color: #007bff;
        background-color: rgba(0, 123, 255, 0.1);
    }

    .sidebar .nav-link.active {
        color: #007bff;
        background-color: rgba(0, 123, 255, 0.1);
        border-right: 3px solid #007bff;
    }

    .sidebar .nav-link i {
        width: 16px;
        text-align: center;
    }

    @media (max-width: 767.98px) {
        .sidebar {
            top: 56px;
        }
    }
</style>
