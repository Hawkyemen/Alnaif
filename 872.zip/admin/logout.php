<?php
require_once '../config/config.php';

// تسجيل النشاط قبل تسجيل الخروج
if (isAdminLoggedIn()) {
    $admin = getCurrentAdmin();
    if ($admin) {
        logActivity($admin['id'], 'admin_logout', 'تسجيل خروج المدير');
    }
}

// إنهاء الجلسة
session_destroy();

// إعادة التوجيه
redirect('login.php');
?>
