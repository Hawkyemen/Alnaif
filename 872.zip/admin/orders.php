<?php
require_once '../config/config.php';

if (!isset($_SESSION['admin_id'])) {
    redirect(ADMIN_URL . '/login.php');
}

$db = Database::getInstance()->getConnection();
$message = '';

// Handle status updates
if ($_POST && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    if (verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $order_id = (int)($_POST['order_id'] ?? 0);
        $status = $_POST['status'] ?? '';
        
        if ($order_id && in_array($status, ['pending', 'processing', 'completed', 'failed', 'cancelled'])) {
            $stmt = $db->prepare("UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?");
            if ($stmt->execute([$status, $order_id])) {
                $message = '<div class="alert alert-success">تم تحديث حالة الطلب بنجاح</div>';
                
                // If order is completed, trigger charging
                if ($status === 'completed') {
                    // Get order details
                    $stmt = $db->prepare("SELECT * FROM orders WHERE id = ?");
                    $stmt->execute([$order_id]);
                    $order = $stmt->fetch();
                    
                    if ($order) {
                        // Trigger charging API
                        $charging_result = triggerCharging($order);
                        if ($charging_result['success']) {
                            $message = '<div class="alert alert-success">تم تحديث الطلب وتفعيل الشحن بنجاح</div>';
                        } else {
                            $message = '<div class="alert alert-warning">تم تحديث الطلب ولكن فشل في تفعيل الشحن: ' . $charging_result['error'] . '</div>';
                        }
                    }
                }
            } else {
                $message = '<div class="alert alert-danger">حدث خطأ أثناء تحديث حالة الطلب</div>';
            }
        }
    }
}

// Get filter parameters
$status_filter = $_GET['status'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$search = $_GET['search'] ?? '';

// Build query
$where_conditions = [];
$params = [];

if ($status_filter) {
    $where_conditions[] = "o.status = ?";
    $params[] = $status_filter;
}

if ($date_from) {
    $where_conditions[] = "DATE(o.created_at) >= ?";
    $params[] = $date_from;
}

if ($date_to) {
    $where_conditions[] = "DATE(o.created_at) <= ?";
    $params[] = $date_to;
}

if ($search) {
    $where_conditions[] = "(u.username LIKE ? OR p.name_ar LIKE ? OR o.customer_id LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

$where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get orders with pagination
$page = (int)($_GET['page'] ?? 1);
$per_page = 20;
$offset = ($page - 1) * $per_page;

$count_query = "SELECT COUNT(*) as total FROM orders o JOIN users u ON o.user_id = u.id JOIN products p ON o.product_id = p.id $where_clause";
$stmt = $db->prepare($count_query);
$stmt->execute($params);
$total_orders = $stmt->fetch()['total'];
$total_pages = ceil($total_orders / $per_page);

$orders_query = "
    SELECT o.*, u.username, u.email, p.name_ar as product_name, p.image as product_image,
           c.name_ar as category_name
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    JOIN products p ON o.product_id = p.id 
    JOIN categories c ON p.category_id = c.id
    $where_clause
    ORDER BY o.created_at DESC 
    LIMIT $per_page OFFSET $offset
";

$stmt = $db->prepare($orders_query);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Get statistics
$stats_query = "
    SELECT 
        COUNT(*) as total_orders,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_orders,
        SUM(CASE WHEN currency = 'YER' THEN amount WHEN currency = 'SAR' THEN amount * 100 WHEN currency = 'USD' THEN amount * 375 END) as total_revenue
    FROM orders 
    WHERE DATE(created_at) = CURDATE()
";
$stmt = $db->query($stats_query);
$today_stats = $stmt->fetch();

function triggerCharging($order) {
    // Simulate charging API call
    return [
        'success' => true,
        'transaction_id' => 'TXN_' . uniqid(),
        'message' => 'تم تفعيل الشحن بنجاح'
    ];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الطلبات - فاست ستار</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">إدارة الطلبات</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button class="btn btn-outline-secondary me-2" onclick="exportOrders()">
                            <i class="fas fa-download me-2"></i>تصدير
                        </button>
                        <button class="btn btn-primary" onclick="refreshOrders()">
                            <i class="fas fa-sync-alt me-2"></i>تحديث
                        </button>
                    </div>
                </div>
                
                <?= $message ?>
                
                <!-- Today's Statistics -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-right-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col me-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">طلبات اليوم</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($today_stats['total_orders']) ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-shopping-cart fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-right-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col me-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">مكتملة</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($today_stats['completed_orders']) ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-right-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col me-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">معلقة</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($today_stats['pending_orders']) ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-clock fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-right-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col me-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">إيرادات اليوم</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= formatCurrency($today_stats['total_revenue']) ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Filters -->
                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-2">
                                <label class="form-label">الحالة</label>
                                <select name="status" class="form-select">
                                    <option value="">جميع الحالات</option>
                                    <option value="pending" <?= $status_filter === 'pending' ? 'selected' : '' ?>>معلق</option>
                                    <option value="processing" <?= $status_filter === 'processing' ? 'selected' : '' ?>>قيد المعالجة</option>
                                    <option value="completed" <?= $status_filter === 'completed' ? 'selected' : '' ?>>مكتمل</option>
                                    <option value="failed" <?= $status_filter === 'failed' ? 'selected' : '' ?>>فاشل</option>
                                    <option value="cancelled" <?= $status_filter === 'cancelled' ? 'selected' : '' ?>>ملغي</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">من تاريخ</label>
                                <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($date_from) ?>">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">إلى تاريخ</label>
                                <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($date_to) ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">البحث</label>
                                <input type="text" name="search" class="form-control" placeholder="اسم المستخدم، المنتج، أو معرف العميل" value="<?= htmlspecialchars($search) ?>">
                            </div>
                            <div class="col-md-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary me-2">
                                    <i class="fas fa-search me-1"></i>بحث
                                </button>
                                <a href="orders.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-times me-1"></i>مسح
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Orders Table -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>رقم الطلب</th>
                                        <th>المستخدم</th>
                                        <th>المنتج</th>
                                        <th>معرف العميل</th>
                                        <th>المبلغ</th>
                                        <th>الحالة</th>
                                        <th>تاريخ الطلب</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td>
                                            <strong>#<?= $order['id'] ?></strong>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div>
                                                    <strong><?= htmlspecialchars($order['username']) ?></strong><br>
                                                    <small class="text-muted"><?= htmlspecialchars($order['email']) ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <?php if ($order['product_image']): ?>
                                                    <img src="<?= UPLOAD_URL . $order['product_image'] ?>" alt="" style="width: 40px; height: 40px; object-fit: cover;" class="rounded me-2">
                                                <?php endif; ?>
                                                <div>
                                                    <strong><?= htmlspecialchars($order['product_name']) ?></strong><br>
                                                    <small class="text-muted"><?= htmlspecialchars($order['category_name']) ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <code><?= htmlspecialchars($order['customer_id']) ?></code>
                                        </td>
                                        <td>
                                            <strong><?= formatCurrency($order['amount'], $order['currency']) ?></strong>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?= getStatusColor($order['status']) ?>">
                                                <?= getStatusText($order['status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?= date('Y-m-d H:i', strtotime($order['created_at'])) ?>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button class="btn btn-sm btn-outline-info" onclick="viewOrder(<?= $order['id'] ?>)">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button class="btn btn-sm btn-outline-primary" onclick="updateOrderStatus(<?= $order['id'] ?>, '<?= $order['status'] ?>')">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!-- Pagination -->
                        <?php if ($total_pages > 1): ?>
                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-center">
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                    <a class="page-link" href="?page=<?= $i ?>&status=<?= urlencode($status_filter) ?>&date_from=<?= urlencode($date_from) ?>&date_to=<?= urlencode($date_to) ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                                </li>
                                <?php endfor; ?>
                            </ul>
                        </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <!-- Update Status Modal -->
    <div class="modal fade" id="updateStatusModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تحديث حالة الطلب</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                        <input type="hidden" name="action" value="update_status">
                        <input type="hidden" name="order_id" id="update_order_id">
                        
                        <div class="mb-3">
                            <label class="form-label">الحالة الجديدة</label>
                            <select name="status" id="update_status" class="form-select" required>
                                <option value="pending">معلق</option>
                                <option value="processing">قيد المعالجة</option>
                                <option value="completed">مكتمل</option>
                                <option value="failed">فاشل</option>
                                <option value="cancelled">ملغي</option>
                            </select>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            عند تغيير الحالة إلى "مكتمل" سيتم تفعيل الشحن تلقائياً
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">تحديث الحالة</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function updateOrderStatus(orderId, currentStatus) {
            document.getElementById('update_order_id').value = orderId;
            document.getElementById('update_status').value = currentStatus;
            new bootstrap.Modal(document.getElementById('updateStatusModal')).show();
        }
        
        function viewOrder(orderId) {
            // Implement order details view
            alert('عرض تفاصيل الطلب #' + orderId);
        }
        
        function exportOrders() {
            // Implement export functionality
            window.location.href = 'export_orders.php?' + new URLSearchParams(window.location.search);
        }
        
        function refreshOrders() {
            window.location.reload();
        }
    </script>
</body>
</html>

<?php
function getStatusColor($status) {
    switch ($status) {
        case 'completed': return 'success';
        case 'processing': return 'info';
        case 'pending': return 'warning';
        case 'failed': return 'danger';
        case 'cancelled': return 'secondary';
        default: return 'secondary';
    }
}

function getStatusText($status) {
    switch ($status) {
        case 'completed': return 'مكتمل';
        case 'processing': return 'قيد المعالجة';
        case 'pending': return 'معلق';
        case 'failed': return 'فاشل';
        case 'cancelled': return 'ملغي';
        default: return 'غير محدد';
    }
}
?>
