<?php
require_once '../config/config.php';

if (!isAdmin()) {
    redirect('login.php');
}

$message = '';
$error = '';

// معالجة تحديث إعدادات بوابة الدفع
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_gateway'])) {
    try {
        $gateway_id = (int)$_POST['gateway_id'];
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $is_sandbox = isset($_POST['is_sandbox']) ? 1 : 0;
        $config = json_encode($_POST['config']);
        
        $stmt = $pdo->prepare("
            UPDATE payment_gateways 
            SET is_active = ?, is_sandbox = ?, config = ?, updated_at = NOW() 
            WHERE id = ?
        ");
        $stmt->execute([$is_active, $is_sandbox, $config, $gateway_id]);
        
        $message = 'تم تحديث إعدادات بوابة الدفع بنجاح';
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// إضافة بوابة دفع جديدة
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_gateway'])) {
    try {
        $name = sanitize($_POST['name']);
        $code = sanitize($_POST['code']);
        $description = sanitize($_POST['description']);
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $is_sandbox = isset($_POST['is_sandbox']) ? 1 : 0;
        $config = json_encode($_POST['config']);
        
        $stmt = $pdo->prepare("
            INSERT INTO payment_gateways (name, code, description, is_active, is_sandbox, config) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$name, $code, $description, $is_active, $is_sandbox, $config]);
        
        $message = 'تم إضافة بوابة الدفع بنجاح';
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// جلب بوابات الدفع
$stmt = $pdo->query("SELECT * FROM payment_gateways ORDER BY name");
$gateways = $stmt->fetchAll();

// إنشاء بوابات الدفع الافتراضية إذا لم تكن موجودة
if (empty($gateways)) {
    $default_gateways = [
        [
            'name' => 'PayPal',
            'code' => 'paypal',
            'description' => 'PayPal Payment Gateway',
            'config' => json_encode([
                'client_id' => '',
                'client_secret' => '',
                'webhook_id' => ''
            ])
        ],
        [
            'name' => 'Stripe',
            'code' => 'stripe',
            'description' => 'Stripe Payment Gateway',
            'config' => json_encode([
                'publishable_key' => '',
                'secret_key' => '',
                'webhook_secret' => ''
            ])
        ],
        [
            'name' => 'مدى',
            'code' => 'mada',
            'description' => 'Mada Payment Gateway (Saudi Arabia)',
            'config' => json_encode([
                'merchant_id' => '',
                'terminal_id' => '',
                'secret_key' => ''
            ])
        ],
        [
            'name' => 'المحفظة الإلكترونية اليمنية',
            'code' => 'ymm',
            'description' => 'Yemen Mobile Money',
            'config' => json_encode([
                'merchant_code' => '',
                'api_key' => '',
                'callback_url' => ''
            ])
        ],
        [
            'name' => 'التحويل البنكي',
            'code' => 'bank_transfer',
            'description' => 'Bank Transfer',
            'config' => json_encode([
                'bank_accounts' => []
            ])
        ]
    ];
    
    foreach ($default_gateways as $gateway) {
        $stmt = $pdo->prepare("
            INSERT INTO payment_gateways (name, code, description, config, is_active, is_sandbox) 
            VALUES (?, ?, ?, ?, 0, 1)
        ");
        $stmt->execute([$gateway['name'], $gateway['code'], $gateway['description'], $gateway['config']]);
    }
    
    // إعادة جلب البوابات
    $stmt = $pdo->query("SELECT * FROM payment_gateways ORDER BY name");
    $gateways = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة بوابات الدفع - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">إدارة بوابات الدفع</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addGatewayModal">
                            <i class="fas fa-plus me-2"></i>إضافة بوابة دفع
                        </button>
                    </div>
                </div>

                <?php if ($message): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- بوابات الدفع -->
                <div class="row">
                    <?php foreach ($gateways as $gateway): ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card h-100">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">
                                    <i class="fas fa-credit-card me-2"></i>
                                    <?php echo htmlspecialchars($gateway['name']); ?>
                                </h5>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" 
                                           <?php echo $gateway['is_active'] ? 'checked' : ''; ?>
                                           onchange="toggleGateway(<?php echo $gateway['id']; ?>, this.checked)">
                                </div>
                            </div>
                            <div class="card-body">
                                <p class="card-text"><?php echo htmlspecialchars($gateway['description']); ?></p>
                                
                                <div class="mb-2">
                                    <small class="text-muted">الكود:</small>
                                    <code><?php echo htmlspecialchars($gateway['code']); ?></code>
                                </div>
                                
                                <div class="mb-2">
                                    <small class="text-muted">الحالة:</small>
                                    <span class="badge bg-<?php echo $gateway['is_active'] ? 'success' : 'secondary'; ?>">
                                        <?php echo $gateway['is_active'] ? 'مفعل' : 'معطل'; ?>
                                    </span>
                                </div>
                                
                                <div class="mb-2">
                                    <small class="text-muted">البيئة:</small>
                                    <span class="badge bg-<?php echo $gateway['is_sandbox'] ? 'warning' : 'info'; ?>">
                                        <?php echo $gateway['is_sandbox'] ? 'تجريبي' : 'إنتاج'; ?>
                                    </span>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="button" class="btn btn-outline-primary btn-sm" 
                                        onclick="configureGateway(<?php echo htmlspecialchars(json_encode($gateway)); ?>)">
                                    <i class="fas fa-cog me-1"></i>تكوين
                                </button>
                                <button type="button" class="btn btn-outline-info btn-sm" 
                                        onclick="testGateway(<?php echo $gateway['id']; ?>)">
                                    <i class="fas fa-vial me-1"></i>اختبار
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </main>
        </div>
    </div>

    <!-- مودال تكوين بوابة الدفع -->
    <div class="modal fade" id="configureGatewayModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تكوين بوابة الدفع</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="configureGatewayForm">
                    <input type="hidden" id="gateway_id" name="gateway_id">
                    <div class="modal-body">
                        <div class="mb-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="is_active" name="is_active">
                                <label class="form-check-label" for="is_active">تفعيل البوابة</label>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="is_sandbox" name="is_sandbox">
                                <label class="form-check-label" for="is_sandbox">وضع التجريب</label>
                            </div>
                        </div>
                        
                        <div id="gateway_config_fields">
                            <!-- سيتم ملء الحقول ديناميكياً -->
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" name="update_gateway" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>حفظ التغييرات
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- مودال إضافة بوابة دفع -->
    <div class="modal fade" id="addGatewayModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إضافة بوابة دفع جديدة</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="name" class="form-label">اسم البوابة *</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="code" class="form-label">كود البوابة *</label>
                            <input type="text" class="form-control" id="code" name="code" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">الوصف</label>
                            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="add_is_active" name="is_active">
                                <label class="form-check-label" for="add_is_active">تفعيل البوابة</label>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="add_is_sandbox" name="is_sandbox" checked>
                                <label class="form-check-label" for="add_is_sandbox">وضع التجريب</label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" name="add_gateway" class="btn btn-primary">
                            <i class="fas fa-plus me-2"></i>إضافة البوابة
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleGateway(gatewayId, isActive) {
            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `update_gateway=1&gateway_id=${gatewayId}&is_active=${isActive ? 1 : 0}`
            })
            .then(response => response.text())
            .then(data => {
                location.reload();
            });
        }

        function configureGateway(gateway) {
            document.getElementById('gateway_id').value = gateway.id;
            document.getElementById('is_active').checked = gateway.is_active == 1;
            document.getElementById('is_sandbox').checked = gateway.is_sandbox == 1;
            
            // إنشاء حقول التكوين
            const configFields = document.getElementById('gateway_config_fields');
            configFields.innerHTML = '';
            
            const config = JSON.parse(gateway.config || '{}');
            
            // حقول مختلفة حسب نوع البوابة
            if (gateway.code === 'paypal') {
                configFields.innerHTML = `
                    <div class="mb-3">
                        <label class="form-label">Client ID</label>
                        <input type="text" class="form-control" name="config[client_id]" value="${config.client_id || ''}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Client Secret</label>
                        <input type="password" class="form-control" name="config[client_secret]" value="${config.client_secret || ''}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Webhook ID</label>
                        <input type="text" class="form-control" name="config[webhook_id]" value="${config.webhook_id || ''}">
                    </div>
                `;
            } else if (gateway.code === 'stripe') {
                configFields.innerHTML = `
                    <div class="mb-3">
                        <label class="form-label">Publishable Key</label>
                        <input type="text" class="form-control" name="config[publishable_key]" value="${config.publishable_key || ''}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Secret Key</label>
                        <input type="password" class="form-control" name="config[secret_key]" value="${config.secret_key || ''}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Webhook Secret</label>
                        <input type="password" class="form-control" name="config[webhook_secret]" value="${config.webhook_secret || ''}">
                    </div>
                `;
            } else if (gateway.code === 'mada') {
                configFields.innerHTML = `
                    <div class="mb-3">
                        <label class="form-label">Merchant ID</label>
                        <input type="text" class="form-control" name="config[merchant_id]" value="${config.merchant_id || ''}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Terminal ID</label>
                        <input type="text" class="form-control" name="config[terminal_id]" value="${config.terminal_id || ''}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Secret Key</label>
                        <input type="password" class="form-control" name="config[secret_key]" value="${config.secret_key || ''}">
                    </div>
                `;
            }
            
            new bootstrap.Modal(document.getElementById('configureGatewayModal')).show();
        }

        function testGateway(gatewayId) {
            alert('سيتم إضافة وظيفة اختبار البوابة قريباً');
        }
    </script>
</body>
</html>
