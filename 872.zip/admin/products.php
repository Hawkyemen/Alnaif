<?php
require_once '../config/config.php';

if (!isAdmin()) {
    redirect('login.php');
}

$message = '';
$error = '';

// معالجة رفع الصورة
function uploadProductImage($file) {
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    if (!in_array($file['type'], $allowed_types)) {
        throw new Exception('نوع الملف غير مدعوم. يرجى رفع صورة JPG أو PNG أو GIF');
    }
    
    if ($file['size'] > MAX_FILE_SIZE) {
        throw new Exception('حجم الملف كبير جداً. الحد الأقصى ' . (MAX_FILE_SIZE / 1024 / 1024) . ' ميجابايت');
    }
    
    $upload_dir = '../uploads/products/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid('product_') . '.' . $extension;
    $filepath = $upload_dir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return 'uploads/products/' . $filename;
    }
    
    throw new Exception('فشل في رفع الصورة');
}

// إضافة منتج جديد
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_product'])) {
    try {
        $category_id = (int)$_POST['category_id'];
        $name = sanitize($_POST['name']);
        $name_en = sanitize($_POST['name_en']);
        $description = sanitize($_POST['description']);
        $description_ar = sanitize($_POST['description_ar']);
        $price_yer = (float)$_POST['price_yer'];
        $price_sar = (float)$_POST['price_sar'];
        $price_usd = (float)$_POST['price_usd'];
        $price_aed = (float)$_POST['price_aed'];
        $customer_id_label = sanitize($_POST['customer_id_label']);
        $customer_id_placeholder = sanitize($_POST['customer_id_placeholder']);
        $instructions = sanitize($_POST['instructions']);
        $instructions_ar = sanitize($_POST['instructions_ar']);
        $status = sanitize($_POST['status']);
        $featured = isset($_POST['featured']) ? 1 : 0;
        
        // رفع الصورة
        $image_path = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $image_path = uploadProductImage($_FILES['image']);
        }
        
        $stmt = $pdo->prepare("
            INSERT INTO products (category_id, name, name_en, description, description_ar, image, 
                                price_yer, price_sar, price_usd, price_aed, customer_id_label, 
                                customer_id_placeholder, instructions, instructions_ar, status, featured)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $category_id, $name, $name_en, $description, $description_ar, $image_path,
            $price_yer, $price_sar, $price_usd, $price_aed, $customer_id_label,
            $customer_id_placeholder, $instructions, $instructions_ar, $status, $featured
        ]);
        
        $message = 'تم إضافة المنتج بنجاح';
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// تحديث منتج
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_product'])) {
    try {
        $id = (int)$_POST['id'];
        $category_id = (int)$_POST['category_id'];
        $name = sanitize($_POST['name']);
        $name_en = sanitize($_POST['name_en']);
        $description = sanitize($_POST['description']);
        $description_ar = sanitize($_POST['description_ar']);
        $price_yer = (float)$_POST['price_yer'];
        $price_sar = (float)$_POST['price_sar'];
        $price_usd = (float)$_POST['price_usd'];
        $price_aed = (float)$_POST['price_aed'];
        $customer_id_label = sanitize($_POST['customer_id_label']);
        $customer_id_placeholder = sanitize($_POST['customer_id_placeholder']);
        $instructions = sanitize($_POST['instructions']);
        $instructions_ar = sanitize($_POST['instructions_ar']);
        $status = sanitize($_POST['status']);
        $featured = isset($_POST['featured']) ? 1 : 0;
        
        // رفع صورة جديدة إذا تم اختيارها
        $image_update = '';
        $image_params = [];
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $image_path = uploadProductImage($_FILES['image']);
            $image_update = ', image = ?';
            $image_params[] = $image_path;
        }
        
        $stmt = $pdo->prepare("
            UPDATE products SET 
                category_id = ?, name = ?, name_en = ?, description = ?, description_ar = ?,
                price_yer = ?, price_sar = ?, price_usd = ?, price_aed = ?, 
                customer_id_label = ?, customer_id_placeholder = ?, instructions = ?, 
                instructions_ar = ?, status = ?, featured = ?, updated_at = NOW()
                $image_update
            WHERE id = ?
        ");
        
        $params = [
            $category_id, $name, $name_en, $description, $description_ar,
            $price_yer, $price_sar, $price_usd, $price_aed,
            $customer_id_label, $customer_id_placeholder, $instructions,
            $instructions_ar, $status, $featured
        ];
        
        $params = array_merge($params, $image_params);
        $params[] = $id;
        
        $stmt->execute($params);
        
        $message = 'تم تحديث المنتج بنجاح';
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// حذف منتج
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    try {
        $id = (int)$_GET['delete'];
        
        // حذف الصورة إذا كانت موجودة
        $stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch();
        
        if ($product && $product['image'] && file_exists('../' . $product['image'])) {
            unlink('../' . $product['image']);
        }
        
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);
        
        $message = 'تم حذف المنتج بنجاح';
    } catch (PDOException $e) {
        $error = 'لا يمكن حذف المنتج. قد يكون مرتبط بطلبات موجودة';
    }
}

// جلب المنتجات
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$category_filter = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$status_filter = isset($_GET['status']) ? sanitize($_GET['status']) : '';

$where_conditions = [];
$params = [];

if ($search) {
    $where_conditions[] = "(p.name LIKE ? OR p.name_en LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($category_filter) {
    $where_conditions[] = "p.category_id = ?";
    $params[] = $category_filter;
}

if ($status_filter) {
    $where_conditions[] = "p.status = ?";
    $params[] = $status_filter;
}

$where_clause = $where_conditions ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

$stmt = $pdo->prepare("
    SELECT p.*, c.name as category_name 
    FROM products p 
    LEFT JOIN categories c ON p.category_id = c.id 
    $where_clause
    ORDER BY p.created_at DESC
");
$stmt->execute($params);
$products = $stmt->fetchAll();

// جلب الفئات للفلتر والنموذج
$stmt = $pdo->query("SELECT id, name FROM categories WHERE status = 'active' ORDER BY name");
$categories = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المنتجات - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">إدارة المنتجات</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProductModal">
                            <i class="fas fa-plus me-2"></i>إضافة منتج جديد
                        </button>
                    </div>
                </div>

                <?php if ($message): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- فلاتر البحث -->
                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-4">
                                <label for="search" class="form-label">البحث</label>
                                <input type="text" class="form-control" id="search" name="search" 
                                       value="<?php echo htmlspecialchars($search); ?>" 
                                       placeholder="البحث في أسماء المنتجات...">
                            </div>
                            <div class="col-md-3">
                                <label for="category" class="form-label">الفئة</label>
                                <select class="form-select" id="category" name="category">
                                    <option value="">جميع الفئات</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>" 
                                                <?php echo $category_filter == $category['id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($category['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="status" class="form-label">الحالة</label>
                                <select class="form-select" id="status" name="status">
                                    <option value="">جميع الحالات</option>
                                    <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>نشط</option>
                                    <option value="inactive" <?php echo $status_filter == 'inactive' ? 'selected' : ''; ?>>غير نشط</option>
                                    <option value="out_of_stock" <?php echo $status_filter == 'out_of_stock' ? 'selected' : ''; ?>>نفد المخزون</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">&nbsp;</label>
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-outline-primary">
                                        <i class="fas fa-search me-1"></i>بحث
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- جدول المنتجات -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>الصورة</th>
                                        <th>اسم المنتج</th>
                                        <th>الفئة</th>
                                        <th>السعر (ر.ي)</th>
                                        <th>السعر (ر.س)</th>
                                        <th>السعر ($)</th>
                                        <th>الحالة</th>
                                        <th>مميز</th>
                                        <th>المبيعات</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($products as $product): ?>
                                    <tr>
                                        <td>
                                            <?php if ($product['image']): ?>
                                                <img src="../<?php echo htmlspecialchars($product['image']); ?>" 
                                                     alt="<?php echo htmlspecialchars($product['name']); ?>"
                                                     class="img-thumbnail" style="width: 50px; height: 50px; object-fit: cover;">
                                            <?php else: ?>
                                                <div class="bg-light d-flex align-items-center justify-content-center" 
                                                     style="width: 50px; height: 50px; border-radius: 0.375rem;">
                                                    <i class="fas fa-image text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="fw-bold"><?php echo htmlspecialchars($product['name']); ?></div>
                                            <small class="text-muted"><?php echo htmlspecialchars($product['name_en']); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($product['category_name']); ?></td>
                                        <td><?php echo number_format($product['price_yer'], 2); ?></td>
                                        <td><?php echo number_format($product['price_sar'], 2); ?></td>
                                        <td><?php echo number_format($product['price_usd'], 2); ?></td>
                                        <td>
                                            <?php
                                            $status_class = '';
                                            $status_text = '';
                                            switch ($product['status']) {
                                                case 'active':
                                                    $status_class = 'success';
                                                    $status_text = 'نشط';
                                                    break;
                                                case 'inactive':
                                                    $status_class = 'secondary';
                                                    $status_text = 'غير نشط';
                                                    break;
                                                case 'out_of_stock':
                                                    $status_class = 'warning';
                                                    $status_text = 'نفد المخزون';
                                                    break;
                                            }
                                            ?>
                                            <span class="badge bg-<?php echo $status_class; ?>">
                                                <?php echo $status_text; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($product['is_featured']): ?>
                                                <i class="fas fa-star text-warning" title="منتج مميز"></i>
                                            <?php else: ?>
                                                <i class="far fa-star text-muted" title="غير مميز"></i>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo number_format($product['total_sales']); ?></td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <button type="button" class="btn btn-outline-primary" 
                                                        onclick="editProduct(<?php echo htmlspecialchars(json_encode($product)); ?>)">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <a href="?delete=<?php echo $product['id']; ?>" 
                                                   class="btn btn-outline-danger"
                                                   onclick="return confirm('هل أنت متأكد من حذف هذا المنتج؟')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- مودال إضافة منتج -->
    <div class="modal fade" id="addProductModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إضافة منتج جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="category_id" class="form-label">الفئة *</label>
                                <select class="form-select" id="category_id" name="category_id" required>
                                    <option value="">اختر الفئة</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>">
                                            <?php echo htmlspecialchars($category['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="status" class="form-label">الحالة *</label>
                                <select class="form-select" id="status" name="status" required>
                                    <option value="active">نشط</option>
                                    <option value="inactive">غير نشط</option>
                                    <option value="out_of_stock">نفد المخزون</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="name" class="form-label">اسم المنتج (عربي) *</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="name_en" class="form-label">اسم المنتج (إنجليزي)</label>
                                <input type="text" class="form-control" id="name_en" name="name_en">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="description" class="form-label">الوصف (عربي)</label>
                                <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="description_en" class="form-label">الوصف (إنجليزي)</label>
                                <textarea class="form-control" id="description_en" name="description_en" rows="3"></textarea>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="image" class="form-label">صورة المنتج</label>
                            <input type="file" class="form-control" id="image" name="image" accept="image/*">
                            <div class="form-text">الحد الأقصى: 5 ميجابايت. الأنواع المدعومة: JPG, PNG, GIF</div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="price_yer" class="form-label">السعر (ر.ي) *</label>
                                <input type="number" class="form-control" id="price_yer" name="price_yer" 
                                       step="0.01" min="0" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="price_sar" class="form-label">السعر (ر.س)</label>
                                <input type="number" class="form-control" id="price_sar" name="price_sar" 
                                       step="0.01" min="0">
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="price_usd" class="form-label">السعر ($)</label>
                                <input type="number" class="form-control" id="price_usd" name="price_usd" 
                                       step="0.01" min="0">
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="price_aed" class="form-label">السعر (د.إ)</label>
                                <input type="number" class="form-control" id="price_aed" name="price_aed" 
                                       step="0.01" min="0">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="featured" name="featured">
                                <label class="form-check-label" for="featured">
                                    منتج مميز
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" name="add_product" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>حفظ المنتج
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- مودال تعديل منتج -->
    <div class="modal fade" id="editProductModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تعديل المنتج</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" enctype="multipart/form-data" id="editProductForm">
                    <input type="hidden" id="edit_id" name="id">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_category_id" class="form-label">الفئة *</label>
                                <select class="form-select" id="edit_category_id" name="category_id" required>
                                    <option value="">اختر الفئة</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>">
                                            <?php echo htmlspecialchars($category['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_status" class="form-label">الحالة *</label>
                                <select class="form-select" id="edit_status" name="status" required>
                                    <option value="active">نشط</option>
                                    <option value="inactive">غير نشط</option>
                                    <option value="out_of_stock">نفد المخزون</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_name" class="form-label">اسم المنتج (عربي) *</label>
                                <input type="text" class="form-control" id="edit_name" name="name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_name_en" class="form-label">اسم المنتج (إنجليزي)</label>
                                <input type="text" class="form-control" id="edit_name_en" name="name_en">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_description" class="form-label">الوصف (عربي)</label>
                                <textarea class="form-control" id="edit_description" name="description" rows="3"></textarea>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_description_en" class="form-label">الوصف (إنجليزي)</label>
                                <textarea class="form-control" id="edit_description_en" name="description_en" rows="3"></textarea>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_image" class="form-label">صورة المنتج</label>
                            <input type="file" class="form-control" id="edit_image" name="image" accept="image/*">
                            <div class="form-text">اتركه فارغاً للاحتفاظ بالصورة الحالية</div>
                            <div id="current_image_preview" class="mt-2"></div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="edit_price_yer" class="form-label">السعر (ر.ي) *</label>
                                <input type="number" class="form-control" id="edit_price_yer" name="price_yer" 
                                       step="0.01" min="0" required>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="edit_price_sar" class="form-label">السعر (ر.س)</label>
                                <input type="number" class="form-control" id="edit_price_sar" name="price_sar" 
                                       step="0.01" min="0">
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="edit_price_usd" class="form-label">السعر ($)</label>
                                <input type="number" class="form-control" id="edit_price_usd" name="price_usd" 
                                       step="0.01" min="0">
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="edit_price_aed" class="form-label">السعر (د.إ)</label>
                                <input type="number" class="form-control" id="edit_price_aed" name="price_aed" 
                                       step="0.01" min="0">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="edit_featured" name="featured">
                                <label class="form-check-label" for="edit_featured">
                                    منتج مميز
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" name="update_product" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>حفظ التغييرات
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editProduct(product) {
            // ملء النموذج بالبيانات
            document.getElementById('edit_id').value = product.id;
            document.getElementById('edit_category_id').value = product.category_id;
            document.getElementById('edit_name').value = product.name;
            document.getElementById('edit_name_en').value = product.name_en;
            document.getElementById('edit_description').value = product.description || '';
            document.getElementById('edit_description_en').value = product.description_en || '';
            document.getElementById('edit_price_yer').value = product.price_yer;
            document.getElementById('edit_price_sar').value = product.price_sar;
            document.getElementById('edit_price_usd').value = product.price_usd;
            document.getElementById('edit_price_aed').value = product.price_aed;
            document.getElementById('edit_status').value = product.status;
            document.getElementById('edit_featured').checked = product.is_featured == 1;
            
            // عرض الصورة الحالية
            const imagePreview = document.getElementById('current_image_preview');
            if (product.image) {
                imagePreview.innerHTML = `
                    <div class="text-muted mb-2">الصورة الحالية:</div>
                    <img src="../<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="img-thumbnail" style="max-width: 150px; max-height: 150px;">
                `;
            } else {
                imagePreview.innerHTML = '<div class="text-muted">لا توجد صورة</div>';
            }
            
            // عرض المودال
            new bootstrap.Modal(document.getElementById('editProductModal')).show();
        }
    </script>
</body>
</html>
