<?php
require_once '../config/config.php';

if (!isset($_SESSION['admin_id'])) {
    redirect(ADMIN_URL . '/login.php');
}

$db = Database::getInstance()->getConnection();

// Get date range
$date_from = $_GET['date_from'] ?? date('Y-m-01'); // First day of current month
$date_to = $_GET['date_to'] ?? date('Y-m-d');
$report_type = $_GET['report_type'] ?? 'overview';

// Sales Overview
$sales_query = "
    SELECT 
        DATE(created_at) as date,
        COUNT(*) as total_orders,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
        SUM(CASE WHEN status = 'completed' THEN 
            CASE 
                WHEN currency = 'YER' THEN amount 
                WHEN currency = 'SAR' THEN amount * 100 
                WHEN currency = 'USD' THEN amount * 375 
                ELSE amount 
            END 
        ELSE 0 END) as revenue_yer
    FROM orders 
    WHERE DATE(created_at) BETWEEN ? AND ?
    GROUP BY DATE(created_at)
    ORDER BY date DESC
";

$stmt = $db->prepare($sales_query);
$stmt->execute([$date_from, $date_to]);
$daily_sales = $stmt->fetchAll();

// Product Performance
$product_performance_query = "
    SELECT 
        p.name_ar,
        p.name,
        c.name_ar as category_name,
        COUNT(o.id) as total_orders,
        SUM(CASE WHEN o.status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
        SUM(CASE WHEN o.status = 'completed' THEN 
            CASE 
                WHEN o.currency = 'YER' THEN o.amount 
                WHEN o.currency = 'SAR' THEN o.amount * 100 
                WHEN o.currency = 'USD' THEN o.amount * 375 
                ELSE o.amount 
            END 
        ELSE 0 END) as revenue_yer,
        AVG(CASE WHEN o.status = 'completed' THEN 
            CASE 
                WHEN o.currency = 'YER' THEN o.amount 
                WHEN o.currency = 'SAR' THEN o.amount * 100 
                WHEN o.currency = 'USD' THEN o.amount * 375 
                ELSE o.amount 
            END 
        ELSE NULL END) as avg_order_value
    FROM products p
    LEFT JOIN orders o ON p.id = o.product_id AND DATE(o.created_at) BETWEEN ? AND ?
    LEFT JOIN categories c ON p.category_id = c.id
    GROUP BY p.id
    HAVING total_orders > 0
    ORDER BY revenue_yer DESC
    LIMIT 20
";

$stmt = $db->prepare($product_performance_query);
$stmt->execute([$date_from, $date_to]);
$product_performance = $stmt->fetchAll();

// User Activity
$user_activity_query = "
    SELECT 
        u.username,
        u.email,
        u.created_at as registration_date,
        COUNT(o.id) as total_orders,
        SUM(CASE WHEN o.status = 'completed' THEN 
            CASE 
                WHEN o.currency = 'YER' THEN o.amount 
                WHEN o.currency = 'SAR' THEN o.amount * 100 
                WHEN o.currency = 'USD' THEN o.amount * 375 
                ELSE o.amount 
            END 
        ELSE 0 END) as total_spent,
        MAX(o.created_at) as last_order_date
    FROM users u
    LEFT JOIN orders o ON u.id = o.user_id AND DATE(o.created_at) BETWEEN ? AND ?
    GROUP BY u.id
    HAVING total_orders > 0
    ORDER BY total_spent DESC
    LIMIT 20
";

$stmt = $db->prepare($user_activity_query);
$stmt->execute([$date_from, $date_to]);
$top_users = $stmt->fetchAll();

// Payment Methods
$payment_methods_query = "
    SELECT 
        payment_method,
        COUNT(*) as total_transactions,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as successful_transactions,
        SUM(CASE WHEN status = 'completed' THEN 
            CASE 
                WHEN currency = 'YER' THEN amount 
                WHEN currency = 'SAR' THEN amount * 100 
                WHEN currency = 'USD' THEN amount * 375 
                ELSE amount 
            END 
        ELSE 0 END) as revenue_yer
    FROM orders 
    WHERE DATE(created_at) BETWEEN ? AND ?
    GROUP BY payment_method
    ORDER BY revenue_yer DESC
";

$stmt = $db->prepare($payment_methods_query);
$stmt->execute([$date_from, $date_to]);
$payment_methods = $stmt->fetchAll();

// Overall Statistics
$overall_stats_query = "
    SELECT 
        COUNT(*) as total_orders,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_orders,
        SUM(CASE WHEN status = 'completed' THEN 
            CASE 
                WHEN currency = 'YER' THEN amount 
                WHEN currency = 'SAR' THEN amount * 100 
                WHEN currency = 'USD' THEN amount * 375 
                ELSE amount 
            END 
        ELSE 0 END) as total_revenue,
        AVG(CASE WHEN status = 'completed' THEN 
            CASE 
                WHEN currency = 'YER' THEN amount 
                WHEN currency = 'SAR' THEN amount * 100 
                WHEN currency = 'USD' THEN amount * 375 
                ELSE amount 
            END 
        ELSE NULL END) as avg_order_value
    FROM orders 
    WHERE DATE(created_at) BETWEEN ? AND ?
";

$stmt = $db->prepare($overall_stats_query);
$stmt->execute([$date_from, $date_to]);
$overall_stats = $stmt->fetch();

// Category Performance
$category_performance_query = "
    SELECT 
        c.name_ar as category_name,
        COUNT(o.id) as total_orders,
        SUM(CASE WHEN o.status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
        SUM(CASE WHEN o.status = 'completed' THEN 
            CASE 
                WHEN o.currency = 'YER' THEN o.amount 
                WHEN o.currency = 'SAR' THEN o.amount * 100 
                WHEN o.currency = 'USD' THEN o.amount * 375 
                ELSE o.amount 
            END 
        ELSE 0 END) as revenue_yer
    FROM categories c
    LEFT JOIN products p ON c.id = p.category_id
    LEFT JOIN orders o ON p.id = o.product_id AND DATE(o.created_at) BETWEEN ? AND ?
    GROUP BY c.id
    HAVING total_orders > 0
    ORDER BY revenue_yer DESC
";

$stmt = $db->prepare($category_performance_query);
$stmt->execute([$date_from, $date_to]);
$category_performance = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>التقارير - فاست ستار</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">التقارير والإحصائيات</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button class="btn btn-outline-secondary me-2" onclick="exportReport()">
                            <i class="fas fa-download me-2"></i>تصدير PDF
                        </button>
                        <button class="btn btn-outline-info me-2" onclick="printReport()">
                            <i class="fas fa-print me-2"></i>طباعة
                        </button>
                        <button class="btn btn-primary" onclick="refreshReport()">
                            <i class="fas fa-sync-alt me-2"></i>تحديث
                        </button>
                    </div>
                </div>
                
                <!-- Filters -->
                <div class="card mb-4">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">من تاريخ</label>
                                <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($date_from) ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">إلى تاريخ</label>
                                <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($date_to) ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">نوع التقرير</label>
                                <select name="report_type" class="form-select">
                                    <option value="overview" <?= $report_type === 'overview' ? 'selected' : '' ?>>نظرة عامة</option>
                                    <option value="sales" <?= $report_type === 'sales' ? 'selected' : '' ?>>المبيعات</option>
                                    <option value="products" <?= $report_type === 'products' ? 'selected' : '' ?>>المنتجات</option>
                                    <option value="users" <?= $report_type === 'users' ? 'selected' : '' ?>>المستخدمين</option>
                                    <option value="payments" <?= $report_type === 'payments' ? 'selected' : '' ?>>طرق الدفع</option>
                                </select>
                            </div>
                            <div class="col-md-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary me-2">
                                    <i class="fas fa-search me-1"></i>تطبيق
                                </button>
                                <a href="reports.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-times me-1"></i>مسح
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
                
                <!-- Overall Statistics -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-right-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col me-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">إجمالي الطلبات</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($overall_stats['total_orders']) ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-shopping-cart fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-right-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col me-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">الطلبات المكتملة</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($overall_stats['completed_orders']) ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-right-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col me-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">إجمالي الإيرادات</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= formatCurrency($overall_stats['total_revenue']) ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-right-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col me-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">متوسط قيمة الطلب</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= formatCurrency($overall_stats['avg_order_value']) ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-chart-line fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Charts Row -->
                <div class="row mb-4">
                    <div class="col-xl-8 col-lg-7">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">المبيعات اليومية</h6>
                            </div>
                            <div class="card-body">
                                <canvas id="salesChart" width="100%" height="40"></canvas>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-4 col-lg-5">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">الفئات الأكثر مبيعاً</h6>
                            </div>
                            <div class="card-body">
                                <canvas id="categoryChart" width="100%" height="100"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Product Performance -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">أداء المنتجات</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>المنتج</th>
                                        <th>الفئة</th>
                                        <th>إجمالي الطلبات</th>
                                        <th>الطلبات المكتملة</th>
                                        <th>الإيرادات</th>
                                        <th>متوسط قيمة الطلب</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($product_performance as $product): ?>
                                    <tr>
                                        <td>
                                            <strong><?= htmlspecialchars($product['name_ar']) ?></strong><br>
                                            <small class="text-muted"><?= htmlspecialchars($product['name']) ?></small>
                                        </td>
                                        <td><?= htmlspecialchars($product['category_name']) ?></td>
                                        <td><?= number_format($product['total_orders']) ?></td>
                                        <td>
                                            <?= number_format($product['completed_orders']) ?>
                                            <small class="text-muted">
                                                (<?= $product['total_orders'] > 0 ? number_format(($product['completed_orders'] / $product['total_orders']) * 100, 1) : 0 ?>%)
                                            </small>
                                        </td>
                                        <td><?= formatCurrency($product['revenue_yer']) ?></td>
                                        <td><?= formatCurrency($product['avg_order_value']) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Top Users -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">أفضل العملاء</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>المستخدم</th>
                                        <th>البريد الإلكتروني</th>
                                        <th>تاريخ التسجيل</th>
                                        <th>عدد الطلبات</th>
                                        <th>إجمالي الإنفاق</th>
                                        <th>آخر طلب</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($top_users as $user): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($user['username']) ?></td>
                                        <td><?= htmlspecialchars($user['email']) ?></td>
                                        <td><?= date('Y-m-d', strtotime($user['registration_date'])) ?></td>
                                        <td><?= number_format($user['total_orders']) ?></td>
                                        <td><?= formatCurrency($user['total_spent']) ?></td>
                                        <td><?= $user['last_order_date'] ? date('Y-m-d', strtotime($user['last_order_date'])) : '-' ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Payment Methods -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">طرق الدفع</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>طريقة الدفع</th>
                                        <th>إجمالي المعاملات</th>
                                        <th>المعاملات الناجحة</th>
                                        <th>معدل النجاح</th>
                                        <th>الإيرادات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($payment_methods as $method): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($method['payment_method'] ?: 'غير محدد') ?></td>
                                        <td><?= number_format($method['total_transactions']) ?></td>
                                        <td><?= number_format($method['successful_transactions']) ?></td>
                                        <td>
                                            <?php 
                                            $success_rate = $method['total_transactions'] > 0 ? 
                                                ($method['successful_transactions'] / $method['total_transactions']) * 100 : 0;
                                            ?>
                                            <span class="badge bg-<?= $success_rate >= 90 ? 'success' : ($success_rate >= 70 ? 'warning' : 'danger') ?>">
                                                <?= number_format($success_rate, 1) ?>%
                                            </span>
                                        </td>
                                        <td><?= formatCurrency($method['revenue_yer']) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Sales Chart
        const salesCtx = document.getElementById('salesChart').getContext('2d');
        const salesChart = new Chart(salesCtx, {
            type: 'line',
            data: {
                labels: [<?php echo "'" . implode("','", array_reverse(array_column($daily_sales, 'date'))) . "'"; ?>],
                datasets: [{
                    label: 'الطلبات',
                    data: [<?php echo implode(',', array_reverse(array_column($daily_sales, 'total_orders'))); ?>],
                    borderColor: 'rgb(75, 192, 192)',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    tension: 0.1
                }, {
                    label: 'الطلبات المكتملة',
                    data: [<?php echo implode(',', array_reverse(array_column($daily_sales, 'completed_orders'))); ?>],
                    borderColor: 'rgb(54, 162, 235)',
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'المبيعات اليومية'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        // Category Chart
        const categoryCtx = document.getElementById('categoryChart').getContext('2d');
        const categoryChart = new Chart(categoryCtx, {
            type: 'doughnut',
            data: {
                labels: [<?php echo "'" . implode("','", array_column($category_performance, 'category_name')) . "'"; ?>],
                datasets: [{
                    data: [<?php echo implode(',', array_column($category_performance, 'revenue_yer')); ?>],
                    backgroundColor: [
                        '#FF6384',
                        '#36A2EB',
                        '#FFCE56',
                        '#4BC0C0',
                        '#9966FF',
                        '#FF9F40'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
        
        function exportReport() {
            const params = new URLSearchParams(window.location.search);
            params.set('export', 'pdf');
            window.open('export_report.php?' + params.toString(), '_blank');
        }
        
        function printReport() {
            window.print();
        }
        
        function refreshReport() {
            location.reload();
        }
    </script>
</body>
</html>
