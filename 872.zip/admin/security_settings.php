<?php
require_once '../config/config.php';

if (!isAdmin()) {
    redirect('login.php');
}

$admin = getCurrentAdmin();
$message = '';
$error = '';

// تغيير كلمة المرور
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    try {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // التحقق من كلمة المرور الحالية
        if (!password_verify($current_password, $admin['password'])) {
            throw new Exception('كلمة المرور الحالية غير صحيحة');
        }
        
        // التحقق من تطابق كلمة المرور الجديدة
        if ($new_password !== $confirm_password) {
            throw new Exception('كلمة المرور الجديدة غير متطابقة');
        }
        
        // التحقق من قوة كلمة المرور
        if (strlen($new_password) < 8) {
            throw new Exception('كلمة المرور يجب أن تكون 8 أحرف على الأقل');
        }
        
        // تحديث كلمة المرور
        $stmt = $pdo->prepare("UPDATE admin_users SET password = ? WHERE id = ?");
        $stmt->execute([password_hash($new_password, PASSWORD_DEFAULT), $admin['id']]);
        
        $message = 'تم تغيير كلمة المرور بنجاح';
        
        // تسجيل النشاط
        logActivity(null, $admin['id'], 'password_change', 'تم تغيير كلمة مرور المدير');
        
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// إنشاء مدير جديد
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_admin'])) {
    try {
        $username = sanitize($_POST['username']);
        $email = sanitize($_POST['email']);
        $full_name = sanitize($_POST['full_name']);
        $password = $_POST['password'];
        $role = sanitize($_POST['role']);
        
        // التحقق من عدم وجود المستخدم
        $stmt = $pdo->prepare("SELECT id FROM admin_users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            throw new Exception('اسم المستخدم أو البريد الإلكتروني موجود مسبقاً');
        }
        
        // إنشاء المدير الجديد
        $stmt = $pdo->prepare("
            INSERT INTO admin_users (username, email, full_name, password, role, status) 
            VALUES (?, ?, ?, ?, ?, 'active')
        ");
        $stmt->execute([$username, $email, $full_name, password_hash($password, PASSWORD_DEFAULT), $role]);
        
        $message = 'تم إنشاء المدير الجديد بنجاح';
        
        // تسجيل النشاط
        logActivity(null, $admin['id'], 'admin_created', 'تم إنشاء مدير جديد: ' . $username);
        
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// تحديث إعدادات الأمان
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_security'])) {
    try {
        $max_login_attempts = (int)$_POST['max_login_attempts'];
        $lockout_duration = (int)$_POST['lockout_duration'];
        $session_timeout = (int)$_POST['session_timeout'];
        $require_2fa = isset($_POST['require_2fa']) ? 1 : 0;
        
        // تحديث الإعدادات
        updateSystemSetting('max_login_attempts', $max_login_attempts, 'security');
        updateSystemSetting('lockout_duration', $lockout_duration, 'security');
        updateSystemSetting('session_timeout', $session_timeout, 'security');
        updateSystemSetting('require_2fa', $require_2fa, 'security');
        
        $message = 'تم تحديث إعدادات الأمان بنجاح';
        
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// جلب إعدادات الأمان الحالية
$security_settings = [
    'max_login_attempts' => getSystemSetting('max_login_attempts', 5),
    'lockout_duration' => getSystemSetting('lockout_duration', 15),
    'session_timeout' => getSystemSetting('session_timeout', 60),
    'require_2fa' => getSystemSetting('require_2fa', 0)
];

// جلب قائمة المديرين
$stmt = $pdo->query("SELECT id, username, email, full_name, role, status, created_at, last_login FROM admin_users ORDER BY created_at DESC");
$admins = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إعدادات الأمان - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">إعدادات الأمان</h1>
                </div>

                <?php if ($message): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <!-- تغيير كلمة المرور -->
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="fas fa-key me-2"></i>تغيير كلمة المرور</h5>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <div class="mb-3">
                                        <label for="current_password" class="form-label">كلمة المرور الحالية</label>
                                        <input type="password" class="form-control" id="current_password" name="current_password" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="new_password" class="form-label">كلمة المرور الجديدة</label>
                                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                                        <div class="form-text">يجب أن تكون 8 أحرف على الأقل</div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="confirm_password" class="form-label">تأكيد كلمة المرور</label>
                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                    </div>
                                    <button type="submit" name="change_password" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>تغيير كلمة المرور
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- إعدادات الأمان العامة -->
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5><i class="fas fa-shield-alt me-2"></i>إعدادات الأمان العامة</h5>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <div class="mb-3">
                                        <label for="max_login_attempts" class="form-label">عدد محاولات تسجيل الدخول</label>
                                        <input type="number" class="form-control" id="max_login_attempts" name="max_login_attempts" 
                                               value="<?php echo $security_settings['max_login_attempts']; ?>" min="3" max="10">
                                    </div>
                                    <div class="mb-3">
                                        <label for="lockout_duration" class="form-label">مدة القفل (بالدقائق)</label>
                                        <input type="number" class="form-control" id="lockout_duration" name="lockout_duration" 
                                               value="<?php echo $security_settings['lockout_duration']; ?>" min="5" max="60">
                                    </div>
                                    <div class="mb-3">
                                        <label for="session_timeout" class="form-label">انتهاء الجلسة (بالدقائق)</label>
                                        <input type="number" class="form-control" id="session_timeout" name="session_timeout" 
                                               value="<?php echo $security_settings['session_timeout']; ?>" min="15" max="480">
                                    </div>
                                    <div class="mb-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="require_2fa" name="require_2fa" 
                                                   <?php echo $security_settings['require_2fa'] ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="require_2fa">
                                                تفعيل المصادقة الثنائية (قريباً)
                                            </label>
                                        </div>
                                    </div>
                                    <button type="submit" name="update_security" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>حفظ الإعدادات
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- إنشاء مدير جديد -->
                <?php if ($admin['role'] == 'super_admin'): ?>
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><i class="fas fa-user-plus me-2"></i>إنشاء مدير جديد</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" class="row g-3">
                            <div class="col-md-3">
                                <label for="username" class="form-label">اسم المستخدم</label>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            <div class="col-md-3">
                                <label for="email" class="form-label">البريد الإلكتروني</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="col-md-3">
                                <label for="full_name" class="form-label">الاسم الكامل</label>
                                <input type="text" class="form-control" id="full_name" name="full_name" required>
                            </div>
                            <div class="col-md-3">
                                <label for="role" class="form-label">الدور</label>
                                <select class="form-select" id="role" name="role" required>
                                    <option value="admin">مدير</option>
                                    <option value="super_admin">مدير عام</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="password" class="form-label">كلمة المرور</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="col-md-6 d-flex align-items-end">
                                <button type="submit" name="create_admin" class="btn btn-success">
                                    <i class="fas fa-user-plus me-2"></i>إنشاء المدير
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- قائمة المديرين -->
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-users me-2"></i>قائمة المديرين</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>اسم المستخدم</th>
                                        <th>الاسم الكامل</th>
                                        <th>البريد الإلكتروني</th>
                                        <th>الدور</th>
                                        <th>الحالة</th>
                                        <th>آخر دخول</th>
                                        <th>تاريخ الإنشاء</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($admins as $admin_user): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($admin_user['username']); ?></td>
                                        <td><?php echo htmlspecialchars($admin_user['full_name']); ?></td>
                                        <td><?php echo htmlspecialchars($admin_user['email']); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $admin_user['role'] == 'super_admin' ? 'danger' : 'primary'; ?>">
                                                <?php echo $admin_user['role'] == 'super_admin' ? 'مدير عام' : 'مدير'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo $admin_user['status'] == 'active' ? 'success' : 'secondary'; ?>">
                                                <?php echo $admin_user['status'] == 'active' ? 'نشط' : 'معطل'; ?>
                                            </span>
                                        </td>
                                        <td><?php echo $admin_user['last_login'] ? date('Y-m-d H:i', strtotime($admin_user['last_login'])) : 'لم يسجل دخول'; ?></td>
                                        <td><?php echo date('Y-m-d', strtotime($admin_user['created_at'])); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
