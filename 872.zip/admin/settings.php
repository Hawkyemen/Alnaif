<?php
require_once '../config/config.php';

if (!isAdmin()) {
    redirect('login.php');
}

$message = '';
$error = '';

// معالجة تحديث الإعدادات
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_settings'])) {
    try {
        // تحديث اسم الموقع
        $site_name = sanitize($_POST['site_name']);
        $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'site_name'");
        $stmt->execute([$site_name]);
        
        // تحديث وصف الموقع
        $site_description = sanitize($_POST['site_description']);
        $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'site_description'");
        $stmt->execute([$site_description]);
        
        // تحديث الكلمات المفتاحية
        $site_keywords = sanitize($_POST['site_keywords']);
        $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'site_keywords'");
        $stmt->execute([$site_keywords]);
        
        // تحديث البريد الإلكتروني للتواصل
        $contact_email = sanitize($_POST['contact_email']);
        $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'contact_email'");
        $stmt->execute([$contact_email]);
        
        // تحديث رقم الهاتف
        $contact_phone = sanitize($_POST['contact_phone']);
        $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'contact_phone'");
        $stmt->execute([$contact_phone]);
        
        // تحديث حالة الصيانة
        $maintenance_mode = isset($_POST['maintenance_mode']) ? 1 : 0;
        $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'maintenance_mode'");
        $stmt->execute([$maintenance_mode]);
        
        // تحديث حالة التسجيل
        $registration_enabled = isset($_POST['registration_enabled']) ? 1 : 0;
        $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'registration_enabled'");
        $stmt->execute([$registration_enabled]);
        
        // تحديث حالة التحقق من الإيميل
        $email_verification_required = isset($_POST['email_verification_required']) ? 1 : 0;
        $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'email_verification_required'");
        $stmt->execute([$email_verification_required]);
        
        $message = 'تم تحديث الإعدادات بنجاح';
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// جلب الإعدادات
$settings = [];
$stmt = $pdo->query("SELECT setting_key, setting_value FROM system_settings");
while ($row = $stmt->fetch()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إعدادات النظام - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">إعدادات النظام</h1>
                </div>

                <?php if ($message): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- نموذج تحديث الإعدادات -->
                <div class="card">
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label for="site_name" class="form-label">اسم الموقع</label>
                                <input type="text" class="form-control" id="site_name" name="site_name" value="<?php echo htmlspecialchars($settings['site_name'] ?? ''); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="site_description" class="form-label">وصف الموقع</label>
                                <textarea class="form-control" id="site_description" name="site_description" rows="3"><?php echo htmlspecialchars($settings['site_description'] ?? ''); ?></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label for="site_keywords" class="form-label">الكلمات المفتاحية</label>
                                <input type="text" class="form-control" id="site_keywords" name="site_keywords" value="<?php echo htmlspecialchars($settings['site_keywords'] ?? ''); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="contact_email" class="form-label">البريد الإلكتروني للتواصل</label>
                                <input type="email" class="form-control" id="contact_email" name="contact_email" value="<?php echo htmlspecialchars($settings['contact_email'] ?? ''); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="contact_phone" class="form-label">رقم الهاتف</label>
                                <input type="text" class="form-control" id="contact_phone" name="contact_phone" value="<?php echo htmlspecialchars($settings['contact_phone'] ?? ''); ?>">
                            </div>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="maintenance_mode" name="maintenance_mode" <?php echo isset($settings['maintenance_mode']) && $settings['maintenance_mode'] == 1 ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="maintenance_mode">وضع الصيانة</label>
                            </div>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="registration_enabled" name="registration_enabled" <?php echo isset($settings['registration_enabled']) && $settings['registration_enabled'] == 1 ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="registration_enabled">تفعيل التسجيل</label>
                            </div>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="email_verification_required" name="email_verification_required" <?php echo isset($settings['email_verification_required']) && $settings['email_verification_required'] == 1 ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="email_verification_required">تفعيل التحقق من الإيميل</label>
                            </div>
                            
                            <button type="submit" name="update_settings" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>حفظ التغييرات
                            </button>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
