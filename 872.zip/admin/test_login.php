<?php
require_once '../config/config.php';

// اختبار تسجيل دخول المدير
$test_results = [];

// اختبار 1: فحص اتصال قاعدة البيانات
try {
    $stmt = $pdo->query("SELECT 1");
    $test_results['database'] = [
        'status' => 'success',
        'message' => 'اتصال قاعدة البيانات يعمل بشكل صحيح'
    ];
} catch (Exception $e) {
    $test_results['database'] = [
        'status' => 'error',
        'message' => 'خطأ في اتصال قاعدة البيانات: ' . $e->getMessage()
    ];
}

// اختبار 2: فحص وجود جدول المديرين
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'admin_users'");
    if ($stmt->rowCount() > 0) {
        $test_results['admin_table'] = [
            'status' => 'success',
            'message' => 'جدول المديرين موجود'
        ];
        
        // فحص المدير الافتراضي
        $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE username = 'admin'");
        $stmt->execute();
        $admin = $stmt->fetch();
        
        if ($admin) {
            $test_results['default_admin'] = [
                'status' => 'success',
                'message' => 'المدير الافتراضي موجود - اسم المستخدم: admin'
            ];
        } else {
            // إنشاء المدير الافتراضي
            $stmt = $pdo->prepare("
                INSERT INTO admin_users (username, email, password, full_name, role, status) 
                VALUES ('admin', 'admin@faststarone.com', ?, 'مدير النظام', 'super_admin', 'active')
            ");
            $stmt->execute([password_hash('admin123', PASSWORD_DEFAULT)]);
            
            $test_results['default_admin'] = [
                'status' => 'success',
                'message' => 'تم إنشاء المدير الافتراضي - اسم المستخدم: admin، كلمة المرور: admin123'
            ];
        }
    } else {
        $test_results['admin_table'] = [
            'status' => 'error',
            'message' => 'جدول المديرين غير موجود'
        ];
    }
} catch (Exception $e) {
    $test_results['admin_table'] = [
        'status' => 'error',
        'message' => 'خطأ في فحص جدول المديرين: ' . $e->getMessage()
    ];
}

// اختبار 3: اختبار تسجيل الدخول
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['test_login'])) {
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    
    try {
        $stmt = $pdo->prepare("SELECT id, username, password, full_name, role, status FROM admin_users WHERE username = ?");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();
        
        if ($admin && password_verify($password, $admin['password'])) {
            $test_results['login_test'] = [
                'status' => 'success',
                'message' => 'تسجيل الدخول نجح! مرحباً ' . $admin['full_name']
            ];
        } else {
            $test_results['login_test'] = [
                'status' => 'error',
                'message' => 'فشل تسجيل الدخول - تحقق من اسم المستخدم وكلمة المرور'
            ];
        }
    } catch (Exception $e) {
        $test_results['login_test'] = [
            'status' => 'error',
            'message' => 'خطأ في اختبار تسجيل الدخول: ' . $e->getMessage()
        ];
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>اختبار تسجيل دخول المدير - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px 0;
        }
        .test-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            padding: 30px;
            margin-bottom: 20px;
        }
        .test-result {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 15px;
            border-left: 4px solid;
        }
        .test-result.success {
            background-color: #d4edda;
            border-color: #28a745;
            color: #155724;
        }
        .test-result.error {
            background-color: #f8d7da;
            border-color: #dc3545;
            color: #721c24;
        }
        .test-result.warning {
            background-color: #fff3cd;
            border-color: #ffc107;
            color: #856404;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="test-container">
                    <h2 class="text-center mb-4">
                        <i class="fas fa-shield-alt text-primary"></i>
                        اختبار تسجيل دخول المدير
                    </h2>
                    
                    <!-- نتائج الاختبارات التلقائية -->
                    <h4>نتائج الاختبارات التلقائية:</h4>
                    
                    <?php foreach ($test_results as $test_name => $result): ?>
                        <div class="test-result <?php echo $result['status']; ?>">
                            <i class="fas fa-<?php echo $result['status'] == 'success' ? 'check-circle' : 'exclamation-triangle'; ?> me-2"></i>
                            <?php echo $result['message']; ?>
                        </div>
                    <?php endforeach; ?>
                    
                    <!-- نموذج اختبار تسجيل الدخول -->
                    <div class="mt-4">
                        <h4>اختبار تسجيل الدخول:</h4>
                        <form method="POST" class="row g-3">
                            <div class="col-md-6">
                                <label for="username" class="form-label">اسم المستخدم</label>
                                <input type="text" class="form-control" id="username" name="username" 
                                       value="admin" required>
                            </div>
                            <div class="col-md-6">
                                <label for="password" class="form-label">كلمة المرور</label>
                                <input type="password" class="form-control" id="password" name="password" 
                                       value="admin123" required>
                            </div>
                            <div class="col-12">
                                <button type="submit" name="test_login" class="btn btn-primary">
                                    <i class="fas fa-sign-in-alt me-2"></i>
                                    اختبار تسجيل الدخول
                                </button>
                            </div>
                        </form>
                    </div>
                    
                    <!-- روابط مفيدة -->
                    <div class="mt-4 text-center">
                        <a href="login.php" class="btn btn-success me-2">
                            <i class="fas fa-sign-in-alt me-2"></i>
                            الذهاب لصفحة تسجيل الدخول
                        </a>
                        <a href="../index.php" class="btn btn-secondary">
                            <i class="fas fa-home me-2"></i>
                            العودة للصفحة الرئيسية
                        </a>
                    </div>
                    
                    <!-- معلومات إضافية -->
                    <div class="mt-4">
                        <h5>معلومات النظام:</h5>
                        <ul class="list-unstyled">
                            <li><strong>إصدار PHP:</strong> <?php echo PHP_VERSION; ?></li>
                            <li><strong>خادم قاعدة البيانات:</strong> <?php echo DB_HOST; ?></li>
                            <li><strong>اسم قاعدة البيانات:</strong> <?php echo DB_NAME; ?></li>
                            <li><strong>اسم الموقع:</strong> <?php echo SITE_NAME; ?></li>
                            <li><strong>رابط الموقع:</strong> <?php echo SITE_URL; ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
