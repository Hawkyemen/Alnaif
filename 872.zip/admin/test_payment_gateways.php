<?php
session_start();
require_once '../config/config.php';
require_once '../config/payment_config.php';

// Check admin authentication
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$db = Database::getInstance()->getConnection();

// Handle test execution
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['run_test'])) {
    $testType = $_POST['test_type'];
    $testResult = runPaymentTest($testType, $_POST);
    
    // Save test result to database
    $stmt = $db->prepare("
        INSERT INTO payment_gateway_tests (admin_id, gateway_code, test_type, test_data, result, status) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $_SESSION['admin_id'],
        $testResult['gateway'],
        $testType,
        json_encode($_POST),
        json_encode($testResult),
        $testResult['status']
    ]);
}

// Get recent test results
$stmt = $db->prepare("
    SELECT pgt.*, a.username as admin_name 
    FROM payment_gateway_tests pgt 
    LEFT JOIN admins a ON pgt.admin_id = a.id 
    ORDER BY pgt.created_at DESC 
    LIMIT 20
");
$stmt->execute();
$recentTests = $stmt->fetchAll(PDO::FETCH_ASSOC);

function runPaymentTest($testType, $data) {
    switch ($testType) {
        case 'card_validation':
            return testCardValidation($data);
        case 'apple_pay_config':
            return testApplePayConfig();
        case 'google_play_config':
            return testGooglePlayConfig();
        case 'stripe_connection':
            return testStripeConnection();
        case 'paypal_connection':
            return testPayPalConnection();
        case 'mada_connection':
            return testMadaConnection();
        case 'wallet_topup':
            return testWalletTopup($data);
        default:
            return ['status' => 'fail', 'gateway' => 'unknown', 'message' => 'Unknown test type'];
    }
}

function testCardValidation($data) {
    $cardNumber = preg_replace('/\D/', '', $data['card_number'] ?? '');
    $cvv = $data['cvv'] ?? '';
    $expiry = $data['expiry'] ?? '';
    
    $errors = [];
    
    // Luhn algorithm validation
    if (!validateLuhn($cardNumber)) {
        $errors[] = 'رقم البطاقة غير صحيح (Luhn algorithm)';
    }
    
    // CVV validation
    if (!preg_match('/^\d{3,4}$/', $cvv)) {
        $errors[] = 'رمز CVV غير صحيح';
    }
    
    // Expiry validation
    if (!preg_match('/^(0[1-9]|1[0-2])\/\d{2}$/', $expiry)) {
        $errors[] = 'تاريخ الانتهاء غير صحيح';
    } else {
        list($month, $year) = explode('/', $expiry);
        $expiryDate = new DateTime('20' . $year . '-' . $month . '-01');
        if ($expiryDate < new DateTime()) {
            $errors[] = 'البطاقة منتهية الصلاحية';
        }
    }
    
    $cardType = detectCardType($cardNumber);
    
    return [
        'status' => empty($errors) ? 'pass' : 'fail',
        'gateway' => 'card_validation',
        'message' => empty($errors) ? "بطاقة $cardType صحيحة" : implode(', ', $errors),
        'card_type' => $cardType,
        'errors' => $errors
    ];
}

function testApplePayConfig() {
    $errors = [];
    
    // Check configuration constants
    if (!defined('APPLE_BUNDLE_ID') || empty(APPLE_BUNDLE_ID)) {
        $errors[] = 'APPLE_BUNDLE_ID غير محدد';
    }
    
    if (!defined('APPLE_SHARED_SECRET') || empty(APPLE_SHARED_SECRET)) {
        $errors[] = 'APPLE_SHARED_SECRET غير محدد';
    }
    
    // Check domain verification file
    $domainFile = '../.well-known/apple-developer-merchantid-domain-association';
    if (!file_exists($domainFile)) {
        $errors[] = 'ملف التحقق من النطاق غير موجود';
    }
    
    // Check certificates (if in production)
    if (defined('APPLE_PAY_ENVIRONMENT') && APPLE_PAY_ENVIRONMENT === 'production') {
        $certPath = '../config/certificates/apple_pay_merchant.pem';
        if (!file_exists($certPath)) {
            $errors[] = 'شهادة Apple Pay غير موجودة';
        }
    }
    
    return [
        'status' => empty($errors) ? 'pass' : 'fail',
        'gateway' => 'apple_pay',
        'message' => empty($errors) ? 'إعداد Apple Pay صحيح' : implode(', ', $errors),
        'errors' => $errors
    ];
}

function testGooglePlayConfig() {
    $errors = [];
    
    // Check configuration constants
    if (!defined('GOOGLE_PLAY_PACKAGE_NAME') || empty(GOOGLE_PLAY_PACKAGE_NAME)) {
        $errors[] = 'GOOGLE_PLAY_PACKAGE_NAME غير محدد';
    }
    
    if (!defined('GOOGLE_PLAY_SERVICE_ACCOUNT_KEY') || empty(GOOGLE_PLAY_SERVICE_ACCOUNT_KEY)) {
        $errors[] = 'GOOGLE_PLAY_SERVICE_ACCOUNT_KEY غير محدد';
    } else {
        $serviceAccount = json_decode(GOOGLE_PLAY_SERVICE_ACCOUNT_KEY, true);
        if (!$serviceAccount || !isset($serviceAccount['client_email'])) {
            $errors[] = 'مفتاح حساب الخدمة غير صحيح';
        }
    }
    
    return [
        'status' => empty($errors) ? 'pass' : 'fail',
        'gateway' => 'google_play',
        'message' => empty($errors) ? 'إعداد Google Play صحيح' : implode(', ', $errors),
        'errors' => $errors
    ];
}

function testStripeConnection() {
    $errors = [];
    
    if (!defined('STRIPE_SECRET_KEY') || empty(STRIPE_SECRET_KEY)) {
        $errors[] = 'STRIPE_SECRET_KEY غير محدد';
    }
    
    if (!defined('STRIPE_PUBLISHABLE_KEY') || empty(STRIPE_PUBLISHABLE_KEY)) {
        $errors[] = 'STRIPE_PUBLISHABLE_KEY غير محدد';
    }
    
    // Test API connection (if keys are available)
    if (empty($errors)) {
        try {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => 'https://api.stripe.com/v1/payment_methods',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer ' . STRIPE_SECRET_KEY,
                    'Content-Type: application/x-www-form-urlencoded'
                ],
                CURLOPT_POSTFIELDS => 'type=card',
                CURLOPT_TIMEOUT => 10
            ]);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode !== 200) {
                $errors[] = 'فشل الاتصال بـ Stripe API';
            }
        } catch (Exception $e) {
            $errors[] = 'خطأ في الاتصال: ' . $e->getMessage();
        }
    }
    
    return [
        'status' => empty($errors) ? 'pass' : 'fail',
        'gateway' => 'stripe',
        'message' => empty($errors) ? 'اتصال Stripe صحيح' : implode(', ', $errors),
        'errors' => $errors
    ];
}

function testPayPalConnection() {
    $errors = [];
    
    if (!defined('PAYPAL_CLIENT_ID') || empty(PAYPAL_CLIENT_ID)) {
        $errors[] = 'PAYPAL_CLIENT_ID غير محدد';
    }
    
    if (!defined('PAYPAL_CLIENT_SECRET') || empty(PAYPAL_CLIENT_SECRET)) {
        $errors[] = 'PAYPAL_CLIENT_SECRET غير محدد';
    }
    
    return [
        'status' => empty($errors) ? 'pass' : 'fail',
        'gateway' => 'paypal',
        'message' => empty($errors) ? 'إعداد PayPal صحيح' : implode(', ', $errors),
        'errors' => $errors
    ];
}

function testMadaConnection() {
    $errors = [];
    
    if (!defined('MADA_MERCHANT_ID') || empty(MADA_MERCHANT_ID)) {
        $errors[] = 'MADA_MERCHANT_ID غير محدد';
    }
    
    if (!defined('MADA_SECRET_KEY') || empty(MADA_SECRET_KEY)) {
        $errors[] = 'MADA_SECRET_KEY غير محدد';
    }
    
    return [
        'status' => empty($errors) ? 'pass' : 'fail',
        'gateway' => 'mada',
        'message' => empty($errors) ? 'إعداد مدى صحيح' : implode(', ', $errors),
        'errors' => $errors
    ];
}

function testWalletTopup($data) {
    $amount = (float)($data['amount'] ?? 0);
    $currency = $data['currency'] ?? 'SAR';
    
    if ($amount <= 0) {
        return [
            'status' => 'fail',
            'gateway' => 'wallet',
            'message' => 'المبلغ يجب أن يكون أكبر من صفر'
        ];
    }
    
    if (!in_array($currency, ['SAR', 'USD', 'AED', 'YER'])) {
        return [
            'status' => 'fail',
            'gateway' => 'wallet',
            'message' => 'العملة غير مدعومة'
        ];
    }
    
    return [
        'status' => 'pass',
        'gateway' => 'wallet',
        'message' => "اختبار شحن $amount $currency نجح"
    ];
}

function validateLuhn($number) {
    $sum = 0;
    $alternate = false;
    
    for ($i = strlen($number) - 1; $i >= 0; $i--) {
        $n = intval($number[$i]);
        if ($alternate) {
            $n *= 2;
            if ($n > 9) $n = ($n % 10) + 1;
        }
        $sum += $n;
        $alternate = !$alternate;
    }
    
    return ($sum % 10) === 0;
}

function detectCardType($number) {
    if (preg_match('/^4/', $number)) return 'Visa';
    if (preg_match('/^5[1-5]/', $number)) return 'Mastercard';
    if (preg_match('/^3[47]/', $number)) return 'American Express';
    if (preg_match('/^(400861|401757|407197)/', $number)) return 'Mada';
    return 'Unknown';
}

include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">🧪 اختبار بوابات الدفع الشامل</h3>
                </div>
                <div class="card-body">
                    
                    <!-- Test Cards Section -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="card border-primary">
                                <div class="card-header bg-primary text-white">
                                    <h5>💳 اختبار البطاقات البنكية</h5>
                                </div>
                                <div class="card-body">
                                    <form method="POST">
                                        <input type="hidden" name="test_type" value="card_validation">
                                        <div class="form-group">
                                            <label>رقم البطاقة</label>
                                            <select class="form-control" name="card_number" onchange="fillCardDetails(this.value)">
                                                <option value="">اختر بطاقة اختبار</option>
                                                <option value="4111111111111111">Visa - 4111 1111 1111 1111</option>
                                                <option value="5555555555554444">Mastercard - 5555 5555 5555 4444</option>
                                                <option value="378282246310005">Amex - 3782 822463 10005</option>
                                                <option value="4008610000000001">Mada - 4008 6100 0000 0001</option>
                                                <option value="4000000000000002">Visa Declined - 4000 0000 0000 0002</option>
                                            </select>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>CVV</label>
                                                    <input type="text" class="form-control" name="cvv" id="cvv" placeholder="123" maxlength="4">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>تاريخ الانتهاء</label>
                                                    <input type="text" class="form-control" name="expiry" id="expiry" placeholder="12/25" maxlength="5">
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit" name="run_test" class="btn btn-primary">اختبار البطاقة</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="card border-success">
                                <div class="card-header bg-success text-white">
                                    <h5>🛍️ اختبار شحن المحفظة</h5>
                                </div>
                                <div class="card-body">
                                    <form method="POST">
                                        <input type="hidden" name="test_type" value="wallet_topup">
                                        <div class="form-group">
                                            <label>المبلغ</label>
                                            <input type="number" class="form-control" name="amount" min="1" max="1000" value="10" required>
                                        </div>
                                        <div class="form-group">
                                            <label>العملة</label>
                                            <select class="form-control" name="currency" required>
                                                <option value="SAR">ريال سعودي (SAR)</option>
                                                <option value="USD">دولار أمريكي (USD)</option>
                                                <option value="AED">درهم إماراتي (AED)</option>
                                                <option value="YER">ريال يمني (YER)</option>
                                            </select>
                                        </div>
                                        <button type="submit" name="run_test" class="btn btn-success">اختبار الشحن</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Gateway Configuration Tests -->
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <div class="card border-info">
                                <div class="card-header bg-info text-white">
                                    <h5>🍎 Apple Pay</h5>
                                </div>
                                <div class="card-body">
                                    <form method="POST">
                                        <input type="hidden" name="test_type" value="apple_pay_config">
                                        <p>اختبار إعداد Apple Pay:</p>
                                        <ul class="small">
                                            <li>Bundle ID</li>
                                            <li>Shared Secret</li>
                                            <li>Domain Verification</li>
                                            <li>Certificates</li>
                                        </ul>
                                        <button type="submit" name="run_test" class="btn btn-info">اختبار Apple Pay</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="card border-warning">
                                <div class="card-header bg-warning text-white">
                                    <h5>🤖 Google Play</h5>
                                </div>
                                <div class="card-body">
                                    <form method="POST">
                                        <input type="hidden" name="test_type" value="google_play_config">
                                        <p>اختبار إعداد Google Play:</p>
                                        <ul class="small">
                                            <li>Package Name</li>
                                            <li>Service Account</li>
                                            <li>API Permissions</li>
                                            <li>Products Setup</li>
                                        </ul>
                                        <button type="submit" name="run_test" class="btn btn-warning">اختبار Google Play</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="card border-secondary">
                                <div class="card-header bg-secondary text-white">
                                    <h5>💰 بوابات أخرى</h5>
                                </div>
                                <div class="card-body">
                                    <div class="btn-group-vertical w-100">
                                        <form method="POST" class="mb-2">
                                            <input type="hidden" name="test_type" value="stripe_connection">
                                            <button type="submit" name="run_test" class="btn btn-outline-primary btn-sm">اختبار Stripe</button>
                                        </form>
                                        <form method="POST" class="mb-2">
                                            <input type="hidden" name="test_type" value="paypal_connection">
                                            <button type="submit" name="run_test" class="btn btn-outline-info btn-sm">اختبار PayPal</button>
                                        </form>
                                        <form method="POST">
                                            <input type="hidden" name="test_type" value="mada_connection">
                                            <button type="submit" name="run_test" class="btn btn-outline-success btn-sm">اختبار مدى</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Test Results -->
                    <?php if (isset($testResult)): ?>
                    <div class="alert alert-<?php echo $testResult['status'] === 'pass' ? 'success' : 'danger'; ?>">
                        <h5>نتيجة الاختبار:</h5>
                        <p><strong>البوابة:</strong> <?php echo htmlspecialchars($testResult['gateway']); ?></p>
                        <p><strong>الرسالة:</strong> <?php echo htmlspecialchars($testResult['message']); ?></p>
                        <?php if (isset($testResult['errors']) && !empty($testResult['errors'])): ?>
                        <p><strong>الأخطاء:</strong></p>
                        <ul>
                            <?php foreach ($testResult['errors'] as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Recent Tests -->
                    <div class="card">
                        <div class="card-header">
                            <h5>📊 نتائج الاختبارات الأخيرة</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>التاريخ</th>
                                            <th>البوابة</th>
                                            <th>نوع الاختبار</th>
                                            <th>النتيجة</th>
                                            <th>المدير</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recentTests as $test): ?>
                                        <tr>
                                            <td><?php echo date('Y-m-d H:i', strtotime($test['created_at'])); ?></td>
                                            <td><?php echo htmlspecialchars($test['gateway_code']); ?></td>
                                            <td><?php echo htmlspecialchars($test['test_type']); ?></td>
                                            <td>
                                                <span class="badge badge-<?php echo $test['status'] === 'pass' ? 'success' : 'danger'; ?>">
                                                    <?php echo $test['status'] === 'pass' ? 'نجح' : 'فشل'; ?>
                                                </span>
                                            </td>
                                            <td><?php echo htmlspecialchars($test['admin_name'] ?? 'غير محدد'); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Setup Instructions -->
                    <div class="row mt-4">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5>📋 دليل الإعداد للإنتاج</h5>
                                </div>
                                <div class="card-body">
                                    <div class="accordion" id="setupAccordion">
                                        
                                        <!-- Apple Pay Setup -->
                                        <div class="card">
                                            <div class="card-header" id="applePayHeading">
                                                <h6 class="mb-0">
                                                    <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#applePaySetup">
                                                        🍎 إعداد Apple Pay للإنتاج
                                                    </button>
                                                </h6>
                                            </div>
                                            <div id="applePaySetup" class="collapse" data-parent="#setupAccordion">
                                                <div class="card-body">
                                                    <ol>
                                                        <li><strong>إنشاء Merchant ID:</strong> في Apple Developer Console</li>
                                                        <li><strong>إنشاء الشهادات:</strong> Payment Processing Certificate و Merchant Identity Certificate</li>
                                                        <li><strong>التحقق من النطاق:</strong> رفع ملف التحقق إلى /.well-known/</li>
                                                        <li><strong>تحديث الإعدادات:</strong> في config/apple_pay_config.php</li>
                                                        <li><strong>الاختبار:</strong> في بيئة sandbox أولاً</li>
                                                    </ol>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Google Play Setup -->
                                        <div class="card">
                                            <div class="card-header" id="googlePlayHeading">
                                                <h6 class="mb-0">
                                                    <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#googlePlaySetup">
                                                        🤖 إعداد Google Play للإنتاج
                                                    </button>
                                                </h6>
                                            </div>
                                            <div id="googlePlaySetup" class="collapse" data-parent="#setupAccordion">
                                                <div class="card-body">
                                                    <ol>
                                                        <li><strong>إنشاء مشروع:</strong> في Google Cloud Console</li>
                                                        <li><strong>تفعيل API:</strong> Google Play Android Publisher API</li>
                                                        <li><strong>إنشاء Service Account:</strong> وتنزيل ملف JSON</li>
                                                        <li><strong>ربط الحساب:</strong> في Google Play Console</li>
                                                        <li><strong>إعداد المنتجات:</strong> في Play Console</li>
                                                    </ol>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Bank Cards Setup -->
                                        <div class="card">
                                            <div class="card-header" id="bankCardsHeading">
                                                <h6 class="mb-0">
                                                    <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#bankCardsSetup">
                                                        💳 إعداد البطاقات البنكية
                                                    </button>
                                                </h6>
                                            </div>
                                            <div id="bankCardsSetup" class="collapse" data-parent="#setupAccordion">
                                                <div class="card-body">
                                                    <ol>
                                                        <li><strong>Stripe:</strong> إنشاء حساب وتفعيل الدفع في السعودية</li>
                                                        <li><strong>مدى:</strong> التسجيل مع مزود خدمة مدى معتمد</li>
                                                        <li><strong>SSL:</strong> تأكيد تفعيل HTTPS</li>
                                                        <li><strong>PCI Compliance:</strong> التأكد من الامتثال لمعايير PCI</li>
                                                        <li><strong>Webhooks:</strong> إعداد webhooks للتحديثات</li>
                                                    </ol>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function fillCardDetails(cardNumber) {
    const cvvField = document.getElementById('cvv');
    const expiryField = document.getElementById('expiry');
    
    // Set default values for test cards
    if (cardNumber) {
        if (cardNumber.startsWith('37')) { // Amex
            cvvField.value = '1234';
        } else {
            cvvField.value = '123';
        }
        expiryField.value = '12/25';
    } else {
        cvvField.value = '';
        expiryField.value = '';
    }
}

// Auto-format expiry date
document.getElementById('expiry').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length >= 2) {
        value = value.substring(0, 2) + '/' + value.substring(2, 4);
    }
    e.target.value = value;
});

// Auto-format CVV
document.getElementById('cvv').addEventListener('input', function(e) {
    e.target.value = e.target.value.replace(/\D/g, '');
});
</script>

<?php include 'includes/footer.php'; ?>
