<?php
session_start();
require_once '../config/database.php';
require_once '../config/config.php';

// التحقق من تسجيل الدخول
if (!isAdminLoggedIn()) {
    redirect('login.php');
}

$admin = getCurrentAdmin();
$db = Database::getInstance()->getConnection();
$message = '';
$error = '';

// معالجة العمليات
if ($_POST) {
    $action = $_POST['action'] ?? '';
    $user_id = $_POST['user_id'] ?? 0;

    switch ($action) {
        case 'add_user':
            try {
                $stmt = $db->prepare("INSERT INTO users (username, email, password, phone, status, user_type, wallet_balance) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $hashed_password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                $stmt->execute([
                    $_POST['username'],
                    $_POST['email'],
                    $hashed_password,
                    $_POST['phone'],
                    $_POST['status'],
                    $_POST['user_type'],
                    floatval($_POST['wallet_balance'])
                ]);
                
                // إنشاء محفظة للمستخدم
                $user_id = $db->lastInsertId();
                $stmt = $db->prepare("INSERT INTO wallets (user_id, balance, currency, status) VALUES (?, ?, 'YER', 'active')");
                $stmt->execute([$user_id, floatval($_POST['wallet_balance'])]);
                
                $message = "تم إضافة المستخدم بنجاح";
            } catch (Exception $e) {
                $error = "خطأ في إضافة المستخدم: " . $e->getMessage();
            }
            break;
            
        case 'update_user':
            try {
                $sql = "UPDATE users SET username=?, email=?, phone=?, status=?, user_type=?, wallet_balance=? WHERE id=?";
                $params = [$_POST['username'], $_POST['email'], $_POST['phone'], $_POST['status'], $_POST['user_type'], floatval($_POST['wallet_balance']), $_POST['user_id']];
                
                if (!empty($_POST['password'])) {
                    $sql = "UPDATE users SET username=?, email=?, password=?, phone=?, status=?, user_type=?, wallet_balance=? WHERE id=?";
                    $hashed_password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                    $params = [$_POST['username'], $_POST['email'], $hashed_password, $_POST['phone'], $_POST['status'], $_POST['user_type'], floatval($_POST['wallet_balance']), $_POST['user_id']];
                }
                
                $stmt = $db->prepare($sql);
                $stmt->execute($params);
                
                // تحديث رصيد المحفظة
                $stmt = $db->prepare("UPDATE wallets SET balance=? WHERE user_id=?");
                $stmt->execute([floatval($_POST['wallet_balance']), $_POST['user_id']]);
                
                $message = "تم تحديث المستخدم بنجاح";
            } catch (Exception $e) {
                $error = "خطأ في تحديث المستخدم: " . $e->getMessage();
            }
            break;
            
        case 'delete_user':
            try {
                $stmt = $db->prepare("UPDATE users SET status = 'banned' WHERE id=?");
                $stmt->execute([$user_id]);
                $message = "تم حظر المستخدم بنجاح";
            } catch (Exception $e) {
                $error = "خطأ في حذف المستخدم: " . $e->getMessage();
            }
            break;
            
        case 'toggle_status':
            try {
                $stmt = $db->prepare("UPDATE users SET status = CASE WHEN status = 'active' THEN 'inactive' ELSE 'active' END WHERE id=?");
                $stmt->execute([$user_id]);
                $message = "تم تحديث حالة المستخدم بنجاح";
            } catch (Exception $e) {
                $error = "خطأ في تغيير الحالة: " . $e->getMessage();
            }
            break;
    }
}

// البحث والفلترة
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

$where_conditions = [];
$params = [];

if ($search) {
    $where_conditions[] = "(username LIKE ? OR email LIKE ? OR phone LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($status_filter) {
    $where_conditions[] = "status = ?";
    $params[] = $status_filter;
}

$where_clause = $where_conditions ? "WHERE " . implode(" AND ", $where_conditions) : "";

// جلب المستخدمين
$sql = "SELECT u.*, w.balance as wallet_balance, 
        (SELECT COUNT(*) FROM orders WHERE user_id = u.id) as total_orders,
        (SELECT SUM(total_amount) FROM orders WHERE user_id = u.id AND status = 'completed') as total_spent
        FROM users u 
        LEFT JOIN wallets w ON u.id = w.user_id 
        $where_clause 
        ORDER BY u.created_at DESC 
        LIMIT $limit OFFSET $offset";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

// عدد المستخدمين الإجمالي
$count_sql = "SELECT COUNT(*) FROM users u $where_clause";
$count_stmt = $db->prepare($count_sql);
$count_stmt->execute($params);
$total_users = $count_stmt->fetchColumn();
$total_pages = ceil($total_users / $limit);

// إحصائيات
$stats_sql = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
    SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive,
    SUM(CASE WHEN user_type = 'premium' THEN 1 ELSE 0 END) as premium,
    SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) as today
    FROM users";
$stats = $db->query($stats_sql)->fetch();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المستخدمين - لوحة التحكم</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
    <style>
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(45deg, #007bff, #0056b3);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        .status-badge {
            font-size: 0.75rem;
        }
        .user-stats {
            font-size: 0.85rem;
            color: #6c757d;
        }
        .search-box {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .stats-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">إدارة المستخدمين</h1>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
                        <i class="fas fa-plus me-2"></i>إضافة مستخدم جديد
                    </button>
                </div>

                <?php if ($message): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?= htmlspecialchars($message) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?= htmlspecialchars($error) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- إحصائيات سريعة -->
                <div class="row mb-4">
                    <div class="col-md-2">
                        <div class="card stats-card text-center">
                            <div class="card-body">
                                <i class="fas fa-users fa-2x text-primary mb-2"></i>
                                <h4><?= number_format($stats['total']) ?></h4>
                                <small class="text-muted">إجمالي المستخدمين</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="card stats-card text-center">
                            <div class="card-body">
                                <i class="fas fa-user-check fa-2x text-success mb-2"></i>
                                <h4><?= number_format($stats['active']) ?></h4>
                                <small class="text-muted">نشط</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="card stats-card text-center">
                            <div class="card-body">
                                <i class="fas fa-user-times fa-2x text-danger mb-2"></i>
                                <h4><?= number_format($stats['inactive']) ?></h4>
                                <small class="text-muted">غير نشط</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="card stats-card text-center">
                            <div class="card-body">
                                <i class="fas fa-crown fa-2x text-warning mb-2"></i>
                                <h4><?= number_format($stats['premium']) ?></h4>
                                <small class="text-muted">مميز</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="card stats-card text-center">
                            <div class="card-body">
                                <i class="fas fa-user-plus fa-2x text-info mb-2"></i>
                                <h4><?= number_format($stats['today']) ?></h4>
                                <small class="text-muted">اليوم</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- البحث والفلترة -->
                <div class="search-box">
                    <form method="GET" class="row g-3">
                        <div class="col-md-4">
                            <input type="text" class="form-control" name="search" placeholder="البحث بالاسم، الإيميل أو الهاتف" value="<?= htmlspecialchars($search) ?>">
                        </div>
                        <div class="col-md-2">
                            <select name="status" class="form-select">
                                <option value="">جميع الحالات</option>
                                <option value="active" <?= $status_filter === 'active' ? 'selected' : '' ?>>نشط</option>
                                <option value="inactive" <?= $status_filter === 'inactive' ? 'selected' : '' ?>>غير نشط</option>
                                <option value="banned" <?= $status_filter === 'banned' ? 'selected' : '' ?>>محظور</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search me-1"></i>بحث
                            </button>
                        </div>
                        <div class="col-md-2">
                            <a href="users.php" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-times me-1"></i>إلغاء
                            </a>
                        </div>
                    </form>
                </div>

                <!-- جدول المستخدمين -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>ID</th>
                                        <th>المستخدم</th>
                                        <th>الاسم الكامل</th>
                                        <th>البريد الإلكتروني</th>
                                        <th>الهاتف</th>
                                        <th>الحالة</th>
                                        <th>رصيد المحفظة</th>
                                        <th>تاريخ التسجيل</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?= $user['id'] ?></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="user-avatar me-3">
                                                    <?= strtoupper(substr($user['username'], 0, 2)) ?>
                                                </div>
                                                <div>
                                                    <strong><?= htmlspecialchars($user['username']) ?></strong>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?= htmlspecialchars($user['full_name']) ?></td>
                                        <td><?= htmlspecialchars($user['email']) ?></td>
                                        <td><?= htmlspecialchars($user['phone'] ?? 'غير محدد') ?></td>
                                        <td>
                                            <span class="badge bg-<?= $user['status'] === 'active' ? 'success' : ($user['status'] === 'inactive' ? 'warning' : 'danger') ?>">
                                                <?= $user['status'] === 'active' ? 'نشط' : ($user['status'] === 'inactive' ? 'غير نشط' : 'محظور') ?>
                                            </span>
                                        </td>
                                        <td>
                                            <strong class="text-success">
                                                <?= number_format($user['wallet_balance'] ?? 0, 2) ?> ر.ي
                                            </strong>
                                        </td>
                                        <td>
                                            <small><?= date('Y-m-d', strtotime($user['created_at'])) ?></small>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="action" value="toggle_status">
                                                    <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-primary" title="تغيير الحالة">
                                                        <i class="fas fa-toggle-on"></i>
                                                    </button>
                                                </form>
                                                <form method="POST" style="display: inline;" onsubmit="return confirm('هل أنت متأكد من حظر هذا المستخدم؟')">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="حظر">
                                                        <i class="fas fa-ban"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- الترقيم -->
                        <?php if ($total_pages > 1): ?>
                        <nav class="mt-4">
                            <ul class="pagination justify-content-center">
                                <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>&status=<?= urlencode($status_filter) ?>">السابق</a>
                                </li>
                                <?php endif; ?>
                                
                                <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                    <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&status=<?= urlencode($status_filter) ?>"><?= $i ?></a>
                                </li>
                                <?php endfor; ?>
                                
                                <?php if ($page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>&status=<?= urlencode($status_filter) ?>">التالي</a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- نافذة إضافة مستخدم -->
    <div class="modal fade" id="addUserModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إضافة مستخدم جديد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add_user">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">اسم المستخدم *</label>
                                    <input type="text" class="form-control" name="username" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">البريد الإلكتروني *</label>
                                    <input type="email" class="form-control" name="email" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">كلمة المرور *</label>
                                    <input type="password" class="form-control" name="password" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">رقم الهاتف</label>
                                    <input type="text" class="form-control" name="phone">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">نوع المستخدم</label>
                                    <select class="form-select" name="user_type">
                                        <option value="regular">عادي</option>
                                        <option value="premium">مميز</option>
                                        <option value="vip">VIP</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">الحالة</label>
                                    <select class="form-select" name="status">
                                        <option value="active">نشط</option>
                                        <option value="inactive">غير نشط</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">رصيد المحفظة</label>
                                    <input type="number" class="form-control" name="wallet_balance" value="0" step="0.01">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">إضافة المستخدم</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

</merged_code>
