<?php
session_start();
require_once '../config/database.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['admin_id'])) {
    http_response_code(403);
    exit('غير مصرح');
}

$wallet_id = intval($_GET['wallet_id'] ?? 0);
if (!$wallet_id) {
    exit('معرف المحفظة مطلوب');
}

$db = Database::getInstance()->getConnection();

// جلب معلومات المحفظة
$stmt = $db->prepare("SELECT w.*, u.username FROM wallets w JOIN users u ON w.user_id = u.id WHERE w.id = ?");
$stmt->execute([$wallet_id]);
$wallet = $stmt->fetch();

if (!$wallet) {
    exit('المحفظة غير موجودة');
}

// جلب المعاملات
$stmt = $db->prepare("
    SELECT wt.*, a.username as admin_name 
    FROM wallet_transactions wt 
    LEFT JOIN admins a ON wt.admin_id = a.id 
    WHERE wt.wallet_id = ? 
    ORDER BY wt.created_at DESC 
    LIMIT 50
");
$stmt->execute([$wallet_id]);
$transactions = $stmt->fetchAll();
?>

<div class="mb-3">
    <h6>محفظة: <?= htmlspecialchars($wallet['username']) ?></h6>
    <p class="mb-0">الرصيد الحالي: <strong class="text-success"><?= number_format($wallet['balance'], 2) ?> <?= $wallet['currency'] ?></strong></p>
</div>

<?php if (empty($transactions)): ?>
    <div class="alert alert-info">لا توجد معاملات لهذه المحفظة</div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-sm">
            <thead class="table-dark">
                <tr>
                    <th>التاريخ</th>
                    <th>النوع</th>
                    <th>المبلغ</th>
                    <th>الوصف</th>
                    <th>المسؤول</th>
                    <th>الحالة</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($transactions as $transaction): ?>
                <tr>
                    <td>
                        <small><?= date('Y-m-d H:i:s', strtotime($transaction['created_at'])) ?></small>
                    </td>
                    <td>
                        <?php if ($transaction['type'] === 'credit'): ?>
                            <span class="badge bg-success">إيداع</span>
                        <?php else: ?>
                            <span class="badge bg-danger">سحب</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <strong class="<?= $transaction['type'] === 'credit' ? 'text-success' : 'text-danger' ?>">
                            <?= $transaction['type'] === 'credit' ? '+' : '-' ?><?= number_format($transaction['amount'], 2) ?>
                        </strong>
                    </td>
                    <td>
                        <small><?= htmlspecialchars($transaction['description']) ?></small>
                    </td>
                    <td>
                        <small><?= htmlspecialchars($transaction['admin_name'] ?? 'النظام') ?></small>
                    </td>
                    <td>
                        <?php
                        $status_colors = [
                            'completed' => 'success',
                            'pending' => 'warning',
                            'failed' => 'danger'
                        ];
                        $status_names = [
                            'completed' => 'مكتمل',
                            'pending' => 'معلق',
                            'failed' => 'فاشل'
                        ];
                        ?>
                        <span class="badge bg-<?= $status_colors[$transaction['status']] ?? 'secondary' ?>">
                            <?= $status_names[$transaction['status']] ?? $transaction['status'] ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
