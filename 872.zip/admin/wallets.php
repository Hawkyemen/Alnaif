<?php
session_start();
require_once '../config/database.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

$db = Database::getInstance()->getConnection();
$message = '';
$error = '';

// معالجة العمليات
if ($_POST) {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add_balance':
                try {
                    $db->beginTransaction();
                    
                    // تحديث رصيد المحفظة
                    $stmt = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE id = ?");
                    $stmt->execute([floatval($_POST['amount']), $_POST['wallet_id']]);
                    
                    // إضافة معاملة
                    $stmt = $db->prepare("INSERT INTO wallet_transactions (wallet_id, type, amount, description, admin_id, status) VALUES (?, 'credit', ?, ?, ?, 'completed')");
                    $stmt->execute([
                        $_POST['wallet_id'],
                        floatval($_POST['amount']),
                        $_POST['description'] ?: 'إضافة رصيد من الإدارة',
                        $_SESSION['admin_id']
                    ]);
                    
                    $db->commit();
                    $message = "تم إضافة الرصيد بنجاح";
                } catch (Exception $e) {
                    $db->rollBack();
                    $error = "خطأ في إضافة الرصيد: " . $e->getMessage();
                }
                break;
                
            case 'deduct_balance':
                try {
                    $db->beginTransaction();
                    
                    // التحقق من الرصيد المتاح
                    $stmt = $db->prepare("SELECT balance FROM wallets WHERE id = ?");
                    $stmt->execute([$_POST['wallet_id']]);
                    $current_balance = $stmt->fetchColumn();
                    
                    if ($current_balance < floatval($_POST['amount'])) {
                        throw new Exception("الرصيد المتاح غير كافي");
                    }
                    
                    // خصم من رصيد المحفظة
                    $stmt = $db->prepare("UPDATE wallets SET balance = balance - ? WHERE id = ?");
                    $stmt->execute([floatval($_POST['amount']), $_POST['wallet_id']]);
                    
                    // إضافة معاملة
                    $stmt = $db->prepare("INSERT INTO wallet_transactions (wallet_id, type, amount, description, admin_id, status) VALUES (?, 'debit', ?, ?, ?, 'completed')");
                    $stmt->execute([
                        $_POST['wallet_id'],
                        floatval($_POST['amount']),
                        $_POST['description'] ?: 'خصم رصيد من الإدارة',
                        $_SESSION['admin_id']
                    ]);
                    
                    $db->commit();
                    $message = "تم خصم الرصيد بنجاح";
                } catch (Exception $e) {
                    $db->rollBack();
                    $error = "خطأ في خصم الرصيد: " . $e->getMessage();
                }
                break;
                
            case 'freeze_wallet':
                try {
                    $stmt = $db->prepare("UPDATE wallets SET status = 'frozen' WHERE id = ?");
                    $stmt->execute([$_POST['wallet_id']]);
                    $message = "تم تجميد المحفظة بنجاح";
                } catch (Exception $e) {
                    $error = "خطأ في تجميد المحفظة: " . $e->getMessage();
                }
                break;
                
            case 'unfreeze_wallet':
                try {
                    $stmt = $db->prepare("UPDATE wallets SET status = 'active' WHERE id = ?");
                    $stmt->execute([$_POST['wallet_id']]);
                    $message = "تم إلغاء تجميد المحفظة بنجاح";
                } catch (Exception $e) {
                    $error = "خطأ في إلغاء تجميد المحفظة: " . $e->getMessage();
                }
                break;
                
            case 'transfer_funds':
                try {
                    $db->beginTransaction();
                    
                    $from_wallet = $_POST['from_wallet'];
                    $to_wallet = $_POST['to_wallet'];
                    $amount = floatval($_POST['amount']);
                    
                    // التحقق من الرصيد
                    $stmt = $db->prepare("SELECT balance FROM wallets WHERE id = ?");
                    $stmt->execute([$from_wallet]);
                    $from_balance = $stmt->fetchColumn();
                    
                    if ($from_balance < $amount) {
                        throw new Exception("الرصيد المتاح غير كافي");
                    }
                    
                    // خصم من المحفظة المرسلة
                    $stmt = $db->prepare("UPDATE wallets SET balance = balance - ? WHERE id = ?");
                    $stmt->execute([$amount, $from_wallet]);
                    
                    // إضافة للمحفظة المستقبلة
                    $stmt = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE id = ?");
                    $stmt->execute([$amount, $to_wallet]);
                    
                    // إضافة معاملات
                    $description = $_POST['description'] ?: 'تحويل من الإدارة';
                    
                    $stmt = $db->prepare("INSERT INTO wallet_transactions (wallet_id, type, amount, description, admin_id, status) VALUES (?, 'debit', ?, ?, ?, 'completed')");
                    $stmt->execute([$from_wallet, $amount, "تحويل إلى محفظة أخرى: " . $description, $_SESSION['admin_id']]);
                    
                    $stmt = $db->prepare("INSERT INTO wallet_transactions (wallet_id, type, amount, description, admin_id, status) VALUES (?, 'credit', ?, ?, ?, 'completed')");
                    $stmt->execute([$to_wallet, $amount, "تحويل من محفظة أخرى: " . $description, $_SESSION['admin_id']]);
                    
                    $db->commit();
                    $message = "تم التحويل بنجاح";
                } catch (Exception $e) {
                    $db->rollBack();
                    $error = "خطأ في التحويل: " . $e->getMessage();
                }
                break;
        }
    }
}

// البحث والفلترة
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';
$currency_filter = $_GET['currency'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

$where_conditions = [];
$params = [];

if ($search) {
    $where_conditions[] = "(u.username LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($status_filter) {
    $where_conditions[] = "w.status = ?";
    $params[] = $status_filter;
}

if ($currency_filter) {
    $where_conditions[] = "w.currency = ?";
    $params[] = $currency_filter;
}

$where_clause = $where_conditions ? "WHERE " . implode(" AND ", $where_conditions) : "";

// جلب المحافظ
$sql = "SELECT w.*, u.username, u.email, u.phone,
        (SELECT COUNT(*) FROM wallet_transactions WHERE wallet_id = w.id) as total_transactions,
        (SELECT SUM(amount) FROM wallet_transactions WHERE wallet_id = w.id AND type = 'credit') as total_credits,
        (SELECT SUM(amount) FROM wallet_transactions WHERE wallet_id = w.id AND type = 'debit') as total_debits,
        (SELECT created_at FROM wallet_transactions WHERE wallet_id = w.id ORDER BY created_at DESC LIMIT 1) as last_transaction
        FROM wallets w 
        JOIN users u ON w.user_id = u.id 
        $where_clause 
        ORDER BY w.balance DESC 
        LIMIT $limit OFFSET $offset";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$wallets = $stmt->fetchAll();

// عدد المحافظ الإجمالي
$count_sql = "SELECT COUNT(*) FROM wallets w JOIN users u ON w.user_id = u.id $where_clause";
$count_stmt = $db->prepare($count_sql);
$count_stmt->execute($params);
$total_wallets = $count_stmt->fetchColumn();
$total_pages = ceil($total_wallets / $limit);

// إحصائيات المحافظ
$stats_sql = "SELECT 
    COUNT(*) as total_wallets,
    SUM(balance) as total_balance,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_wallets,
    SUM(CASE WHEN status = 'frozen' THEN 1 ELSE 0 END) as frozen_wallets,
    AVG(balance) as avg_balance,
    MAX(balance) as max_balance
    FROM wallets";
$stats = $db->query($stats_sql)->fetch();

// إحصائيات المعاملات اليومية
$daily_stats_sql = "SELECT 
    COUNT(*) as today_transactions,
    SUM(CASE WHEN type = 'credit' THEN amount ELSE 0 END) as today_credits,
    SUM(CASE WHEN type = 'debit' THEN amount ELSE 0 END) as today_debits
    FROM wallet_transactions 
    WHERE DATE(created_at) = CURDATE()";
$daily_stats = $db->query($daily_stats_sql)->fetch();

// العملات المتاحة
$currencies = $db->query("SELECT DISTINCT currency FROM wallets ORDER BY currency")->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المحافظ - لوحة التحكم</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
    <style>
        .wallet-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }
        .wallet-card:hover {
            transform: translateY(-2px);
        }
        .balance-display {
            font-size: 1.5rem;
            font-weight: bold;
        }
        .transaction-badge {
            font-size: 0.75rem;
        }
        .search-box {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .stats-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .currency-badge {
            font-size: 0.8rem;
            padding: 0.25rem 0.5rem;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include 'includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">إدارة المحافظ</h1>
                    <div class="btn-group">
                        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addBalanceModal">
                            <i class="fas fa-plus me-2"></i>إضافة رصيد
                        </button>
                        <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#transferModal">
                            <i class="fas fa-exchange-alt me-2"></i>تحويل أموال
                        </button>
                    </div>
                </div>

                <?php if ($message): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <?= htmlspecialchars($message) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?= htmlspecialchars($error) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- إحصائيات المحافظ -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card stats-card text-center">
                            <div class="card-body">
                                <i class="fas fa-wallet fa-2x text-primary mb-2"></i>
                                <h4><?= number_format($stats['total_wallets']) ?></h4>
                                <small class="text-muted">إجمالي المحافظ</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stats-card text-center">
                            <div class="card-body">
                                <i class="fas fa-coins fa-2x text-success mb-2"></i>
                                <h4><?= number_format($stats['total_balance'], 2) ?></h4>
                                <small class="text-muted">إجمالي الأرصدة</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stats-card text-center">
                            <div class="card-body">
                                <i class="fas fa-check-circle fa-2x text-info mb-2"></i>
                                <h4><?= number_format($stats['active_wallets']) ?></h4>
                                <small class="text-muted">محافظ نشطة</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stats-card text-center">
                            <div class="card-body">
                                <i class="fas fa-lock fa-2x text-danger mb-2"></i>
                                <h4><?= number_format($stats['frozen_wallets']) ?></h4>
                                <small class="text-muted">محافظ مجمدة</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- إحصائيات المعاملات اليومية -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="card stats-card text-center">
                            <div class="card-body">
                                <i class="fas fa-exchange-alt fa-2x text-warning mb-2"></i>
                                <h4><?= number_format($daily_stats['today_transactions']) ?></h4>
                                <small class="text-muted">معاملات اليوم</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card stats-card text-center">
                            <div class="card-body">
                                <i class="fas fa-arrow-up fa-2x text-success mb-2"></i>
                                <h4><?= number_format($daily_stats['today_credits'], 2) ?></h4>
                                <small class="text-muted">إيداعات اليوم</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card stats-card text-center">
                            <div class="card-body">
                                <i class="fas fa-arrow-down fa-2x text-danger mb-2"></i>
                                <h4><?= number_format($daily_stats['today_debits'], 2) ?></h4>
                                <small class="text-muted">سحوبات اليوم</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- البحث والفلترة -->
                <div class="search-box">
                    <form method="GET" class="row g-3">
                        <div class="col-md-4">
                            <input type="text" class="form-control" name="search" placeholder="البحث بالاسم، الإيميل أو الهاتف" value="<?= htmlspecialchars($search) ?>">
                        </div>
                        <div class="col-md-2">
                            <select name="status" class="form-select">
                                <option value="">جميع الحالات</option>
                                <option value="active" <?= $status_filter === 'active' ? 'selected' : '' ?>>نشط</option>
                                <option value="frozen" <?= $status_filter === 'frozen' ? 'selected' : '' ?>>مجمد</option>
                                <option value="suspended" <?= $status_filter === 'suspended' ? 'selected' : '' ?>>معلق</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="currency" class="form-select">
                                <option value="">جميع العملات</option>
                                <?php foreach ($currencies as $currency): ?>
                                <option value="<?= $currency ?>" <?= $currency_filter === $currency ? 'selected' : '' ?>><?= $currency ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search me-1"></i>بحث
                            </button>
                        </div>
                        <div class="col-md-2">
                            <a href="wallets.php" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-times me-1"></i>إلغاء
                            </a>
                        </div>
                    </form>
                </div>

                <!-- جدول المحافظ -->
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-dark">
                                    <tr>
                                        <th>المستخدم</th>
                                        <th>الرصيد</th>
                                        <th>العملة</th>
                                        <th>الحالة</th>
                                        <th>المعاملات</th>
                                        <th>آخر معاملة</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($wallets as $wallet): ?>
                                    <tr>
                                        <td>
                                            <div>
                                                <strong><?= htmlspecialchars($wallet['username']) ?></strong>
                                                <br><small class="text-muted"><?= htmlspecialchars($wallet['email']) ?></small>
                                                <?php if ($wallet['phone']): ?>
                                                <br><small class="text-muted"><?= htmlspecialchars($wallet['phone']) ?></small>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="balance-display <?= $wallet['balance'] > 0 ? 'text-success' : 'text-muted' ?>">
                                                <?= number_format($wallet['balance'], 2) ?>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge currency-badge bg-secondary"><?= $wallet['currency'] ?></span>
                                        </td>
                                        <td>
                                            <?php
                                            $status_colors = [
                                                'active' => 'success',
                                                'frozen' => 'danger',
                                                'suspended' => 'warning'
                                            ];
                                            $status_names = [
                                                'active' => 'نشط',
                                                'frozen' => 'مجمد',
                                                'suspended' => 'معلق'
                                            ];
                                            ?>
                                            <span class="badge bg-<?= $status_colors[$wallet['status']] ?? 'secondary' ?>">
                                                <?= $status_names[$wallet['status']] ?? $wallet['status'] ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="small">
                                                <div><i class="fas fa-list me-1"></i><?= $wallet['total_transactions'] ?> معاملة</div>
                                                <div class="text-success"><i class="fas fa-arrow-up me-1"></i><?= number_format($wallet['total_credits'] ?? 0, 2) ?></div>
                                                <div class="text-danger"><i class="fas fa-arrow-down me-1"></i><?= number_format($wallet['total_debits'] ?? 0, 2) ?></div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if ($wallet['last_transaction']): ?>
                                            <small><?= date('Y-m-d H:i', strtotime($wallet['last_transaction'])) ?></small>
                                            <?php else: ?>
                                            <small class="text-muted">لا توجد معاملات</small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button class="btn btn-sm btn-outline-success" onclick="addBalance(<?= $wallet['id'] ?>, '<?= htmlspecialchars($wallet['username']) ?>')">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                                <button class="btn btn-sm btn-outline-danger" onclick="deductBalance(<?= $wallet['id'] ?>, '<?= htmlspecialchars($wallet['username']) ?>', <?= $wallet['balance'] ?>)">
                                                    <i class="fas fa-minus"></i>
                                                </button>
                                                <button class="btn btn-sm btn-outline-info" onclick="viewTransactions(<?= $wallet['id'] ?>, '<?= htmlspecialchars($wallet['username']) ?>')">
                                                    <i class="fas fa-history"></i>
                                                </button>
                                                <?php if ($wallet['status'] === 'active'): ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="action" value="freeze_wallet">
                                                    <input type="hidden" name="wallet_id" value="<?= $wallet['id'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-warning" onclick="return confirm('هل أنت متأكد من تجميد هذه المحفظة؟')">
                                                        <i class="fas fa-lock"></i>
                                                    </button>
                                                </form>
                                                <?php else: ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="action" value="unfreeze_wallet">
                                                    <input type="hidden" name="wallet_id" value="<?= $wallet['id'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-success" onclick="return confirm('هل أنت متأكد من إلغاء تجميد هذه المحفظة؟')">
                                                        <i class="fas fa-unlock"></i>
                                                    </button>
                                                </form>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- الترقيم -->
                        <?php if ($total_pages > 1): ?>
                        <nav class="mt-4">
                            <ul class="pagination justify-content-center">
                                <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>&status=<?= urlencode($status_filter) ?>&currency=<?= urlencode($currency_filter) ?>">السابق</a>
                                </li>
                                <?php endif; ?>
                                
                                <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                    <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&status=<?= urlencode($status_filter) ?>&currency=<?= urlencode($currency_filter) ?>"><?= $i ?></a>
                                </li>
                                <?php endfor; ?>
                                
                                <?php if ($page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>&status=<?= urlencode($status_filter) ?>&currency=<?= urlencode($currency_filter) ?>">التالي</a>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- نافذة إضافة رصيد -->
    <div class="modal fade" id="addBalanceModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إضافة رصيد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="addBalanceForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add_balance">
                        <input type="hidden" name="wallet_id" id="add_wallet_id">
                        <div class="mb-3">
                            <label class="form-label">المستخدم</label>
                            <input type="text" class="form-control" id="add_username" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">المبلغ *</label>
                            <input type="number" class="form-control" name="amount" step="0.01" min="0.01" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الوصف</label>
                            <textarea class="form-control" name="description" rows="3" placeholder="سبب إضافة الرصيد..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-success">إضافة الرصيد</button>
                    </div>
                </form  class="btn btn-success">إضافة الرصيد</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- نافذة خصم رصيد -->
    <div class="modal fade" id="deductBalanceModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">خصم رصيد</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="deductBalanceForm">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="deduct_balance">
                        <input type="hidden" name="wallet_id" id="deduct_wallet_id">
                        <div class="mb-3">
                            <label class="form-label">المستخدم</label>
                            <input type="text" class="form-control" id="deduct_username" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الرصيد الحالي</label>
                            <input type="text" class="form-control" id="current_balance" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">المبلغ المراد خصمه *</label>
                            <input type="number" class="form-control" name="amount" step="0.01" min="0.01" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الوصف</label>
                            <textarea class="form-control" name="description" rows="3" placeholder="سبب خصم الرصيد..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-danger">خصم الرصيد</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- نافذة تحويل الأموال -->
    <div class="modal fade" id="transferModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تحويل أموال</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="transfer_funds">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">من المحفظة *</label>
                                    <select class="form-select" name="from_wallet" required>
                                        <option value="">اختر المحفظة المرسلة</option>
                                        <?php foreach ($wallets as $wallet): ?>
                                        <option value="<?= $wallet['id'] ?>" data-balance="<?= $wallet['balance'] ?>">
                                            <?= htmlspecialchars($wallet['username']) ?> - <?= number_format($wallet['balance'], 2) ?> <?= $wallet['currency'] ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">إلى المحفظة *</label>
                                    <select class="form-select" name="to_wallet" required>
                                        <option value="">اختر المحفظة المستقبلة</option>
                                        <?php foreach ($wallets as $wallet): ?>
                                        <option value="<?= $wallet['id'] ?>">
                                            <?= htmlspecialchars($wallet['username']) ?> - <?= number_format($wallet['balance'], 2) ?> <?= $wallet['currency'] ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">المبلغ *</label>
                            <input type="number" class="form-control" name="amount" step="0.01" min="0.01" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الوصف</label>
                            <textarea class="form-control" name="description" rows="3" placeholder="سبب التحويل..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-warning">تحويل الأموال</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- نافذة عرض المعاملات -->
    <div class="modal fade" id="transactionsModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">سجل المعاملات</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="transactionsContent">
                        <!-- سيتم تحميل المعاملات هنا عبر AJAX -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function addBalance(walletId, username) {
            document.getElementById('add_wallet_id').value = walletId;
            document.getElementById('add_username').value = username;
            new bootstrap.Modal(document.getElementById('addBalanceModal')).show();
        }

        function deductBalance(walletId, username, currentBalance) {
            document.getElementById('deduct_wallet_id').value = walletId;
            document.getElementById('deduct_username').value = username;
            document.getElementById('current_balance').value = currentBalance.toFixed(2) + ' ر.ي';
            new bootstrap.Modal(document.getElementById('deductBalanceModal')).show();
        }

        function viewTransactions(walletId, username) {
            const modal = new bootstrap.Modal(document.getElementById('transactionsModal'));
            const content = document.getElementById('transactionsContent');
            
            content.innerHTML = '<div class="text-center"><i class="fas fa-spinner fa-spin fa-2x"></i><br>جاري التحميل...</div>';
            modal.show();
            
            // تحميل المعاملات عبر AJAX
            fetch(`wallet_transactions.php?wallet_id=${walletId}`)
                .then(response => response.text())
                .then(data => {
                    content.innerHTML = data;
                })
                .catch(error => {
                    content.innerHTML = '<div class="alert alert-danger">خطأ في تحميل المعاملات</div>';
                });
        }

        // التحقق من صحة التحويل
        document.querySelector('form[action*="transfer_funds"]').addEventListener('submit', function(e) {
            const fromWallet = this.querySelector('select[name="from_wallet"]').value;
            const toWallet = this.querySelector('select[name="to_wallet"]').value;
            
            if (fromWallet === toWallet) {
                e.preventDefault();
                alert('لا يمكن التحويل من وإلى نفس المحفظة');
                return false;
            }
        });
    </script>
</body>
</html>
