<?php
require_once '../../config/config.php';
require_once '../../config/payment_config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// API Authentication
function authenticateAPI() {
    $headers = getallheaders();
    $auth_header = $headers['Authorization'] ?? '';
    
    if (!$auth_header || !str_starts_with($auth_header, 'Bearer ')) {
        http_response_code(401);
        echo json_encode(['error' => 'Missing or invalid authorization header']);
        exit;
    }
    
    $token = substr($auth_header, 7);
    // Verify API token (you should implement proper token validation)
    if ($token !== 'your_api_secret_key') {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid API token']);
        exit;
    }
}

class ChargingAPI {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function chargeProduct($product_id, $customer_id, $amount, $currency) {
        try {
            // Get product details
            $stmt = $this->db->prepare("SELECT p.*, c.type FROM products p JOIN categories c ON p.category_id = c.id WHERE p.id = ? AND p.status = 'active'");
            $stmt->execute([$product_id]);
            $product = $stmt->fetch();
            
            if (!$product) {
                throw new Exception('Product not found');
            }
            
            // Get charging API configuration
            $stmt = $this->db->prepare("SELECT * FROM charging_apis WHERE product_id = ? AND is_active = 1 ORDER BY success_rate DESC LIMIT 1");
            $stmt->execute([$product_id]);
            $api_config = $stmt->fetch();
            
            if (!$api_config) {
                // Use default charging method
                return $this->defaultCharging($product, $customer_id, $amount, $currency);
            }
            
            // Use configured API
            return $this->callChargingAPI($api_config, $product, $customer_id, $amount, $currency);
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'timestamp' => date('Y-m-d H:i:s')
            ];
        }
    }
    
    private function callChargingAPI($api_config, $product, $customer_id, $amount, $currency) {
        $request_template = json_decode($api_config['request_template'], true);
        $headers = json_decode($api_config['headers'], true) ?: [];
        
        // Build request data
        $request_data = $this->buildRequestData($request_template, [
            'customer_id' => $customer_id,
            'product_id' => $product['id'],
            'product_name' => $product['name'],
            'amount' => $amount,
            'currency' => $currency,
            'api_key' => $api_config['api_key']
        ]);
        
        // Make API call
        $response = $this->makeAPICall(
            $api_config['api_url'],
            $request_data,
            $api_config['method'],
            $headers
        );
        
        // Update API usage
        $this->updateAPIUsage($api_config['id'], $response !== false);
        
        if ($response) {
            return [
                'success' => true,
                'transaction_id' => $response['transaction_id'] ?? uniqid(),
                'status' => $response['status'] ?? 'completed',
                'message' => 'تم شحن الحساب بنجاح',
                'customer_id' => $customer_id,
                'product' => $product['name_ar'],
                'amount' => $amount,
                'currency' => $currency,
                'timestamp' => date('Y-m-d H:i:s')
            ];
        }
        
        throw new Exception('فشل في شحن الحساب');
    }
    
    private function defaultCharging($product, $customer_id, $amount, $currency) {
        // Default charging logic for products without specific API
        $charging_methods = [
            'pubg' => 'chargePUBG',
            'freefire' => 'chargeFreefire',
            'bigo' => 'chargeBigo',
            'happy_chat' => 'chargeHappyChat'
        ];
        
        $product_key = strtolower(str_replace(' ', '_', $product['name']));
        
        if (isset($charging_methods[$product_key])) {
            return $this->{$charging_methods[$product_key]}($customer_id, $amount, $currency);
        }
        
        // Generic charging
        return $this->genericCharging($product, $customer_id, $amount, $currency);
    }
    
    private function chargePUBG($customer_id, $amount, $currency) {
        $pubg_config = CHARGING_APIS['pubg'];
        
        $data = [
            'user_id' => $customer_id,
            'amount' => $amount,
            'currency' => $currency,
            'api_key' => $pubg_config['key']
        ];
        
        $response = $this->makeAPICall($pubg_config['url'], $data, $pubg_config['method']);
        
        if ($response && isset($response['success']) && $response['success']) {
            return [
                'success' => true,
                'transaction_id' => $response['transaction_id'],
                'message' => 'تم شحن حساب PUBG بنجاح',
                'uc_amount' => $response['uc_amount'] ?? 0
            ];
        }
        
        throw new Exception('فشل في شحن حساب PUBG');
    }
    
    private function chargeFreefire($customer_id, $amount, $currency) {
        $ff_config = CHARGING_APIS['freefire'];
        
        $data = [
            'player_id' => $customer_id,
            'diamonds' => $this->convertToDiamonds($amount, $currency),
            'api_key' => $ff_config['key']
        ];
        
        $response = $this->makeAPICall($ff_config['url'], $data, $ff_config['method']);
        
        if ($response && $response['status'] === 'success') {
            return [
                'success' => true,
                'transaction_id' => $response['order_id'],
                'message' => 'تم شحن حساب Free Fire بنجاح',
                'diamonds' => $response['diamonds_added']
            ];
        }
        
        throw new Exception('فشل في شحن حساب Free Fire');
    }
    
    private function chargeBigo($customer_id, $amount, $currency) {
        $bigo_config = CHARGING_APIS['bigo'];
        
        $data = [
            'bigo_id' => $customer_id,
            'beans' => $this->convertToBeans($amount, $currency),
            'api_key' => $bigo_config['key']
        ];
        
        $response = $this->makeAPICall($bigo_config['url'], $data, $bigo_config['method']);
        
        if ($response && $response['result'] === 'success') {
            return [
                'success' => true,
                'transaction_id' => $response['transaction_id'],
                'message' => 'تم شحن حساب Bigo Live بنجاح',
                'beans' => $response['beans_added']
            ];
        }
        
        throw new Exception('فشل في شحن حساب Bigo Live');
    }
    
    private function chargeHappyChat($customer_id, $amount, $currency) {
        // Happy Chat charging simulation
        return [
            'success' => true,
            'transaction_id' => 'HC_' . uniqid(),
            'message' => 'تم شحن حساب Happy Chat بنجاح',
            'coins' => $this->convertToCoins($amount, $currency),
            'customer_id' => $customer_id
        ];
    }
    
    private function genericCharging($product, $customer_id, $amount, $currency) {
        // Generic charging for products without specific API
        sleep(2); // Simulate processing time
        
        return [
            'success' => true,
            'transaction_id' => 'GEN_' . uniqid(),
            'message' => "تم شحن حساب {$product['name_ar']} بنجاح",
            'customer_id' => $customer_id,
            'amount' => $amount,
            'currency' => $currency,
            'note' => 'سيتم تفعيل الشحن خلال 5-10 دقائق'
        ];
    }
    
    private function makeAPICall($url, $data, $method = 'POST', $headers = []) {
        $ch = curl_init();
        
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            $headers[] = 'Content-Type: application/json';
        }
        
        if (!empty($headers)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code >= 200 && $http_code < 300) {
            return json_decode($response, true);
        }
        
        return false;
    }
    
    private function buildRequestData($template, $variables) {
        $json_string = json_encode($template);
        foreach ($variables as $key => $value) {
            $json_string = str_replace("{{$key}}", $value, $json_string);
        }
        return json_decode($json_string, true);
    }
    
    private function updateAPIUsage($api_id, $success) {
        $stmt = $this->db->prepare("UPDATE charging_apis SET last_used = NOW() WHERE id = ?");
        $stmt->execute([$api_id]);
        
        if ($success) {
            $stmt = $this->db->prepare("UPDATE charging_apis SET success_rate = (success_rate * 0.9) + 10 WHERE id = ?");
            $stmt->execute([$api_id]);
        } else {
            $stmt = $this->db->prepare("UPDATE charging_apis SET success_rate = success_rate * 0.9 WHERE id = ?");
            $stmt->execute([$api_id]);
        }
    }
    
    private function convertToDiamonds($amount, $currency) {
        $rates = ['YER' => 0.1, 'SAR' => 10, 'USD' => 37.5];
        return intval($amount / $rates[$currency]);
    }
    
    private function convertToBeans($amount, $currency) {
        $rates = ['YER' => 0.05, 'SAR' => 5, 'USD' => 18.75];
        return intval($amount / $rates[$currency]);
    }
    
    private function convertToCoins($amount, $currency) {
        $rates = ['YER' => 0.2, 'SAR' => 20, 'USD' => 75];
        return intval($amount / $rates[$currency]);
    }
}

// Handle API request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    authenticateAPI();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid JSON input']);
        exit;
    }
    
    $required_fields = ['product_id', 'customer_id', 'amount', 'currency'];
    foreach ($required_fields as $field) {
        if (!isset($input[$field])) {
            http_response_code(400);
            echo json_encode(['error' => "Missing required field: $field"]);
            exit;
        }
    }
    
    $charging_api = new ChargingAPI();
    $result = $charging_api->chargeProduct(
        $input['product_id'],
        $input['customer_id'],
        $input['amount'],
        $input['currency']
    );
    
    echo json_encode($result);
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
?>
