<?php
/**
 * واجهة برمجة التطبيقات للتطبيق المحمول
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// التعامل مع طلبات OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once dirname(__DIR__, 2) . '/config/config.php';
require_once dirname(__DIR__, 2) . '/config/email_config.php';

/**
 * فئة واجهة برمجة التطبيقات للتطبيق المحمول
 */
class MobileAPI {
    private $pdo;
    private $notificationManager;
    private $currentUser = null;
    
    public function __construct() {
        $this->pdo = Database::getInstance()->getConnection();
        $this->notificationManager = new NotificationManager();
        
        // التحقق من التوكن إذا كان مطلوباً
        $this->authenticateUser();
    }
    
    /**
     * التحقق من صحة المستخدم
     */
    private function authenticateUser() {
        $headers = getallheaders();
        $token = null;
        
        // البحث عن التوكن في الهيدر
        if (isset($headers['Authorization'])) {
            $authHeader = $headers['Authorization'];
            if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
                $token = $matches[1];
            }
        }
        
        if ($token) {
            $stmt = $this->pdo->prepare("
                SELECT at.*, u.* FROM api_tokens at
                JOIN users u ON at.user_id = u.id
                WHERE at.token = ? AND at.expires_at > NOW() AND at.is_active = 1
            ");
            $stmt->execute([$token]);
            $this->currentUser = $stmt->fetch();
            
            if ($this->currentUser) {
                // تحديث آخر استخدام للتوكن
                $stmt = $this->pdo->prepare("UPDATE api_tokens SET last_used = NOW() WHERE token = ?");
                $stmt->execute([$token]);
            }
        }
    }
    
    /**
     * التحقق من أن المستخدم مسجل دخول
     */
    private function requireAuth() {
        if (!$this->currentUser) {
            $this->sendError('غير مصرح', 401);
        }
    }
    
    /**
     * إرسال استجابة نجاح
     */
    private function sendSuccess($data = null, $message = 'تم بنجاح') {
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    /**
     * إرسال استجابة خطأ
     */
    private function sendError($message, $code = 400) {
        http_response_code($code);
        echo json_encode([
            'success' => false,
            'message' => $message
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }
    
    /**
     * الحصول على البيانات المرسلة
     */
    private function getInput() {
        $input = json_decode(file_get_contents('php://input'), true);
        return $input ?: $_POST;
    }
    
    /**
     * معالجة الطلبات
     */
    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $pathParts = explode('/', trim($path, '/'));
        
        // إزالة أجزاء المسار غير المطلوبة
        $endpoint = end($pathParts);
        
        try {
            switch ($endpoint) {
                case 'login':
                    $this->handleLogin();
                    break;
                    
                case 'register':
                    $this->handleRegister();
                    break;
                    
                case 'categories':
                    $this->handleCategories();
                    break;
                    
                case 'products':
                    $this->handleProducts();
                    break;
                    
                case 'orders':
                    $this->requireAuth();
                    $this->handleOrders();
                    break;
                    
                case 'wallet':
                    $this->requireAuth();
                    $this->handleWallet();
                    break;
                    
                case 'notifications':
                    $this->requireAuth();
                    $this->handleNotifications();
                    break;
                    
                case 'profile':
                    $this->requireAuth();
                    $this->handleProfile();
                    break;
                    
                case 'purchase':
                    $this->requireAuth();
                    $this->handlePurchase();
                    break;
                    
                default:
                    $this->sendError('نقطة النهاية غير موجودة', 404);
            }
        } catch (Exception $e) {
            error_log("Mobile API Error: " . $e->getMessage());
            $this->sendError('خطأ في الخادم', 500);
        }
    }
    
    /**
     * معالجة تسجيل الدخول
     */
    private function handleLogin() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendError('طريقة غير مسموحة', 405);
        }
        
        $input = $this->getInput();
        $username = $input['username'] ?? '';
        $password = $input['password'] ?? '';
        $deviceInfo = $input['device_info'] ?? null;
        
        if (empty($username) || empty($password)) {
            $this->sendError('اسم المستخدم وكلمة المرور مطلوبان');
        }
        
        // البحث عن المستخدم
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();
        
        if (!$user || !password_verify($password, $user['password'])) {
            $this->sendError('بيانات الدخول غير صحيحة');
        }
        
        if ($user['status'] !== 'active') {
            $this->sendError('الحساب غير مفعل');
        }
        
        // إنشاء توكن جديد
        $token = bin2hex(random_bytes(32));
        $expiresAt = date('Y-m-d H:i:s', strtotime('+30 days'));
        
        $stmt = $this->pdo->prepare("
            INSERT INTO api_tokens (user_id, token, expires_at, device_info) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $user['id'],
            $token,
            $expiresAt,
            $deviceInfo ? json_encode($deviceInfo) : null
        ]);
        
        // تحديث آخر دخول
        $stmt = $this->pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $stmt->execute([$user['id']]);
        
        $this->sendSuccess([
            'token' => $token,
            'expires_at' => $expiresAt,
            'user' => [
                'id' => $user['id'],
                'username' => $user['username'],
                'email' => $user['email'],
                'full_name' => $user['full_name'],
                'phone' => $user['phone']
            ]
        ], 'تم تسجيل الدخول بنجاح');
    }
    
    /**
     * معالجة التسجيل
     */
    private function handleRegister() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendError('طريقة غير مسموحة', 405);
        }
        
        $input = $this->getInput();
        $username = $input['username'] ?? '';
        $email = $input['email'] ?? '';
        $password = $input['password'] ?? '';
        $fullName = $input['full_name'] ?? '';
        $phone = $input['phone'] ?? '';
        
        // التحقق من البيانات المطلوبة
        if (empty($username) || empty($email) || empty($password) || empty($fullName)) {
            $this->sendError('جميع الحقول مطلوبة');
        }
        
        // التحقق من صحة البريد الإلكتروني
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->sendError('البريد الإلكتروني غير صحيح');
        }
        
        // التحقق من قوة كلمة المرور
        if (strlen($password) < 6) {
            $this->sendError('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
        }
        
        // التحقق من عدم وجود المستخدم
        $stmt = $this->pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            $this->sendError('اسم المستخدم أو البريد الإلكتروني موجود مسبقاً');
        }
        
        // إنشاء المستخدم الجديد
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $this->pdo->prepare("
            INSERT INTO users (username, email, password, full_name, phone, status) 
            VALUES (?, ?, ?, ?, ?, 'active')
        ");
        
        if ($stmt->execute([$username, $email, $hashedPassword, $fullName, $phone])) {
            $userId = $this->pdo->lastInsertId();
            
            // إرسال إشعار ترحيب
            $this->notificationManager->sendWelcomeNotification($userId, $email, $fullName);
            
            $this->sendSuccess([
                'user_id' => $userId
            ], 'تم إنشاء الحساب بنجاح');
        } else {
            $this->sendError('فشل في إنشاء الحساب');
        }
    }
    
    /**
     * معالجة الفئات
     */
    private function handleCategories() {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->sendError('طريقة غير مسموحة', 405);
        }
        
        $stmt = $this->pdo->prepare("
            SELECT c.*, COUNT(p.id) as product_count
            FROM categories c
            LEFT JOIN products p ON c.id = p.category_id AND p.status = 'active'
            WHERE c.status = 'active'
            GROUP BY c.id
            ORDER BY c.sort_order, c.name
        ");
        $stmt->execute();
        $categories = $stmt->fetchAll();
        
        $this->sendSuccess($categories);
    }
    
    /**
     * معالجة المنتجات
     */
    private function handleProducts() {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->sendError('طريقة غير مسموحة', 405);
        }
        
        $categoryId = $_GET['category_id'] ?? null;
        $featured = $_GET['featured'] ?? null;
        $search = $_GET['search'] ?? null;
        $limit = min(($_GET['limit'] ?? 20), 100);
        $offset = $_GET['offset'] ?? 0;
        
        $sql = "SELECT * FROM products WHERE status = 'active'";
        $params = [];
        
        if ($categoryId) {
            $sql .= " AND category_id = ?";
            $params[] = $categoryId;
        }
        
        if ($featured) {
            $sql .= " AND is_featured = 1";
        }
        
        if ($search) {
            $sql .= " AND (name LIKE ? OR name_en LIKE ? OR description LIKE ?)";
            $searchTerm = "%$search%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        $sql .= " ORDER BY is_featured DESC, sort_order, name LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        $products = $stmt->fetchAll();
        
        $this->sendSuccess($products);
    }
    
    /**
     * معالجة الطلبات
     */
    private function handleOrders() {
        $method = $_SERVER['REQUEST_METHOD'];
        
        switch ($method) {
            case 'GET':
                $this->getUserOrders();
                break;
                
            case 'POST':
                $this->createOrder();
                break;
                
            default:
                $this->sendError('طريقة غير مسموحة', 405);
        }
    }
    
    /**
     * الحصول على طلبات المستخدم
     */
    private function getUserOrders() {
        $limit = min(($_GET['limit'] ?? 20), 100);
        $offset = $_GET['offset'] ?? 0;
        $status = $_GET['status'] ?? null;
        
        $sql = "
            SELECT o.*, p.name as product_name, p.name_en as product_name_en
            FROM orders o
            JOIN products p ON o.product_id = p.id
            WHERE o.user_id = ?
        ";
        $params = [$this->currentUser['id']];
        
        if ($status) {
            $sql .= " AND o.status = ?";
            $params[] = $status;
        }
        
        $sql .= " ORDER BY o.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        $orders = $stmt->fetchAll();
        
        $this->sendSuccess($orders);
    }
    
    /**
     * إنشاء طلب جديد
     */
    private function createOrder() {
        $input = $this->getInput();
        $productId = $input['product_id'] ?? null;
        $customerId = $input['customer_id'] ?? '';
        $quantity = $input['quantity'] ?? 1;
        $currency = $input['currency'] ?? 'YER';
        
        if (!$productId || empty($customerId)) {
            $this->sendError('معرف المنتج ومعرف العميل مطلوبان');
        }
        
        // الحصول على تفاصيل المنتج
        $stmt = $this->pdo->prepare("SELECT * FROM products WHERE id = ? AND status = 'active'");
        $stmt->execute([$productId]);
        $product = $stmt->fetch();
        
        if (!$product) {
            $this->sendError('المنتج غير موجود');
        }
        
        // حساب السعر
        $priceField = "price_" . strtolower($currency);
        if (!isset($product[$priceField])) {
            $this->sendError('العملة غير مدعومة');
        }
        
        $totalAmount = $product[$priceField] * $quantity;
        
        // إنشاء رقم الطلب
        $orderNumber = 'ORD' . date('Ymd') . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        
        // إنشاء الطلب
        $stmt = $this->pdo->prepare("
            INSERT INTO orders (
                user_id, product_id, order_number, customer_id, 
                quantity, total_amount, currency, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
        ");
        
        if ($stmt->execute([
            $this->currentUser['id'],
            $productId,
            $orderNumber,
            $customerId,
            $quantity,
            $totalAmount,
            $currency
        ])) {
            $orderId = $this->pdo->lastInsertId();
            
            // إرسال إشعار تأكيد الطلب
            $orderData = [
                'order_number' => $orderNumber,
                'product_name' => $product['name'],
                'total_amount' => $totalAmount,
                'currency' => $currency,
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            $this->notificationManager->sendOrderConfirmationNotification(
                $this->currentUser['id'],
                $this->currentUser['email'],
                $orderData
            );
            
            $this->sendSuccess([
                'order_id' => $orderId,
                'order_number' => $orderNumber,
                'total_amount' => $totalAmount,
                'currency' => $currency
            ], 'تم إنشاء الطلب بنجاح');
        } else {
            $this->sendError('فشل في إنشاء الطلب');
        }
    }
    
    /**
     * معالجة المحفظة
     */
    private function handleWallet() {
        $method = $_SERVER['REQUEST_METHOD'];
        
        switch ($method) {
            case 'GET':
                $this->getWalletBalance();
                break;
                
            case 'POST':
                $this->handleWalletTransaction();
                break;
                
            default:
                $this->sendError('طريقة غير مسموحة', 405);
        }
    }
    
    /**
     * الحصول على رصيد المحفظة
     */
    private function getWalletBalance() {
        $stmt = $this->pdo->prepare("SELECT * FROM wallets WHERE user_id = ?");
        $stmt->execute([$this->currentUser['id']]);
        $wallet = $stmt->fetch();
        
        if (!$wallet) {
            // إنشاء محفظة جديدة
            $stmt = $this->pdo->prepare("INSERT INTO wallets (user_id) VALUES (?)");
            $stmt->execute([$this->currentUser['id']]);
            
            $wallet = [
                'user_id' => $this->currentUser['id'],
                'balance_yer' => 0.00,
                'balance_sar' => 0.00,
                'balance_usd' => 0.00,
                'balance_aed' => 0.00,
                'is_frozen' => 0
            ];
        }
        
        $this->sendSuccess($wallet);
    }
    
    /**
     * معالجة معاملات المحفظة
     */
    private function handleWalletTransaction() {
        $input = $this->getInput();
        $type = $input['type'] ?? '';
        $amount = $input['amount'] ?? 0;
        $currency = $input['currency'] ?? 'YER';
        $description = $input['description'] ?? '';
        
        if (!in_array($type, ['deposit', 'withdraw']) || $amount <= 0) {
            $this->sendError('نوع المعاملة أو المبلغ غير صحيح');
        }
        
        // الحصول على المحفظة
        $stmt = $this->pdo->prepare("SELECT * FROM wallets WHERE user_id = ?");
        $stmt->execute([$this->currentUser['id']]);
        $wallet = $stmt->fetch();
        
        if (!$wallet) {
            $this->sendError('المحفظة غير موجودة');
        }
        
        if ($wallet['is_frozen']) {
            $this->sendError('المحفظة مجمدة');
        }
        
        $balanceField = "balance_" . strtolower($currency);
        $currentBalance = $wallet[$balanceField];
        
        if ($type === 'withdraw' && $currentBalance < $amount) {
            $this->sendError('الرصيد غير كافي');
        }
        
        // حساب الرصيد الجديد
        $newBalance = $type === 'deposit' ? 
            $currentBalance + $amount : 
            $currentBalance - $amount;
        
        try {
            $this->pdo->beginTransaction();
            
            // تحديث رصيد المحفظة
            $stmt = $this->pdo->prepare("UPDATE wallets SET $balanceField = ? WHERE user_id = ?");
            $stmt->execute([$newBalance, $this->currentUser['id']]);
            
            // إضافة معاملة المحفظة
            $stmt = $this->pdo->prepare("
                INSERT INTO wallet_transactions (
                    user_id, type, amount, currency, balance_before, 
                    balance_after, description
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $this->currentUser['id'],
                $type,
                $amount,
                $currency,
                $currentBalance,
                $newBalance,
                $description
            ]);
            
            $this->pdo->commit();
            
            $this->sendSuccess([
                'new_balance' => $newBalance,
                'currency' => $currency
            ], 'تمت المعاملة بنجاح');
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            $this->sendError('فشل في تنفيذ المعاملة');
        }
    }
    
    /**
     * معالجة الإشعارات
     */
    private function handleNotifications() {
        $method = $_SERVER['REQUEST_METHOD'];
        
        switch ($method) {
            case 'GET':
                $this->getUserNotifications();
                break;
                
            case 'PUT':
                $this->markNotificationAsRead();
                break;
                
            default:
                $this->sendError('طريقة غير مسموحة', 405);
        }
    }
    
    /**
     * الحصول على إشعارات المستخدم
     */
    private function getUserNotifications() {
        $limit = min(($_GET['limit'] ?? 20), 100);
        $unreadOnly = $_GET['unread_only'] ?? false;
        
        $notifications = $this->notificationManager->getUserNotifications(
            $this->currentUser['id'],
            $limit,
            $unreadOnly
        );
        
        $unreadCount = $this->notificationManager->getUnreadCount($this->currentUser['id']);
        
        $this->sendSuccess([
            'notifications' => $notifications,
            'unread_count' => $unreadCount
        ]);
    }
    
    /**
     * تحديد الإشعار كمقروء
     */
    private function markNotificationAsRead() {
        $input = $this->getInput();
        $notificationId = $input['notification_id'] ?? null;
        
        if ($notificationId) {
            $this->notificationManager->markAsRead($notificationId, $this->currentUser['id']);
            $this->sendSuccess(null, 'تم تحديد الإشعار كمقروء');
        } else {
            $this->notificationManager->markAllAsRead($this->currentUser['id']);
            $this->sendSuccess(null, 'تم تحديد جميع الإشعارات كمقروءة');
        }
    }
    
    /**
     * معالجة الملف الشخصي
     */
    private function handleProfile() {
        $method = $_SERVER['REQUEST_METHOD'];
        
        switch ($method) {
            case 'GET':
                $this->getUserProfile();
                break;
                
            case 'PUT':
                $this->updateUserProfile();
                break;
                
            default:
                $this->sendError('طريقة غير مسموحة', 405);
        }
    }
    
    /**
     * الحصول على الملف الشخصي
     */
    private function getUserProfile() {
        $profile = [
            'id' => $this->currentUser['id'],
            'username' => $this->currentUser['username'],
            'email' => $this->currentUser['email'],
            'full_name' => $this->currentUser['full_name'],
            'phone' => $this->currentUser['phone'],
            'created_at' => $this->currentUser['created_at']
        ];
        
        $this->sendSuccess($profile);
    }
    
    /**
     * تحديث الملف الشخصي
     */
    private function updateUserProfile() {
        $input = $this->getInput();
        $fullName = $input['full_name'] ?? $this->currentUser['full_name'];
        $phone = $input['phone'] ?? $this->currentUser['phone'];
        $email = $input['email'] ?? $this->currentUser['email'];
        
        // التحقق من صحة البريد الإلكتروني
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->sendError('البريد الإلكتروني غير صحيح');
        }
        
        // التحقق من عدم وجود البريد الإلكتروني لمستخدم آخر
        if ($email !== $this->currentUser['email']) {
            $stmt = $this->pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->execute([$email, $this->currentUser['id']]);
            if ($stmt->fetch()) {
                $this->sendError('البريد الإلكتروني موجود مسبقاً');
            }
        }
        
        // تحديث البيانات
        $stmt = $this->pdo->prepare("
            UPDATE users SET full_name = ?, phone = ?, email = ? WHERE id = ?
        ");
        
        if ($stmt->execute([$fullName, $phone, $email, $this->currentUser['id']])) {
            $this->sendSuccess(null, 'تم تحديث الملف الشخصي بنجاح');
        } else {
            $this->sendError('فشل في تحديث الملف الشخصي');
        }
    }
    
    /**
     * معالجة الشراء
     */
    private function handlePurchase() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendError('طريقة غير مسموحة', 405);
        }
        
        $input = $this->getInput();
        $orderId = $input['order_id'] ?? null;
        $paymentMethod = $input['payment_method'] ?? 'wallet';
        
        if (!$orderId) {
            $this->sendError('معرف الطلب مطلوب');
        }
        
        // الحصول على تفاصيل الطلب
        $stmt = $this->pdo->prepare("
            SELECT o.*, p.name as product_name 
            FROM orders o 
            JOIN products p ON o.product_id = p.id 
            WHERE o.id = ? AND o.user_id = ?
        ");
        $stmt->execute([$orderId, $this->currentUser['id']]);
        $order = $stmt->fetch();
        
        if (!$order) {
            $this->sendError('الطلب غير موجود');
        }
        
        if ($order['status'] !== 'pending') {
            $this->sendError('الطلب تم معالجته مسبقاً');
        }
        
        if ($paymentMethod === 'wallet') {
            $this->processWalletPayment($order);
        } else {
            $this->sendError('طريقة الدفع غير مدعومة');
        }
    }
    
    /**
     * معالجة الدفع من المحفظة
     */
    private function processWalletPayment($order) {
        // الحصول على رصيد المحفظة
        $stmt = $this->pdo->prepare("SELECT * FROM wallets WHERE user_id = ?");
        $stmt->execute([$this->currentUser['id']]);
        $wallet = $stmt->fetch();
        
        if (!$wallet) {
            $this->sendError('المحفظة غير موجودة');
        }
        
        $balanceField = "balance_" . strtolower($order['currency']);
        $currentBalance = $wallet[$balanceField];
        
        if ($currentBalance < $order['total_amount']) {
            $this->sendError('الرصيد غير كافي');
        }
        
        try {
            $this->pdo->beginTransaction();
            
            // خصم المبلغ من المحفظة
            $newBalance = $currentBalance - $order['total_amount'];
            $stmt = $this->pdo->prepare("UPDATE wallets SET $balanceField = ? WHERE user_id = ?");
            $stmt->execute([$newBalance, $this->currentUser['id']]);
            
            // إضافة معاملة المحفظة
            $stmt = $this->pdo->prepare("
                INSERT INTO wallet_transactions (
                    user_id, type, amount, currency, balance_before, 
                    balance_after, description, reference_id
                ) VALUES (?, 'withdraw', ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $this->currentUser['id'],
                $order['total_amount'],
                $order['currency'],
                $currentBalance,
                $newBalance,
                "دفع طلب #{$order['order_number']}",
                $order['order_number']
            ]);
            
            // تحديث حالة الطلب
            $stmt = $this->pdo->prepare("UPDATE orders SET status = 'paid' WHERE id = ?");
            $stmt->execute([$order['id']]);
            
            $this->pdo->commit();
            
            // إرسال إشعار نجاح الدفع
            $paymentData = [
                'transaction_id' => $order['order_number'],
                'amount' => $order['total_amount'],
                'currency' => $order['currency'],
                'gateway_name' => 'المحفظة الإلكترونية',
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            $this->notificationManager->sendPaymentSuccessNotification(
                $this->currentUser['id'],
                $this->currentUser['email'],
                $paymentData
            );
            
            $this->sendSuccess([
                'order_id' => $order['id'],
                'new_balance' => $newBalance
            ], 'تم الدفع بنجاح');
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            $this->sendError('فشل في معالجة الدفع');
        }
    }
}

// تشغيل واجهة برمجة التطبيقات
$api = new MobileAPI();
$api->handleRequest();
?>
