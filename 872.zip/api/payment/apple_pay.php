<?php
require_once '../../config/config.php';
require_once '../../config/payment_config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON input']);
    exit;
}

$user_id = $input['user_id'] ?? 0;
$amount = (float)($input['amount'] ?? 0);
$currency = $input['currency'] ?? 'USD';
$receipt_data = $input['receipt_data'] ?? '';

if (!$user_id || !$amount || !$receipt_data) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

try {
    $db = Database::getInstance()->getConnection();
    
    // Verify Apple Pay receipt
    $verification_result = verifyApplePayReceipt($receipt_data);
    
    if ($verification_result['success']) {
        // Create transaction
        $transaction_id = 'APPLE_' . uniqid();
        
        $stmt = $db->prepare("INSERT INTO payment_transactions (user_id, gateway_id, transaction_id, amount, currency, status, payment_method, gateway_response) VALUES (?, 5, ?, ?, ?, 'completed', 'apple_pay', ?)");
        $stmt->execute([$user_id, $transaction_id, $amount, $currency, json_encode($verification_result)]);
        
        // Update user wallet
        $wallet_field = 'wallet_balance_' . strtolower($currency);
        $stmt = $db->prepare("UPDATE users SET $wallet_field = $wallet_field + ? WHERE id = ?");
        $stmt->execute([$amount, $user_id]);
        
        // Add wallet transaction
        $stmt = $db->prepare("INSERT INTO wallet_transactions (user_id, type, amount, currency, description, status) VALUES (?, 'deposit', ?, ?, 'شحن المحفظة عبر Apple Pay', 'completed')");
        $stmt->execute([$user_id, $amount, $currency]);
        
        echo json_encode([
            'success' => true,
            'transaction_id' => $transaction_id,
            'message' => 'تم شحن المحفظة بنجاح عبر Apple Pay'
        ]);
    } else {
        throw new Exception('فشل في التحقق من إيصال Apple Pay');
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}

function verifyApplePayReceipt($receipt_data) {
    // Apple Pay receipt verification
    $sandbox_url = 'https://sandbox.itunes.apple.com/verifyReceipt';
    $production_url = 'https://buy.itunes.apple.com/verifyReceipt';
    
    $post_data = json_encode([
        'receipt-data' => $receipt_data,
        'password' => APPLE_SHARED_SECRET // Define this in payment_config.php
    ]);
    
    // Try production first
    $result = makeAppleRequest($production_url, $post_data);
    
    // If production fails with sandbox receipt, try sandbox
    if ($result && isset($result['status']) && $result['status'] == 21007) {
        $result = makeAppleRequest($sandbox_url, $post_data);
    }
    
    if ($result && isset($result['status']) && $result['status'] == 0) {
        return [
            'success' => true,
            'receipt' => $result['receipt'],
            'transaction_id' => $result['receipt']['in_app'][0]['transaction_id'] ?? uniqid()
        ];
    }
    
    return ['success' => false, 'error' => 'Invalid receipt'];
}

function makeAppleRequest($url, $data) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($response, true);
}
?>
