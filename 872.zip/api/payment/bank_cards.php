<?php
require_once '../../config/config.php';
require_once '../../config/payment_config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON input']);
    exit;
}

$user_id = $input['user_id'] ?? 0;
$amount = (float)($input['amount'] ?? 0);
$currency = $input['currency'] ?? 'SAR';
$card_number = $input['card_number'] ?? '';
$expiry_month = $input['expiry_month'] ?? '';
$expiry_year = $input['expiry_year'] ?? '';
$cvv = $input['cvv'] ?? '';
$card_holder = $input['card_holder'] ?? '';

if (!$user_id || !$amount || !$card_number || !$expiry_month || !$expiry_year || !$cvv) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

try {
    $db = Database::getInstance()->getConnection();
    
    // Process bank card payment
    $payment_result = processBankCardPayment([
        'card_number' => $card_number,
        'expiry_month' => $expiry_month,
        'expiry_year' => $expiry_year,
        'cvv' => $cvv,
        'card_holder' => $card_holder,
        'amount' => $amount,
        'currency' => $currency
    ]);
    
    if ($payment_result['success']) {
        // Create transaction
        $transaction_id = 'CARD_' . uniqid();
        
        $stmt = $db->prepare("INSERT INTO payment_transactions (user_id, gateway_id, transaction_id, gateway_transaction_id, amount, currency, status, payment_method, gateway_response) VALUES (?, 7, ?, ?, ?, ?, 'completed', 'bank_card', ?)");
        $stmt->execute([$user_id, $transaction_id, $payment_result['transaction_id'], $amount, $currency, json_encode($payment_result)]);
        
        // Update user wallet
        $wallet_field = 'wallet_balance_' . strtolower($currency);
        $stmt = $db->prepare("UPDATE users SET $wallet_field = $wallet_field + ? WHERE id = ?");
        $stmt->execute([$amount, $user_id]);
        
        // Add wallet transaction
        $stmt = $db->prepare("INSERT INTO wallet_transactions (user_id, type, amount, currency, description, status) VALUES (?, 'deposit', ?, ?, 'شحن المحفظة عبر البطاقة البنكية', 'completed')");
        $stmt->execute([$user_id, $amount, $currency]);
        
        echo json_encode([
            'success' => true,
            'transaction_id' => $transaction_id,
            'message' => 'تم شحن المحفظة بنجاح عبر البطاقة البنكية'
        ]);
    } else {
        throw new Exception($payment_result['error'] ?? 'فشل في معالجة الدفع');
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}

function processBankCardPayment($card_data) {
    // Integrate with Saudi payment gateway (Mada/Visa/Mastercard)
    
    // For Mada cards (Saudi Arabia)
    if (isMadaCard($card_data['card_number'])) {
        return processMadaPayment($card_data);
    }
    
    // For international cards (Visa/Mastercard)
    return processInternationalCardPayment($card_data);
}

function isMadaCard($card_number) {
    // Mada card BIN ranges
    $mada_bins = [
        '400861', '401757', '407197', '407395', '409201', '410685', '412565',
        '417633', '419593', '420132', '421141', '424519', '424679', '431361',
        '432328', '434107', '439954', '440533', '440647', '440795', '446393',
        '446404', '446672', '457865', '457997', '484783', '486094', '486104',
        '486674', '489318', '489362', '493428', '504300', '506968', '508160',
        '521076', '524130', '529415', '529741', '530906', '531095', '532013',
        '535825', '543357', '549760', '554180', '557606', '558563', '588845',
        '588848', '588850', '588982', '589005', '589206', '627781', '636120'
    ];
    
    $card_bin = substr($card_number, 0, 6);
    return in_array($card_bin, $mada_bins);
}

function processMadaPayment($card_data) {
    // Mada payment processing
    $transaction_id = 'MADA_' . uniqid();
    
    $payment_data = [
        'merchant_id' => MADA_MERCHANT_ID,
        'terminal_id' => MADA_TERMINAL_ID,
        'amount' => $card_data['amount'] * 100, // Convert to halalas
        'currency' => '682', // SAR currency code
        'card_number' => $card_data['card_number'],
        'expiry_date' => $card_data['expiry_month'] . $card_data['expiry_year'],
        'cvv' => $card_data['cvv'],
        'transaction_id' => $transaction_id,
        'timestamp' => date('YmdHis')
    ];
    
    // Create hash for security
    $hash_string = implode('|', $payment_data) . '|' . MADA_SECRET_KEY;
    $payment_data['hash'] = hash('sha256', $hash_string);
    
    // Make API call to Mada gateway
    $response = makePaymentRequest(MADA_API_URL, $payment_data);
    
    if ($response && $response['response_code'] === '00') {
        return [
            'success' => true,
            'transaction_id' => $response['transaction_id'],
            'approval_code' => $response['approval_code'],
            'response_code' => $response['response_code']
        ];
    }
    
    return [
        'success' => false,
        'error' => $response['response_message'] ?? 'فشل في معالجة الدفع عبر مدى'
    ];
}

function processInternationalCardPayment($card_data) {
    // Use Stripe for international cards
    $stripe_data = [
        'amount' => $card_data['amount'] * 100, // Convert to cents
        'currency' => strtolower($card_data['currency']),
        'payment_method_data' => [
            'type' => 'card',
            'card' => [
                'number' => $card_data['card_number'],
                'exp_month' => $card_data['expiry_month'],
                'exp_year' => $card_data['expiry_year'],
                'cvc' => $card_data['cvv']
            ],
            'billing_details' => [
                'name' => $card_data['card_holder']
            ]
        ],
        'confirm' => true,
        'return_url' => SITE_URL . '/user/payment_success.php'
    ];
    
    $response = makePaymentRequest('https://api.stripe.com/v1/payment_intents', 
        http_build_query($stripe_data), [
        'Authorization: Bearer ' . STRIPE_SECRET_KEY,
        'Content-Type: application/x-www-form-urlencoded'
    ]);
    
    if ($response && $response['status'] === 'succeeded') {
        return [
            'success' => true,
            'transaction_id' => $response['id'],
            'status' => $response['status']
        ];
    }
    
    return [
        'success' => false,
        'error' => $response['last_payment_error']['message'] ?? 'فشل في معالجة الدفع'
    ];
}

function makePaymentRequest($url, $data, $headers = []) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, is_array($data) ? json_encode($data) : $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    if (empty($headers)) {
        $headers = ['Content-Type: application/json'];
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code >= 200 && $http_code < 300) {
        return json_decode($response, true);
    }
    
    return false;
}
?>
