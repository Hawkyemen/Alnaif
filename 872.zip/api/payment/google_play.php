<?php
require_once '../../config/config.php';
require_once '../../config/payment_config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON input']);
    exit;
}

$user_id = $input['user_id'] ?? 0;
$amount = (float)($input['amount'] ?? 0);
$currency = $input['currency'] ?? 'USD';
$purchase_token = $input['purchase_token'] ?? '';
$product_id = $input['product_id'] ?? '';

if (!$user_id || !$amount || !$purchase_token || !$product_id) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

try {
    $db = Database::getInstance()->getConnection();
    
    // Verify Google Play purchase
    $verification_result = verifyGooglePlayPurchase($purchase_token, $product_id);
    
    if ($verification_result['success']) {
        // Create transaction
        $transaction_id = 'GOOGLE_' . uniqid();
        
        $stmt = $db->prepare("INSERT INTO payment_transactions (user_id, gateway_id, transaction_id, amount, currency, status, payment_method, gateway_response) VALUES (?, 6, ?, ?, ?, 'completed', 'google_play', ?)");
        $stmt->execute([$user_id, $transaction_id, $amount, $currency, json_encode($verification_result)]);
        
        // Update user wallet
        $wallet_field = 'wallet_balance_' . strtolower($currency);
        $stmt = $db->prepare("UPDATE users SET $wallet_field = $wallet_field + ? WHERE id = ?");
        $stmt->execute([$amount, $user_id]);
        
        // Add wallet transaction
        $stmt = $db->prepare("INSERT INTO wallet_transactions (user_id, type, amount, currency, description, status) VALUES (?, 'deposit', ?, ?, 'شحن المحفظة عبر Google Play', 'completed')");
        $stmt->execute([$user_id, $amount, $currency]);
        
        echo json_encode([
            'success' => true,
            'transaction_id' => $transaction_id,
            'message' => 'تم شحن المحفظة بنجاح عبر Google Play'
        ]);
    } else {
        throw new Exception('فشل في التحقق من شراء Google Play');
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}

function verifyGooglePlayPurchase($purchase_token, $product_id) {
    // Google Play purchase verification
    $access_token = getGooglePlayAccessToken();
    
    if (!$access_token) {
        return ['success' => false, 'error' => 'Failed to get access token'];
    }
    
    $url = "https://androidpublisher.googleapis.com/androidpublisher/v3/applications/" . GOOGLE_PLAY_PACKAGE_NAME . "/purchases/products/$product_id/tokens/$purchase_token";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $access_token,
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code == 200) {
        $data = json_decode($response, true);
        if ($data && isset($data['purchaseState']) && $data['purchaseState'] == 0) {
            return [
                'success' => true,
                'purchase_data' => $data,
                'order_id' => $data['orderId'] ?? uniqid()
            ];
        }
    }
    
    return ['success' => false, 'error' => 'Invalid purchase'];
}

function getGooglePlayAccessToken() {
    // Use service account key to get access token
    $service_account_key = json_decode(GOOGLE_PLAY_SERVICE_ACCOUNT_KEY, true);
    
    if (!$service_account_key) {
        return false;
    }
    
    $jwt = createJWT($service_account_key);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://oauth2.googleapis.com/token');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion' => $jwt
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $data = json_decode($response, true);
    return $data['access_token'] ?? false;
}

function createJWT($service_account_key) {
    $header = json_encode(['typ' => 'JWT', 'alg' => 'RS256']);
    $payload = json_encode([
        'iss' => $service_account_key['client_email'],
        'scope' => 'https://www.googleapis.com/auth/androidpublisher',
        'aud' => 'https://oauth2.googleapis.com/token',
        'exp' => time() + 3600,
        'iat' => time()
    ]);
    
    $base64_header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
    $base64_payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
    
    $signature_input = $base64_header . '.' . $base64_payload;
    
    openssl_sign($signature_input, $signature, $service_account_key['private_key'], OPENSSL_ALGO_SHA256);
    $base64_signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
    
    return $signature_input . '.' . $base64_signature;
}
?>
