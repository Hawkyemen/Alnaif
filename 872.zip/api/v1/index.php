<?php
/**
 * Advanced API System v1.0
 * نظام API متقدم
 * 
 * Features:
 * - JWT Authentication
 * - API Key Authentication
 * - Rate Limiting
 * - Comprehensive Endpoints
 * - Error Handling
 * - Request Logging
 * - CORS Support
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../../config/config.php';
require_once '../../config/api_config.php';

class AdvancedAPI {
    private $db;
    private $request_method;
    private $endpoint;
    private $params;
    private $authenticated_user = null;
    private $api_key_info = null;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->request_method = $_SERVER['REQUEST_METHOD'];
        $this->parseRequest();
        
        // Log API request
        $this->logRequest();
        
        // Check rate limiting
        $this->checkRateLimit();
    }
    
    private function parseRequest() {
        $request_uri = $_SERVER['REQUEST_URI'];
        $script_name = $_SERVER['SCRIPT_NAME'];
        $path = str_replace(dirname($script_name), '', $request_uri);
        $path = trim($path, '/');
        
        // Remove query string
        if (($pos = strpos($path, '?')) !== false) {
            $path = substr($path, 0, $pos);
        }
        
        $parts = explode('/', $path);
        $this->endpoint = $parts[0] ?? '';
        $this->params = array_slice($parts, 1);
    }
    
    public function processRequest() {
        try {
            // Authenticate request
            if (!$this->authenticate()) {
                return $this->sendResponse(401, ['error' => 'Authentication required']);
            }
            
            // Route to appropriate handler
            switch ($this->endpoint) {
                case 'users':
                    return $this->handleUsers();
                case 'products':
                    return $this->handleProducts();
                case 'orders':
                    return $this->handleOrders();
                case 'wallet':
                    return $this->handleWallet();
                case 'payments':
                    return $this->handlePayments();
                case 'charging':
                    return $this->handleCharging();
                case 'stats':
                    return $this->handleStats();
                case 'docs':
                    return $this->handleDocs();
                default:
                    return $this->sendResponse(404, ['error' => 'Endpoint not found']);
            }
            
        } catch (Exception $e) {
            error_log("API Error: " . $e->getMessage());
            return $this->sendResponse(500, ['error' => 'Internal server error']);
        }
    }
    
    private function authenticate() {
        // Check API Key authentication
        $api_key = $_SERVER['HTTP_X_API_KEY'] ?? $_GET['api_key'] ?? null;
        if ($api_key) {
            return $this->authenticateApiKey($api_key);
        }
        
        // Check JWT authentication
        $auth_header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (strpos($auth_header, 'Bearer ') === 0) {
            $token = substr($auth_header, 7);
            return $this->authenticateJWT($token);
        }
        
        // Public endpoints that don't require authentication
        $public_endpoints = ['docs', 'products'];
        if (in_array($this->endpoint, $public_endpoints) && $this->request_method === 'GET') {
            return true;
        }
        
        return false;
    }
    
    private function authenticateApiKey($api_key) {
        $stmt = $this->db->prepare("
            SELECT ak.*, u.id as user_id, u.username, u.email, u.role
            FROM api_keys ak
            LEFT JOIN users u ON ak.user_id = u.id
            WHERE ak.api_key = ? AND ak.status = 'active' AND ak.expires_at > NOW()
        ");
        $stmt->execute([$api_key]);
        $key_info = $stmt->fetch();
        
        if (!$key_info) {
            return false;
        }
        
        // Update last used
        $stmt = $this->db->prepare("UPDATE api_keys SET last_used_at = NOW() WHERE id = ?");
        $stmt->execute([$key_info['id']]);
        
        $this->api_key_info = $key_info;
        $this->authenticated_user = [
            'id' => $key_info['user_id'],
            'username' => $key_info['username'],
            'email' => $key_info['email'],
            'role' => $key_info['role'],
            'auth_type' => 'api_key'
        ];
        
        return true;
    }
    
    private function authenticateJWT($token) {
        try {
            $decoded = JWT::decode($token, API_JWT_SECRET, ['HS256']);
            
            // Verify user still exists and is active
            $stmt = $this->db->prepare("SELECT * FROM users WHERE id = ? AND status = 'active'");
            $stmt->execute([$decoded->user_id]);
            $user = $stmt->fetch();
            
            if (!$user) {
                return false;
            }
            
            $this->authenticated_user = [
                'id' => $user['id'],
                'username' => $user['username'],
                'email' => $user['email'],
                'role' => $user['role'],
                'auth_type' => 'jwt'
            ];
            
            return true;
            
        } catch (Exception $e) {
            return false;
        }
    }
    
    private function checkRateLimit() {
        if (!$this->authenticated_user) {
            return; // Skip rate limiting for unauthenticated requests
        }
        
        $user_id = $this->authenticated_user['id'];
        $window = 3600; // 1 hour
        $limit = 1000; // requests per hour
        
        // Check current request count
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM api_requests 
            WHERE user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL ? SECOND)
        ");
        $stmt->execute([$user_id, $window]);
        $request_count = $stmt->fetchColumn();
        
        if ($request_count >= $limit) {
            $this->sendResponse(429, [
                'error' => 'Rate limit exceeded',
                'limit' => $limit,
                'window' => $window,
                'reset_time' => time() + $window
            ]);
            exit();
        }
    }
    
    private function logRequest() {
        $user_id = $this->authenticated_user['id'] ?? null;
        $api_key_id = $this->api_key_info['id'] ?? null;
        
        $stmt = $this->db->prepare("
            INSERT INTO api_requests (user_id, api_key_id, endpoint, method, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $user_id,
            $api_key_id,
            $this->endpoint,
            $this->request_method,
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);
    }
    
    // Users endpoint handler
    private function handleUsers() {
        switch ($this->request_method) {
            case 'GET':
                if (isset($this->params[0])) {
                    return $this->getUser($this->params[0]);
                }
                return $this->getUsers();
                
            case 'POST':
                return $this->createUser();
                
            case 'PUT':
                if (isset($this->params[0])) {
                    return $this->updateUser($this->params[0]);
                }
                break;
                
            case 'DELETE':
                if (isset($this->params[0])) {
                    return $this->deleteUser($this->params[0]);
                }
                break;
        }
        
        return $this->sendResponse(405, ['error' => 'Method not allowed']);
    }
    
    private function getUsers() {
        // Only admins can list all users
        if ($this->authenticated_user['role'] !== 'admin') {
            return $this->sendResponse(403, ['error' => 'Access denied']);
        }
        
        $page = $_GET['page'] ?? 1;
        $limit = min($_GET['limit'] ?? 20, 100);
        $offset = ($page - 1) * $limit;
        
        $stmt = $this->db->prepare("
            SELECT id, username, email, role, status, created_at, last_login
            FROM users 
            ORDER BY created_at DESC 
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$limit, $offset]);
        $users = $stmt->fetchAll();
        
        // Get total count
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM users");
        $stmt->execute();
        $total = $stmt->fetchColumn();
        
        return $this->sendResponse(200, [
            'users' => $users,
            'pagination' => [
                'page' => (int)$page,
                'limit' => (int)$limit,
                'total' => (int)$total,
                'pages' => ceil($total / $limit)
            ]
        ]);
    }
    
    private function getUser($user_id) {
        // Users can only access their own data, admins can access any
        if ($this->authenticated_user['role'] !== 'admin' && $this->authenticated_user['id'] != $user_id) {
            return $this->sendResponse(403, ['error' => 'Access denied']);
        }
        
        $stmt = $this->db->prepare("
            SELECT u.*, w.balance as wallet_balance
            FROM users u
            LEFT JOIN wallets w ON u.id = w.user_id
            WHERE u.id = ?
        ");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
        
        if (!$user) {
            return $this->sendResponse(404, ['error' => 'User not found']);
        }
        
        // Remove sensitive data
        unset($user['password']);
        
        return $this->sendResponse(200, ['user' => $user]);
    }
    
    // Products endpoint handler
    private function handleProducts() {
        switch ($this->request_method) {
            case 'GET':
                if (isset($this->params[0])) {
                    return $this->getProduct($this->params[0]);
                }
                return $this->getProducts();
                
            case 'POST':
                return $this->createProduct();
                
            case 'PUT':
                if (isset($this->params[0])) {
                    return $this->updateProduct($this->params[0]);
                }
                break;
                
            case 'DELETE':
                if (isset($this->params[0])) {
                    return $this->deleteProduct($this->params[0]);
                }
                break;
        }
        
        return $this->sendResponse(405, ['error' => 'Method not allowed']);
    }
    
    private function getProducts() {
        $category = $_GET['category'] ?? null;
        $search = $_GET['search'] ?? null;
        $page = $_GET['page'] ?? 1;
        $limit = min($_GET['limit'] ?? 20, 100);
        $offset = ($page - 1) * $limit;
        
        $where_conditions = ["p.status = 'active'"];
        $params = [];
        
        if ($category) {
            $where_conditions[] = "c.name = ?";
            $params[] = $category;
        }
        
        if ($search) {
            $where_conditions[] = "(p.name LIKE ? OR p.description LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }
        
        $where_clause = implode(' AND ', $where_conditions);
        
        $stmt = $this->db->prepare("
            SELECT p.*, c.name as category_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE $where_clause
            ORDER BY p.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $params[] = $limit;
        $params[] = $offset;
        $stmt->execute($params);
        $products = $stmt->fetchAll();
        
        return $this->sendResponse(200, ['products' => $products]);
    }
    
    // Orders endpoint handler
    private function handleOrders() {
        switch ($this->request_method) {
            case 'GET':
                if (isset($this->params[0])) {
                    return $this->getOrder($this->params[0]);
                }
                return $this->getOrders();
                
            case 'POST':
                return $this->createOrder();
                
            case 'PUT':
                if (isset($this->params[0])) {
                    return $this->updateOrder($this->params[0]);
                }
                break;
        }
        
        return $this->sendResponse(405, ['error' => 'Method not allowed']);
    }
    
    private function createOrder() {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input || !isset($input['product_id']) || !isset($input['quantity'])) {
            return $this->sendResponse(400, ['error' => 'Missing required fields']);
        }
        
        $product_id = $input['product_id'];
        $quantity = $input['quantity'];
        $user_id = $this->authenticated_user['id'];
        
        // Get product details
        $stmt = $this->db->prepare("SELECT * FROM products WHERE id = ? AND status = 'active'");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch();
        
        if (!$product) {
            return $this->sendResponse(404, ['error' => 'Product not found']);
        }
        
        $total_amount = $product['price'] * $quantity;
        
        // Check wallet balance
        $stmt = $this->db->prepare("SELECT balance FROM wallets WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $wallet = $stmt->fetch();
        
        if (!$wallet || $wallet['balance'] < $total_amount) {
            return $this->sendResponse(400, ['error' => 'Insufficient wallet balance']);
        }
        
        try {
            $this->db->beginTransaction();
            
            // Create order
            $stmt = $this->db->prepare("
                INSERT INTO orders (user_id, product_id, quantity, unit_price, total_amount, status)
                VALUES (?, ?, ?, ?, ?, 'pending')
            ");
            $stmt->execute([$user_id, $product_id, $quantity, $product['price'], $total_amount]);
            $order_id = $this->db->lastInsertId();
            
            // Deduct from wallet
            $stmt = $this->db->prepare("UPDATE wallets SET balance = balance - ? WHERE user_id = ?");
            $stmt->execute([$total_amount, $user_id]);
            
            // Add wallet transaction
            $stmt = $this->db->prepare("
                INSERT INTO wallet_transactions (user_id, type, amount, description, order_id)
                VALUES (?, 'debit', ?, ?, ?)
            ");
            $stmt->execute([$user_id, $total_amount, "Order payment for {$product['name']}", $order_id]);
            
            // Update order status
            $stmt = $this->db->prepare("UPDATE orders SET status = 'completed' WHERE id = ?");
            $stmt->execute([$order_id]);
            
            $this->db->commit();
            
            return $this->sendResponse(201, [
                'message' => 'Order created successfully',
                'order_id' => $order_id,
                'total_amount' => $total_amount
            ]);
            
        } catch (Exception $e) {
            $this->db->rollBack();
            return $this->sendResponse(500, ['error' => 'Failed to create order']);
        }
    }
    
    // Wallet endpoint handler
    private function handleWallet() {
        $user_id = $this->authenticated_user['id'];
        
        switch ($this->request_method) {
            case 'GET':
                return $this->getWalletInfo($user_id);
                
            case 'POST':
                if (isset($this->params[0]) && $this->params[0] === 'topup') {
                    return $this->topupWallet($user_id);
                }
                break;
        }
        
        return $this->sendResponse(405, ['error' => 'Method not allowed']);
    }
    
    private function getWalletInfo($user_id) {
        // Get wallet balance
        $stmt = $this->db->prepare("SELECT * FROM wallets WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $wallet = $stmt->fetch();
        
        // Get recent transactions
        $stmt = $this->db->prepare("
            SELECT * FROM wallet_transactions 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT 10
        ");
        $stmt->execute([$user_id]);
        $transactions = $stmt->fetchAll();
        
        return $this->sendResponse(200, [
            'wallet' => $wallet,
            'recent_transactions' => $transactions
        ]);
    }
    
    // Stats endpoint handler
    private function handleStats() {
        if ($this->authenticated_user['role'] !== 'admin') {
            return $this->sendResponse(403, ['error' => 'Access denied']);
        }
        
        switch ($this->request_method) {
            case 'GET':
                return $this->getStats();
        }
        
        return $this->sendResponse(405, ['error' => 'Method not allowed']);
    }
    
    private function getStats() {
        $stats = [];
        
        // Users stats
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(*) as total_users,
                COUNT(CASE WHEN status = 'active' THEN 1 END) as active_users,
                COUNT(CASE WHEN DATE(created_at) = CURDATE() THEN 1 END) as today_users
            FROM users
        ");
        $stmt->execute();
        $stats['users'] = $stmt->fetch();
        
        // Orders stats
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(*) as total_orders,
                SUM(total_amount) as total_revenue,
                COUNT(CASE WHEN DATE(created_at) = CURDATE() THEN 1 END) as today_orders,
                SUM(CASE WHEN DATE(created_at) = CURDATE() THEN total_amount ELSE 0 END) as today_revenue
            FROM orders
            WHERE status = 'completed'
        ");
        $stmt->execute();
        $stats['orders'] = $stmt->fetch();
        
        // Products stats
        $stmt = $this->db->prepare("
            SELECT 
                COUNT(*) as total_products,
                COUNT(CASE WHEN status = 'active' THEN 1 END) as active_products
            FROM products
        ");
        $stmt->execute();
        $stats['products'] = $stmt->fetch();
        
        return $this->sendResponse(200, ['stats' => $stats]);
    }
    
    // Documentation endpoint
    private function handleDocs() {
        $docs = [
            'version' => '1.0',
            'base_url' => 'https://' . $_SERVER['HTTP_HOST'] . '/api/v1',
            'authentication' => [
                'api_key' => 'Include X-API-Key header or api_key parameter',
                'jwt' => 'Include Authorization: Bearer {token} header'
            ],
            'endpoints' => [
                'users' => [
                    'GET /users' => 'List all users (admin only)',
                    'GET /users/{id}' => 'Get user details',
                    'POST /users' => 'Create new user',
                    'PUT /users/{id}' => 'Update user',
                    'DELETE /users/{id}' => 'Delete user'
                ],
                'products' => [
                    'GET /products' => 'List products',
                    'GET /products/{id}' => 'Get product details',
                    'POST /products' => 'Create product (admin only)',
                    'PUT /products/{id}' => 'Update product (admin only)',
                    'DELETE /products/{id}' => 'Delete product (admin only)'
                ],
                'orders' => [
                    'GET /orders' => 'List user orders',
                    'GET /orders/{id}' => 'Get order details',
                    'POST /orders' => 'Create new order'
                ],
                'wallet' => [
                    'GET /wallet' => 'Get wallet info',
                    'POST /wallet/topup' => 'Top up wallet'
                ],
                'stats' => [
                    'GET /stats' => 'Get system statistics (admin only)'
                ]
            ],
            'rate_limits' => [
                'requests_per_hour' => 1000,
                'window' => 3600
            ]
        ];
        
        return $this->sendResponse(200, $docs);
    }
    
    private function sendResponse($status_code, $data) {
        http_response_code($status_code);
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit();
    }
}

// Simple JWT implementation
class JWT {
    public static function encode($payload, $key, $alg = 'HS256') {
        $header = json_encode(['typ' => 'JWT', 'alg' => $alg]);
        $payload = json_encode($payload);
        
        $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
        $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
        
        $signature = hash_hmac('sha256', $base64Header . "." . $base64Payload, $key, true);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
        
        return $base64Header . "." . $base64Payload . "." . $base64Signature;
    }
    
    public static function decode($jwt, $key, $allowed_algs = ['HS256']) {
        $parts = explode('.', $jwt);
        if (count($parts) != 3) {
            throw new Exception('Invalid JWT');
        }
        
        list($base64Header, $base64Payload, $base64Signature) = $parts;
        
        $header = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $base64Header)), true);
        $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $base64Payload)), true);
        
        if (!in_array($header['alg'], $allowed_algs)) {
            throw new Exception('Algorithm not allowed');
        }
        
        $signature = base64_decode(str_replace(['-', '_'], ['+', '/'], $base64Signature));
        $expected_signature = hash_hmac('sha256', $base64Header . "." . $base64Payload, $key, true);
        
        if (!hash_equals($signature, $expected_signature)) {
            throw new Exception('Invalid signature');
        }
        
        if (isset($payload['exp']) && $payload['exp'] < time()) {
            throw new Exception('Token expired');
        }
        
        return (object)$payload;
    }
}

// Initialize and process API request
$api = new AdvancedAPI();
$api->processRequest();
?>
