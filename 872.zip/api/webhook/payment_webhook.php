<?php
require_once '../../config/config.php';
require_once '../../config/payment_config.php';

header('Content-Type: application/json');

$input = file_get_contents('php://input');
$data = json_decode($input, true);

$db = Database::getInstance()->getConnection();

// Determine webhook source
$webhook_source = $_GET['source'] ?? 'unknown';

try {
    switch ($webhook_source) {
        case 'paypal':
            handlePayPalWebhook($data, $db);
            break;
        case 'stripe':
            handleStripeWebhook($data, $db);
            break;
        case 'mada':
            handleMadaWebhook($data, $db);
            break;
        case 'ymm':
            handleYMMWebhook($data, $db);
            break;
        default:
            throw new Exception('Unknown webhook source');
    }
    
    http_response_code(200);
    echo json_encode(['status' => 'success']);
    
} catch (Exception $e) {
    error_log('Webhook error: ' . $e->getMessage());
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}

function handlePayPalWebhook($data, $db) {
    if ($data['event_type'] === 'PAYMENT.SALE.COMPLETED') {
        $payment_id = $data['resource']['parent_payment'];
        
        // Update transaction status
        $stmt = $db->prepare("UPDATE payment_transactions SET status = 'completed', completed_at = NOW(), gateway_response = ? WHERE transaction_id = ?");
        $stmt->execute([json_encode($data), $payment_id]);
        
        // Get transaction details
        $stmt = $db->prepare("SELECT * FROM payment_transactions WHERE transaction_id = ?");
        $stmt->execute([$payment_id]);
        $transaction = $stmt->fetch();
        
        if ($transaction) {
            // Update user wallet
            $wallet_field = 'wallet_balance_' . strtolower($transaction['currency']);
            $stmt = $db->prepare("UPDATE users SET $wallet_field = $wallet_field + ? WHERE id = ?");
            $stmt->execute([$transaction['amount'], $transaction['user_id']]);
            
            // Add wallet transaction
            $stmt = $db->prepare("INSERT INTO wallet_transactions (user_id, type, amount, currency, description, status) VALUES (?, 'deposit', ?, ?, 'شحن المحفظة عبر PayPal', 'completed')");
            $stmt->execute([$transaction['user_id'], $transaction['amount'], $transaction['currency']]);
        }
    }
}

function handleStripeWebhook($data, $db) {
    if ($data['type'] === 'payment_intent.succeeded') {
        $payment_intent = $data['data']['object'];
        
        // Update transaction status
        $stmt = $db->prepare("UPDATE payment_transactions SET status = 'completed', completed_at = NOW(), gateway_response = ? WHERE transaction_id = ?");
        $stmt->execute([json_encode($data), $payment_intent['id']]);
        
        // Get transaction details
        $stmt = $db->prepare("SELECT * FROM payment_transactions WHERE transaction_id = ?");
        $stmt->execute([$payment_intent['id']]);
        $transaction = $stmt->fetch();
        
        if ($transaction) {
            // Update user wallet
            $wallet_field = 'wallet_balance_' . strtolower($transaction['currency']);
            $amount = $transaction['amount'];
            
            $stmt = $db->prepare("UPDATE users SET $wallet_field = $wallet_field + ? WHERE id = ?");
            $stmt->execute([$amount, $transaction['user_id']]);
            
            // Add wallet transaction
            $stmt = $db->prepare("INSERT INTO wallet_transactions (user_id, type, amount, currency, description, status) VALUES (?, 'deposit', ?, ?, 'شحن المحفظة عبر Stripe', 'completed')");
            $stmt->execute([$transaction['user_id'], $amount, $transaction['currency']]);
        }
    }
}

function handleMadaWebhook($data, $db) {
    if ($data['status'] === 'SUCCESS') {
        $transaction_id = $data['transaction_id'];
        
        // Update transaction status
        $stmt = $db->prepare("UPDATE payment_transactions SET status = 'completed', completed_at = NOW(), gateway_transaction_id = ?, gateway_response = ? WHERE transaction_id = ?");
        $stmt->execute([$data['mada_transaction_id'], json_encode($data), $transaction_id]);
        
        // Get transaction details
        $stmt = $db->prepare("SELECT * FROM payment_transactions WHERE transaction_id = ?");
        $stmt->execute([$transaction_id]);
        $transaction = $stmt->fetch();
        
        if ($transaction) {
            // Update user wallet
            $wallet_field = 'wallet_balance_' . strtolower($transaction['currency']);
            $stmt = $db->prepare("UPDATE users SET $wallet_field = $wallet_field + ? WHERE id = ?");
            $stmt->execute([$transaction['amount'], $transaction['user_id']]);
            
            // Add wallet transaction
            $stmt = $db->prepare("INSERT INTO wallet_transactions (user_id, type, amount, currency, description, status) VALUES (?, 'deposit', ?, ?, 'شحن المحفظة عبر مدى', 'completed')");
            $stmt->execute([$transaction['user_id'], $transaction['amount'], $transaction['currency']]);
        }
    }
}

function handleYMMWebhook($data, $db) {
    if ($data['status'] === 'completed') {
        $transaction_id = $data['merchant_transaction_id'];
        
        // Update transaction status
        $stmt = $db->prepare("UPDATE payment_transactions SET status = 'completed', completed_at = NOW(), gateway_transaction_id = ?, gateway_response = ? WHERE transaction_id = ?");
        $stmt->execute([$data['ymm_transaction_id'], json_encode($data), $transaction_id]);
        
        // Get transaction details
        $stmt = $db->prepare("SELECT * FROM payment_transactions WHERE transaction_id = ?");
        $stmt->execute([$transaction_id]);
        $transaction = $stmt->fetch();
        
        if ($transaction) {
            // Update user wallet
            $wallet_field = 'wallet_balance_' . strtolower($transaction['currency']);
            $stmt = $db->prepare("UPDATE users SET $wallet_field = $wallet_field + ? WHERE id = ?");
            $stmt->execute([$transaction['amount'], $transaction['user_id']]);
            
            // Add wallet transaction
            $stmt = $db->prepare("INSERT INTO wallet_transactions (user_id, type, amount, currency, description, status) VALUES (?, 'deposit', ?, ?, 'شحن المحفظة عبر Yemen Mobile Money', 'completed')");
            $stmt->execute([$transaction['user_id'], $transaction['amount'], $transaction['currency']]);
        }
    }
}
?>
