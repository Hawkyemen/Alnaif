<?php
/**
 * Advanced API Configuration
 * إعدادات API المتقدمة
 */

// JWT Configuration
define('API_JWT_SECRET', 'your-super-secret-jwt-key-change-this-in-production');
define('API_JWT_ALGORITHM', 'HS256');
define('API_JWT_EXPIRATION', 86400); // 24 hours
define('API_JWT_REFRESH_EXPIRATION', 604800); // 7 days

// API Rate Limiting
define('API_RATE_LIMIT_REQUESTS', 1000); // requests per window
define('API_RATE_LIMIT_WINDOW', 3600); // 1 hour in seconds
define('API_RATE_LIMIT_BURST', 100); // burst limit

// API Versioning
define('API_VERSION', '1.0');
define('API_MIN_VERSION', '1.0');
define('API_MAX_VERSION', '1.0');

// CORS Settings
define('API_CORS_ORIGINS', '*'); // Change to specific domains in production
define('API_CORS_METHODS', 'GET,POST,PUT,DELETE,OPTIONS');
define('API_CORS_HEADERS', 'Content-Type,Authorization,X-API-Key,X-Requested-With');

// API Security
define('API_REQUIRE_HTTPS', false); // Set to true in production
define('API_MAX_REQUEST_SIZE', 10485760); // 10MB
define('API_TIMEOUT', 30); // seconds

// Webhook Configuration
define('WEBHOOK_SECRET', 'your-webhook-secret-key');
define('WEBHOOK_TIMEOUT', 30);
define('WEBHOOK_MAX_RETRIES', 3);

// Payment Gateway API Keys
define('PAYPAL_CLIENT_ID', 'AYour_PayPal_Client_ID_Here');
define('PAYPAL_CLIENT_SECRET', 'Your_PayPal_Client_Secret_Here');
define('PAYPAL_SANDBOX', true); // Set to false for production

define('STRIPE_PUBLISHABLE_KEY', 'pk_test_Your_Stripe_Publishable_Key_Here');
define('STRIPE_SECRET_KEY', 'sk_test_Your_Stripe_Secret_Key_Here');
define('STRIPE_WEBHOOK_SECRET', 'whsec_Your_Stripe_Webhook_Secret_Here');

// Mada Payment Gateway (Saudi Arabia)
define('MADA_MERCHANT_ID', 'Your_Mada_Merchant_ID');
define('MADA_TERMINAL_ID', 'Your_Mada_Terminal_ID');
define('MADA_SECRET_KEY', 'Your_Mada_Secret_Key');
define('MADA_API_URL', 'https://api.mada.com.sa/payment');

// Apple Pay Configuration
define('APPLE_MERCHANT_ID', 'merchant.com.faststarone.app');
define('APPLE_BUNDLE_ID', 'com.faststarone.app');
define('APPLE_SHARED_SECRET', 'Your_Apple_Shared_Secret');
define('APPLE_PAY_ENVIRONMENT', 'sandbox'); // 'sandbox' or 'production'

// Google Pay Configuration
define('GOOGLE_PAY_MERCHANT_ID', 'Your_Google_Pay_Merchant_ID');
define('GOOGLE_PAY_ENVIRONMENT', 'TEST'); // 'TEST' or 'PRODUCTION'

// Yemen Mobile Money
define('YMM_MERCHANT_CODE', 'Your_YMM_Merchant_Code');
define('YMM_API_KEY', 'Your_YMM_API_Key');
define('YMM_API_URL', 'https://api.yemenmobi.com/payment');

// API Response Formats
define('API_DEFAULT_FORMAT', 'json');
define('API_SUPPORTED_FORMATS', ['json', 'xml']);

// Logging Configuration
define('API_LOG_REQUESTS', true);
define('API_LOG_RESPONSES', true);
define('API_LOG_ERRORS', true);
define('API_LOG_LEVEL', 'INFO'); // DEBUG, INFO, WARNING, ERROR

// Cache Configuration
define('API_CACHE_ENABLED', true);
define('API_CACHE_TTL', 300); // 5 minutes
define('API_CACHE_PREFIX', 'faststar_api_');

// Database Configuration for API
define('API_DB_HOST', DB_HOST);
define('API_DB_NAME', DB_NAME);
define('API_DB_USER', DB_USER);
define('API_DB_PASS', DB_PASS);

// API Error Messages (Arabic)
define('API_MESSAGES', [
    'INVALID_API_KEY' => 'مفتاح API غير صحيح',
    'RATE_LIMIT_EXCEEDED' => 'تم تجاوز الحد المسموح من الطلبات',
    'INVALID_TOKEN' => 'رمز المصادقة غير صحيح',
    'TOKEN_EXPIRED' => 'انتهت صلاحية رمز المصادقة',
    'INSUFFICIENT_PERMISSIONS' => 'صلاحيات غير كافية',
    'INVALID_REQUEST' => 'طلب غير صحيح',
    'RESOURCE_NOT_FOUND' => 'المورد غير موجود',
    'INTERNAL_ERROR' => 'خطأ داخلي في الخادم',
    'PAYMENT_FAILED' => 'فشل في عملية الدفع',
    'INSUFFICIENT_BALANCE' => 'رصيد غير كافي',
    'INVALID_PAYMENT_METHOD' => 'طريقة دفع غير صحيحة'
]);

// API Helper Functions
class APIConfig {
    
    public static function getPaymentGatewayConfig($gateway) {
        switch ($gateway) {
            case 'paypal':
                return [
                    'client_id' => PAYPAL_CLIENT_ID,
                    'client_secret' => PAYPAL_CLIENT_SECRET,
                    'sandbox' => PAYPAL_SANDBOX,
                    'api_url' => PAYPAL_SANDBOX ? 'https://api.sandbox.paypal.com' : 'https://api.paypal.com'
                ];
                
            case 'stripe':
                return [
                    'publishable_key' => STRIPE_PUBLISHABLE_KEY,
                    'secret_key' => STRIPE_SECRET_KEY,
                    'webhook_secret' => STRIPE_WEBHOOK_SECRET,
                    'api_url' => 'https://api.stripe.com'
                ];
                
            case 'mada':
                return [
                    'merchant_id' => MADA_MERCHANT_ID,
                    'terminal_id' => MADA_TERMINAL_ID,
                    'secret_key' => MADA_SECRET_KEY,
                    'api_url' => MADA_API_URL
                ];
                
            case 'apple_pay':
                return [
                    'merchant_id' => APPLE_MERCHANT_ID,
                    'bundle_id' => APPLE_BUNDLE_ID,
                    'shared_secret' => APPLE_SHARED_SECRET,
                    'environment' => APPLE_PAY_ENVIRONMENT
                ];
                
            case 'google_pay':
                return [
                    'merchant_id' => GOOGLE_PAY_MERCHANT_ID,
                    'environment' => GOOGLE_PAY_ENVIRONMENT
                ];
                
            case 'ymm':
                return [
                    'merchant_code' => YMM_MERCHANT_CODE,
                    'api_key' => YMM_API_KEY,
                    'api_url' => YMM_API_URL
                ];
                
            default:
                return null;
        }
    }
    
    public static function validateApiKey($api_key) {
        if (empty($api_key)) {
            return false;
        }
        
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("
            SELECT ak.*, u.id as user_id, u.username, u.status as user_status
            FROM api_keys ak
            LEFT JOIN users u ON ak.user_id = u.id
            WHERE ak.api_key = ? AND ak.status = 'active' 
            AND (ak.expires_at IS NULL OR ak.expires_at > NOW())
        ");
        $stmt->execute([$api_key]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($result) {
            // Update last used timestamp
            $stmt = $db->prepare("UPDATE api_keys SET last_used_at = NOW() WHERE id = ?");
            $stmt->execute([$result['id']]);
        }
        
        return $result;
    }
    
    public static function checkRateLimit($user_id, $api_key_id = null) {
        $db = Database::getInstance()->getConnection();
        
        // Check requests in the current window
        $stmt = $db->prepare("
            SELECT COUNT(*) as request_count
            FROM api_requests 
            WHERE user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL ? SECOND)
        ");
        $stmt->execute([$user_id, API_RATE_LIMIT_WINDOW]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result['request_count'] < API_RATE_LIMIT_REQUESTS;
    }
    
    public static function logApiRequest($data) {
        if (!API_LOG_REQUESTS) {
            return;
        }
        
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("
            INSERT INTO api_requests 
            (user_id, api_key_id, endpoint, method, request_data, response_code, response_time, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $data['user_id'] ?? null,
            $data['api_key_id'] ?? null,
            $data['endpoint'] ?? '',
            $data['method'] ?? '',
            json_encode($data['request_data'] ?? []),
            $data['response_code'] ?? 200,
            $data['response_time'] ?? 0,
            $_SERVER['REMOTE_ADDR'] ?? '',
            $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);
    }
    
    public static function generateApiKey($user_id, $name, $permissions = []) {
        $api_key = 'fsk_' . bin2hex(random_bytes(32));
        
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare("
            INSERT INTO api_keys (user_id, api_key, name, permissions, status)
            VALUES (?, ?, ?, ?, 'active')
        ");
        
        $stmt->execute([
            $user_id,
            $api_key,
            $name,
            json_encode($permissions)
        ]);
        
        return $api_key;
    }
}

// Initialize API error handler
set_error_handler(function($severity, $message, $file, $line) {
    if (API_LOG_ERRORS) {
        error_log("API Error: $message in $file on line $line");
    }
    
    if ($severity === E_ERROR || $severity === E_PARSE) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => [
                'code' => 500,
                'message' => API_MESSAGES['INTERNAL_ERROR']
            ]
        ]);
        exit;
    }
});

// Set timezone
date_default_timezone_set('Asia/Riyadh');
?>
