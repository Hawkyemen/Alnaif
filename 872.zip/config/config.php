<?php
// إعدادات قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_NAME', 'alnaif3');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// إعدادات الموقع
define('SITE_NAME', 'فاست ستار');
define('SITE_URL', 'http://localhost');
define('SITE_EMAIL', 'info@faststarone.com');
define('SITE_PHONE', '+967-1-234567');

// إعدادات الأمان
define('ENCRYPTION_KEY', 'your-secret-encryption-key-here-change-this');
define('JWT_SECRET', 'your-jwt-secret-key-here-change-this');
define('PASSWORD_SALT', 'your-password-salt-here-change-this');

// إعدادات الجلسة
define('SESSION_LIFETIME', 3600); // ساعة واحدة
define('REMEMBER_ME_LIFETIME', 2592000); // 30 يوم

// إعدادات رفع الملفات
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5 ميجابايت
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif']);
define('UPLOAD_PATH', __DIR__ . '/../uploads/');

// إعدادات API
define('API_RATE_LIMIT', 100); // طلب في الساعة
define('API_TIMEOUT', 30); // ثانية

// إعدادات الإيميل
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-app-password');
define('SMTP_ENCRYPTION', 'tls');

// إعدادات العملات وأسعار الصرف
define('EXCHANGE_RATES', [
    'YER' => 1,
    'SAR' => 0.004,    // 1 ريال يمني = 0.004 ريال سعودي
    'USD' => 0.00267,  // 1 ريال يمني = 0.00267 دولار
    'AED' => 0.0098    // 1 ريال يمني = 0.0098 درهم إماراتي
]);

// إعدادات المنطقة الزمنية
date_default_timezone_set('Asia/Aden');

// بدء الجلسة
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// الاتصال بقاعدة البيانات
class Database {
    private static $instance = null;
    private $connection;
    
    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
            ];
            
            $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // إذا فشل الاتصال بقاعدة البيانات، حاول الاتصال بدون تحديد اسم قاعدة البيانات
            try {
                $dsn = "mysql:host=" . DB_HOST . ";charset=" . DB_CHARSET;
                $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);
            } catch (PDOException $e2) {
                error_log("Database connection failed: " . $e2->getMessage());
                die("خطأ في الاتصال بقاعدة البيانات. يرجى التحقق من الإعدادات أو تشغيل setup_database.php");
            }
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->connection;
    }
}

// محاولة الحصول على اتصال قاعدة البيانات
try {
    $pdo = Database::getInstance()->getConnection();
} catch (Exception $e) {
    // إذا فشل الاتصال، توجيه المستخدم لصفحة الإعداد
    if (!isset($_SERVER['REQUEST_URI']) || strpos($_SERVER['REQUEST_URI'], 'setup_database.php') === false) {
        header('Location: setup_database.php');
        exit;
    }
}

// دوال مساعدة
function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    if (!headers_sent()) {
        header("Location: $url");
        exit;
    } else {
        echo "<script>window.location.href='$url';</script>";
        exit;
    }
}

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND status = 'active'");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch();
    } catch (Exception $e) {
        return null;
    }
}

function getCurrentAdmin() {
    if (!isAdmin()) {
        return null;
    }
    
    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE id = ? AND status = 'active'");
        $stmt->execute([$_SESSION['admin_id']]);
        return $stmt->fetch();
    } catch (Exception $e) {
        return null;
    }
}

function formatCurrency($amount, $currency = 'YER') {
    $symbols = [
        'YER' => 'ر.ي',
        'SAR' => 'ر.س',
        'USD' => '$',
        'AED' => 'د.إ'
    ];
    
    return number_format($amount, 2) . ' ' . ($symbols[$currency] ?? $currency);
}

function convertCurrency($amount, $from, $to) {
    if ($from === $to) {
        return $amount;
    }
    
    $rates = EXCHANGE_RATES;
    
    // تحويل إلى الريال اليمني أولاً
    $yer_amount = $amount / $rates[$from];
    
    // ثم تحويل إلى العملة المطلوبة
    return $yer_amount * $rates[$to];
}

function getUserWalletBalance($user_id, $currency = 'YER') {
    global $pdo;
    
    try {
        $column = 'wallet_balance_' . strtolower($currency);
        $stmt = $pdo->prepare("SELECT $column FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $result = $stmt->fetch();
        
        return $result ? $result[$column] : 0;
    } catch (Exception $e) {
        return 0;
    }
}

function updateUserWalletBalance($user_id, $amount, $currency, $type = 'deposit', $description = '') {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        // الحصول على الرصيد الحالي
        $current_balance = getUserWalletBalance($user_id, $currency);
        
        // حساب الرصيد الجديد
        $new_balance = $type === 'deposit' ? $current_balance + $amount : $current_balance - $amount;
        
        if ($new_balance < 0) {
            throw new Exception('الرصيد غير كافي');
        }
        
        // تحديث رصيد المحفظة
        $column = 'wallet_balance_' . strtolower($currency);
        $stmt = $pdo->prepare("UPDATE users SET $column = ? WHERE id = ?");
        $stmt->execute([$new_balance, $user_id]);
        
        // إضافة سجل المعاملة
        $stmt = $pdo->prepare("
            INSERT INTO wallet_transactions 
            (user_id, type, amount, currency, balance_before, balance_after, description, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 'completed')
        ");
        $stmt->execute([
            $user_id, $type, $amount, $currency, 
            $current_balance, $new_balance, $description
        ]);
        
        $pdo->commit();
        return true;
        
    } catch (Exception $e) {
        $pdo->rollback();
        logError("Wallet update error: " . $e->getMessage());
        return false;
    }
}

function logActivity($user_id, $admin_id, $action, $description, $data = null) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO activity_logs (user_id, admin_id, action, description, data, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $user_id, $admin_id, $action, $description, 
            $data ? json_encode($data) : null,
            $_SERVER['REMOTE_ADDR'] ?? '',
            $_SERVER['HTTP_USER_AGENT'] ?? ''
        ]);
    } catch (Exception $e) {
        error_log("Activity log error: " . $e->getMessage());
    }
}

function logError($message, $context = []) {
    $log_entry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'message' => $message,
        'context' => $context,
        'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
    ];
    
    error_log(json_encode($log_entry, JSON_UNESCAPED_UNICODE));
}

function sendNotification($user_id, $type, $title, $message, $data = null) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO notifications (user_id, type, title, message, data) 
            VALUES (?, ?, ?, ?, ?)
        ");
        
        return $stmt->execute([
            $user_id, $type, $title, $message, 
            $data ? json_encode($data) : null
        ]);
    } catch (Exception $e) {
        return false;
    }
}

function generateOrderNumber() {
    return 'FS' . date('Ymd') . rand(1000, 9999);
}

function generateTransactionId() {
    return 'TXN' . time() . rand(100, 999);
}

function getSystemSetting($key, $default = null) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetch();
        
        return $result ? $result['setting_value'] : $default;
    } catch (Exception $e) {
        return $default;
    }
}

function updateSystemSetting($key, $value, $category = 'general') {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO system_settings (category, setting_key, setting_value) 
            VALUES (?, ?, ?) 
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()
        ");
        
        return $stmt->execute([$category, $key, $value]);
    } catch (Exception $e) {
        return false;
    }
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validatePhone($phone) {
    return preg_match('/^[\+]?[0-9\-$$$$\s]+$/', $phone);
}

function generateSecureToken($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function isStrongPassword($password) {
    return strlen($password) >= 8 && 
           preg_match('/[A-Z]/', $password) && 
           preg_match('/[a-z]/', $password) && 
           preg_match('/[0-9]/', $password);
}

function timeAgo($datetime) {
    $time = time() - strtotime($datetime);
    
    if ($time < 60) return 'الآن';
    if ($time < 3600) return floor($time/60) . ' دقيقة';
    if ($time < 86400) return floor($time/3600) . ' ساعة';
    if ($time < 2592000) return floor($time/86400) . ' يوم';
    if ($time < 31536000) return floor($time/2592000) . ' شهر';
    
    return floor($time/31536000) . ' سنة';
}

function truncateText($text, $length = 100) {
    if (strlen($text) <= $length) {
        return $text;
    }
    
    return substr($text, 0, $length) . '...';
}

function isMaintenanceMode() {
    return getSystemSetting('maintenance_mode', '0') === '1';
}

function checkMaintenanceMode() {
    if (isMaintenanceMode() && !isAdmin()) {
        include 'maintenance.php';
        exit;
    }
}

// فحص وضع الصيانة
// checkMaintenanceMode();

// إعداد معالج الأخطاء
set_error_handler(function($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    
    logError("PHP Error: $message in $file on line $line", [
        'severity' => $severity,
        'file' => $file,
        'line' => $line
    ]);
    
    return true;
});

// إعداد معالج الاستثناءات
set_exception_handler(function($exception) {
    logError("Uncaught Exception: " . $exception->getMessage(), [
        'file' => $exception->getFile(),
        'line' => $exception->getLine(),
        'trace' => $exception->getTraceAsString()
    ]);
    
    if (!isAdmin()) {
        die('حدث خطأ في النظام. يرجى المحاولة لاحقاً.');
    }
});
?>
