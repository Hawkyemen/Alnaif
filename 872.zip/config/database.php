<?php
/**
 * إعدادات قاعدة البيانات المحلية
 * Local Database Configuration
 */

// إعدادات قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'alnaif3');
define('DB_CHARSET', 'utf8mb4');

// إعدادات الموقع
define('SITE_NAME', 'فاست ستار');
define('SITE_URL', 'http://localhost');
define('ADMIN_EMAIL', 'admin@faststarone.com');
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('UPLOAD_URL', SITE_URL . '/uploads/');

// إعدادات الأمان
define('HASH_ALGO', 'sha256');
define('SESSION_TIMEOUT', 3600);
define('MAX_LOGIN_ATTEMPTS', 5);
define('CSRF_TOKEN_NAME', 'csrf_token');

// إعدادات العملة
define('DEFAULT_CURRENCY', 'YER');
define('SUPPORTED_CURRENCIES', ['YER', 'SAR', 'USD', 'AED']);

// معلومات المدير الافتراضي
define('DEFAULT_ADMIN_USERNAME', 'admin');
define('DEFAULT_ADMIN_PASSWORD', 'faststar2024');
define('DEFAULT_ADMIN_EMAIL', 'admin@faststarone.com');

// معلومات المستخدم التجريبي
define('TEST_USER_USERNAME', 'testuser');
define('TEST_USER_PASSWORD', 'test123');
define('TEST_USER_EMAIL', 'test@example.com');

/**
 * فئة قاعدة البيانات
 */
class Database {
    private static $instance = null;
    private $connection;
    
    private function __construct() {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            $this->connection = new PDO($dsn, DB_USERNAME, DB_PASSWORD, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES ' . DB_CHARSET,
                PDO::ATTR_EMULATE_PREPARES => false
            ]);
            
            // اختبار الاتصال
            $this->connection->query('SELECT 1');
            
        } catch (PDOException $e) {
            error_log('Database connection failed: ' . $e->getMessage());
            die('خطأ في الاتصال بقاعدة البيانات. يرجى التحقق من الإعدادات.');
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    public function testConnection() {
        try {
            $stmt = $this->connection->query('SELECT 1 as test');
            return $stmt->fetch()['test'] === 1;
        } catch (Exception $e) {
            return false;
        }
    }
}

// بدء الجلسة
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * وظائف مساعدة
 */
function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header('Location: ' . $url);
    exit();
}

function is_logged_in() {
    return isset($_SESSION['user_id']) || isset($_SESSION['admin_id']);
}

function is_admin() {
    return isset($_SESSION['admin_id']);
}

function get_current_user() {
    if (isset($_SESSION['user_id'])) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare('SELECT * FROM users WHERE id = ? AND status = "active"');
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch();
    }
    return null;
}

function get_current_admin() {
    if (isset($_SESSION['admin_id'])) {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare('SELECT * FROM admins WHERE id = ? AND status = "active"');
        $stmt->execute([$_SESSION['admin_id']]);
        return $stmt->fetch();
    }
    return null;
}

function generate_csrf_token() {
    if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

function verify_csrf_token($token) {
    return isset($_SESSION[CSRF_TOKEN_NAME]) && hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

function format_currency($amount, $currency = 'YER') {
    $symbols = [
        'YER' => 'ر.ي',
        'SAR' => 'ر.س',
        'USD' => '$',
        'AED' => 'د.إ'
    ];
    
    return number_format($amount, 2) . ' ' . ($symbols[$currency] ?? $currency);
}

function get_setting($key, $default = null) {
    static $settings = null;
    
    if ($settings === null) {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->query('SELECT `key`, `value` FROM settings');
            $settings = [];
            while ($row = $stmt->fetch()) {
                $settings[$row['key']] = $row['value'];
            }
        } catch (Exception $e) {
            $settings = [];
        }
    }
    
    return $settings[$key] ?? $default;
}

function log_activity($user_id, $action, $details = null) {
    try {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->prepare('INSERT INTO activity_logs (user_id, action, details, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([
            $user_id,
            $action,
            $details,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
    } catch (Exception $e) {
        error_log('Failed to log activity: ' . $e->getMessage());
    }
}

// اختبار الاتصال عند تحميل الملف
try {
    $db_test = Database::getInstance();
    if (!$db_test->testConnection()) {
        throw new Exception('Database connection test failed');
    }
} catch (Exception $e) {
    error_log('Database initialization error: ' . $e->getMessage());
}
?>
