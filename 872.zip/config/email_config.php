<?php
/**
 * إعدادات البريد الإلكتروني
 */

class EmailConfig {
    // إعدادات SMTP
    const SMTP_HOST = 'smtp.gmail.com';
    const SMTP_PORT = 587;
    const SMTP_USERNAME = ''; // ضع بريدك الإلكتروني هنا
    const SMTP_PASSWORD = ''; // ضع كلمة مرور التطبيق هنا
    const SMTP_ENCRYPTION = 'tls';
    
    // إعدادات المرسل
    const FROM_EMAIL = 'noreply@yoursite.com';
    const FROM_NAME = 'نظام الشحن الإلكتروني';
    
    // قوالب البريد الإلكتروني
    const TEMPLATES = [
        'welcome' => 'مرحباً بك في نظام الشحن الإلكتروني',
        'order_confirmation' => 'تأكيد الطلب',
        'order_completed' => 'تم إكمال الطلب',
        'payment_success' => 'تم الدفع بنجاح',
        'payment_failed' => 'فشل في الدفع',
        'password_reset' => 'إعادة تعيين كلمة المرور'
    ];
    
    public static function getConfig() {
        return [
            'host' => self::SMTP_HOST,
            'port' => self::SMTP_PORT,
            'username' => self::SMTP_USERNAME,
            'password' => self::SMTP_PASSWORD,
            'encryption' => self::SMTP_ENCRYPTION,
            'from_email' => self::FROM_EMAIL,
            'from_name' => self::FROM_NAME
        ];
    }
}

/**
 * فئة إرسال البريد الإلكتروني
 */
class EmailSender {
    private $config;
    
    public function __construct() {
        $this->config = EmailConfig::getConfig();
    }
    
    /**
     * إرسال بريد إلكتروني
     */
    public function send($to, $subject, $body, $isHtml = true) {
        try {
            // استخدام PHPMailer أو mail() function
            if (function_exists('mail')) {
                $headers = "From: {$this->config['from_name']} <{$this->config['from_email']}>\r\n";
                $headers .= "Reply-To: {$this->config['from_email']}\r\n";
                $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
                
                if ($isHtml) {
                    $headers .= "MIME-Version: 1.0\r\n";
                    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                }
                
                return mail($to, $subject, $body, $headers);
            }
            
            return false;
        } catch (Exception $e) {
            error_log("Email sending failed: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * إرسال بريد ترحيب
     */
    public function sendWelcomeEmail($userEmail, $userName) {
        $subject = "مرحباً بك في نظام الشحن الإلكتروني";
        $body = $this->getWelcomeTemplate($userName);
        
        return $this->send($userEmail, $subject, $body);
    }
    
    /**
     * إرسال تأكيد الطلب
     */
    public function sendOrderConfirmation($userEmail, $orderData) {
        $subject = "تأكيد الطلب #{$orderData['order_number']}";
        $body = $this->getOrderConfirmationTemplate($orderData);
        
        return $this->send($userEmail, $subject, $body);
    }
    
    /**
     * إرسال إشعار إكمال الطلب
     */
    public function sendOrderCompleted($userEmail, $orderData) {
        $subject = "تم إكمال طلبك #{$orderData['order_number']}";
        $body = $this->getOrderCompletedTemplate($orderData);
        
        return $this->send($userEmail, $subject, $body);
    }
    
    /**
     * إرسال إشعار نجاح الدفع
     */
    public function sendPaymentSuccess($userEmail, $paymentData) {
        $subject = "تم الدفع بنجاح";
        $body = $this->getPaymentSuccessTemplate($paymentData);
        
        return $this->send($userEmail, $subject, $body);
    }
    
    /**
     * قالب البريد الترحيبي
     */
    private function getWelcomeTemplate($userName) {
        return "
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: Arial, sans-serif; direction: rtl; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #007bff; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background: #f8f9fa; }
                .footer { padding: 20px; text-align: center; color: #666; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>مرحباً بك في نظام الشحن الإلكتروني</h1>
                </div>
                <div class='content'>
                    <h2>أهلاً وسهلاً {$userName}</h2>
                    <p>نحن سعداء بانضمامك إلى منصتنا لشحن الألعاب والتطبيقات.</p>
                    <p>يمكنك الآن:</p>
                    <ul>
                        <li>شحن ألعابك المفضلة</li>
                        <li>شراء بطاقات الهدايا</li>
                        <li>إدارة محفظتك الإلكترونية</li>
                        <li>متابعة طلباتك</li>
                    </ul>
                    <p>إذا كان لديك أي استفسار، لا تتردد في التواصل معنا.</p>
                </div>
                <div class='footer'>
                    <p>شكراً لاختيارك منصتنا</p>
                    <p>فريق نظام الشحن الإلكتروني</p>
                </div>
            </div>
        </body>
        </html>
        ";
    }
    
    /**
     * قالب تأكيد الطلب
     */
    private function getOrderConfirmationTemplate($orderData) {
        return "
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: Arial, sans-serif; direction: rtl; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #28a745; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background: #f8f9fa; }
                .order-details { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; }
                .footer { padding: 20px; text-align: center; color: #666; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>تأكيد الطلب</h1>
                </div>
                <div class='content'>
                    <h2>تم استلام طلبك بنجاح</h2>
                    <div class='order-details'>
                        <h3>تفاصيل الطلب:</h3>
                        <p><strong>رقم الطلب:</strong> {$orderData['order_number']}</p>
                        <p><strong>المنتج:</strong> {$orderData['product_name']}</p>
                        <p><strong>المبلغ:</strong> {$orderData['total_amount']} {$orderData['currency']}</p>
                        <p><strong>تاريخ الطلب:</strong> {$orderData['created_at']}</p>
                        <p><strong>حالة الطلب:</strong> قيد المعالجة</p>
                    </div>
                    <p>سيتم معالجة طلبك خلال الوقت المحدد وستحصل على إشعار عند الانتهاء.</p>
                </div>
                <div class='footer'>
                    <p>شكراً لثقتك بنا</p>
                    <p>فريق نظام الشحن الإلكتروني</p>
                </div>
            </div>
        </body>
        </html>
        ";
    }
    
    /**
     * قالب إكمال الطلب
     */
    private function getOrderCompletedTemplate($orderData) {
        return "
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: Arial, sans-serif; direction: rtl; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #007bff; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background: #f8f9fa; }
                .success-box { background: #d4edda; border: 1px solid #c3e6cb; padding: 15px; margin: 10px 0; border-radius: 5px; }
                .footer { padding: 20px; text-align: center; color: #666; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>تم إكمال طلبك بنجاح!</h1>
                </div>
                <div class='content'>
                    <div class='success-box'>
                        <h2>🎉 تهانينا!</h2>
                        <p>تم إكمال طلبك #{$orderData['order_number']} بنجاح</p>
                    </div>
                    <h3>تفاصيل الطلب:</h3>
                    <p><strong>المنتج:</strong> {$orderData['product_name']}</p>
                    <p><strong>المبلغ:</strong> {$orderData['total_amount']} {$orderData['currency']}</p>
                    " . (isset($orderData['delivery_details']) ? "<p><strong>تفاصيل التسليم:</strong> {$orderData['delivery_details']}</p>" : "") . "
                    <p>يمكنك الآن الاستمتاع بخدمتك المشتراة.</p>
                </div>
                <div class='footer'>
                    <p>شكراً لاختيارك منصتنا</p>
                    <p>فريق نظام الشحن الإلكتروني</p>
                </div>
            </div>
        </body>
        </html>
        ";
    }
    
    /**
     * قالب نجاح الدفع
     */
    private function getPaymentSuccessTemplate($paymentData) {
        return "
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: Arial, sans-serif; direction: rtl; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #28a745; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background: #f8f9fa; }
                .payment-details { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; }
                .footer { padding: 20px; text-align: center; color: #666; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>تم الدفع بنجاح</h1>
                </div>
                <div class='content'>
                    <h2>✅ تم استلام دفعتك</h2>
                    <div class='payment-details'>
                        <h3>تفاصيل الدفع:</h3>
                        <p><strong>رقم المعاملة:</strong> {$paymentData['transaction_id']}</p>
                        <p><strong>المبلغ:</strong> {$paymentData['amount']} {$paymentData['currency']}</p>
                        <p><strong>طريقة الدفع:</strong> {$paymentData['gateway_name']}</p>
                        <p><strong>التاريخ:</strong> {$paymentData['created_at']}</p>
                    </div>
                    <p>تم معالجة دفعتك بنجاح وسيتم تنفيذ طلبك قريباً.</p>
                </div>
                <div class='footer'>
                    <p>شكراً لثقتك بنا</p>
                    <p>فريق نظام الشحن الإلكتروني</p>
                </div>
            </div>
        </body>
        </html>
        ";
    }
}

/**
 * فئة إدارة الإشعارات
 */
class NotificationManager {
    private $pdo;
    private $emailSender;
    
    public function __construct() {
        $this->pdo = Database::getInstance()->getConnection();
        $this->emailSender = new EmailSender();
    }
    
    /**
     * إنشاء إشعار جديد
     */
    public function createNotification($userId, $type, $title, $message, $data = null) {
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO notifications (user_id, type, title, message, data) 
                VALUES (?, ?, ?, ?, ?)
            ");
            
            return $stmt->execute([
                $userId,
                $type,
                $title,
                $message,
                $data ? json_encode($data) : null
            ]);
        } catch (Exception $e) {
            error_log("Failed to create notification: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * إرسال إشعار ترحيب
     */
    public function sendWelcomeNotification($userId, $userEmail, $userName) {
        // إنشاء إشعار في قاعدة البيانات
        $this->createNotification(
            $userId,
            'welcome',
            'مرحباً بك!',
            'مرحباً بك في نظام الشحن الإلكتروني. نحن سعداء بانضمامك إلينا.'
        );
        
        // إرسال بريد إلكتروني
        return $this->emailSender->sendWelcomeEmail($userEmail, $userName);
    }
    
    /**
     * إرسال إشعار تأكيد الطلب
     */
    public function sendOrderConfirmationNotification($userId, $userEmail, $orderData) {
        // إنشاء إشعار في قاعدة البيانات
        $this->createNotification(
            $userId,
            'order_confirmation',
            'تأكيد الطلب',
            "تم استلام طلبك #{$orderData['order_number']} وسيتم معالجته قريباً.",
            $orderData
        );
        
        // إرسال بريد إلكتروني
        return $this->emailSender->sendOrderConfirmation($userEmail, $orderData);
    }
    
    /**
     * إرسال إشعار إكمال الطلب
     */
    public function sendOrderCompletedNotification($userId, $userEmail, $orderData) {
        // إنشاء إشعار في قاعدة البيانات
        $this->createNotification(
            $userId,
            'order_completed',
            'تم إكمال الطلب',
            "تم إكمال طلبك #{$orderData['order_number']} بنجاح!",
            $orderData
        );
        
        // إرسال بريد إلكتروني
        return $this->emailSender->sendOrderCompleted($userEmail, $orderData);
    }
    
    /**
     * إرسال إشعار نجاح الدفع
     */
    public function sendPaymentSuccessNotification($userId, $userEmail, $paymentData) {
        // إنشاء إشعار في قاعدة البيانات
        $this->createNotification(
            $userId,
            'payment_success',
            'تم الدفع بنجاح',
            "تم استلام دفعتك بمبلغ {$paymentData['amount']} {$paymentData['currency']} بنجاح.",
            $paymentData
        );
        
        // إرسال بريد إلكتروني
        return $this->emailSender->sendPaymentSuccess($userEmail, $paymentData);
    }
    
    /**
     * الحصول على إشعارات المستخدم
     */
    public function getUserNotifications($userId, $limit = 10, $unreadOnly = false) {
        try {
            $sql = "SELECT * FROM notifications WHERE user_id = ?";
            $params = [$userId];
            
            if ($unreadOnly) {
                $sql .= " AND is_read = 0";
            }
            
            $sql .= " ORDER BY created_at DESC LIMIT ?";
            $params[] = $limit;
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Failed to get user notifications: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * تحديد الإشعار كمقروء
     */
    public function markAsRead($notificationId, $userId) {
        try {
            $stmt = $this->pdo->prepare("
                UPDATE notifications 
                SET is_read = 1, read_at = NOW() 
                WHERE id = ? AND user_id = ?
            ");
            
            return $stmt->execute([$notificationId, $userId]);
        } catch (Exception $e) {
            error_log("Failed to mark notification as read: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * تحديد جميع الإشعارات كمقروءة
     */
    public function markAllAsRead($userId) {
        try {
            $stmt = $this->pdo->prepare("
                UPDATE notifications 
                SET is_read = 1, read_at = NOW() 
                WHERE user_id = ? AND is_read = 0
            ");
            
            return $stmt->execute([$userId]);
        } catch (Exception $e) {
            error_log("Failed to mark all notifications as read: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * عدد الإشعارات غير المقروءة
     */
    public function getUnreadCount($userId) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT COUNT(*) FROM notifications 
                WHERE user_id = ? AND is_read = 0
            ");
            $stmt->execute([$userId]);
            
            return $stmt->fetchColumn();
        } catch (Exception $e) {
            error_log("Failed to get unread count: " . $e->getMessage());
            return 0;
        }
    }
}
?>
