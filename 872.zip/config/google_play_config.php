<?php
/**
 * Google Play Billing Production Configuration
 * إعداد Google Play Billing للإنتاج
 */

// Google Play Production Settings
define('GOOGLE_PLAY_ENVIRONMENT', 'production'); // 'sandbox' or 'production'
define('GOOGLE_PLAY_PACKAGE_NAME', 'com.faststarone.app');
define('GOOGLE_PLAY_APPLICATION_NAME', 'FastStarOne');

// Service Account Configuration
define('GOOGLE_PLAY_SERVICE_ACCOUNT_EMAIL', 'faststarone-billing@faststarone-prod.iam.gserviceaccount.com');
define('GOOGLE_PLAY_SERVICE_ACCOUNT_KEY_FILE', __DIR__ . '/certificates/google-play-service-account.json');

// API URLs
define('GOOGLE_PLAY_API_BASE_URL', 'https://androidpublisher.googleapis.com/androidpublisher/v3');
define('GOOGLE_OAUTH2_TOKEN_URL', 'https://oauth2.googleapis.com/token');

class GooglePlayProduction {
    
    private $packageName;
    private $serviceAccountEmail;
    private $serviceAccountKeyFile;
    private $accessToken;
    private $tokenExpiry;
    
    public function __construct() {
        $this->packageName = GOOGLE_PLAY_PACKAGE_NAME;
        $this->serviceAccountEmail = GOOGLE_PLAY_SERVICE_ACCOUNT_EMAIL;
        $this->serviceAccountKeyFile = GOOGLE_PLAY_SERVICE_ACCOUNT_KEY_FILE;
    }
    
    /**
     * Get OAuth2 access token
     */
    private function getAccessToken() {
        if ($this->accessToken && $this->tokenExpiry > time()) {
            return $this->accessToken;
        }
        
        if (!file_exists($this->serviceAccountKeyFile)) {
            throw new Exception('Google Play service account key file not found');
        }
        
        $serviceAccount = json_decode(file_get_contents($this->serviceAccountKeyFile), true);
        if (!$serviceAccount) {
            throw new Exception('Invalid service account key file');
        }
        
        // Create JWT
        $header = json_encode(['alg' => 'RS256', 'typ' => 'JWT']);
        $now = time();
        $payload = json_encode([
            'iss' => $serviceAccount['client_email'],
            'scope' => 'https://www.googleapis.com/auth/androidpublisher',
            'aud' => GOOGLE_OAUTH2_TOKEN_URL,
            'exp' => $now + 3600,
            'iat' => $now
        ]);
        
        $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
        $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
        
        $signature = '';
        openssl_sign($base64Header . '.' . $base64Payload, $signature, $serviceAccount['private_key'], 'SHA256');
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
        
        $jwt = $base64Header . '.' . $base64Payload . '.' . $base64Signature;
        
        // Request access token
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => GOOGLE_OAUTH2_TOKEN_URL,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query([
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $jwt
            ]),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded']
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200) {
            throw new Exception('Failed to get access token: HTTP ' . $httpCode);
        }
        
        $tokenData = json_decode($response, true);
        if (!$tokenData || !isset($tokenData['access_token'])) {
            throw new Exception('Invalid token response');
        }
        
        $this->accessToken = $tokenData['access_token'];
        $this->tokenExpiry = time() + ($tokenData['expires_in'] ?? 3600) - 60; // 1 minute buffer
        
        return $this->accessToken;
    }
    
    /**
     * Verify purchase with Google Play
     */
    public function verifyPurchase($productId, $purchaseToken) {
        $accessToken = $this->getAccessToken();
        
        $url = GOOGLE_PLAY_API_BASE_URL . "/applications/{$this->packageName}/purchases/products/{$productId}/tokens/{$purchaseToken}";
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $accessToken,
                'Content-Type: application/json'
            ]
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200) {
            throw new Exception('Purchase verification failed: HTTP ' . $httpCode);
        }
        
        $purchaseData = json_decode($response, true);
        if (!$purchaseData) {
            throw new Exception('Invalid purchase verification response');
        }
        
        return $purchaseData;
    }
    
    /**
     * Acknowledge purchase
     */
    public function acknowledgePurchase($productId, $purchaseToken) {
        $accessToken = $this->getAccessToken();
        
        $url = GOOGLE_PLAY_API_BASE_URL . "/applications/{$this->packageName}/purchases/products/{$productId}/tokens/{$purchaseToken}:acknowledge";
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => '{}',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $accessToken,
                'Content-Type: application/json'
            ]
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return $httpCode === 204; // No content means success
    }
    
    /**
     * Process Google Play purchase
     */
    public function processPurchase($userId, $productId, $purchaseToken, $orderId) {
        try {
            // Verify purchase with Google Play
            $purchaseData = $this->verifyPurchase($productId, $purchaseToken);
            
            // Check if purchase is valid
            if ($purchaseData['purchaseState'] !== 1) { // 1 = Purchased
                throw new Exception('Purchase is not in purchased state');
            }
            
            if ($purchaseData['consumptionState'] === 1) { // 1 = Consumed
                throw new Exception('Purchase has already been consumed');
            }
            
            // Get product details
            $product = $this->getWalletProduct($productId);
            if (!$product) {
                throw new Exception('Product not found');
            }
            
            // Check for duplicate purchase
            if ($this->isDuplicatePurchase($orderId)) {
                throw new Exception('Duplicate purchase detected');
            }
            
            // Process the purchase
            $transactionId = 'gplay_' . $orderId;
            
            // Update user wallet
            $this->updateUserWallet($userId, $product['amount'], $product['currency'], $transactionId);
            
            // Record the purchase
            $this->recordPurchase($userId, $productId, $purchaseToken, $orderId, $product, $purchaseData);
            
            // Acknowledge the purchase
            $acknowledged = $this->acknowledgePurchase($productId, $purchaseToken);
            
            if (!$acknowledged) {
                error_log('Failed to acknowledge Google Play purchase: ' . $orderId);
            }
            
            return [
                'success' => true,
                'transactionId' => $transactionId,
                'amount' => $product['amount'],
                'currency' => $product['currency'],
                'message' => 'Purchase processed successfully'
            ];
            
        } catch (Exception $e) {
            error_log('Google Play purchase processing error: ' . $e->getMessage());
            
            // Record failed purchase
            $this->recordFailedPurchase($userId, $productId, $purchaseToken, $orderId, $e->getMessage());
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get wallet product details
     */
    private function getWalletProduct($productId) {
        $db = Database::getInstance()->getConnection();
        
        $stmt = $db->prepare("SELECT * FROM wallet_topup_products WHERE product_id = ? AND platform = 'android' AND status = 'active'");
        $stmt->execute([$productId]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Check for duplicate purchase
     */
    private function isDuplicatePurchase($orderId) {
        $db = Database::getInstance()->getConnection();
        
        $stmt = $db->prepare("SELECT id FROM in_app_purchases WHERE transaction_id = ? AND platform = 'android'");
        $stmt->execute([$orderId]);
        
        return $stmt->rowCount() > 0;
    }
    
    /**
     * Update user wallet balance
     */
    private function updateUserWallet($userId, $amount, $currency, $transactionId) {
        $db = Database::getInstance()->getConnection();
        
        try {
            $db->beginTransaction();
            
            // Update wallet balance
            $walletField = 'wallet_balance_' . strtolower($currency);
            $stmt = $db->prepare("UPDATE users SET $walletField = $walletField + ? WHERE id = ?");
            $stmt->execute([$amount, $userId]);
            
            // Add wallet transaction record
            $stmt = $db->prepare("
                INSERT INTO wallet_transactions 
                (user_id, type, amount, currency, description, transaction_id, status) 
                VALUES (?, 'deposit', ?, ?, 'شحن المحفظة عبر Google Play', ?, 'completed')
            ");
            $stmt->execute([$userId, $amount, $currency, $transactionId]);
            
            $db->commit();
            
        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }
    }
    
    /**
     * Record successful purchase
     */
    private function recordPurchase($userId, $productId, $purchaseToken, $orderId, $product, $purchaseData) {
        $db = Database::getInstance()->getConnection();
        
        $stmt = $db->prepare("
            INSERT INTO in_app_purchases 
            (user_id, platform, product_id, transaction_id, original_transaction_id, receipt_data, amount, currency, status, verification_data) 
            VALUES (?, 'android', ?, ?, ?, ?, ?, ?, 'verified', ?)
        ");
        
        $receiptData = json_encode([
            'purchaseToken' => $purchaseToken,
            'orderId' => $orderId,
            'packageName' => $this->packageName
        ]);
        
        $stmt->execute([
            $userId,
            $productId,
            $orderId,
            $orderId, // original_transaction_id same as transaction_id for Google Play
            $receiptData,
            $product['amount'],
            $product['currency'],
            json_encode($purchaseData)
        ]);
    }
    
    /**
     * Record failed purchase
     */
    private function recordFailedPurchase($userId, $productId, $purchaseToken, $orderId, $error) {
        $db = Database::getInstance()->getConnection();
        
        try {
            $stmt = $db->prepare("
                INSERT INTO in_app_purchases 
                (user_id, platform, product_id, transaction_id, receipt_data, amount, currency, status, verification_data) 
                VALUES (?, 'android', ?, ?, ?, 0, 'SAR', 'failed', ?)
            ");
            
            $receiptData = json_encode([
                'purchaseToken' => $purchaseToken,
                'orderId' => $orderId,
                'packageName' => $this->packageName
            ]);
            
            $verificationData = json_encode([
                'error' => $error,
                'timestamp' => date('Y-m-d H:i:s')
            ]);
            
            $stmt->execute([$userId, $productId, $orderId, $receiptData, $verificationData]);
            
        } catch (Exception $e) {
            error_log('Failed to record failed Google Play purchase: ' . $e->getMessage());
        }
    }
    
    /**
     * Get available products for Google Play
     */
    public function getAvailableProducts() {
        $db = Database::getInstance()->getConnection();
        
        $stmt = $db->query("
            SELECT product_id, amount, currency, price_local, currency_local, title_ar, title_en, description_ar, description_en 
            FROM wallet_topup_products 
            WHERE platform = 'android' AND status = 'active' 
            ORDER BY amount ASC
        ");
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Validate service account configuration
     */
    public function validateConfiguration() {
        $errors = [];
        
        // Check service account key file
        if (!file_exists($this->serviceAccountKeyFile)) {
            $errors[] = 'Service account key file not found';
        } else {
            $serviceAccount = json_decode(file_get_contents($this->serviceAccountKeyFile), true);
            if (!$serviceAccount) {
                $errors[] = 'Invalid service account key file format';
            } elseif (!isset($serviceAccount['client_email']) || !isset($serviceAccount['private_key'])) {
                $errors[] = 'Service account key file missing required fields';
            }
        }
        
        // Test API connection
        try {
            $this->getAccessToken();
        } catch (Exception $e) {
            $errors[] = 'Failed to get access token: ' . $e->getMessage();
        }
        
        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }
    
    /**
     * Get setup instructions for production
     */
    public static function getProductionSetupInstructions() {
        return [
            'service_account' => [
                'title' => 'إعداد حساب الخدمة',
                'items' => [
                    'إنشاء مشروع في Google Cloud Console',
                    'تفعيل Google Play Android Publisher API',
                    'إنشاء حساب خدمة جديد',
                    'تنزيل ملف JSON للحساب',
                    'منح الصلاحيات في Google Play Console'
                ]
            ],
            'play_console' => [
                'title' => 'إعداد Google Play Console',
                'items' => [
                    'ربط حساب الخدمة بالتطبيق',
                    'منح صلاحيات "View app information and download bulk reports"',
                    'منح صلاحيات "Manage orders and subscriptions"',
                    'إعداد منتجات الشحن في التطبيق',
                    'نشر التطبيق للاختبار أو الإنتاج'
                ]
            ],
            'configuration' => [
                'title' => 'الإعدادات',
                'items' => [
                    'تحديث GOOGLE_PLAY_ENVIRONMENT إلى production',
                    'تحديث مسار ملف حساب الخدمة',
                    'تحديث اسم الحزمة',
                    'اختبار التكامل مع Google Play'
                ]
            ],
            'testing' => [
                'title' => 'الاختبار',
                'items' => [
                    'اختبار الحصول على رمز الوصول',
                    'اختبار التحقق من المشتريات',
                    'اختبار إقرار المشتريات',
                    'اختبار تحديث المحفظة'
                ]
            ]
        ];
    }
}

// API endpoints for Google Play
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    try {
        $googlePlay = new GooglePlayProduction();
        $action = $_POST['action'] ?? '';
        
        switch ($action) {
            case 'verify_purchase':
                $productId = $_POST['productId'] ?? '';
                $purchaseToken = $_POST['purchaseToken'] ?? '';
                
                if (empty($productId) || empty($purchaseToken)) {
                    throw new Exception('Product ID and purchase token are required');
                }
                
                $purchaseData = $googlePlay->verifyPurchase($productId, $purchaseToken);
                echo json_encode(['success' => true, 'purchaseData' => $purchaseData]);
                break;
                
            case 'process_purchase':
                $userId = (int)($_POST['userId'] ?? 0);
                $productId = $_POST['productId'] ?? '';
                $purchaseToken = $_POST['purchaseToken'] ?? '';
                $orderId = $_POST['orderId'] ?? '';
                
                if (!$userId || empty($productId) || empty($purchaseToken) || empty($orderId)) {
                    throw new Exception('Missing required parameters');
                }
                
                $result = $googlePlay->processPurchase($userId, $productId, $purchaseToken, $orderId);
                echo json_encode($result);
                break;
                
            case 'get_products':
                $products = $googlePlay->getAvailableProducts();
                echo json_encode(['success' => true, 'products' => $products]);
                break;
                
            case 'validate_config':
                $validation = $googlePlay->validateConfiguration();
                echo json_encode(['success' => $validation['valid'], 'errors' => $validation['errors']]);
                break;
                
            default:
                throw new Exception('Invalid action');
        }
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}
?>
