<?php
/**
 * Google Play Billing Setup and Configuration
 * دليل إعداد Google Play Billing
 */

class GooglePlaySetup {
    
    private $packageName;
    private $serviceAccountKey;
    
    public function __construct() {
        $this->packageName = GOOGLE_PLAY_PACKAGE_NAME;
        $this->serviceAccountKey = json_decode(GOOGLE_PLAY_SERVICE_ACCOUNT_KEY, true);
    }
    
    /**
     * Get access token for Google Play API
     */
    public function getAccessToken() {
        $jwt = $this->createJWT();
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://oauth2.googleapis.com/token');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $jwt
        ]));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            return $data['access_token'] ?? null;
        }
        
        return null;
    }
    
    /**
     * Create JWT for Google API authentication
     */
    private function createJWT() {
        $header = json_encode(['typ' => 'JWT', 'alg' => 'RS256']);
        $payload = json_encode([
            'iss' => $this->serviceAccountKey['client_email'],
            'scope' => 'https://www.googleapis.com/auth/androidpublisher',
            'aud' => 'https://oauth2.googleapis.com/token',
            'exp' => time() + 3600,
            'iat' => time()
        ]);
        
        $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
        $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
        
        $signatureInput = $base64Header . '.' . $base64Payload;
        
        openssl_sign($signatureInput, $signature, $this->serviceAccountKey['private_key'], OPENSSL_ALGO_SHA256);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
        
        return $signatureInput . '.' . $base64Signature;
    }
    
    /**
     * Verify purchase with Google Play
     */
    public function verifyPurchase($productId, $purchaseToken) {
        $accessToken = $this->getAccessToken();
        
        if (!$accessToken) {
            return ['success' => false, 'error' => 'Failed to get access token'];
        }
        
        $url = "https://androidpublisher.googleapis.com/androidpublisher/v3/applications/{$this->packageName}/purchases/products/$productId/tokens/$purchaseToken";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json'
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            
            if ($data && isset($data['purchaseState']) && $data['purchaseState'] == 0) {
                return [
                    'success' => true,
                    'purchaseData' => $data,
                    'orderId' => $data['orderId'] ?? null,
                    'purchaseTime' => $data['purchaseTimeMillis'] ?? null
                ];
            }
        }
        
        return ['success' => false, 'error' => 'Invalid purchase or API error'];
    }
    
    /**
     * Acknowledge purchase
     */
    public function acknowledgePurchase($productId, $purchaseToken) {
        $accessToken = $this->getAccessToken();
        
        if (!$accessToken) {
            return false;
        }
        
        $url = "https://androidpublisher.googleapis.com/androidpublisher/v3/applications/{$this->packageName}/purchases/products/$productId/tokens/$purchaseToken:acknowledge";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, '{}');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json'
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return $httpCode === 204;
    }
    
    /**
     * Get available products for purchase
     */
    public function getProducts() {
        return [
            [
                'productId' => 'wallet_topup_10_sar',
                'type' => 'inapp',
                'price' => '10.00',
                'currency' => 'SAR',
                'title' => 'شحن المحفظة 10 ريال',
                'description' => 'شحن المحفظة بمبلغ 10 ريال سعودي'
            ],
            [
                'productId' => 'wallet_topup_25_sar',
                'type' => 'inapp',
                'price' => '25.00',
                'currency' => 'SAR',
                'title' => 'شحن المحفظة 25 ريال',
                'description' => 'شحن المحفظة بمبلغ 25 ريال سعودي'
            ],
            [
                'productId' => 'wallet_topup_50_sar',
                'type' => 'inapp',
                'price' => '50.00',
                'currency' => 'SAR',
                'title' => 'شحن المحفظة 50 ريال',
                'description' => 'شحن المحفظة بمبلغ 50 ريال سعودي'
            ],
            [
                'productId' => 'wallet_topup_100_sar',
                'type' => 'inapp',
                'price' => '100.00',
                'currency' => 'SAR',
                'title' => 'شحن المحفظة 100 ريال',
                'description' => 'شحن المحفظة بمبلغ 100 ريال سعودي'
            ],
            [
                'productId' => 'wallet_topup_5_usd',
                'type' => 'inapp',
                'price' => '5.00',
                'currency' => 'USD',
                'title' => 'شحن المحفظة 5 دولار',
                'description' => 'شحن المحفظة بمبلغ 5 دولار أمريكي'
            ],
            [
                'productId' => 'wallet_topup_10_usd',
                'type' => 'inapp',
                'price' => '10.00',
                'currency' => 'USD',
                'title' => 'شحن المحفظة 10 دولار',
                'description' => 'شحن المحفظة بمبلغ 10 دولار أمريكي'
            ]
        ];
    }
    
    /**
     * Process purchase and update wallet
     */
    public function processPurchase($userId, $productId, $purchaseToken) {
        // Verify purchase first
        $verification = $this->verifyPurchase($productId, $purchaseToken);
        
        if (!$verification['success']) {
            return $verification;
        }
        
        // Get product details
        $products = $this->getProducts();
        $product = null;
        
        foreach ($products as $p) {
            if ($p['productId'] === $productId) {
                $product = $p;
                break;
            }
        }
        
        if (!$product) {
            return ['success' => false, 'error' => 'Product not found'];
        }
        
        try {
            $db = Database::getInstance()->getConnection();
            
            // Check if purchase already processed
            $stmt = $db->prepare("SELECT id FROM in_app_purchases WHERE transaction_id = ?");
            $stmt->execute([$verification['purchaseData']['orderId']]);
            
            if ($stmt->fetch()) {
                return ['success' => false, 'error' => 'Purchase already processed'];
            }
            
            // Save purchase record
            $stmt = $db->prepare("INSERT INTO in_app_purchases (user_id, platform, product_id, transaction_id, receipt_data, amount, currency, status) VALUES (?, 'google', ?, ?, ?, ?, ?, 'verified')");
            $stmt->execute([
                $userId,
                $productId,
                $verification['purchaseData']['orderId'],
                json_encode($verification['purchaseData']),
                $product['price'],
                $product['currency']
            ]);
            
            // Update user wallet
            $walletField = 'wallet_balance_' . strtolower($product['currency']);
            $stmt = $db->prepare("UPDATE users SET $walletField = $walletField + ? WHERE id = ?");
            $stmt->execute([$product['price'], $userId]);
            
            // Add wallet transaction
            $stmt = $db->prepare("INSERT INTO wallet_transactions (user_id, type, amount, currency, description, status) VALUES (?, 'deposit', ?, ?, 'شحن المحفظة عبر Google Play', 'completed')");
            $stmt->execute([$userId, $product['price'], $product['currency']]);
            
            // Acknowledge purchase
            $this->acknowledgePurchase($productId, $purchaseToken);
            
            return [
                'success' => true,
                'message' => 'Purchase processed successfully',
                'amount' => $product['price'],
                'currency' => $product['currency']
            ];
            
        } catch (Exception $e) {
            return ['success' => false, 'error' => 'Database error: ' . $e->getMessage()];
        }
    }
    
    /**
     * Get setup instructions
     */
    public static function getSetupInstructions() {
        return [
            'steps' => [
                '1. إنشاء تطبيق في Google Play Console',
                '2. إعداد In-App Products في Play Console',
                '3. إنشاء Service Account في Google Cloud Console',
                '4. تفعيل Google Play Developer API',
                '5. منح صلاحيات Service Account للتطبيق',
                '6. تحميل Service Account Key (JSON)',
                '7. إضافة Google Play Billing Library للتطبيق',
                '8. اختبار المشتريات مع حسابات الاختبار'
            ],
            'required_permissions' => [
                'Google Play Developer API',
                'Service Account Token Creator',
                'Service Account User'
            ],
            'testing' => [
                'إضافة حسابات اختبار في Play Console',
                'اختبار المشتريات مع بطاقات اختبار',
                'التحقق من استلام الإيصالات',
                'اختبار إلغاء وإرجاع المشتريات'
            ],
            'products_setup' => [
                'wallet_topup_10_sar - شحن 10 ريال سعودي',
                'wallet_topup_25_sar - شحن 25 ريال سعودي',
                'wallet_topup_50_sar - شحن 50 ريال سعودي',
                'wallet_topup_100_sar - شحن 100 ريال سعودي',
                'wallet_topup_5_usd - شحن 5 دولار أمريكي',
                'wallet_topup_10_usd - شحن 10 دولار أمريكي'
            ]
        ];
    }
}

// API endpoint for mobile app
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    $googlePlay = new GooglePlaySetup();
    $action = $_POST['action'];
    
    switch ($action) {
        case 'verify_purchase':
            $userId = $_POST['user_id'] ?? 0;
            $productId = $_POST['product_id'] ?? '';
            $purchaseToken = $_POST['purchase_token'] ?? '';
            
            if ($userId && $productId && $purchaseToken) {
                $result = $googlePlay->processPurchase($userId, $productId, $purchaseToken);
                echo json_encode($result);
            } else {
                echo json_encode(['success' => false, 'error' => 'Missing required parameters']);
            }
            break;
            
        case 'get_products':
            echo json_encode(['success' => true, 'products' => $googlePlay->getProducts()]);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
    exit;
}
?>
