<?php
// إعدادات بوابات الدفع

// PayPal Configuration
define('PAYPAL_CLIENT_ID', 'your_paypal_client_id_here');
define('PAYPAL_CLIENT_SECRET', 'your_paypal_client_secret_here');
define('PAYPAL_SANDBOX', true); // تغيير إلى false في الإنتاج
define('PAYPAL_WEBHOOK_ID', 'your_paypal_webhook_id');

// Stripe Configuration
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_your_stripe_publishable_key');
define('STRIPE_SECRET_KEY', 'sk_test_your_stripe_secret_key');
define('STRIPE_WEBHOOK_SECRET', 'whsec_your_stripe_webhook_secret');

// Mada Pay Configuration (Saudi Arabia)
define('MADA_MERCHANT_ID', 'your_mada_merchant_id');
define('MADA_TERMINAL_ID', 'your_mada_terminal_id');
define('MADA_SECRET_KEY', 'your_mada_secret_key');
define('MADA_API_URL', 'https://api.mada.com.sa/payment');

// Yemen Mobile Money Configuration
define('YMM_MERCHANT_CODE', 'your_ymm_merchant_code');
define('YMM_API_KEY', 'your_ymm_api_key');
define('YMM_API_URL', 'https://api.yemenmobi.com');
define('YMM_CALLBACK_URL', SITE_URL . '/api/webhook/ymm_callback.php');

// Apple Pay Configuration
define('APPLE_MERCHANT_ID', 'merchant.com.faststarone.app');
define('APPLE_SHARED_SECRET', 'your_apple_shared_secret');
define('APPLE_BUNDLE_ID', 'com.faststarone.app');

// Google Play Configuration
define('GOOGLE_PLAY_PACKAGE_NAME', 'com.faststarone.app');
define('GOOGLE_PLAY_SERVICE_ACCOUNT_KEY', '{
  "type": "service_account",
  "project_id": "your-project-id",
  "private_key_id": "your-private-key-id",
  "private_key": "-----BEGIN PRIVATE KEY-----\\nyour-private-key\\n-----END PRIVATE KEY-----\\n",
  "client_email": "your-service-account@your-project-id.iam.gserviceaccount.com",
  "client_id": "your-client-id",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token"
}');

// Charging APIs Configuration
define('CHARGING_APIS', [
    'pubg' => [
        'name' => 'PUBG Mobile API',
        'url' => 'https://api.pubgmobile.com/charge',
        'key' => 'your_pubg_api_key',
        'secret' => 'your_pubg_api_secret',
        'method' => 'POST',
        'timeout' => 30
    ],
    'freefire' => [
        'name' => 'Free Fire API',
        'url' => 'https://api.freefire.com/topup',
        'key' => 'your_freefire_api_key',
        'secret' => 'your_freefire_api_secret',
        'method' => 'POST',
        'timeout' => 30
    ],
    'bigo' => [
        'name' => 'Bigo Live API',
        'url' => 'https://api.bigo.tv/recharge',
        'key' => 'your_bigo_api_key',
        'secret' => 'your_bigo_api_secret',
        'method' => 'POST',
        'timeout' => 30
    ],
    'tiktok' => [
        'name' => 'TikTok API',
        'url' => 'https://api.tiktok.com/coins',
        'key' => 'your_tiktok_api_key',
        'secret' => 'your_tiktok_api_secret',
        'method' => 'POST',
        'timeout' => 30
    ]
]);

class PaymentGateway {
    private $pdo;
    
    public function __construct() {
        $this->pdo = Database::getInstance()->getConnection();
    }
    
    public function processPayment($gateway_code, $amount, $currency, $user_id, $order_id = null) {
        try {
            switch ($gateway_code) {
                case 'paypal':
                    return $this->processPayPal($amount, $currency, $user_id, $order_id);
                case 'stripe':
                    return $this->processStripe($amount, $currency, $user_id, $order_id);
                case 'mada':
                    return $this->processMada($amount, $currency, $user_id, $order_id);
                case 'ymm':
                    return $this->processYMM($amount, $currency, $user_id, $order_id);
                case 'bank_transfer':
                    return $this->processBankTransfer($amount, $currency, $user_id, $order_id);
                default:
                    throw new Exception('بوابة دفع غير مدعومة');
            }
        } catch (Exception $e) {
            logError("Payment processing error: " . $e->getMessage(), [
                'gateway' => $gateway_code,
                'amount' => $amount,
                'currency' => $currency,
                'user_id' => $user_id,
                'order_id' => $order_id
            ]);
            throw $e;
        }
    }
    
    private function processPayPal($amount, $currency, $user_id, $order_id) {
        $paypal_url = PAYPAL_SANDBOX ? 'https://api.sandbox.paypal.com' : 'https://api.paypal.com';
        
        // الحصول على رمز الوصول
        $auth = base64_encode(PAYPAL_CLIENT_ID . ':' . PAYPAL_CLIENT_SECRET);
        $token_response = $this->makeRequest($paypal_url . '/v1/oauth2/token', [
            'grant_type' => 'client_credentials'
        ], [
            'Authorization: Basic ' . $auth,
            'Content-Type: application/x-www-form-urlencoded'
        ]);
        
        if (!$token_response || !isset($token_response['access_token'])) {
            throw new Exception('فشل في الحصول على رمز PayPal');
        }
        
        // إنشاء الدفعة
        $payment_data = [
            'intent' => 'CAPTURE',
            'purchase_units' => [[
                'amount' => [
                    'currency_code' => $currency,
                    'value' => number_format($amount, 2, '.', '')
                ],
                'description' => 'شحن محفظة فاست ستار'
            ]],
            'application_context' => [
                'return_url' => SITE_URL . '/user/payment_success.php',
                'cancel_url' => SITE_URL . '/user/payment_cancel.php'
            ]
        ];
        
        $payment_response = $this->makeRequest($paypal_url . '/v2/checkout/orders', 
            json_encode($payment_data), [
            'Authorization: Bearer ' . $token_response['access_token'],
            'Content-Type: application/json'
        ]);
        
        if ($payment_response && isset($payment_response['id'])) {
            // حفظ المعاملة
            $transaction_id = generateTransactionId();
            $stmt = $this->pdo->prepare("
                INSERT INTO payment_transactions 
                (transaction_id, user_id, order_id, gateway_id, amount, currency, gateway_transaction_id, gateway_response, status) 
                VALUES (?, ?, ?, 1, ?, ?, ?, ?, 'pending')
            ");
            $stmt->execute([
                $transaction_id, $user_id, $order_id, $amount, $currency, 
                $payment_response['id'], json_encode($payment_response)
            ]);
            
            // العثور على رابط الموافقة
            foreach ($payment_response['links'] as $link) {
                if ($link['rel'] === 'approve') {
                    return [
                        'success' => true,
                        'redirect_url' => $link['href'],
                        'transaction_id' => $transaction_id
                    ];
                }
            }
        }
        
        throw new Exception('فشل في إنشاء دفعة PayPal');
    }
    
    private function processStripe($amount, $currency, $user_id, $order_id) {
        $stripe_data = [
            'amount' => $amount * 100, // Stripe يستخدم السنتات
            'currency' => strtolower($currency),
            'description' => 'شحن محفظة فاست ستار',
            'metadata' => [
                'user_id' => $user_id,
                'order_id' => $order_id
            ]
        ];
        
        $response = $this->makeRequest('https://api.stripe.com/v1/payment_intents', 
            http_build_query($stripe_data), [
            'Authorization: Bearer ' . STRIPE_SECRET_KEY,
            'Content-Type: application/x-www-form-urlencoded'
        ]);
        
        if ($response && isset($response['client_secret'])) {
            // حفظ المعاملة
            $transaction_id = generateTransactionId();
            $stmt = $this->pdo->prepare("
                INSERT INTO payment_transactions 
                (transaction_id, user_id, order_id, gateway_id, amount, currency, gateway_transaction_id, gateway_response, status) 
                VALUES (?, ?, ?, 2, ?, ?, ?, ?, 'pending')
            ");
            $stmt->execute([
                $transaction_id, $user_id, $order_id, $amount, $currency, 
                $response['id'], json_encode($response)
            ]);
            
            return [
                'success' => true,
                'client_secret' => $response['client_secret'],
                'transaction_id' => $transaction_id
            ];
        }
        
        throw new Exception('فشل في إنشاء نية دفع Stripe');
    }
    
    private function processMada($amount, $currency, $user_id, $order_id) {
        $transaction_id = generateTransactionId();
        $mada_data = [
            'merchant_id' => MADA_MERCHANT_ID,
            'terminal_id' => MADA_TERMINAL_ID,
            'amount' => $amount,
            'currency' => $currency,
            'transaction_id' => $transaction_id,
            'return_url' => SITE_URL . '/user/payment_success.php',
            'cancel_url' => SITE_URL . '/user/payment_cancel.php',
            'hash' => hash('sha256', MADA_MERCHANT_ID . $amount . $transaction_id . MADA_SECRET_KEY)
        ];
        
        // حفظ المعاملة
        $stmt = $this->pdo->prepare("
            INSERT INTO payment_transactions 
            (transaction_id, user_id, order_id, gateway_id, amount, currency, status) 
            VALUES (?, ?, ?, 3, ?, ?, 'pending')
        ");
        $stmt->execute([$transaction_id, $user_id, $order_id, $amount, $currency]);
        
        return [
            'success' => true,
            'form_data' => $mada_data,
            'action_url' => MADA_API_URL,
            'transaction_id' => $transaction_id
        ];
    }
    
    private function processYMM($amount, $currency, $user_id, $order_id) {
        $transaction_id = generateTransactionId();
        $ymm_data = [
            'merchant_code' => YMM_MERCHANT_CODE,
            'amount' => $amount,
            'currency' => $currency,
            'transaction_id' => $transaction_id,
            'callback_url' => YMM_CALLBACK_URL,
            'description' => 'شحن محفظة فاست ستار'
        ];
        
        $response = $this->makeRequest(YMM_API_URL . '/payment/create', 
            json_encode($ymm_data), [
            'Authorization: Bearer ' . YMM_API_KEY,
            'Content-Type: application/json'
        ]);
        
        if ($response && isset($response['payment_url'])) {
            // حفظ المعاملة
            $stmt = $this->pdo->prepare("
                INSERT INTO payment_transactions 
                (transaction_id, user_id, order_id, gateway_id, amount, currency, gateway_response, status) 
                VALUES (?, ?, ?, 4, ?, ?, ?, 'pending')
            ");
            $stmt->execute([
                $transaction_id, $user_id, $order_id, $amount, $currency, 
                json_encode($response)
            ]);
            
            return [
                'success' => true,
                'redirect_url' => $response['payment_url'],
                'transaction_id' => $transaction_id
            ];
        }
        
        throw new Exception('فشل في إنشاء دفعة المحفظة الإلكترونية اليمنية');
    }
    
    private function processBankTransfer($amount, $currency, $user_id, $order_id) {
        $transaction_id = generateTransactionId();
        
        // حفظ المعاملة
        $stmt = $this->pdo->prepare("
            INSERT INTO payment_transactions 
            (transaction_id, user_id, order_id, gateway_id, amount, currency, status) 
            VALUES (?, ?, ?, 5, ?, ?, 'pending')
        ");
        $stmt->execute([$transaction_id, $user_id, $order_id, $amount, $currency]);
        
        // الحصول على معلومات الحسابات البنكية
        $bank_accounts = $this->getBankAccounts($currency);
        
        return [
            'success' => true,
            'bank_accounts' => $bank_accounts,
            'transaction_id' => $transaction_id,
            'instructions' => 'يرجى تحويل المبلغ إلى أحد الحسابات المذكورة وإرسال إيصال التحويل'
        ];
    }
    
    private function getBankAccounts($currency) {
        $accounts = [
            'YER' => [
                [
                    'bank_name' => 'البنك الأهلي اليمني',
                    'account_number' => '123456789',
                    'account_name' => 'فاست ستار للخدمات الرقمية',
                    'iban' => 'YE12345678901234567890'
                ],
                [
                    'bank_name' => 'بنك اليمن الدولي',
                    'account_number' => '987654321',
                    'account_name' => 'فاست ستار للخدمات الرقمية',
                    'iban' => 'YE09876543210987654321'
                ]
            ],
            'SAR' => [
                [
                    'bank_name' => 'البنك الأهلي السعودي',
                    'account_number' => '123456789',
                    'account_name' => 'FastStar Digital Services',
                    'iban' => 'SA1234567890123456789012'
                ]
            ],
            'USD' => [
                [
                    'bank_name' => 'Bank of America',
                    'account_number' => '123456789',
                    'account_name' => 'FastStar Digital Services',
                    'swift' => 'BOFAUS3N'
                ]
            ]
        ];
        
        return $accounts[$currency] ?? [];
    }
    
    private function makeRequest($url, $data, $headers = []) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, is_array($data) ? http_build_query($data) : $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code >= 200 && $http_code < 300) {
            return json_decode($response, true);
        }
        
        return false;
    }
    
    public function verifyPayment($transaction_id, $gateway_data) {
        // التحقق من صحة الدفعة حسب البوابة
        $stmt = $this->pdo->prepare("SELECT * FROM payment_transactions WHERE transaction_id = ?");
        $stmt->execute([$transaction_id]);
        $transaction = $stmt->fetch();
        
        if (!$transaction) {
            return false;
        }
        
        $gateway_id = $transaction['gateway_id'];
        
        switch ($gateway_id) {
            case 1: // PayPal
                return $this->verifyPayPalPayment($transaction, $gateway_data);
            case 2: // Stripe
                return $this->verifyStripePayment($transaction, $gateway_data);
            case 3: // Mada
                return $this->verifyMadaPayment($transaction, $gateway_data);
            case 4: // YMM
                return $this->verifyYMMPayment($transaction, $gateway_data);
            default:
                return false;
        }
    }
    
    private function verifyPayPalPayment($transaction, $gateway_data) {
        // التحقق من دفعة PayPal
        $paypal_url = PAYPAL_SANDBOX ? 'https://api.sandbox.paypal.com' : 'https://api.paypal.com';
        
        // الحصول على رمز الوصول
        $auth = base64_encode(PAYPAL_CLIENT_ID . ':' . PAYPAL_CLIENT_SECRET);
        $token_response = $this->makeRequest($paypal_url . '/v1/oauth2/token', [
            'grant_type' => 'client_credentials'
        ], [
            'Authorization: Basic ' . $auth,
            'Content-Type: application/x-www-form-urlencoded'
        ]);
        
        if (!$token_response || !isset($token_response['access_token'])) {
            return false;
        }
        
        // التحقق من حالة الطلب
        $order_response = $this->makeRequest(
            $paypal_url . '/v2/checkout/orders/' . $gateway_data['orderID'],
            '',
            [
                'Authorization: Bearer ' . $token_response['access_token'],
                'Content-Type: application/json'
            ]
        );
        
        return $order_response && $order_response['status'] === 'COMPLETED';
    }
    
    private function verifyStripePayment($transaction, $gateway_data) {
        // التحقق من دفعة Stripe
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_intents/' . $gateway_data['payment_intent']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . STRIPE_SECRET_KEY
        ]);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 200) {
            $payment_intent = json_decode($response, true);
            return $payment_intent['status'] === 'succeeded';
        }
        
        return false;
    }
    
    private function verifyMadaPayment($transaction, $gateway_data) {
        // التحقق من دفعة مدى
        $expected_hash = hash('sha256', 
            $gateway_data['merchant_id'] . 
            $gateway_data['amount'] . 
            $gateway_data['transaction_id'] . 
            MADA_SECRET_KEY
        );
        
        return $gateway_data['hash'] === $expected_hash && $gateway_data['status'] === 'success';
    }
    
    private function verifyYMMPayment($transaction, $gateway_data) {
        // التحقق من دفعة المحفظة الإلكترونية اليمنية
        return isset($gateway_data['status']) && $gateway_data['status'] === 'completed';
    }
}
?>
