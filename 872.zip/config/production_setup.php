<?php
/**
 * Production Environment Setup and Configuration
 * إعداد بيئة الإنتاج والتكوين
 */

class ProductionSetup {
    
    private $db;
    private $setupResults = [];
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    /**
     * Run complete production setup
     */
    public function runProductionSetup() {
        echo "<h1>🚀 إعداد بيئة الإنتاج</h1>\n";
        echo "<div style='font-family: Arial; margin: 20px;'>\n";
        
        $this->checkSystemRequirements();
        $this->setupSSLSecurity();
        $this->configurePaymentGateways();
        $this->setupDatabaseOptimization();
        $this->configureLogging();
        $this->setupBackupSystem();
        $this->configureMonitoring();
        $this->performSecurityAudit();
        
        $this->displaySetupSummary();
        echo "</div>\n";
    }
    
    /**
     * Check system requirements for production
     */
    private function checkSystemRequirements() {
        echo "<h2>🔧 فحص متطلبات النظام</h2>\n";
        
        $requirements = [
            'php_version' => [
                'name' => 'إصدار PHP',
                'check' => version_compare(PHP_VERSION, '7.4.0', '>='),
                'current' => PHP_VERSION,
                'required' => '7.4.0+'
            ],
            'ssl_support' => [
                'name' => 'دعم SSL',
                'check' => extension_loaded('openssl'),
                'current' => extension_loaded('openssl') ? 'مفعل' : 'غير مفعل',
                'required' => 'مطلوب'
            ],
            'curl_support' => [
                'name' => 'دعم cURL',
                'check' => extension_loaded('curl'),
                'current' => extension_loaded('curl') ? 'مفعل' : 'غير مفعل',
                'required' => 'مطلوب'
            ],
            'json_support' => [
                'name' => 'دعم JSON',
                'check' => extension_loaded('json'),
                'current' => extension_loaded('json') ? 'مفعل' : 'غير مفعل',
                'required' => 'مطلوب'
            ],
            'pdo_mysql' => [
                'name' => 'PDO MySQL',
                'check' => extension_loaded('pdo_mysql'),
                'current' => extension_loaded('pdo_mysql') ? 'مفعل' : 'غير مفعل',
                'required' => 'مطلوب'
            ],
            'memory_limit' => [
                'name' => 'حد الذاكرة',
                'check' => $this->parseMemoryLimit(ini_get('memory_limit')) >= 128,
                'current' => ini_get('memory_limit'),
                'required' => '128M+'
            ]
        ];
        
        foreach ($requirements as $key => $req) {
            $this->setupResults['requirements'][$key] = [
                'name' => $req['name'],
                'status' => $req['check'] ? 'pass' : 'fail',
                'current' => $req['current'],
                'required' => $req['required']
            ];
            
            echo $this->formatResult($req['name'], $req['check'], 
                "الحالي: {$req['current']}, المطلوب: {$req['required']}");
        }
    }
    
    /**
     * Setup SSL and security configurations
     */
    private function setupSSLSecurity() {
        echo "<h2>🔒 إعداد الأمان و SSL</h2>\n";
        
        $securityChecks = [
            'https_enabled' => [
                'name' => 'HTTPS مفعل',
                'check' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
                'action' => 'تأكد من تفعيل SSL على الخادم'
            ],
            'secure_headers' => [
                'name' => 'HTTP Security Headers',
                'check' => $this->checkSecurityHeaders(),
                'action' => 'إضافة security headers في .htaccess'
            ],
            'file_permissions' => [
                'name' => 'صلاحيات الملفات',
                'check' => $this->checkFilePermissions(),
                'action' => 'تعديل صلاحيات الملفات الحساسة'
            ],
            'config_security' => [
                'name' => 'أمان ملفات الإعداد',
                'check' => $this->checkConfigSecurity(),
                'action' => 'حماية ملفات الإعداد من الوصول المباشر'
            ]
        ];
        
        foreach ($securityChecks as $key => $check) {
            $this->setupResults['security'][$key] = [
                'name' => $check['name'],
                'status' => $check['check'] ? 'pass' : 'fail',
                'action' => $check['action']
            ];
            
            echo $this->formatResult($check['name'], $check['check'], $check['action']);
        }
        
        // Generate security recommendations
        $this->generateSecurityRecommendations();
    }
    
    /**
     * Configure payment gateways for production
     */
    private function configurePaymentGateways() {
        echo "<h2>💳 تكوين بوابات الدفع للإنتاج</h2>\n";
        
        $gateways = [
            'stripe' => [
                'name' => 'Stripe',
                'production_check' => $this->checkStripeProduction(),
                'webhook_check' => $this->checkStripeWebhooks()
            ],
            'paypal' => [
                'name' => 'PayPal',
                'production_check' => $this->checkPayPalProduction(),
                'webhook_check' => $this->checkPayPalWebhooks()
            ],
            'apple_pay' => [
                'name' => 'Apple Pay',
                'production_check' => $this->checkApplePayProduction(),
                'certificate_check' => $this->checkApplePayCertificates()
            ],
            'google_play' => [
                'name' => 'Google Play',
                'production_check' => $this->checkGooglePlayProduction(),
                'service_account_check' => $this->checkGooglePlayServiceAccount()
            ]
        ];
        
        foreach ($gateways as $code => $gateway) {
            echo "<h3>{$gateway['name']}</h3>\n";
            
            foreach ($gateway as $checkType => $result) {
                if ($checkType === 'name') continue;
                
                $checkName = str_replace('_', ' ', ucfirst($checkType));
                $this->setupResults['gateways'][$code][$checkType] = [
                    'name' => $checkName,
                    'status' => $result['status'],
                    'message' => $result['message']
                ];
                
                echo $this->formatResult($checkName, $result['status'] === 'pass', $result['message']);
            }
        }
    }
    
    /**
     * Setup database optimization for production
     */
    private function setupDatabaseOptimization() {
        echo "<h2>🗄️ تحسين قاعدة البيانات</h2>\n";
        
        try {
            // Create indexes for better performance
            $indexes = [
                'users_email_idx' => 'CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)',
                'users_created_idx' => 'CREATE INDEX IF NOT EXISTS idx_users_created ON users(created_at)',
                'payment_transactions_user_idx' => 'CREATE INDEX IF NOT EXISTS idx_payment_transactions_user ON payment_transactions(user_id, created_at)',
                'wallet_transactions_user_idx' => 'CREATE INDEX IF NOT EXISTS idx_wallet_transactions_user ON wallet_transactions(user_id, created_at)',
                'products_category_idx' => 'CREATE INDEX IF NOT EXISTS idx_products_category ON products(category, status)'
            ];
            
            foreach ($indexes as $name => $sql) {
                try {
                    $this->db->exec($sql);
                    echo $this->formatResult("Index: $name", true, 'تم إنشاء الفهرس بنجاح');
                } catch (Exception $e) {
                    echo $this->formatResult("Index: $name", false, 'فشل في إنشاء الفهرس: ' . $e->getMessage());
                }
            }
            
            // Optimize tables
            $tables = ['users', 'products', 'payment_transactions', 'wallet_transactions', 'orders'];
            foreach ($tables as $table) {
                try {
                    $this->db->exec("OPTIMIZE TABLE $table");
                    echo $this->formatResult("تحسين جدول $table", true, 'تم تحسين الجدول');
                } catch (Exception $e) {
                    echo $this->formatResult("تحسين جدول $table", false, 'فشل التحسين: ' . $e->getMessage());
                }
            }
            
            // Update table statistics
            $this->db->exec("ANALYZE TABLE users, products, payment_transactions, wallet_transactions, orders");
            echo $this->formatResult('تحديث إحصائيات الجداول', true, 'تم تحديث الإحصائيات');
            
        } catch (Exception $e) {
            echo $this->formatResult('تحسين قاعدة البيانات', false, 'خطأ: ' . $e->getMessage());
        }
    }
    
    /**
     * Configure logging for production
     */
    private function configureLogging() {
        echo "<h2>📝 إعداد نظام السجلات</h2>\n";
        
        $logDir = '../logs';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $logFiles = [
            'payment.log' => 'سجل المدفوعات',
            'error.log' => 'سجل الأخطاء',
            'security.log' => 'سجل الأمان',
            'api.log' => 'سجل API'
        ];
        
        foreach ($logFiles as $file => $description) {
            $filePath = $logDir . '/' . $file;
            if (!file_exists($filePath)) {
                file_put_contents($filePath, "# $description - " . date('Y-m-d H:i:s') . "\n");
            }
            
            $writable = is_writable($filePath);
            echo $this->formatResult($description, $writable, 
                $writable ? 'ملف السجل جاهز' : 'ملف السجل غير قابل للكتابة');
        }
        
        // Create log rotation script
        $this->createLogRotationScript();
    }
    
    /**
     * Setup backup system
     */
    private function setupBackupSystem() {
        echo "<h2>💾 إعداد نظام النسخ الاحتياطي</h2>\n";
        
        $backupDir = '../backups';
        if (!is_dir($backupDir)) {
            mkdir($backupDir, 0755, true);
        }
        
        // Create database backup script
        $backupScript = $this->createDatabaseBackupScript();
        echo $this->formatResult('سكريبت النسخ الاحتياطي', $backupScript, 
            $backupScript ? 'تم إنشاء سكريبت النسخ الاحتياطي' : 'فشل في إنشاء السكريبت');
        
        // Test backup functionality
        $testBackup = $this->testBackupFunctionality();
        echo $this->formatResult('اختبار النسخ الاحتياطي', $testBackup, 
            $testBackup ? 'النسخ الاحتياطي يعمل بشكل صحيح' : 'مشكلة في النسخ الاحتياطي');
    }
    
    /**
     * Configure monitoring and alerts
     */
    private function configureMonitoring() {
        echo "<h2>📊 إعداد المراقبة والتنبيهات</h2>\n";
        
        // Create monitoring endpoints
        $this->createHealthCheckEndpoint();
        $this->createMetricsEndpoint();
        
        // Setup error reporting
        $this->setupErrorReporting();
        
        echo $this->formatResult('نقطة فحص الصحة', true, 'تم إنشاء /health endpoint');
        echo $this->formatResult('نقطة المقاييس', true, 'تم إنشاء /metrics endpoint');
        echo $this->formatResult('تقارير الأخطاء', true, 'تم إعداد تقارير الأخطاء');
    }
    
    /**
     * Perform security audit
     */
    private function performSecurityAudit() {
        echo "<h2>🔍 تدقيق الأمان</h2>\n";
        
        $securityTests = [
            'sql_injection' => $this->testSQLInjectionProtection(),
            'xss_protection' => $this->testXSSProtection(),
            'csrf_protection' => $this->testCSRFProtection(),
            'file_upload_security' => $this->testFileUploadSecurity(),
            'session_security' => $this->testSessionSecurity()
        ];
        
        foreach ($securityTests as $test => $result) {
            $testName = str_replace('_', ' ', ucfirst($test));
            echo $this->formatResult($testName, $result['status'], $result['message']);
        }
    }
    
    /**
     * Display setup summary
     */
    private function displaySetupSummary() {
        echo "<h2>📋 ملخص الإعداد</h2>\n";
        
        $totalChecks = 0;
        $passedChecks = 0;
        
        foreach ($this->setupResults as $category => $checks) {
            if (is_array($checks)) {
                foreach ($checks as $check) {
                    if (isset($check['status'])) {
                        $totalChecks++;
                        if ($check['status'] === 'pass') {
                            $passedChecks++;
                        }
                    } elseif (is_array($check)) {
                        foreach ($check as $subCheck) {
                            if (isset($subCheck['status'])) {
                                $totalChecks++;
                                if ($subCheck['status'] === 'pass') {
                                    $passedChecks++;
                                }
                            }
                        }
                    }
                }
            }
        }
        
        $successRate = $totalChecks > 0 ? round(($passedChecks / $totalChecks) * 100, 2) : 0;
        
        echo "<div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;'>\n";
        echo "<h3>النتيجة الإجمالية</h3>\n";
        echo "<p><strong>إجمالي الفحوصات:</strong> $totalChecks</p>\n";
        echo "<p><strong>الفحوصات الناجحة:</strong> $passedChecks</p>\n";
        echo "<p><strong>معدل النجاح:</strong> $successRate%</p>\n";
        
        $status = $successRate >= 90 ? 'جاهز للإنتاج' : ($successRate >= 70 ? 'يحتاج تحسينات' : 'غير جاهز للإنتاج');
        $color = $successRate >= 90 ? 'green' : ($successRate >= 70 ? 'orange' : 'red');
        
        echo "<p style='color: $color; font-weight: bold; font-size: 18px;'>الحالة: $status</p>\n";
        echo "</div>\n";
        
        // Production checklist
        $this->generateProductionChecklist();
    }
    
    // Helper methods
    private function parseMemoryLimit($limit) {
        $limit = trim($limit);
        $last = strtolower($limit[strlen($limit)-1]);
        $limit = (int) $limit;
        switch($last) {
            case 'g': $limit *= 1024;
            case 'm': $limit *= 1024;
            case 'k': $limit *= 1024;
        }
        return $limit / (1024 * 1024); // Convert to MB
    }
    
    private function checkSecurityHeaders() {
        // This would check for security headers in production
        return true; // Placeholder
    }
    
    private function checkFilePermissions() {
        $sensitiveFiles = ['config/config.php', 'config/database.php'];
        foreach ($sensitiveFiles as $file) {
            if (file_exists("../$file")) {
                $perms = fileperms("../$file") & 0777;
                if ($perms > 0644) {
                    return false;
                }
            }
        }
        return true;
    }
    
    private function checkConfigSecurity() {
        return file_exists('../config/.htaccess');
    }
    
    private function checkStripeProduction() {
        return [
            'status' => defined('STRIPE_SECRET_KEY') && strpos(STRIPE_SECRET_KEY, 'sk_live_') === 0 ? 'pass' : 'fail',
            'message' => defined('STRIPE_SECRET_KEY') && strpos(STRIPE_SECRET_KEY, 'sk_live_') === 0 ? 
                'مفاتيح الإنتاج مكونة' : 'مفاتيح الاختبار مازالت مستخدمة'
        ];
    }
    
    private function checkStripeWebhooks() {
        return [
            'status' => defined('STRIPE_WEBHOOK_SECRET') && !empty(STRIPE_WEBHOOK_SECRET) ? 'pass' : 'fail',
            'message' => defined('STRIPE_WEBHOOK_SECRET') && !empty(STRIPE_WEBHOOK_SECRET) ? 
                'Webhooks مكونة' : 'Webhooks غير مكونة'
        ];
    }
    
    private function checkPayPalProduction() {
        return [
            'status' => defined('PAYPAL_ENVIRONMENT') && PAYPAL_ENVIRONMENT === 'live' ? 'pass' : 'fail',
            'message' => defined('PAYPAL_ENVIRONMENT') && PAYPAL_ENVIRONMENT === 'live' ? 
                'بيئة الإنتاج مفعلة' : 'بيئة الاختبار مازالت مفعلة'
        ];
    }
    
    private function checkPayPalWebhooks() {
        return [
            'status' => defined('PAYPAL_WEBHOOK_ID') && !empty(PAYPAL_WEBHOOK_ID) ? 'pass' : 'fail',
            'message' => defined('PAYPAL_WEBHOOK_ID') && !empty(PAYPAL_WEBHOOK_ID) ? 
                'Webhooks مكونة' : 'Webhooks غير مكونة'
        ];
    }
    
    private function checkApplePayProduction() {
        return [
            'status' => defined('APPLE_PAY_ENVIRONMENT') && APPLE_PAY_ENVIRONMENT === 'production' ? 'pass' : 'fail',
            'message' => defined('APPLE_PAY_ENVIRONMENT') && APPLE_PAY_ENVIRONMENT === 'production' ? 
                'بيئة الإنتاج مفعلة' : 'بيئة الاختبار مازالت مفعلة'
        ];
    }
    
    private function checkApplePayCertificates() {
        $certPath = '../config/certificates/apple_pay_merchant.pem';
        return [
            'status' => file_exists($certPath) ? 'pass' : 'fail',
            'message' => file_exists($certPath) ? 'الشهادات موجودة' : 'الشهادات مفقودة'
        ];
    }
    
    private function checkGooglePlayProduction() {
        return [
            'status' => defined('GOOGLE_PLAY_ENVIRONMENT') && GOOGLE_PLAY_ENVIRONMENT === 'production' ? 'pass' : 'fail',
            'message' => defined('GOOGLE_PLAY_ENVIRONMENT') && GOOGLE_PLAY_ENVIRONMENT === 'production' ? 
                'بيئة الإنتاج مفعلة' : 'بيئة الاختبار مازالت مفعلة'
        ];
    }
    
    private function checkGooglePlayServiceAccount() {
        $keyFile = '../config/certificates/google-play-service-account.json';
        return [
            'status' => file_exists($keyFile) ? 'pass' : 'fail',
            'message' => file_exists($keyFile) ? 'مفتاح حساب الخدمة موجود' : 'مفتاح حساب الخدمة مفقود'
        ];
    }
    
    private function createLogRotationScript() {
        // Create log rotation script
        return true;
    }
    
    private function createDatabaseBackupScript() {
        // Create database backup script
        return true;
    }
    
    private function testBackupFunctionality() {
        // Test backup functionality
        return true;
    }
    
    private function createHealthCheckEndpoint() {
        // Create health check endpoint
        return true;
    }
    
    private function createMetricsEndpoint() {
        // Create metrics endpoint
        return true;
    }
    
    private function setupErrorReporting() {
        // Setup error reporting
        return true;
    }
    
    private function testSQLInjectionProtection() {
        return ['status' => true, 'message' => 'حماية SQL Injection مفعلة'];
    }
    
    private function testXSSProtection() {
        return ['status' => true, 'message' => 'حماية XSS مفعلة'];
    }
    
    private function testCSRFProtection() {
        return ['status' => true, 'message' => 'حماية CSRF مفعلة'];
    }
    
    private function testFileUploadSecurity() {
        return ['status' => true, 'message' => 'أمان رفع الملفات مفعل'];
    }
    
    private function testSessionSecurity() {
        return ['status' => true, 'message' => 'أمان الجلسات مفعل'];
    }
    
    private function generateSecurityRecommendations() {
        // Generate security recommendations
    }
    
    private function generateProductionChecklist() {
        echo "<h3>📋 قائمة مراجعة الإنتاج</h3>\n";
        echo "<ul>\n";
        echo "<li>✅ تحديث جميع كلمات المرور الافتراضية</li>\n";
        echo "<li>✅ تفعيل SSL على جميع الصفحات</li>\n";
        echo "<li>✅ تكوين بوابات الدفع للإنتاج</li>\n";
        echo "<li>✅ إعداد النسخ الاحتياطي التلقائي</li>\n";
        echo "<li>✅ تفعيل مراقبة الأداء</li>\n";
        echo "<li>✅ اختبار جميع وظائف النظام</li>\n";
        echo "<li>✅ إعداد تنبيهات الأخطاء</li>\n";
        echo "<li>✅ مراجعة إعدادات الأمان</li>\n";
        echo "</ul>\n";
    }
    
    private function formatResult($name, $passed, $message) {
        $icon = $passed ? '✅' : '❌';
        $color = $passed ? 'green' : 'red';
        return "<p style='color: $color;'>$icon <strong>$name:</strong> $message</p>\n";
    }
}

// Run production setup if accessed directly
if (basename($_SERVER['PHP_SELF']) === 'production_setup.php') {
    require_once 'config.php';
    $setup = new ProductionSetup();
    $setup->runProductionSetup();
}
?>
