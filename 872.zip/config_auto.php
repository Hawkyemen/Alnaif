<?php
// تم إنشاء هذا الملف تلقائياً بواسطة معالج الإعداد
// تاريخ الإنشاء: 2025-07-11 04:06:21

// إعدادات قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_NAME', 'faststar_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// إعدادات الموقع
define('SITE_NAME', 'فاست ستار');
define('SITE_URL', 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']));
define('SITE_EMAIL', 'info@faststarone.com');
define('SITE_PHONE', '+967-1-234567');

// إعدادات الأمان
define('ENCRYPTION_KEY', 'e9aada2f0b653e833d09374dfb966940');
define('JWT_SECRET', 'c6234300c32f90baec71098adc1317b68ce88a7cadd513486c5f5a23b02c0399');
define('PASSWORD_SALT', '674f18d793c94d90012613172bb92e85');

// تم الإعداد بنجاح
define('SETUP_COMPLETED', true);
define('SETUP_DATE', '2025-07-11 04:06:21');

// باقي الإعدادات...
require_once __DIR__ . '/config/config.php';
?>
