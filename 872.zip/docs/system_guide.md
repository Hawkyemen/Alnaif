# دليل النظام المتقدم - فاست ستار
## FastStar Advanced System Guide

---

## 📋 جدول المحتويات

1. [نظرة عامة على النظام](#نظرة-عامة-على-النظام)
2. [متطلبات النظام](#متطلبات-النظام)
3. [التثبيت والإعداد](#التثبيت-والإعداد)
4. [إعداد قاعدة البيانات](#إعداد-قاعدة-البيانات)
5. [ربط خدمات الدفع](#ربط-خدمات-الدفع)
6. [API المتقدم](#api-المتقدم)
7. [نظام النسخ الاحتياطي](#نظام-النسخ-الاحتياطي)
8. [الأمان والحماية](#الأمان-والحماية)
9. [استكشاف الأخطاء](#استكشاف-الأخطاء)
10. [الصيانة والمراقبة](#الصيانة-والمراقبة)

---

## 🌟 نظرة عامة على النظام

فاست ستار هو نظام متقدم لشحن الألعاب والتطبيقات يوفر:

### المميزات الرئيسية:
- ✅ **إدارة المستخدمين والمديرين**
- ✅ **نظام محفظة متعدد العملات**
- ✅ **بوابات دفع متعددة**
- ✅ **API متقدم مع مصادقة JWT**
- ✅ **نظام نسخ احتياطي تلقائي**
- ✅ **لوحة تحكم شاملة**
- ✅ **تقارير وإحصائيات مفصلة**
- ✅ **نظام أمان متقدم**

### التقنيات المستخدمة:
- **Backend**: PHP 8.0+, MySQL 8.0+
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **API**: RESTful API with JWT Authentication
- **Payment**: PayPal, Stripe, Mada, Apple Pay, Google Pay
- **Security**: CSRF Protection, Rate Limiting, Input Validation

---

## 🔧 متطلبات النظام

### متطلبات الخادم:
\`\`\`
- PHP 8.0 أو أحدث
- MySQL 8.0 أو أحدث
- Apache/Nginx
- SSL Certificate (مطلوب للإنتاج)
- cURL extension
- GD extension
- ZIP extension
- OpenSSL extension
\`\`\`

### متطلبات PHP Extensions:
\`\`\`php
- pdo_mysql
- curl
- gd
- zip
- openssl
- json
- mbstring
- fileinfo
\`\`\`

### مساحة التخزين:
\`\`\`
- الحد الأدنى: 1GB
- المُوصى به: 5GB+
- للنسخ الاحتياطي: 10GB+
\`\`\`

---

## 🚀 التثبيت والإعداد

### 1. تحميل الملفات:
\`\`\`bash
# تحميل المشروع
git clone https://github.com/faststarone/system.git
cd system

# تعيين الصلاحيات
chmod 755 -R .
chmod 777 uploads/
chmod 777 backups/
chmod 777 logs/
\`\`\`

### 2. إعداد قاعدة البيانات:
\`\`\`sql
-- إنشاء قاعدة البيانات
CREATE DATABASE faststar_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- إنشاء مستخدم قاعدة البيانات
CREATE USER 'faststar_user'@'localhost' IDENTIFIED BY 'strong_password_here';
GRANT ALL PRIVILEGES ON faststar_db.* TO 'faststar_user'@'localhost';
FLUSH PRIVILEGES;
\`\`\`

### 3. تحديث ملف الإعدادات:
\`\`\`php
// config/database.php
define('DB_HOST', 'localhost');
define('DB_NAME', 'faststar_db');
define('DB_USER', 'faststar_user');
define('DB_PASS', 'strong_password_here');
\`\`\`

### 4. تشغيل سكريبت الإعداد:
\`\`\`bash
php scripts/install.php
\`\`\`

---

## 🗄️ إعداد قاعدة البيانات

### تشغيل سكريبتات قاعدة البيانات:

#### 1. الإعداد الأساسي:
\`\`\`bash
mysql -u faststar_user -p faststar_db < scripts/database_setup.sql
\`\`\`

#### 2. إدراج البيانات الأولية:
\`\`\`bash
mysql -u faststar_user -p faststar_db < scripts/insert_game_products.sql
mysql -u faststar_user -p faststar_db < scripts/insert_chat_products.sql
\`\`\`

#### 3. إعداد نظام النسخ الاحتياطي:
\`\`\`bash
mysql -u faststar_user -p faststar_db < scripts/backup_system_tables.sql
\`\`\`

#### 4. إعداد بوابات الدفع:
\`\`\`bash
mysql -u faststar_user -p faststar_db < scripts/add_payment_tables.sql
\`\`\`

### هيكل قاعدة البيانات الرئيسي:

\`\`\`sql
-- الجداول الأساسية
users                 -- المستخدمين
admins               -- المديرين
categories           -- فئات المنتجات
products             -- المنتجات
orders               -- الطلبات

-- نظام المحفظة
wallets              -- محافظ المستخدمين
wallet_transactions  -- معاملات المحفظة

-- نظام الدفع
payment_gateways     -- بوابات الدفع
payment_transactions -- معاملات الدفع

-- نظام API
api_keys            -- مفاتيح API
api_requests        -- طلبات API

-- نظام النسخ الاحتياطي
backups             -- النسخ الاحتياطية
backup_schedules    -- جدولة النسخ
backup_logs         -- سجلات النسخ

-- نظام الشحن
charging_apis       -- APIs الشحن
api_logs           -- سجلات API
\`\`\`

---

## 💳 ربط خدمات الدفع

### 1. إعداد PayPal:

#### الحصول على بيانات PayPal:
1. سجل دخول إلى [PayPal Developer](https://developer.paypal.com)
2. إنشاء تطبيق جديد
3. احصل على Client ID و Client Secret

#### التكوين:
\`\`\`php
// config/payment_config.php
define('PAYPAL_CLIENT_ID', 'your_paypal_client_id');
define('PAYPAL_CLIENT_SECRET', 'your_paypal_client_secret');
define('PAYPAL_SANDBOX', true); // false للإنتاج
\`\`\`

#### اختبار PayPal:
\`\`\`php
// test/paypal_test.php
$paypal = new PayPalGateway();
$result = $paypal->createPayment(100, 'USD', 'Test Payment');
\`\`\`

### 2. إعداد Stripe:

#### الحصول على بيانات Stripe:
1. سجل دخول إلى [Stripe Dashboard](https://dashboard.stripe.com)
2. اذهب إلى API Keys
3. احصل على Publishable Key و Secret Key

#### التكوين:
\`\`\`php
// config/payment_config.php
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_your_key');
define('STRIPE_SECRET_KEY', 'sk_test_your_secret');
\`\`\`

#### اختبار Stripe:
\`\`\`javascript
// Frontend Integration
const stripe = Stripe('pk_test_your_key');
const elements = stripe.elements();
const cardElement = elements.create('card');
cardElement.mount('#card-element');
\`\`\`

### 3. إعداد Mada (السعودية):

#### التكوين:
\`\`\`php
// config/payment_config.php
define('MADA_MERCHANT_ID', 'your_merchant_id');
define('MADA_TERMINAL_ID', 'your_terminal_id');
define('MADA_SECRET_KEY', 'your_secret_key');
\`\`\`

#### معالجة الدفع:
\`\`\`php
$mada = new MadaGateway();
$payment_url = $mada->createPayment([
    'amount' => 100,
    'currency' => 'SAR',
    'order_id' => '12345'
]);
\`\`\`

### 4. إعداد Apple Pay:

#### متطلبات Apple Pay:
1. Apple Developer Account
2. Merchant ID
3. SSL Certificate

#### التكوين:
\`\`\`php
// config/payment_config.php
define('APPLE_PAY_MERCHANT_ID', 'merchant.com.yoursite');
define('APPLE_PAY_CERTIFICATE_PATH', '/path/to/cert.pem');
\`\`\`

#### Frontend Integration:
\`\`\`javascript
// Apple Pay Button
const applePayButton = document.getElementById('apple-pay-button');
applePayButton.addEventListener('click', function() {
    const paymentRequest = {
        countryCode: 'SA',
        currencyCode: 'SAR',
        supportedNetworks: ['visa', 'masterCard', 'mada'],
        merchantCapabilities: ['supports3DS'],
        total: {
            label: 'FastStar Payment',
            amount: '100.00'
        }
    };
    
    const session = new ApplePaySession(3, paymentRequest);
    session.begin();
});
\`\`\`

### 5. إعداد Google Pay:

#### التكوين:
\`\`\`php
// config/payment_config.php
define('GOOGLE_PAY_MERCHANT_ID', 'your_merchant_id');
define('GOOGLE_PAY_ENVIRONMENT', 'TEST'); // أو 'PRODUCTION'
\`\`\`

#### Frontend Integration:
\`\`\`javascript
// Google Pay Configuration
const base_request = {
    apiVersion: 2,
    apiVersionMinor: 0
};

const tokenization_specification = {
    type: 'PAYMENT_GATEWAY',
    parameters: {
        'gateway': 'example',
        'gatewayMerchantId': 'exampleGatewayMerchantId'
    }
};
\`\`\`

### 6. إعداد التحويل البنكي:

#### التكوين:
\`\`\`php
// config/payment_config.php
define('BANK_TRANSFER_ENABLED', true);
define('BANK_ACCOUNT_NUMBER', '1234567890');
define('BANK_IBAN', 'SA1234567890123456789012');
define('BANK_NAME', 'البنك الأهلي السعودي');
\`\`\`

---

## 🔌 API المتقدم

### نظرة عامة على API:

فاست ستار يوفر API RESTful متقدم مع المميزات التالية:
- **مصادقة JWT**
- **Rate Limiting**
- **CORS Support**
- **API Keys Management**
- **Comprehensive Logging**

### 1. المصادقة (Authentication):

#### الحصول على JWT Token:
\`\`\`bash
curl -X POST https://yoursite.com/api/v1/auth/login \\
  -H "Content-Type: application/json" \\
  -d '{
    "username": "your_username",
    "password": "your_password"
  }'
\`\`\`

#### الاستجابة:
\`\`\`json
{
  "success": true,
  "data": {
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
    "expires_in": 86400,
    "user": {
      "id": 1,
      "username": "user123",
      "email": "user@example.com"
    }
  }
}
\`\`\`

### 2. إنشاء API Key:

#### طلب إنشاء API Key:
\`\`\`bash
curl -X POST https://yoursite.com/api/v1/keys \\
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "My App API Key",
    "permissions": ["read", "write"],
    "rate_limit": 1000
  }'
\`\`\`

### 3. استخدام API:

#### الحصول على المنتجات:
\`\`\`bash
curl -X GET https://yoursite.com/api/v1/products \\
  -H "X-API-Key: fsk_your_api_key_here" \\
  -H "Content-Type: application/json"
\`\`\`

#### إنشاء طلب شحن:
\`\`\`bash
curl -X POST https://yoursite.com/api/v1/orders \\
  -H "X-API-Key: fsk_your_api_key_here" \\
  -H "Content-Type: application/json" \\
  -d '{
    "product_id": 1,
    "quantity": 1,
    "player_id": "123456789",
    "payment_method": "wallet"
  }'
\`\`\`

### 4. Endpoints المتاحة:

#### المصادقة:
\`\`\`
POST /api/v1/auth/login      - تسجيل الدخول
POST /api/v1/auth/register   - إنشاء حساب
POST /api/v1/auth/refresh    - تجديد Token
POST /api/v1/auth/logout     - تسجيل الخروج
\`\`\`

#### المنتجات:
\`\`\`
GET    /api/v1/products           - قائمة المنتجات
GET    /api/v1/products/{id}      - تفاصيل منتج
GET    /api/v1/categories         - قائمة الفئات
GET    /api/v1/categories/{id}    - منتجات فئة معينة
\`\`\`

#### الطلبات:
\`\`\`
POST   /api/v1/orders            - إنشاء طلب
GET    /api/v1/orders            - قائمة الطلبات
GET    /api/v1/orders/{id}       - تفاصيل طلب
PUT    /api/v1/orders/{id}       - تحديث طلب
\`\`\`

#### المحفظة:
\`\`\`
GET    /api/v1/wallet            - رصيد المحفظة
POST   /api/v1/wallet/topup     - شحن المحفظة
GET    /api/v1/wallet/history   - تاريخ المعاملات
\`\`\`

#### الدفع:
\`\`\`
POST   /api/v1/payment/create   - إنشاء عملية دفع
POST   /api/v1/payment/verify   - التحقق من الدفع
GET    /api/v1/payment/methods  - طرق الدفع المتاحة
\`\`\`

### 5. معالجة الأخطاء:

#### رموز الأخطاء الشائعة:
\`\`\`json
{
  "success": false,
  "error": {
    "code": 401,
    "message": "Unauthorized",
    "details": "Invalid API key"
  }
}
\`\`\`

#### رموز الحالة:
\`\`\`
200 - نجح الطلب
201 - تم الإنشاء بنجاح
400 - خطأ في البيانات المرسلة
401 - غير مصرح
403 - ممنوع
404 - غير موجود
429 - تجاوز الحد المسموح
500 - خطأ في الخادم
\`\`\`

### 6. Rate Limiting:

#### الحدود الافتراضية:
\`\`\`
- 1000 طلب في الساعة لكل API Key
- 100 طلب في الدقيقة لكل IP
- 10 طلبات تسجيل دخول في الدقيقة
\`\`\`

#### Headers الاستجابة:
\`\`\`
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1640995200
\`\`\`

---

## 💾 نظام النسخ الاحتياطي

### 1. أنواع النسخ الاحتياطية:

#### نسخة قاعدة البيانات:
\`\`\`bash
# يدوي
php scripts/backup_cron.php --type=database

# تلقائي (crontab)
0 2 * * * /usr/bin/php /path/to/scripts/backup_cron.php --type=database
\`\`\`

#### نسخة الملفات:
\`\`\`bash
# يدوي
php scripts/backup_cron.php --type=files

# تلقائي (crontab)
0 3 * * 0 /usr/bin/php /path/to/scripts/backup_cron.php --type=files
\`\`\`

#### نسخة كاملة:
\`\`\`bash
# يدوي
php scripts/backup_cron.php --type=full

# تلقائي (crontab)
0 4 * * 0 /usr/bin/php /path/to/scripts/backup_cron.php --type=full
\`\`\`

### 2. إعداد النسخ التلقائي:

#### إضافة إلى crontab:
\`\`\`bash
# تحرير crontab
crontab -e

# إضافة المهام
# نسخة قاعدة البيانات يومياً في الساعة 2:00 صباحاً
0 2 * * * /usr/bin/php /var/www/html/scripts/backup_cron.php --type=database

# نسخة كاملة أسبوعياً يوم الأحد في الساعة 3:00 صباحاً
0 3 * * 0 /usr/bin/php /var/www/html/scripts/backup_cron.php --type=full

# تنظيف النسخ القديمة يومياً
0 5 * * * /usr/bin/php /var/www/html/scripts/cleanup_backups.php
\`\`\`

### 3. إعدادات النسخ الاحتياطي:

#### من لوحة التحكم:
1. اذهب إلى **النظام > النسخ الاحتياطي**
2. اضبط الإعدادات:
   - عدد النسخ المحفوظة: 10
   - مدة الاحتفاظ: 30 يوم
   - تفعيل الضغط: نعم
   - إشعارات البريد: نعم

#### من قاعدة البيانات:
\`\`\`sql
-- تحديث إعدادات النسخ
UPDATE backup_settings SET setting_value = '15' WHERE setting_key = 'max_backup_files';
UPDATE backup_settings SET setting_value = '45' WHERE setting_key = 'backup_retention_days';
\`\`\`

### 4. استعادة النسخ الاحتياطية:

#### استعادة قاعدة البيانات:
\`\`\`bash
# فك ضغط النسخة (إذا كانت مضغوطة)
gunzip backup_file.sql.gz

# استعادة قاعدة البيانات
mysql -u username -p database_name < backup_file.sql
\`\`\`

#### استعادة الملفات:
\`\`\`bash
# فك ضغط النسخة
unzip backup_files.zip -d /restore/location/

# نسخ الملفات
cp -r /restore/location/* /var/www/html/
\`\`\`

### 5. مراقبة النسخ الاحتياطية:

#### فحص حالة النسخ:
\`\`\`sql
-- آخر النسخ الاحتياطية
SELECT * FROM backups ORDER BY created_at DESC LIMIT 10;

-- إحصائيات النسخ
CALL GetBackupStats();

-- النسخ الفاشلة
SELECT * FROM backup_logs WHERE status = 'failed' ORDER BY created_at DESC;
\`\`\`

#### سجلات النسخ:
\`\`\`bash
# عرض سجل النسخ
tail -f logs/backup_cron.log

# البحث عن أخطاء
grep "ERROR" logs/backup_cron.log
\`\`\`

---

## 🔒 الأمان والحماية

### 1. حماية الملفات:

#### صلاحيات الملفات:
\`\`\`bash
# الملفات العامة
chmod 644 *.php
chmod 644 *.html
chmod 644 *.css
chmod 644 *.js

# المجلدات
chmod 755 */

# ملفات الإعدادات (حماية إضافية)
chmod 600 config/*.php

# مجلدات الرفع والنسخ
chmod 777 uploads/
chmod 777 backups/
chmod 755 logs/
\`\`\`

#### حماية .htaccess:
\`\`\`apache
# .htaccess في المجلد الرئيسي
RewriteEngine On

# منع الوصول لملفات الإعدادات
<Files "config.php">
    Order Allow,Deny
    Deny from all
</Files>

# منع الوصول لملفات النسخ الاحتياطي
<Directory "backups">
    Order Allow,Deny
    Deny from all
</Directory>

# منع الوصول للسجلات
<Directory "logs">
    Order Allow,Deny
    Deny from all
</Directory>

# حماية من SQL Injection
RewriteCond %{QUERY_STRING} (\<|%3C).*script.*(\>|%3E) [NC,OR]
RewriteCond %{QUERY_STRING} GLOBALS(=|\[|\%[0-9A-Z]{0,2}) [OR]
RewriteCond %{QUERY_STRING} _REQUEST(=|\[|\%[0-9A-Z]{0,2}) [OR]
RewriteCond %{QUERY_STRING} (\<|%3C).*iframe.*(\>|%3E) [NC,OR]
RewriteCond %{QUERY_STRING} (\<|%3C).*object.*(\>|%3E) [NC,OR]
RewriteCond %{QUERY_STRING} (\<|%3C).*embed.*(\>|%3E) [NC,OR]
RewriteCond %{QUERY_STRING} (SELECT|UNION|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER) [NC]
RewriteRule ^(.*)$ - [F,L]
\`\`\`

### 2. حماية قاعدة البيانات:

#### إعدادات MySQL الآمنة:
\`\`\`sql
-- إنشاء مستخدم محدود الصلاحيات
CREATE USER 'faststar_app'@'localhost' IDENTIFIED BY 'complex_password_123!';

-- منح صلاحيات محددة فقط
GRANT SELECT, INSERT, UPDATE, DELETE ON faststar_db.* TO 'faststar_app'@'localhost';

-- منع صلاحيات خطيرة
REVOKE CREATE, DROP, ALTER, INDEX ON faststar_db.* FROM 'faststar_app'@'localhost';

FLUSH PRIVILEGES;
\`\`\`

#### Prepared Statements:
\`\`\`php
// استخدام Prepared Statements دائماً
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND status = ?");
$stmt->execute([$email, 'active']);
$user = $stmt->fetch();

// تجنب هذا (خطير)
$query = "SELECT * FROM users WHERE email = '$email'"; // خطر SQL Injection
\`\`\`

### 3. حماية الجلسات:

#### إعدادات الجلسات الآمنة:
\`\`\`php
// config/security.php
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Strict');

// تجديد معرف الجلسة
session_regenerate_id(true);

// انتهاء صلاحية الجلسة
if (isset($_SESSION['last_activity']) && 
    (time() - $_SESSION['last_activity'] > 1800)) {
    session_unset();
    session_destroy();
}
$_SESSION['last_activity'] = time();
\`\`\`

### 4. حماية من CSRF:

#### إنشاء CSRF Token:
\`\`\`php
// إنشاء Token
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// التحقق من Token
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && 
           hash_equals($_SESSION['csrf_token'], $token);
}
\`\`\`

#### استخدام في النماذج:
\`\`\`html
<form method="POST" action="process.php">
    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
    <!-- باقي حقول النموذج -->
    <button type="submit">إرسال</button>
</form>
\`\`\`

### 5. تشفير البيانات الحساسة:

#### تشفير كلمات المرور:
\`\`\`php
// تشفير كلمة المرور
$hashed_password = password_hash($password, PASSWORD_ARGON2ID, [
    'memory_cost' => 65536,
    'time_cost' => 4,
    'threads' => 3
]);

// التحقق من كلمة المرور
if (password_verify($password, $hashed_password)) {
    // كلمة المرور صحيحة
}
\`\`\`

#### تشفير البيانات الحساسة:
\`\`\`php
// تشفير البيانات
function encryptData($data, $key) {
    $iv = random_bytes(16);
    $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
    return base64_encode($iv . $encrypted);
}

// فك التشفير
function decryptData($encrypted_data, $key) {
    $data = base64_decode($encrypted_data);
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);
    return openssl_decrypt($encrypted, 'AES-256-CBC', $key, 0, $iv);
}
\`\`\`

### 6. Rate Limiting:

#### حماية من الهجمات:
\`\`\`php
// Rate Limiting للتسجيل
function checkLoginAttempts($ip, $username) {
    $db = Database::getInstance()->getConnection();
    
    // فحص المحاولات في آخر 15 دقيقة
    $stmt = $db->prepare("
        SELECT COUNT(*) FROM login_attempts 
        WHERE (ip_address = ? OR username = ?) 
        AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
    ");
    $stmt->execute([$ip, $username]);
    $attempts = $stmt->fetchColumn();
    
    if ($attempts >= 5) {
        throw new Exception('تم تجاوز عدد المحاولات المسموحة. حاول مرة أخرى بعد 15 دقيقة.');
    }
}

// تسجيل محاولة فاشلة
function logFailedAttempt($ip, $username) {
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        INSERT INTO login_attempts (ip_address, username, created_at) 
        VALUES (?, ?, NOW())
    ");
    $stmt->execute([$ip, $username]);
}
\`\`\`

---

## 🔍 استكشاف الأخطاء

### 1. أخطاء قاعدة البيانات:

#### خطأ الاتصال:
\`\`\`
خطأ: SQLSTATE[HY000] [2002] Connection refused

الحل:
1. تأكد من تشغيل MySQL
2. تحقق من بيانات الاتصال في config/database.php
3. تأكد من صلاحيات المستخدم
\`\`\`

#### خطأ الجدول غير موجود:
\`\`\`
خطأ: Table 'faststar_db.users' doesn't exist

الحل:
1. تشغيل سكريبت إعداد قاعدة البيانات
mysql -u username -p database_name < scripts/database_setup.sql
\`\`\`

### 2. أخطاء الدفع:

#### خطأ PayPal:
\`\`\`
خطأ: INVALID_CLIENT_CREDENTIALS

الحل:
1. تحقق من Client ID و Client Secret
2. تأكد من إعداد Sandbox/Production بشكل صحيح
3. تحقق من صلاحيات التطبيق في PayPal
\`\`\`

#### خطأ Stripe:
\`\`\`
خطأ: Invalid API Key

الحل:
1. تحقق من مفاتيح API في config/payment_config.php
2. تأكد من استخدام المفاتيح الصحيحة (Test/Live)
\`\`\`

### 3. أخطاء API:

#### خطأ 401 Unauthorized:
\`\`\`json
{
  "success": false,
  "error": {
    "code": 401,
    "message": "Invalid API key"
  }
}

الحل:
1. تحقق من API Key في الطلب
2. تأكد من صحة التوقيع
3. تحقق من انتهاء صلاحية المفتاح
\`\`\`

#### خطأ 429 Rate Limit:
\`\`\`json
{
  "success": false,
  "error": {
    "code": 429,
    "message": "Rate limit exceeded"
  }
}

الحل:
1. انتظر حتى انتهاء النافذة الزمنية
2. قلل من عدد الطلبات
3. اطلب زيادة الحد المسموح
\`\`\`

### 4. أخطاء النسخ الاحتياطي:

#### خطأ في إنشاء النسخة:
\`\`\`
خطأ: mysqldump: command not found

الحل:
1. تثبيت MySQL client
sudo apt-get install mysql-client

2. تحديد مسار mysqldump في الإعدادات
UPDATE backup_settings SET setting_value = '/usr/bin/mysqldump' 
WHERE setting_key = 'mysql_dump_path';
\`\`\`

#### خطأ في الصلاحيات:
\`\`\`
خطأ: Permission denied

الحل:
1. تعيين صلاحيات مجلد النسخ
chmod 777 backups/

2. تأكد من ملكية المجلد
chown www-data:www-data backups/
\`\`\`

### 5. سجلات الأخطاء:

#### فحص سجلات PHP:
\`\`\`bash
# سجل أخطاء PHP
tail -f /var/log/php/error.log

# سجل أخطاء Apache
tail -f /var/log/apache2/error.log

# سجل أخطاء النظام
tail -f logs/system.log
\`\`\`

#### فحص سجلات قاعدة البيانات:
\`\`\`sql
-- أخطاء قاعدة البيانات
SELECT * FROM error_logs ORDER BY created_at DESC LIMIT 50;

-- أخطاء API
SELECT * FROM api_requests WHERE response_code >= 400 ORDER BY created_at DESC;
\`\`\`

---

## 🔧 الصيانة والمراقبة

### 1. مراقبة الأداء:

#### مراقبة قاعدة البيانات:
\`\`\`sql
-- فحص الاستعلامات البطيئة
SHOW PROCESSLIST;

-- إحصائيات الجداول
SELECT 
    table_name,
    table_rows,
    data_length,
    index_length,
    (data_length + index_length) as total_size
FROM information_schema.tables 
WHERE table_schema = 'faststar_db'
ORDER BY total_size DESC;

-- فحص الفهارس المفقودة
SELECT * FROM sys.schema_unused_indexes;
\`\`\`

#### مراقبة الخادم:
\`\`\`bash
# استخدام المعالج
top

# استخدام الذاكرة
free -h

# مساحة القرص
df -h

# حالة الخدمات
systemctl status apache2
systemctl status mysql
\`\`\`

### 2. تنظيف البيانات:

#### تنظيف السجلات القديمة:
\`\`\`sql
-- حذف سجلات API القديمة (أكثر من 30 يوم)
DELETE FROM api_requests 
WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);

-- حذف محاولات تسجيل الدخول القديمة
DELETE FROM login_attempts 
WHERE created_at < DATE_SUB(NOW(), INTERVAL 7 DAY);

-- حذف الجلسات المنتهية الصلاحية
DELETE FROM sessions 
WHERE expires_at < NOW();
\`\`\`

#### تنظيف الملفات:
\`\`\`bash
# حذف ملفات السجلات القديمة
find logs/ -name "*.log" -mtime +30 -delete

# حذف ملفات مؤقتة
find tmp/ -type f -mtime +1 -delete

# تنظيف cache
rm -rf cache/*
\`\`\`

### 3. تحديث النظام:

#### تحديث قاعدة البيانات:
\`\`\`bash
# تشغيل سكريبتات التحديث
mysql -u username -p database_name < scripts/update_v2.0.sql
\`\`\`

#### تحديث الملفات:
\`\`\`bash
# نسخ احتياطية قبل التحديث
cp -r /var/www/html /backup/before_update/

# تحديث الملفات
git pull origin main

# تشغيل سكريبت ما بعد التحديث
php scripts/post_update.php
\`\`\`

### 4. مراقبة الأمان:

#### فحص محاولات الاختراق:
\`\`\`bash
# فحص سجل Apache للهجمات
grep -i "hack\|attack\|exploit" /var/log/apache2/access.log

# فحص محاولات تسجيل الدخول المشبوهة
grep "Failed password" /var/log/auth.log
\`\`\`

#### فحص تكامل الملفات:
\`\`\`bash
# إنشاء checksums للملفات المهمة
find . -name "*.php" -exec md5sum {} \; > checksums.txt

# فحص التغييرات
md5sum -c checksums.txt
\`\`\`

### 5. النسخ الاحتياطي والاستعادة:

#### جدولة النسخ التلقائية:
\`\`\`bash
# إضافة إلى crontab
0 2 * * * /usr/bin/php /var/www/html/scripts/backup_cron.php --type=database
0 3 * * 0 /usr/bin/php /var/www/html/scripts/backup_cron.php --type=full
0 4 * * * /usr/bin/php /var/www/html/scripts/cleanup_old_backups.php
\`\`\`

#### اختبار الاستعادة:
\`\`\`bash
# اختبار استعادة قاعدة البيانات
mysql -u username -p test_database < latest_backup.sql

# التحقق من سلامة البيانات
mysql -u username -p -e "SELECT COUNT(*) FROM test_database.users;"
\`\`\`

---

## 📞 الدعم والمساعدة

### معلومات الاتصال:
- **الموقع**: https://faststarone.com
- **البريد الإلكتروني**: support@faststarone.com
- **الهاتف**: +966-XX-XXX-XXXX

### الموارد المفيدة:
- **التوثيق الكامل**: https://docs.faststarone.com
- **منتدى الدعم**: https://forum.faststarone.com
- **قناة التليجرام**: @FastStarSupport

### تحديثات النظام:
- **الإصدار الحالي**: v2.0.0
- **آخر تحديث**: 2024-01-15
- **التحديث القادم**: v2.1.0 (متوقع في مارس 2024)

---

*© 2024 FastStar - جميع الحقوق محفوظة*
\`\`\`
