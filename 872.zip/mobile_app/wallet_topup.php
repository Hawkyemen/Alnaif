<?php
// صفحة شحن المحفظة للتطبيق المحمول
require_once '../config/config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// التحقق من المصادقة
$headers = getallheaders();
$auth_header = $headers['Authorization'] ?? '';

if (!$auth_header || !str_starts_with($auth_header, 'Bearer ')) {
    http_response_code(401);
    echo json_encode(['error' => 'Missing or invalid authorization header']);
    exit;
}

$token = substr($auth_header, 7);
// يجب التحقق من صحة الرمز المميز هنا

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // إرجاع منتجات شحن المحفظة
    try {
        $db = Database::getInstance()->getConnection();
        
        $stmt = $db->query("
            SELECT p.*, c.name as category_name 
            FROM products p 
            JOIN categories c ON p.category_id = c.id 
            WHERE c.type = 'wallet' AND p.status = 'active' 
            ORDER BY p.price_usd ASC
        ");
        $products = $stmt->fetchAll();
        
        $wallet_products = [];
        foreach ($products as $product) {
            $wallet_products[] = [
                'id' => $product['id'],
                'name' => $product['name'],
                'name_ar' => $product['name_ar'],
                'prices' => [
                    'YER' => (float)$product['price_yer'],
                    'SAR' => (float)$product['price_sar'],
                    'USD' => (float)$product['price_usd']
                ],
                'apple_product_id' => 'com.faststarone.wallet.' . $product['id'],
                'google_product_id' => 'wallet_topup_' . $product['id']
            ];
        }
        
        echo json_encode([
            'success' => true,
            'products' => $wallet_products
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // معالجة عملية الشراء
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid JSON input']);
        exit;
    }
    
    $user_id = $input['user_id'] ?? 0;
    $platform = $input['platform'] ?? ''; // 'apple' or 'google'
    $product_id = $input['product_id'] ?? '';
    $transaction_id = $input['transaction_id'] ?? '';
    $receipt_data = $input['receipt_data'] ?? '';
    $amount = (float)($input['amount'] ?? 0);
    $currency = $input['currency'] ?? 'USD';
    
    if (!$user_id || !$platform || !$product_id || !$transaction_id || !$amount) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing required fields']);
        exit;
    }
    
    try {
        $db = Database::getInstance()->getConnection();
        
        // التحقق من عدم وجود المعاملة مسبقاً
        $stmt = $db->prepare("SELECT id FROM in_app_purchases WHERE transaction_id = ?");
        $stmt->execute([$transaction_id]);
        if ($stmt->fetch()) {
            echo json_encode(['error' => 'Transaction already processed']);
            exit;
        }
        
        // حفظ عملية الشراء
        $stmt = $db->prepare("INSERT INTO in_app_purchases (user_id, platform, product_id, transaction_id, receipt_data, amount, currency) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $platform, $product_id, $transaction_id, $receipt_data, $amount, $currency]);
        
        // التحقق من الإيصال
        $verification_result = false;
        if ($platform === 'apple') {
            $verification_result = verifyAppleReceipt($receipt_data);
        } elseif ($platform === 'google') {
            $verification_result = verifyGooglePurchase($product_id, $transaction_id);
        }
        
        if ($verification_result) {
            // تحديث حالة الشراء
            $stmt = $db->prepare("UPDATE in_app_purchases SET status = 'verified', verified_at = NOW() WHERE transaction_id = ?");
            $stmt->execute([$transaction_id]);
            
            // إضافة المبلغ إلى محفظة المستخدم
            $wallet_field = 'wallet_balance_' . strtolower($currency);
            $stmt = $db->prepare("UPDATE users SET $wallet_field = $wallet_field + ? WHERE id = ?");
            $stmt->execute([$amount, $user_id]);
            
            // إضافة معاملة المحفظة
            $stmt = $db->prepare("INSERT INTO wallet_transactions (user_id, type, amount, currency, description, status) VALUES (?, 'deposit', ?, ?, ?, 'completed')");
            $stmt->execute([$user_id, $amount, $currency, "شحن المحفظة عبر $platform"]);
            
            echo json_encode([
                'success' => true,
                'message' => 'تم شحن المحفظة بنجاح',
                'transaction_id' => $transaction_id,
                'amount' => $amount,
                'currency' => $currency
            ]);
        } else {
            // فشل التحقق
            $stmt = $db->prepare("UPDATE in_app_purchases SET status = 'failed' WHERE transaction_id = ?");
            $stmt->execute([$transaction_id]);
            
            echo json_encode(['error' => 'Receipt verification failed']);
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Processing error: ' . $e->getMessage()]);
    }
}

function verifyAppleReceipt($receipt_data) {
    // التحقق من إيصال Apple
    $sandbox_url = 'https://sandbox.itunes.apple.com/verifyReceipt';
    $production_url = 'https://buy.itunes.apple.com/verifyReceipt';
    
    $post_data = json_encode([
        'receipt-data' => $receipt_data,
        'password' => APPLE_SHARED_SECRET
    ]);
    
    // جرب الإنتاج أولاً
    $result = makeAppleRequest($production_url, $post_data);
    
    // إذا فشل الإنتاج مع إيصال sandbox، جرب sandbox
    if ($result && isset($result['status']) && $result['status'] == 21007) {
        $result = makeAppleRequest($sandbox_url, $post_data);
    }
    
    return $result && isset($result['status']) && $result['status'] == 0;
}

function verifyGooglePurchase($product_id, $purchase_token) {
    // التحقق من شراء Google Play
    $access_token = getGooglePlayAccessToken();
    
    if (!$access_token) {
        return false;
    }
    
    $url = "https://androidpublisher.googleapis.com/androidpublisher/v3/applications/" . GOOGLE_PLAY_PACKAGE_NAME . "/purchases/products/$product_id/tokens/$purchase_token";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $access_token,
        'Content-Type: application/json'
    ]);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code == 200) {
        $data = json_decode($response, true);
        return $data && isset($data['purchaseState']) && $data['purchaseState'] == 0;
    }
    
    return false;
}

function makeAppleRequest($url, $data) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($response, true);
}

function getGooglePlayAccessToken() {
    // الحصول على رمز الوصول من Google Play
    // يجب تنفيذ هذا باستخدام مفتاح حساب الخدمة
    return 'your_access_token_here';
}
?>
