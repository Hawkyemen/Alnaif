<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إعداد سريع - فاست ستار</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
            min-height: 100vh;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        .content {
            padding: 30px;
        }
        .step {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
            border-left: 5px solid #667eea;
        }
        .success {
            background: #d4edda;
            border-left-color: #28a745;
            color: #155724;
        }
        .error {
            background: #f8d7da;
            border-left-color: #dc3545;
            color: #721c24;
        }
        .warning {
            background: #fff3cd;
            border-left-color: #ffc107;
            color: #856404;
        }
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            display: inline-block;
            margin: 10px 5px;
            transition: transform 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
        }
        .progress {
            background: #e9ecef;
            border-radius: 10px;
            height: 20px;
            margin: 20px 0;
        }
        .progress-bar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100%;
            border-radius: 10px;
            transition: width 0.5s;
        }
        .info-box {
            background: #e3f2fd;
            border: 1px solid #2196f3;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
        }
        .credentials {
            background: #fff8e1;
            border: 1px solid #ff9800;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
        }
        .credentials h4 {
            margin-top: 0;
            color: #e65100;
        }
        pre {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
            border-left: 3px solid #667eea;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 إعداد سريع - فاست ستار</h1>
            <p>إعداد قاعدة البيانات والنظام بشكل تلقائي</p>
        </div>
        
        <div class="content">
            <?php
            if (isset($_POST['setup'])) {
                echo '<div class="step">';
                echo '<h3>🔄 جاري الإعداد...</h3>';
                echo '<div class="progress"><div class="progress-bar" style="width: 10%"></div></div>';
                echo '</div>';
                
                // تشغيل إعداد قاعدة البيانات
                ob_start();
                include 'scripts/apply_database.php';
                $output = ob_get_clean();
                
                if (strpos($output, 'تم تطبيق قاعدة البيانات بنجاح') !== false) {
                    echo '<div class="step success">';
                    echo '<h3>✅ تم الإعداد بنجاح!</h3>';
                    echo '<div class="progress"><div class="progress-bar" style="width: 100%"></div></div>';
                    echo '<pre>' . htmlspecialchars($output) . '</pre>';
                    echo '</div>';
                    
                    echo '<div class="credentials">';
                    echo '<h4>🔐 بيانات تسجيل الدخول</h4>';
                    echo '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">';
                    echo '<div>';
                    echo '<h5>👨‍💼 المدير الرئيسي</h5>';
                    echo '<p><strong>اسم المستخدم:</strong> admin</p>';
                    echo '<p><strong>كلمة المرور:</strong> faststar2024</p>';
                    echo '<p><strong>الرابط:</strong> <a href="admin/login.php">admin/login.php</a></p>';
                    echo '</div>';
                    echo '<div>';
                    echo '<h5>👤 مستخدم تجريبي</h5>';
                    echo '<p><strong>اسم المستخدم:</strong> testuser</p>';
                    echo '<p><strong>كلمة المرور:</strong> test123</p>';
                    echo '<p><strong>الرابط:</strong> <a href="login.php">login.php</a></p>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                    
                    echo '<div class="info-box">';
                    echo '<h4>🔗 روابط مهمة</h4>';
                    echo '<a href="admin/login.php" class="btn">لوحة تحكم المدير</a>';
                    echo '<a href="login.php" class="btn">تسجيل دخول المستخدم</a>';
                    echo '<a href="test_system.php" class="btn">اختبار النظام</a>';
                    echo '</div>';
                    
                } else {
                    echo '<div class="step error">';
                    echo '<h3>❌ فشل في الإعداد</h3>';
                    echo '<pre>' . htmlspecialchars($output) . '</pre>';
                    echo '</div>';
                }
            } else {
                ?>
                <div class="step">
                    <h3>📋 معلومات الإعداد</h3>
                    <p>سيتم إعداد النظام بالمعلومات التالية:</p>
                    <ul>
                        <li><strong>قاعدة البيانات:</strong> faststar_db</li>
                        <li><strong>الخادم:</strong> localhost</li>
                        <li><strong>المستخدم:</strong> root</li>
                        <li><strong>كلمة المرور:</strong> (فارغة)</li>
                    </ul>
                </div>
                
                <div class="step warning">
                    <h3>⚠️ تحذير مهم</h3>
                    <p>تأكد من أن:</p>
                    <ul>
                        <li>خادم MySQL يعمل على localhost</li>
                        <li>المستخدم root لديه صلاحيات إنشاء قواعد البيانات</li>
                        <li>لا توجد قاعدة بيانات بنفس الاسم (faststar_db)</li>
                    </ul>
                </div>
                
                <div class="step">
                    <h3>🎯 ما سيتم إنشاؤه</h3>
                    <ul>
                        <li>15 جدول قاعدة بيانات مع العلاقات</li>
                        <li>مدير رئيسي (admin/faststar2024)</li>
                        <li>مستخدم تجريبي (testuser/test123)</li>
                        <li>6 فئات منتجات</li>
                        <li>6 منتجات تجريبية</li>
                        <li>8 بوابات دفع</li>
                        <li>أسعار صرف العملات</li>
                        <li>إعدادات النظام الأساسية</li>
                    </ul>
                </div>
                
                <form method="post" style="text-align: center;">
                    <button type="submit" name="setup" class="btn" style="font-size: 18px; padding: 15px 40px;">
                        🚀 بدء الإعداد الآن
                    </button>
                </form>
                <?php
            }
            ?>
        </div>
    </div>
</body>
</html>
