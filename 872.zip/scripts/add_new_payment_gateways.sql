-- إضافة بوابات دفع جديدة ومحلية
-- Add New and Local Payment Gateways

-- إضافة بوابات الدفع اليمنية والعربية الجديدة
INSERT INTO `payment_gateways` (`code`, `name`, `name_ar`, `description`, `config`, `supported_currencies`, `min_amount`, `max_amount`, `fees_percentage`, `fees_fixed`, `sort_order`, `status`, `test_mode`) VALUES
-- بوابات الدفع اليمنية
('ym_bank', 'Yemen Mobile Bank', 'بنك يمن موبايل', 'Yemen Mobile banking services', '{"merchant_id": "", "api_key": "", "callback_url": "", "environment": "sandbox"}', 'YER', 500.00, 1000000.00, 1.50, 10.00, 9, 'active', 1),
('cac_bank', 'CAC Bank', 'بنك التسليف التعاونى والزراعى', 'Cooperative and Agricultural Credit Bank', '{"merchant_code": "", "terminal_id": "", "secret_key": ""}', 'YER', 1000.00, 500000.00, 2.00, 15.00, 10, 'active', 1),
('kuraimi_bank', 'Kuraimi Bank', 'بنك الكريمي', 'Kuraimi Islamic Bank payment gateway', '{"account_id": "", "api_token": "", "branch_code": ""}', 'YER', 500.00, 300000.00, 1.75, 8.00, 11, 'active', 1),
('tadhamon_bank', 'Tadhamon Bank', 'بنك التضامن الإسلامي', 'Tadhamon Islamic Bank services', '{"client_id": "", "client_secret": "", "branch_id": ""}', 'YER', 1000.00, 750000.00, 2.25, 12.00, 12, 'active', 1),

-- بوابات الدفع السعودية
('stc_pay', 'STC Pay', 'إس تي سي باي', 'STC Pay digital wallet', '{"merchant_id": "", "api_key": "", "webhook_secret": ""}', 'SAR', 5.00, 50000.00, 2.50, 1.00, 13, 'active', 1),
('urpay', 'urpay', 'يور باي', 'urpay payment solutions', '{"merchant_code": "", "terminal_id": "", "encryption_key": ""}', 'SAR', 10.00, 100000.00, 2.75, 2.00, 14, 'active', 1),
('hyperpay', 'HyperPay', 'هايبر باي', 'HyperPay payment gateway', '{"entity_id": "", "access_token": "", "webhook_url": ""}', 'SAR,AED,USD', 1.00, 999999.99, 2.85, 1.50, 15, 'active', 1),
('moyasar', 'Moyasar', 'ميسر', 'Moyasar payment platform', '{"publishable_key": "", "secret_key": "", "webhook_secret": ""}', 'SAR', 1.00, 200000.00, 2.90, 1.00, 16, 'active', 1),

-- بوابات الدفع الإماراتية
('network_intl', 'Network International', 'نتورك انترناشيونال', 'Network International payment gateway', '{"merchant_id": "", "password": "", "gateway_url": ""}', 'AED,USD,SAR', 5.00, 500000.00, 2.95, 2.00, 17, 'active', 1),
('ngenius', 'N-Genius', 'إن جينيوس', 'Network International N-Genius platform', '{"api_key": "", "outlet_ref": "", "webhook_url": ""}', 'AED,USD', 1.00, 100000.00, 2.80, 1.50, 18, 'active', 1),
('cbd_now', 'CBD Now', 'سي بي دي ناو', 'Commercial Bank of Dubai payment', '{"merchant_id": "", "terminal_id": "", "secret_key": ""}', 'AED', 10.00, 250000.00, 2.50, 3.00, 19, 'active', 1),

-- بوابات الدفع الدولية الإضافية
('razorpay', 'Razorpay', 'رازور باي', 'Razorpay payment gateway', '{"key_id": "", "key_secret": "", "webhook_secret": ""}', 'USD,EUR,GBP', 0.50, 50000.00, 2.00, 0.30, 20, 'active', 1),
('paymob', 'Paymob', 'باي موب', 'Paymob payment solutions', '{"api_key": "", "integration_id": "", "hmac_secret": ""}', 'EGP,SAR,AED', 1.00, 100000.00, 2.65, 1.00, 21, 'active', 1),
('fawry', 'Fawry', 'فوري', 'Fawry payment network', '{"merchant_code": "", "security_key": "", "fawry_fees": "customer"}', 'EGP', 5.00, 50000.00, 1.95, 2.00, 22, 'active', 1),
('tap_payments', 'Tap Payments', 'تاب للمدفوعات', 'Tap payment platform', '{"secret_key": "", "public_key": "", "webhook_url": ""}', 'KWD,SAR,AED,BHD', 0.50, 25000.00, 2.75, 0.50, 23, 'active', 1),

-- محافظ رقمية إضافية
('orange_money', 'Orange Money', 'أورانج موني', 'Orange Money mobile wallet', '{"partner_id": "", "api_key": "", "callback_url": ""}', 'XOF,XAF', 100.00, 1000000.00, 2.00, 5.00, 24, 'active', 1),
('vodafone_cash', 'Vodafone Cash', 'فودافون كاش', 'Vodafone Cash mobile wallet', '{"merchant_id": "", "api_secret": "", "service_type": ""}', 'EGP', 10.00, 50000.00, 1.50, 2.50, 25, 'active', 1),
('etisalat_wallet', 'Etisalat Wallet', 'محفظة اتصالات', 'Etisalat digital wallet', '{"wallet_id": "", "api_token": "", "encryption_key": ""}', 'AED', 5.00, 25000.00, 2.25, 1.50, 26, 'active', 1),

-- عملات رقمية إضافية
('binance_pay', 'Binance Pay', 'باينانس باي', 'Binance Pay cryptocurrency', '{"merchant_id": "", "api_key": "", "secret_key": ""}', 'USDT,BUSD,BTC,ETH', 1.00, 100000.00, 0.50, 0.00, 27, 'active', 1),
('coinbase', 'Coinbase Commerce', 'كوين بيس', 'Coinbase cryptocurrency payments', '{"api_key": "", "webhook_secret": "", "charge_url": ""}', 'BTC,ETH,USDC,DAI', 5.00, 50000.00, 1.00, 0.00, 28, 'active', 1),
('crypto_com', 'Crypto.com Pay', 'كريبتو دوت كوم', 'Crypto.com payment gateway', '{"secret_key": "", "publishable_key": "", "webhook_url": ""}', 'CRO,USDT,BTC,ETH', 1.00, 25000.00, 0.40, 0.00, 29, 'active', 1);

-- إضافة طرق الدفع المفصلة للبوابات الجديدة
INSERT INTO `payment_methods` (`gateway_id`, `code`, `name`, `name_ar`, `type`, `description`, `supported_currencies`, `min_amount`, `max_amount`, `processing_time`, `fees_percentage`, `fees_fixed`, `sort_order`, `is_active`) VALUES
-- طرق دفع يمن موبايل
((SELECT id FROM payment_gateways WHERE code = 'ym_bank'), 'ym_transfer', 'Yemen Mobile Transfer', 'حوالة يمن موبايل', 'wallet', 'Transfer via Yemen Mobile banking', 'YER', 500.00, 1000000.00, '5-15 minutes', 1.50, 10.00, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'ym_bank'), 'ym_card', 'Yemen Mobile Card', 'بطاقة يمن موبايل', 'card', 'Yemen Mobile debit card', 'YER', 500.00, 500000.00, 'instant', 2.00, 10.00, 2, 1),

-- طرق دفع بنك الكريمي
((SELECT id FROM payment_gateways WHERE code = 'kuraimi_bank'), 'kuraimi_transfer', 'Kuraimi Bank Transfer', 'حوالة بنك الكريمي', 'bank', 'Bank transfer via Kuraimi Bank', 'YER', 500.00, 300000.00, '10-30 minutes', 1.75, 8.00, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'kuraimi_bank'), 'kuraimi_atm', 'Kuraimi ATM Card', 'بطاقة صراف الكريمي', 'card', 'Kuraimi Bank ATM card', 'YER', 500.00, 100000.00, 'instant', 2.25, 8.00, 2, 1),

-- طرق دفع STC Pay
((SELECT id FROM payment_gateways WHERE code = 'stc_pay'), 'stc_wallet', 'STC Pay Wallet', 'محفظة إس تي سي باي', 'wallet', 'STC Pay digital wallet', 'SAR', 5.00, 50000.00, 'instant', 2.50, 1.00, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'stc_pay'), 'stc_qr', 'STC Pay QR', 'كود إس تي سي باي', 'wallet', 'Pay via STC Pay QR code', 'SAR', 5.00, 10000.00, 'instant', 2.50, 1.00, 2, 1),

-- طرق دفع HyperPay
((SELECT id FROM payment_gateways WHERE code = 'hyperpay'), 'hyperpay_visa', 'HyperPay Visa', 'فيزا هايبر باي', 'card', 'Visa cards via HyperPay', 'SAR,AED,USD', 1.00, 999999.99, 'instant', 2.85, 1.50, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'hyperpay'), 'hyperpay_master', 'HyperPay Mastercard', 'ماستركارد هايبر باي', 'card', 'Mastercard via HyperPay', 'SAR,AED,USD', 1.00, 999999.99, 'instant', 2.85, 1.50, 2, 1),
((SELECT id FROM payment_gateways WHERE code = 'hyperpay'), 'hyperpay_mada', 'HyperPay Mada', 'مدى هايبر باي', 'card', 'Mada cards via HyperPay', 'SAR', 1.00, 50000.00, 'instant', 2.50, 1.50, 3, 1),

-- طرق دفع Moyasar
((SELECT id FROM payment_gateways WHERE code = 'moyasar'), 'moyasar_visa', 'Moyasar Visa', 'فيزا ميسر', 'card', 'Visa cards via Moyasar', 'SAR', 1.00, 200000.00, 'instant', 2.90, 1.00, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'moyasar'), 'moyasar_mada', 'Moyasar Mada', 'مدى ميسر', 'card', 'Mada cards via Moyasar', 'SAR', 1.00, 50000.00, 'instant', 2.50, 1.00, 2, 1),
((SELECT id FROM payment_gateways WHERE code = 'moyasar'), 'moyasar_applepay', 'Moyasar Apple Pay', 'آبل باي ميسر', 'wallet', 'Apple Pay via Moyasar', 'SAR', 1.00, 10000.00, 'instant', 2.90, 1.00, 3, 1),

-- طرق دفع N-Genius
((SELECT id FROM payment_gateways WHERE code = 'ngenius'), 'ngenius_card', 'N-Genius Card', 'بطاقة إن جينيوس', 'card', 'Credit/Debit cards via N-Genius', 'AED,USD', 1.00, 100000.00, 'instant', 2.80, 1.50, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'ngenius'), 'ngenius_applepay', 'N-Genius Apple Pay', 'آبل باي إن جينيوس', 'wallet', 'Apple Pay via N-Genius', 'AED,USD', 1.00, 5000.00, 'instant', 2.80, 1.50, 2, 1),

-- طرق دفع Tap Payments
((SELECT id FROM payment_gateways WHERE code = 'tap_payments'), 'tap_card', 'Tap Card Payment', 'دفع بطاقة تاب', 'card', 'Credit/Debit cards via Tap', 'KWD,SAR,AED,BHD', 0.50, 25000.00, 'instant', 2.75, 0.50, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'tap_payments'), 'tap_knet', 'Tap KNET', 'كي نت تاب', 'card', 'KNET payments via Tap', 'KWD', 0.50, 5000.00, 'instant', 2.00, 0.50, 2, 1),
((SELECT id FROM payment_gateways WHERE code = 'tap_payments'), 'tap_benefit', 'Tap Benefit', 'بنفت تاب', 'card', 'Benefit payments via Tap', 'BHD', 0.50, 3000.00, 'instant', 2.25, 0.50, 3, 1),

-- طرق دفع العملات الرقمية
((SELECT id FROM payment_gateways WHERE code = 'binance_pay'), 'binance_usdt', 'Binance USDT', 'تيثر باينانس', 'crypto', 'USDT payments via Binance Pay', 'USDT', 1.00, 100000.00, '5-10 minutes', 0.50, 0.00, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'binance_pay'), 'binance_busd', 'Binance BUSD', 'BUSD باينانس', 'crypto', 'BUSD payments via Binance Pay', 'BUSD', 1.00, 100000.00, '5-10 minutes', 0.50, 0.00, 2, 1),
((SELECT id FROM payment_gateways WHERE code = 'binance_pay'), 'binance_btc', 'Binance Bitcoin', 'بيتكوين باينانس', 'crypto', 'Bitcoin payments via Binance Pay', 'BTC', 10.00, 50000.00, '10-30 minutes', 0.75, 0.00, 3, 1),

((SELECT id FROM payment_gateways WHERE code = 'coinbase'), 'coinbase_btc', 'Coinbase Bitcoin', 'بيتكوين كوين بيس', 'crypto', 'Bitcoin via Coinbase Commerce', 'BTC', 5.00, 50000.00, '10-60 minutes', 1.00, 0.00, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'coinbase'), 'coinbase_eth', 'Coinbase Ethereum', 'إيثيريوم كوين بيس', 'crypto', 'Ethereum via Coinbase Commerce', 'ETH', 5.00, 50000.00, '5-30 minutes', 1.00, 0.00, 2, 1),
((SELECT id FROM payment_gateways WHERE code = 'coinbase'), 'coinbase_usdc', 'Coinbase USDC', 'USDC كوين بيس', 'crypto', 'USDC via Coinbase Commerce', 'USDC', 1.00, 50000.00, '5-15 minutes', 1.00, 0.00, 3, 1);

-- إضافة أسعار صرف جديدة للعملات المضافة
INSERT INTO `exchange_rates` (`from_currency`, `to_currency`, `rate`, `source`) VALUES
-- أسعار العملات الخليجية
('KWD', 'YER', 1237.50, 'manual'),
('YER', 'KWD', 0.000808, 'manual'),
('BHD', 'YER', 993.75, 'manual'),
('YER', 'BHD', 0.001006, 'manual'),
('QAR', 'YER', 102.74, 'manual'),
('YER', 'QAR', 0.009733, 'manual'),
('OMR', 'YER', 973.68, 'manual'),
('YER', 'OMR', 0.001027, 'manual'),

-- أسعار العملات الأفريقية
('EGP', 'YER', 12.10, 'manual'),
('YER', 'EGP', 0.0826, 'manual'),
('XOF', 'YER', 0.64, 'manual'),
('YER', 'XOF', 1.5625, 'manual'),
('XAF', 'YER', 0.64, 'manual'),
('YER', 'XAF', 1.5625, 'manual'),

-- أسعار العملات الرقمية (بالدولار)
('USDT', 'USD', 1.00, 'auto'),
('USD', 'USDT', 1.00, 'auto'),
('BUSD', 'USD', 1.00, 'auto'),
('USD', 'BUSD', 1.00, 'auto'),
('BTC', 'USD', 43500.00, 'auto'),
('USD', 'BTC', 0.000023, 'auto'),
('ETH', 'USD', 2650.00, 'auto'),
('USD', 'ETH', 0.000377, 'auto'),
('USDC', 'USD', 1.00, 'auto'),
('USD', 'USDC', 1.00, 'auto'),
('CRO', 'USD', 0.085, 'auto'),
('USD', 'CRO', 11.76, 'auto'),

-- تحويل العملات الرقمية إلى الريال اليمني
('USDT', 'YER', 375.00, 'auto'),
('YER', 'USDT', 0.00267, 'auto'),
('BTC', 'YER', 16312500.00, 'auto'),
('YER', 'BTC', 0.0000000613, 'auto'),
('ETH', 'YER', 993750.00, 'auto'),
('YER', 'ETH', 0.00000101, 'auto');

-- إنشاء جدول رسوم البوابات المفصلة
CREATE TABLE IF NOT EXISTS `gateway_fees_structure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gateway_id` int(11) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `amount_from` decimal(15,2) NOT NULL,
  `amount_to` decimal(15,2) NOT NULL,
  `fee_type` enum('percentage','fixed','hybrid') DEFAULT 'percentage',
  `fee_percentage` decimal(5,2) DEFAULT 0.00,
  `fee_fixed` decimal(10,2) DEFAULT 0.00,
  `fee_min` decimal(10,2) DEFAULT NULL,
  `fee_max` decimal(10,2) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_gateway_currency` (`gateway_id`,`currency`),
  KEY `idx_amount_range` (`amount_from`,`amount_to`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `fk_gateway_fees_structure` FOREIGN KEY (`gateway_id`) REFERENCES `payment_gateways` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج هيكل رسوم مفصل للبوابات الجديدة
INSERT INTO `gateway_fees_structure` (`gateway_id`, `currency`, `amount_from`, `amount_to`, `fee_type`, `fee_percentage`, `fee_fixed`, `fee_min`, `fee_max`) VALUES
-- رسوم يمن موبايل
((SELECT id FROM payment_gateways WHERE code = 'ym_bank'), 'YER', 500.00, 10000.00, 'hybrid', 1.50, 10.00, 10.00, 50.00),
((SELECT id FROM payment_gateways WHERE code = 'ym_bank'), 'YER', 10000.01, 100000.00, 'hybrid', 1.25, 15.00, 15.00, 200.00),
((SELECT id FROM payment_gateways WHERE code = 'ym_bank'), 'YER', 100000.01, 1000000.00, 'hybrid', 1.00, 25.00, 25.00, 500.00),

-- رسوم STC Pay
((SELECT id FROM payment_gateways WHERE code = 'stc_pay'), 'SAR', 5.00, 1000.00, 'hybrid', 2.50, 1.00, 1.00, 10.00),
((SELECT id FROM payment_gateways WHERE code = 'stc_pay'), 'SAR', 1000.01, 10000.00, 'hybrid', 2.25, 2.00, 2.00, 50.00),
((SELECT id FROM payment_gateways WHERE code = 'stc_pay'), 'SAR', 10000.01, 50000.00, 'hybrid', 2.00, 5.00, 5.00, 200.00),

-- رسوم HyperPay
((SELECT id FROM payment_gateways WHERE code = 'hyperpay'), 'SAR', 1.00, 5000.00, 'hybrid', 2.85, 1.50, 1.50, 25.00),
((SELECT id FROM payment_gateways WHERE code = 'hyperpay'), 'AED', 1.00, 5000.00, 'hybrid', 2.85, 1.50, 1.50, 25.00),
((SELECT id FROM payment_gateways WHERE code = 'hyperpay'), 'USD', 1.00, 1000.00, 'hybrid', 2.85, 0.50, 0.50, 15.00),

-- رسوم العملات الرقمية
((SELECT id FROM payment_gateways WHERE code = 'binance_pay'), 'USDT', 1.00, 10000.00, 'percentage', 0.50, 0.00, 0.00, 50.00),
((SELECT id FROM payment_gateways WHERE code = 'binance_pay'), 'BTC', 10.00, 50000.00, 'percentage', 0.75, 0.00, 0.00, 100.00),
((SELECT id FROM payment_gateways WHERE code = 'coinbase'), 'BTC', 5.00, 50000.00, 'percentage', 1.00, 0.00, 0.00, 100.00),
((SELECT id FROM payment_gateways WHERE code = 'coinbase'), 'ETH', 5.00, 50000.00, 'percentage', 1.00, 0.00, 0.00, 100.00);

-- إنشاء جدول حالة البوابات
CREATE TABLE IF NOT EXISTS `gateway_status_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gateway_id` int(11) NOT NULL,
  `status` enum('online','offline','maintenance','error') NOT NULL,
  `response_time` int(11) DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `checked_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_gateway_id` (`gateway_id`),
  KEY `idx_status` (`status`),
  KEY `idx_checked_at` (`checked_at`),
  CONSTRAINT `fk_gateway_status_log` FOREIGN KEY (`gateway_id`) REFERENCES `payment_gateways` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج حالات وهمية للبوابات
INSERT INTO `gateway_status_log` (`gateway_id`, `status`, `response_time`, `checked_at`) 
SELECT 
    pg.id,
    CASE 
        WHEN RAND() > 0.1 THEN 'online'
        WHEN RAND() > 0.05 THEN 'maintenance'
        ELSE 'offline'
    END,
    FLOOR(RAND() * 2000) + 100,
    NOW() - INTERVAL FLOOR(RAND() * 60) MINUTE
FROM payment_gateways pg
WHERE pg.id > (SELECT COALESCE(MAX(id), 0) FROM payment_gateways WHERE code IN ('paypal', 'stripe', 'mada'));

-- إنشاء جدول حدود المعاملات حسب البلد
CREATE TABLE IF NOT EXISTS `country_payment_limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) NOT NULL,
  `country_name` varchar(100) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `daily_limit` decimal(15,2) DEFAULT NULL,
  `monthly_limit` decimal(15,2) DEFAULT NULL,
  `transaction_limit` decimal(15,2) DEFAULT NULL,
  `allowed_gateways` text DEFAULT NULL,
  `restricted_gateways` text DEFAULT NULL,
  `kyc_required_above` decimal(15,2) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `country_currency` (`country_code`,`currency`),
  KEY `idx_country_code` (`country_code`),
  KEY `idx_currency` (`currency`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج حدود الدول العربية
INSERT INTO `country_payment_limits` (`country_code`, `country_name`, `currency`, `daily_limit`, `monthly_limit`, `transaction_limit`, `allowed_gateways`, `kyc_required_above`, `is_active`) VALUES
('YE', 'اليمن', 'YER', 500000.00, 5000000.00, 100000.00, 'ym_bank,cac_bank,kuraimi_bank,tadhamon_bank,sabafon_cash,y_cash,yemen_mobile', 50000.00, 1),
('SA', 'السعودية', 'SAR', 50000.00, 500000.00, 25000.00, 'stc_pay,urpay,hyperpay,moyasar,mada,paypal,stripe', 10000.00, 1),
('AE', 'الإمارات', 'AED', 50000.00, 500000.00, 25000.00, 'network_intl,ngenius,cbd_now,hyperpay,paypal,stripe', 10000.00, 1),
('KW', 'الكويت', 'KWD', 5000.00, 50000.00, 2500.00, 'tap_payments,paypal,stripe', 1000.00, 1),
('BH', 'البحرين', 'BHD', 5000.00, 50000.00, 2500.00, 'tap_payments,paypal,stripe', 1000.00, 1),
('QA', 'قطر', 'QAR', 50000.00, 500000.00, 25000.00, 'paypal,stripe,hyperpay', 10000.00, 1),
('OM', 'عمان', 'OMR', 5000.00, 50000.00, 2500.00, 'paypal,stripe,hyperpay', 1000.00, 1),
('EG', 'مصر', 'EGP', 100000.00, 1000000.00, 50000.00, 'paymob,fawry,vodafone_cash,paypal,stripe', 20000.00, 1);

-- إنشاء إجراءات مخزنة للبوابات الجديدة
DELIMITER $$

CREATE PROCEDURE `GetAvailableGateways`(
    IN p_country_code VARCHAR(2),
    IN p_currency VARCHAR(3),
    IN p_amount DECIMAL(15,2)
)
BEGIN
    SELECT 
        pg.id,
        pg.code,
        pg.name,
        pg.name_ar,
        pg.logo,
        pg.min_amount,
        pg.max_amount,
        pg.fees_percentage,
        pg.fees_fixed,
        pg.status,
        pm.code as method_code,
        pm.name as method_name,
        pm.name_ar as method_name_ar,
        pm.type as method_type,
        pm.processing_time,
        CASE 
            WHEN gfs.fee_type = 'percentage' THEN (p_amount * gfs.fee_percentage / 100)
            WHEN gfs.fee_type = 'fixed' THEN gfs.fee_fixed
            WHEN gfs.fee_type = 'hybrid' THEN (p_amount * gfs.fee_percentage / 100) + gfs.fee_fixed
            ELSE (p_amount * pg.fees_percentage / 100) + pg.fees_fixed
        END as calculated_fee
    FROM payment_gateways pg
    JOIN payment_methods pm ON pg.id = pm.gateway_id
    LEFT JOIN gateway_fees_structure gfs ON pg.id = gfs.gateway_id 
        AND gfs.currency = p_currency 
        AND p_amount BETWEEN gfs.amount_from AND gfs.amount_to
        AND gfs.is_active = 1
    LEFT JOIN country_payment_limits cpl ON cpl.country_code = p_country_code 
        AND cpl.currency = p_currency
    WHERE pg.status = 'active'
    AND pm.is_active = 1
    AND FIND_IN_SET(p_currency, pg.supported_currencies) > 0
    AND p_amount BETWEEN pg.min_amount AND pg.max_amount
    AND (cpl.id IS NULL OR FIND_IN_SET(pg.code, cpl.allowed_gateways) > 0)
    AND (cpl.id IS NULL OR FIND_IN_SET(pg.code, COALESCE(cpl.restricted_gateways, '')) = 0)
    AND (cpl.transaction_limit IS NULL OR p_amount <= cpl.transaction_limit)
    ORDER BY pg.sort_order ASC, calculated_fee ASC;
END$$

CREATE PROCEDURE `CalculateGatewayFee`(
    IN p_gateway_id INT,
    IN p_currency VARCHAR(3),
    IN p_amount DECIMAL(15,2),
    OUT p_fee DECIMAL(10,2)
)
BEGIN
    DECLARE v_fee_type VARCHAR(20);
    DECLARE v_fee_percentage DECIMAL(5,2);
    DECLARE v_fee_fixed DECIMAL(10,2);
    DECLARE v_fee_min DECIMAL(10,2);
    DECLARE v_fee_max DECIMAL(10,2);
    DECLARE v_calculated_fee DECIMAL(10,2);
    
    -- Get fee structure
    SELECT fee_type, fee_percentage, fee_fixed, fee_min, fee_max
    INTO v_fee_type, v_fee_percentage, v_fee_fixed, v_fee_min, v_fee_max
    FROM gateway_fees_structure
    WHERE gateway_id = p_gateway_id
    AND currency = p_currency
    AND p_amount BETWEEN amount_from AND amount_to
    AND is_active = 1
    LIMIT 1;
    
    -- If no specific fee structure found, use gateway default
    IF v_fee_type IS NULL THEN
        SELECT fees_percentage, fees_fixed
        INTO v_fee_percentage, v_fee_fixed
        FROM payment_gateways
        WHERE id = p_gateway_id;
        SET v_fee_type = 'hybrid';
    END IF;
    
    -- Calculate fee based on type
    CASE v_fee_type
        WHEN 'percentage' THEN
            SET v_calculated_fee = p_amount * v_fee_percentage / 100;
        WHEN 'fixed' THEN
            SET v_calculated_fee = v_fee_fixed;
        WHEN 'hybrid' THEN
            SET v_calculated_fee = (p_amount * v_fee_percentage / 100) + v_fee_fixed;
    END CASE;
    
    -- Apply min/max limits
    IF v_fee_min IS NOT NULL AND v_calculated_fee < v_fee_min THEN
        SET v_calculated_fee = v_fee_min;
    END IF;
    
    IF v_fee_max IS NOT NULL AND v_calculated_fee > v_fee_max THEN
        SET v_calculated_fee = v_fee_max;
    END IF;
    
    SET p_fee = v_calculated_fee;
END$$

CREATE PROCEDURE `CheckGatewayStatus`(IN p_gateway_id INT)
BEGIN
    DECLARE v_status VARCHAR(20);
    DECLARE v_last_check TIMESTAMP;
    DECLARE v_response_time INT;
    
    -- Get latest status
    SELECT status, checked_at, response_time
    INTO v_status, v_last_check, v_response_time
    FROM gateway_status_log
    WHERE gateway_id = p_gateway_id
    ORDER BY checked_at DESC
    LIMIT 1;
    
    SELECT 
        pg.code,
        pg.name_ar,
        COALESCE(v_status, 'unknown') as current_status,
        v_last_check as last_checked,
        v_response_time as response_time_ms,
        CASE 
            WHEN v_last_check IS NULL THEN 'never_checked'
            WHEN v_last_check < DATE_SUB(NOW(), INTERVAL 5 MINUTE) THEN 'outdated'
            WHEN v_status = 'online' THEN 'operational'
            WHEN v_status = 'maintenance' THEN 'maintenance'
            ELSE 'unavailable'
        END as health_status
    FROM payment_gateways pg
    WHERE pg.id = p_gateway_id;
END$$

DELIMITER ;

-- إنشاء Event لفحص حالة البوابات
DELIMITER $$

CREATE EVENT `check_gateway_status`
ON SCHEDULE EVERY 5 MINUTE
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE gateway_id INT;
    DECLARE gateway_cursor CURSOR FOR 
        SELECT id FROM payment_gateways WHERE status = 'active';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN gateway_cursor;
    
    gateway_loop: LOOP
        FETCH gateway_cursor INTO gateway_id;
        IF done THEN
            LEAVE gateway_loop;
        END IF;
        
        -- Simulate gateway status check (in real implementation, this would make actual API calls)
        INSERT INTO gateway_status_log (gateway_id, status, response_time)
        VALUES (
            gateway_id,
            CASE 
                WHEN RAND() > 0.05 THEN 'online'
                WHEN RAND() > 0.02 THEN 'maintenance'
                ELSE 'offline'
            END,
            FLOOR(RAND() * 3000) + 100
        );
    END LOOP;
    
    CLOSE gateway_cursor;
    
    -- Clean old status logs (keep only last 24 hours)
    DELETE FROM gateway_status_log 
    WHERE checked_at < DATE_SUB(NOW(), INTERVAL 24 HOUR);
END$$

DELIMITER ;

-- تحديث إعدادات البوابات الجديدة
INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_type`, `description`, `group_name`) VALUES
('enable_crypto_payments', '1', 'boolean', 'تفعيل مدفوعات العملات الرقمية', 'payment'),
('crypto_confirmation_blocks', '3', 'number', 'عدد التأكيدات المطلوبة للعملات الرقمية', 'payment'),
('gateway_health_check_interval', '5', 'number', 'فترة فحص حالة البوابات (دقائق)', 'payment'),
('auto_disable_failed_gateways', '1', 'boolean', 'تعطيل البوابات الفاشلة تلقائياً', 'payment'),
('gateway_failure_threshold', '5', 'number', 'عدد الفشل المسموح قبل التعطيل', 'payment'),
('enable_dynamic_fees', '1', 'boolean', 'تفعيل الرسوم الديناميكية', 'payment'),
('fee_calculation_method', 'lowest', 'string', 'طريقة حساب الرسوم (lowest/fastest/balanced)', 'payment')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- إنشاء فهارس إضافية لتحسين الأداء
CREATE INDEX idx_gateway_fees_amount_range ON gateway_fees_structure(gateway_id, currency, amount_from, amount_to);
CREATE INDEX idx_gateway_status_latest ON gateway_status_log(gateway_id, checked_at DESC);
CREATE INDEX idx_country_limits_active ON country_payment_limits(country_code, is_active);
CREATE INDEX idx_payment_methods_gateway_active ON payment_methods(gateway_id, is_active);

-- إنشاء View لملخص البوابات
CREATE VIEW `gateway_summary` AS
SELECT 
    pg.id,
    pg.code,
    pg.name_ar,
    pg.status,
    pg.supported_currencies,
    COUNT(pm.id) as payment_methods_count,
    (SELECT status FROM gateway_status_log gsl 
     WHERE gsl.gateway_id = pg.id 
     ORDER BY checked_at DESC LIMIT 1) as current_status,
    (SELECT COUNT(*) FROM payment_transactions pt 
     WHERE pt.gateway_id = pg.id 
     AND DATE(pt.created_at) = CURDATE()) as today_transactions,
    (SELECT SUM(amount) FROM payment_transactions pt 
     WHERE pt.gateway_id = pg.id 
     AND pt.status = 'completed' 
     AND DATE(pt.created_at) = CURDATE()) as today_volume
FROM payment_gateways pg
LEFT JOIN payment_methods pm ON pg.id = pm.gateway_id AND pm.is_active = 1
GROUP BY pg.id;

SELECT 'New payment gateways added successfully!' as message;
SELECT COUNT(*) as total_gateways FROM payment_gateways;
SELECT COUNT(*) as total_payment_methods FROM payment_methods;
SELECT COUNT(*) as total_exchange_rates FROM exchange_rates;
SELECT COUNT(*) as active_gateways FROM payment_gateways WHERE status = 'active';
