-- إضافة جداول الدفع المتقدمة
-- Advanced Payment Tables

-- جدول بوابات الدفع المحلية
INSERT INTO `payment_gateways` (`code`, `name`, `name_ar`, `description`, `config`, `supported_currencies`, `min_amount`, `max_amount`, `fees_percentage`, `fees_fixed`, `sort_order`, `status`, `test_mode`) VALUES
('paypal', 'PayPal', 'باي بال', 'PayPal payment gateway for international transactions', '{"client_id": "", "client_secret": "", "sandbox": true}', 'USD,EUR,SAR', 1.00, 10000.00, 3.49, 0.49, 1, 'active', 1),
('stripe', 'Stripe', 'سترايب', 'Stripe payment processing for cards', '{"publishable_key": "", "secret_key": "", "webhook_secret": ""}', 'USD,EUR,SAR,AED', 0.50, 999999.99, 2.90, 0.30, 2, 'active', 1),
('mada', 'Mada', 'مدى', 'Saudi Mada payment system', '{"merchant_id": "", "terminal_id": "", "secret_key": ""}', 'SAR', 1.00, 50000.00, 1.75, 0.00, 3, 'active', 1),
('yemen_mobile', 'Yemen Mobile Money', 'المحفظة الإلكترونية اليمنية', 'Yemen mobile money services', '{"merchant_code": "", "api_key": "", "callback_url": ""}', 'YER', 100.00, 500000.00, 2.00, 5.00, 4, 'active', 1),
('sabafon_cash', 'Sabafon Cash', 'سبافون كاش', 'Sabafon mobile wallet service', '{"merchant_id": "", "api_secret": "", "service_code": ""}', 'YER', 50.00, 200000.00, 1.50, 2.00, 5, 'active', 1),
('y_cash', 'Y Cash', 'واي كاش', 'Y Telecom mobile wallet', '{"partner_id": "", "api_token": "", "encryption_key": ""}', 'YER', 100.00, 300000.00, 2.25, 3.00, 6, 'active', 1),
('bank_transfer', 'Bank Transfer', 'حوالة بنكية', 'Direct bank transfer', '{"bank_accounts": []}', 'YER,SAR,USD', 1000.00, 1000000.00, 0.00, 0.00, 7, 'active', 0),
('crypto_usdt', 'USDT (TRC20)', 'تيثر', 'USDT cryptocurrency payments', '{"wallet_address": "", "network": "TRC20", "api_key": ""}', 'USDT', 10.00, 50000.00, 1.00, 0.00, 8, 'active', 1);

-- جدول طرق الدفع المفصلة
CREATE TABLE IF NOT EXISTS `payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gateway_id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `type` enum('card','wallet','bank','crypto','cash') DEFAULT 'card',
  `icon` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `config` text DEFAULT NULL,
  `supported_currencies` varchar(255) DEFAULT 'YER',
  `min_amount` decimal(10,2) DEFAULT 0.00,
  `max_amount` decimal(10,2) DEFAULT 0.00,
  `processing_time` varchar(50) DEFAULT 'instant',
  `fees_percentage` decimal(5,2) DEFAULT 0.00,
  `fees_fixed` decimal(10,2) DEFAULT 0.00,
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gateway_code` (`gateway_id`,`code`),
  KEY `idx_type` (`type`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `fk_payment_methods_gateway` FOREIGN KEY (`gateway_id`) REFERENCES `payment_gateways` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج طرق الدفع
INSERT INTO `payment_methods` (`gateway_id`, `code`, `name`, `name_ar`, `type`, `description`, `supported_currencies`, `min_amount`, `max_amount`, `processing_time`, `fees_percentage`, `fees_fixed`, `sort_order`, `is_active`) VALUES
((SELECT id FROM payment_gateways WHERE code = 'paypal'), 'paypal_account', 'PayPal Account', 'حساب باي بال', 'wallet', 'Pay with your PayPal account', 'USD,EUR,SAR', 1.00, 10000.00, 'instant', 3.49, 0.49, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'stripe'), 'visa', 'Visa Card', 'بطاقة فيزا', 'card', 'Pay with Visa credit/debit card', 'USD,EUR,SAR,AED', 0.50, 999999.99, 'instant', 2.90, 0.30, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'stripe'), 'mastercard', 'Mastercard', 'ماستركارد', 'card', 'Pay with Mastercard credit/debit card', 'USD,EUR,SAR,AED', 0.50, 999999.99, 'instant', 2.90, 0.30, 2, 1),
((SELECT id FROM payment_gateways WHERE code = 'mada'), 'mada_card', 'Mada Card', 'بطاقة مدى', 'card', 'Saudi Mada debit card', 'SAR', 1.00, 50000.00, 'instant', 1.75, 0.00, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'yemen_mobile'), 'ym_wallet', 'Yemen Mobile Wallet', 'محفظة يمن موبايل', 'wallet', 'Yemen Mobile electronic wallet', 'YER', 100.00, 500000.00, '5-10 minutes', 2.00, 5.00, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'sabafon_cash'), 'sabafon_wallet', 'Sabafon Cash Wallet', 'محفظة سبافون كاش', 'wallet', 'Sabafon mobile money service', 'YER', 50.00, 200000.00, '2-5 minutes', 1.50, 2.00, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'y_cash'), 'y_wallet', 'Y Cash Wallet', 'محفظة واي كاش', 'wallet', 'Y Telecom mobile wallet', 'YER', 100.00, 300000.00, '3-7 minutes', 2.25, 3.00, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'bank_transfer'), 'local_bank', 'Local Bank Transfer', 'حوالة بنكية محلية', 'bank', 'Transfer to local bank account', 'YER,SAR', 1000.00, 1000000.00, '1-3 hours', 0.00, 0.00, 1, 1),
((SELECT id FROM payment_gateways WHERE code = 'crypto_usdt'), 'usdt_trc20', 'USDT TRC20', 'تيثر TRC20', 'crypto', 'USDT on TRON network', 'USDT', 10.00, 50000.00, '10-30 minutes', 1.00, 0.00, 1, 1);

-- جدول حالات المعاملات المفصلة
CREATE TABLE IF NOT EXISTS `transaction_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  `created_by` enum('system','admin','gateway','user') DEFAULT 'system',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_transaction_statuses` FOREIGN KEY (`transaction_id`) REFERENCES `payment_transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول رسوم الدفع المفصلة
CREATE TABLE IF NOT EXISTS `payment_fees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `fee_type` enum('gateway','processing','currency','service') NOT NULL,
  `fee_name` varchar(100) NOT NULL,
  `fee_amount` decimal(10,2) NOT NULL,
  `fee_currency` varchar(3) NOT NULL,
  `fee_percentage` decimal(5,2) DEFAULT NULL,
  `calculated_from` decimal(10,2) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_fee_type` (`fee_type`),
  CONSTRAINT `fk_payment_fees` FOREIGN KEY (`transaction_id`) REFERENCES `payment_transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول عمليات الاسترداد
CREATE TABLE IF NOT EXISTS `refunds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `refund_amount` decimal(10,2) NOT NULL,
  `refund_currency` varchar(3) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `refund_type` enum('full','partial','fee_only') DEFAULT 'full',
  `status` enum('pending','processing','completed','failed','cancelled') DEFAULT 'pending',
  `gateway_refund_id` varchar(100) DEFAULT NULL,
  `gateway_response` text DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_transaction_id` (`transaction_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_refunds_transaction` FOREIGN KEY (`transaction_id`) REFERENCES `payment_transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_refunds_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_refunds_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول المحافظ المتعددة العملات
CREATE TABLE IF NOT EXISTS `user_wallets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `balance` decimal(15,2) DEFAULT 0.00,
  `frozen_balance` decimal(15,2) DEFAULT 0.00,
  `total_deposits` decimal(15,2) DEFAULT 0.00,
  `total_withdrawals` decimal(15,2) DEFAULT 0.00,
  `total_spent` decimal(15,2) DEFAULT 0.00,
  `last_transaction_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_currency` (`user_id`,`currency`),
  KEY `idx_currency` (`currency`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `fk_user_wallets` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء محافظ افتراضية للمستخدمين الحاليين
INSERT INTO `user_wallets` (`user_id`, `currency`, `balance`, `total_deposits`, `total_withdrawals`, `total_spent`)
SELECT 
    id,
    'YER',
    wallet_balance_yer,
    0.00,
    0.00,
    0.00
FROM users
WHERE id NOT IN (SELECT user_id FROM user_wallets WHERE currency = 'YER');

INSERT INTO `user_wallets` (`user_id`, `currency`, `balance`, `total_deposits`, `total_withdrawals`, `total_spent`)
SELECT 
    id,
    'SAR',
    wallet_balance_sar,
    0.00,
    0.00,
    0.00
FROM users
WHERE id NOT IN (SELECT user_id FROM user_wallets WHERE currency = 'SAR');

INSERT INTO `user_wallets` (`user_id`, `currency`, `balance`, `total_deposits`, `total_withdrawals`, `total_spent`)
SELECT 
    id,
    'USD',
    wallet_balance_usd,
    0.00,
    0.00,
    0.00
FROM users
WHERE id NOT IN (SELECT user_id FROM user_wallets WHERE currency = 'USD');

INSERT INTO `user_wallets` (`user_id`, `currency`, `balance`, `total_deposits`, `total_withdrawals`, `total_spent`)
SELECT 
    id,
    'AED',
    wallet_balance_aed,
    0.00,
    0.00,
    0.00
FROM users
WHERE id NOT IN (SELECT user_id FROM user_wallets WHERE currency = 'AED');

-- جدول قيود المحفظة
CREATE TABLE IF NOT EXISTS `wallet_limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `currency` varchar(3) NOT NULL,
  `limit_type` enum('daily','weekly','monthly','transaction','balance') NOT NULL,
  `limit_amount` decimal(15,2) NOT NULL,
  `current_usage` decimal(15,2) DEFAULT 0.00,
  `reset_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_currency` (`currency`),
  KEY `idx_limit_type` (`limit_type`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `fk_wallet_limits` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج حدود افتراضية للمحافظ
INSERT INTO `wallet_limits` (`user_id`, `currency`, `limit_type`, `limit_amount`) 
SELECT 
    NULL,
    'YER',
    'daily',
    100000.00
UNION ALL
SELECT 
    NULL,
    'YER',
    'monthly',
    1000000.00
UNION ALL
SELECT 
    NULL,
    'SAR',
    'daily',
    1000.00
UNION ALL
SELECT 
    NULL,
    'SAR',
    'monthly',
    10000.00
UNION ALL
SELECT 
    NULL,
    'USD',
    'daily',
    267.00
UNION ALL
SELECT 
    NULL,
    'USD',
    'monthly',
    2670.00;

-- جدول تقارير المعاملات
CREATE TABLE IF NOT EXISTS `payment_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_date` date NOT NULL,
  `gateway_id` int(11) DEFAULT NULL,
  `currency` varchar(3) NOT NULL,
  `total_transactions` int(11) DEFAULT 0,
  `successful_transactions` int(11) DEFAULT 0,
  `failed_transactions` int(11) DEFAULT 0,
  `total_amount` decimal(15,2) DEFAULT 0.00,
  `total_fees` decimal(15,2) DEFAULT 0.00,
  `net_amount` decimal(15,2) DEFAULT 0.00,
  `refunded_amount` decimal(15,2) DEFAULT 0.00,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `report_gateway_currency_date` (`report_date`,`gateway_id`,`currency`),
  KEY `idx_report_date` (`report_date`),
  KEY `idx_gateway_id` (`gateway_id`),
  KEY `idx_currency` (`currency`),
  CONSTRAINT `fk_payment_reports_gateway` FOREIGN KEY (`gateway_id`) REFERENCES `payment_gateways` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء Triggers محدثة للمحافظ الجديدة
DELIMITER $$

DROP TRIGGER IF EXISTS `update_wallet_balance`$$

CREATE TRIGGER `update_user_wallet_balance` AFTER INSERT ON `wallet_transactions`
FOR EACH ROW
BEGIN
    -- تحديث المحفظة الجديدة
    INSERT INTO user_wallets (user_id, currency, balance, last_transaction_at)
    VALUES (NEW.user_id, NEW.currency, NEW.balance_after, NOW())
    ON DUPLICATE KEY UPDATE 
        balance = NEW.balance_after,
        total_deposits = CASE WHEN NEW.type = 'deposit' THEN total_deposits + NEW.amount ELSE total_deposits END,
        total_withdrawals = CASE WHEN NEW.type = 'withdrawal' THEN total_withdrawals + NEW.amount ELSE total_withdrawals END,
        total_spent = CASE WHEN NEW.type = 'purchase' THEN total_spent + NEW.amount ELSE total_spent END,
        last_transaction_at = NOW();
    
    -- تحديث المحفظة القديمة للتوافق
    CASE NEW.currency
        WHEN 'YER' THEN
            UPDATE users SET wallet_balance_yer = NEW.balance_after WHERE id = NEW.user_id;
        WHEN 'SAR' THEN
            UPDATE users SET wallet_balance_sar = NEW.balance_after WHERE id = NEW.user_id;
        WHEN 'USD' THEN
            UPDATE users SET wallet_balance_usd = NEW.balance_after WHERE id = NEW.user_id;
        WHEN 'AED' THEN
            UPDATE users SET wallet_balance_aed = NEW.balance_after WHERE id = NEW.user_id;
    END CASE;
END$$

CREATE TRIGGER `update_payment_reports` AFTER INSERT ON `payment_transactions`
FOR EACH ROW
BEGIN
    INSERT INTO payment_reports (report_date, gateway_id, currency, total_transactions, successful_transactions, failed_transactions, total_amount, total_fees, net_amount)
    VALUES (DATE(NEW.created_at), NEW.gateway_id, NEW.currency, 1, 
            CASE WHEN NEW.status = 'completed' THEN 1 ELSE 0 END,
            CASE WHEN NEW.status = 'failed' THEN 1 ELSE 0 END,
            CASE WHEN NEW.status = 'completed' THEN NEW.amount ELSE 0 END,
            CASE WHEN NEW.status = 'completed' THEN NEW.fees ELSE 0 END,
            CASE WHEN NEW.status = 'completed' THEN (NEW.amount - NEW.fees) ELSE 0 END)
    ON DUPLICATE KEY UPDATE
        total_transactions = total_transactions + 1,
        successful_transactions = successful_transactions + CASE WHEN NEW.status = 'completed' THEN 1 ELSE 0 END,
        failed_transactions = failed_transactions + CASE WHEN NEW.status = 'failed' THEN 1 ELSE 0 END,
        total_amount = total_amount + CASE WHEN NEW.status = 'completed' THEN NEW.amount ELSE 0 END,
        total_fees = total_fees + CASE WHEN NEW.status = 'completed' THEN NEW.fees ELSE 0 END,
        net_amount = net_amount + CASE WHEN NEW.status = 'completed' THEN (NEW.amount - NEW.fees) ELSE 0 END,
        updated_at = NOW();
END$$

DELIMITER ;

-- إنشاء Views مفيدة للتقارير
CREATE VIEW `payment_summary` AS
SELECT 
    pg.name_ar as gateway_name,
    pt.currency,
    COUNT(*) as total_transactions,
    SUM(CASE WHEN pt.status = 'completed' THEN 1 ELSE 0 END) as successful_transactions,
    SUM(CASE WHEN pt.status = 'failed' THEN 1 ELSE 0 END) as failed_transactions,
    SUM(CASE WHEN pt.status = 'completed' THEN pt.amount ELSE 0 END) as total_amount,
    SUM(CASE WHEN pt.status = 'completed' THEN pt.fees ELSE 0 END) as total_fees,
    AVG(CASE WHEN pt.status = 'completed' THEN pt.amount ELSE NULL END) as avg_transaction_amount
FROM payment_transactions pt
JOIN payment_gateways pg ON pt.gateway_id = pg.id
WHERE pt.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY pg.id, pt.currency;

CREATE VIEW `user_wallet_summary` AS
SELECT 
    u.id,
    u.username,
    u.email,
    GROUP_CONCAT(CONCAT(uw.currency, ': ', FORMAT(uw.balance, 2)) SEPARATOR ', ') as balances,
    SUM(uw.total_deposits) as total_deposits,
    SUM(uw.total_withdrawals) as total_withdrawals,
    SUM(uw.total_spent) as total_spent,
    MAX(uw.last_transaction_at) as last_transaction_at
FROM users u
LEFT JOIN user_wallets uw ON u.id = uw.user_id
GROUP BY u.id;

-- إنشاء فهارس إضافية لتحسين الأداء
CREATE INDEX idx_payment_transactions_gateway_status ON payment_transactions(gateway_id, status);
CREATE INDEX idx_payment_transactions_currency_date ON payment_transactions(currency, created_at);
CREATE INDEX idx_wallet_transactions_user_currency ON wallet_transactions(user_id, currency);
CREATE INDEX idx_user_wallets_currency_balance ON user_wallets(currency, balance);

-- إضافة إعدادات الدفع الجديدة
INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_type`, `description`, `group_name`) VALUES
('enable_wallet_system', '1', 'boolean', 'تفعيل نظام المحافظ المتعددة', 'payment'),
('auto_currency_conversion', '1', 'boolean', 'تحويل العملات تلقائياً', 'payment'),
('wallet_transaction_fee', '0.5', 'number', 'رسوم معاملات المحفظة (%)', 'payment'),
('min_wallet_balance', '10', 'number', 'الحد الأدنى لرصيد المحفظة', 'payment'),
('max_daily_wallet_limit', '100000', 'number', 'الحد الأقصى اليومي للمحفظة', 'payment'),
('payment_verification_required', '1', 'boolean', 'مطلوب التحقق من الدفعات الكبيرة', 'security'),
('large_payment_threshold', '10000', 'number', 'حد الدفعات الكبيرة', 'security');

SELECT 'Advanced payment tables created successfully!' as message;
