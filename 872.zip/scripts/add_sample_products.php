#!/usr/bin/env php
<?php
/**
 * إضافة منتجات تجريبية للنظام
 */

require_once dirname(__DIR__) . '/config/config.php';

class SampleProductsGenerator {
    private $pdo;
    
    public function __construct() {
        $this->pdo = Database::getInstance()->getConnection();
        
        echo "🛍️ بدء إضافة المنتجات التجريبية...\n\n";
        $this->addSampleProducts();
    }
    
    private function addSampleProducts() {
        // التأكد من وجود الفئات
        $this->ensureCategories();
        
        // إضافة منتجات الألعاب
        $this->addGameProducts();
        
        // إضافة منتجات التطبيقات
        $this->addAppProducts();
        
        // إضافة بطاقات الهدايا
        $this->addGiftCards();
        
        echo "\n✅ تم إضافة جميع المنتجات التجريبية بنجاح!\n";
        $this->showProductStats();
    }
    
    private function ensureCategories() {
        $categories = [
            ['name' => 'ألعاب الهاتف', 'description' => 'شحن ألعاب الهاتف المحمول', 'icon' => 'fas fa-mobile-alt'],
            ['name' => 'تطبيقات التواصل', 'description' => 'شحن تطبيقات التواصل الاجتماعي', 'icon' => 'fas fa-comments'],
            ['name' => 'بطاقات الهدايا', 'description' => 'بطاقات هدايا رقمية', 'icon' => 'fas fa-gift'],
            ['name' => 'خدمات رقمية', 'description' => 'خدمات رقمية متنوعة', 'icon' => 'fas fa-cloud']
        ];
        
        foreach ($categories as $category) {
            $stmt = $this->pdo->prepare("SELECT id FROM categories WHERE name = ?");
            $stmt->execute([$category['name']]);
            
            if (!$stmt->fetch()) {
                $stmt = $this->pdo->prepare("
                    INSERT INTO categories (name, description, icon, status) 
                    VALUES (?, ?, ?, 'active')
                ");
                $stmt->execute([$category['name'], $category['description'], $category['icon']]);
                echo "✅ تم إنشاء فئة: {$category['name']}\n";
            }
        }
    }
    
    private function addGameProducts() {
        echo "🎮 إضافة منتجات الألعاب...\n";
        
        $category_id = $this->getCategoryId('ألعاب الهاتف');
        
        $games = [
            [
                'name' => 'PUBG Mobile - 60 UC',
                'name_en' => 'PUBG Mobile - 60 UC',
                'description' => 'شحن 60 UC لعبة ببجي موبايل',
                'price_yer' => 500,
                'price_sar' => 2,
                'price_usd' => 1.34,
                'price_aed' => 4.9,
                'customer_id_label' => 'Player ID',
                'customer_id_placeholder' => 'أدخل Player ID الخاص بك',
                'instructions' => 'ستحصل على UC خلال 5-10 دقائق',
                'delivery_time' => '5-10 دقائق',
                'is_featured' => true
            ],
            [
                'name' => 'PUBG Mobile - 325 UC',
                'name_en' => 'PUBG Mobile - 325 UC',
                'description' => 'شحن 325 UC لعبة ببجي موبايل',
                'price_yer' => 2500,
                'price_sar' => 10,
                'price_usd' => 6.68,
                'price_aed' => 24.5,
                'customer_id_label' => 'Player ID',
                'customer_id_placeholder' => 'أدخل Player ID الخاص بك',
                'instructions' => 'ستحصل على UC خلال 5-10 دقائق',
                'delivery_time' => '5-10 دقائق',
                'is_featured' => true
            ],
            [
                'name' => 'Free Fire - 100 Diamonds',
                'name_en' => 'Free Fire - 100 Diamonds',
                'description' => 'شحن 100 ماسة لعبة فري فاير',
                'price_yer' => 400,
                'price_sar' => 1.6,
                'price_usd' => 1.07,
                'price_aed' => 3.92,
                'customer_id_label' => 'Player ID',
                'customer_id_placeholder' => 'أدخل Player ID الخاص بك',
                'instructions' => 'ستحصل على الماس خلال 5-10 دقائق',
                'delivery_time' => '5-10 دقائق',
                'is_featured' => true
            ],
            [
                'name' => 'Free Fire - 520 Diamonds',
                'name_en' => 'Free Fire - 520 Diamonds',
                'description' => 'شحن 520 ماسة لعبة فري فاير',
                'price_yer' => 2000,
                'price_sar' => 8,
                'price_usd' => 5.34,
                'price_aed' => 19.6,
                'customer_id_label' => 'Player ID',
                'customer_id_placeholder' => 'أدخل Player ID الخاص بك',
                'instructions' => 'ستحصل على الماس خلال 5-10 دقائق',
                'delivery_time' => '5-10 دقائق',
                'is_featured' => false
            ],
            [
                'name' => 'Mobile Legends - 86 Diamonds',
                'name_en' => 'Mobile Legends - 86 Diamonds',
                'description' => 'شحن 86 ماسة لعبة موبايل ليجندز',
                'price_yer' => 450,
                'price_sar' => 1.8,
                'price_usd' => 1.2,
                'price_aed' => 4.41,
                'customer_id_label' => 'User ID',
                'customer_id_placeholder' => 'أدخل User ID الخاص بك',
                'instructions' => 'ستحصل على الماس خلال 5-10 دقائق',
                'delivery_time' => '5-10 دقائق',
                'is_featured' => false
            ]
        ];
        
        foreach ($games as $game) {
            $this->insertProduct($category_id, $game);
        }
    }
    
    private function addAppProducts() {
        echo "📱 إضافة منتجات التطبيقات...\n";
        
        $category_id = $this->getCategoryId('تطبيقات التواصل');
        
        $apps = [
            [
                'name' => 'TikTok - 100 Coins',
                'name_en' => 'TikTok - 100 Coins',
                'description' => 'شحن 100 عملة تيك توك',
                'price_yer' => 300,
                'price_sar' => 1.2,
                'price_usd' => 0.8,
                'price_aed' => 2.94,
                'customer_id_label' => 'TikTok ID',
                'customer_id_placeholder' => 'أدخل TikTok ID الخاص بك',
                'instructions' => 'ستحصل على العملات خلال 10-15 دقيقة',
                'delivery_time' => '10-15 دقيقة',
                'is_featured' => true
            ],
            [
                'name' => 'Bigo Live - 42 Diamonds',
                'name_en' => 'Bigo Live - 42 Diamonds',
                'description' => 'شحن 42 ماسة بيجو لايف',
                'price_yer' => 250,
                'price_sar' => 1,
                'price_usd' => 0.67,
                'price_aed' => 2.45,
                'customer_id_label' => 'Bigo ID',
                'customer_id_placeholder' => 'أدخل Bigo ID الخاص بك',
                'instructions' => 'ستحصل على الماس خلال 10-15 دقيقة',
                'delivery_time' => '10-15 دقيقة',
                'is_featured' => false
            ],
            [
                'name' => 'Likee - 100 Diamonds',
                'name_en' => 'Likee - 100 Diamonds',
                'description' => 'شحن 100 ماسة لايكي',
                'price_yer' => 350,
                'price_sar' => 1.4,
                'price_usd' => 0.93,
                'price_aed' => 3.43,
                'customer_id_label' => 'Likee ID',
                'customer_id_placeholder' => 'أدخل Likee ID الخاص بك',
                'instructions' => 'ستحصل على الماس خلال 10-15 دقيقة',
                'delivery_time' => '10-15 دقيقة',
                'is_featured' => false
            ]
        ];
        
        foreach ($apps as $app) {
            $this->insertProduct($category_id, $app);
        }
    }
    
    private function addGiftCards() {
        echo "🎁 إضافة بطاقات الهدايا...\n";
        
        $category_id = $this->getCategoryId('بطاقات الهدايا');
        
        $cards = [
            [
                'name' => 'Google Play - 10$',
                'name_en' => 'Google Play Gift Card - $10',
                'description' => 'بطاقة هدايا جوجل بلاي بقيمة 10 دولار',
                'price_yer' => 3750,
                'price_sar' => 15,
                'price_usd' => 10,
                'price_aed' => 36.75,
                'customer_id_label' => 'البريد الإلكتروني',
                'customer_id_placeholder' => 'أدخل بريدك الإلكتروني',
                'instructions' => 'ستحصل على الكود خلال 30 دقيقة',
                'delivery_time' => '30 دقيقة',
                'is_featured' => true
            ],
            [
                'name' => 'iTunes - 10$',
                'name_en' => 'iTunes Gift Card - $10',
                'description' => 'بطاقة هدايا آيتونز بقيمة 10 دولار',
                'price_yer' => 3750,
                'price_sar' => 15,
                'price_usd' => 10,
                'price_aed' => 36.75,
                'customer_id_label' => 'البريد الإلكتروني',
                'customer_id_placeholder' => 'أدخل بريدك الإلكتروني',
                'instructions' => 'ستحصل على الكود خلال 30 دقيقة',
                'delivery_time' => '30 دقيقة',
                'is_featured' => true
            ],
            [
                'name' => 'Steam Wallet - 5$',
                'name_en' => 'Steam Wallet - $5',
                'description' => 'شحن محفظة ستيم بقيمة 5 دولار',
                'price_yer' => 1875,
                'price_sar' => 7.5,
                'price_usd' => 5,
                'price_aed' => 18.38,
                'customer_id_label' => 'Steam ID',
                'customer_id_placeholder' => 'أدخل Steam ID الخاص بك',
                'instructions' => 'ستحصل على الرصيد خلال 1-2 ساعة',
                'delivery_time' => '1-2 ساعة',
                'is_featured' => false
            ]
        ];
        
        foreach ($cards as $card) {
            $this->insertProduct($category_id, $card);
        }
    }
    
    private function getCategoryId($name) {
        $stmt = $this->pdo->prepare("SELECT id FROM categories WHERE name = ?");
        $stmt->execute([$name]);
        $result = $stmt->fetch();
        return $result ? $result['id'] : 1;
    }
    
    private function insertProduct($category_id, $product) {
        // التحقق من عدم وجود المنتج
        $stmt = $this->pdo->prepare("SELECT id FROM products WHERE name = ?");
        $stmt->execute([$product['name']]);
        
        if ($stmt->fetch()) {
            echo "⚠️ المنتج موجود مسبقاً: {$product['name']}\n";
            return;
        }
        
        $stmt = $this->pdo->prepare("
            INSERT INTO products (
                category_id, name, name_en, description, 
                price_yer, price_sar, price_usd, price_aed,
                customer_id_label, customer_id_placeholder, 
                instructions, delivery_time, is_featured, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
        ");
        
        $stmt->execute([
            $category_id,
            $product['name'],
            $product['name_en'],
            $product['description'],
            $product['price_yer'],
            $product['price_sar'],
            $product['price_usd'],
            $product['price_aed'],
            $product['customer_id_label'],
            $product['customer_id_placeholder'],
            $product['instructions'],
            $product['delivery_time'],
            $product['is_featured'] ? 1 : 0
        ]);
        
        echo "✅ تم إضافة: {$product['name']}\n";
    }
    
    private function showProductStats() {
        $stmt = $this->pdo->query("
            SELECT c.name as category_name, COUNT(p.id) as product_count
            FROM categories c
            LEFT JOIN products p ON c.id = p.category_id
            GROUP BY c.id, c.name
        ");
        
        echo "\n📊 إحصائيات المنتجات:\n";
        while ($row = $stmt->fetch()) {
            echo "   {$row['category_name']}: {$row['product_count']} منتج\n";
        }
        
        $total = $this->pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
        echo "   المجموع الكلي: $total منتج\n";
    }
}

// تشغيل المولد
if (php_sapi_name() === 'cli') {
    new SampleProductsGenerator();
} else {
    echo "<pre>";
    new SampleProductsGenerator();
    echo "</pre>";
}
?>
