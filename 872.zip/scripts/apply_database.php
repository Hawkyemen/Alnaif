<?php
/**
 * تطبيق قاعدة البيانات الكاملة
 * Apply Complete Database Setup
 */

// إعدادات قاعدة البيانات المحلية
$db_config = [
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'faststar_db',
    'charset' => 'utf8mb4'
];

echo "🚀 بدء تطبيق قاعدة البيانات على localhost...\n\n";

try {
    // الاتصال بقاعدة البيانات بدون تحديد قاعدة بيانات أولاً
    $dsn = "mysql:host={$db_config['host']};charset={$db_config['charset']}";
    $pdo = new PDO($dsn, $db_config['username'], $db_config['password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES {$db_config['charset']}"
    ]);
    
    echo "✅ تم الاتصال بخادم MySQL بنجاح\n";
    
    // إنشاء قاعدة البيانات إذا لم تكن موجودة
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$db_config['database']}` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    echo "✅ تم إنشاء قاعدة البيانات: {$db_config['database']}\n";
    
    // اختيار قاعدة البيانات
    $pdo->exec("USE `{$db_config['database']}`");
    echo "✅ تم اختيار قاعدة البيانات: {$db_config['database']}\n";
    
    // منح الصلاحيات (إذا كان ممكناً)
    try {
        $pdo->exec("GRANT ALL PRIVILEGES ON `{$db_config['database']}`.* TO '{$db_config['username']}'@'localhost'");
        $pdo->exec("FLUSH PRIVILEGES");
        echo "✅ تم منح الصلاحيات الكاملة\n";
    } catch (Exception $e) {
        echo "⚠️ تحذير: لم يتم منح الصلاحيات (المستخدم root لديه صلاحيات كاملة مسبقاً)\n";
    }
    
    // قراءة وتنفيذ ملف SQL
    $sql_file = __DIR__ . '/complete_database_setup.sql';
    
    if (!file_exists($sql_file)) {
        throw new Exception("ملف SQL غير موجود: $sql_file");
    }
    
    $sql_content = file_get_contents($sql_file);
    
    echo "\n📝 تطبيق سكريبت قاعدة البيانات...\n";
    
    // تقسيم SQL إلى عبارات منفصلة
    $statements = preg_split('/;\s*$/m', $sql_content);
    $executed = 0;
    $errors = 0;
    
    foreach ($statements as $statement) {
        $statement = trim($statement);
        
        // تجاهل التعليقات والعبارات الفارغة
        if (empty($statement) || 
            strpos($statement, '--') === 0 || 
            strpos($statement, '/*') === 0 ||
            strpos($statement, 'SET SQL_MODE') === 0 ||
            strpos($statement, 'SET AUTOCOMMIT') === 0 ||
            strpos($statement, 'START TRANSACTION') === 0 ||
            strpos($statement, 'COMMIT') === 0 ||
            strpos($statement, 'SET time_zone') === 0) {
            continue;
        }
        
        try {
            $pdo->exec($statement);
            $executed++;
            
            // عرض تقدم العملية
            if ($executed % 5 == 0) {
                echo "   تم تنفيذ $executed عبارة...\n";
            }
            
        } catch (PDOException $e) {
            $errors++;
            // تجاهل أخطاء الجداول الموجودة مسبقاً والمفاتيح المكررة
            if (strpos($e->getMessage(), 'already exists') === false && 
                strpos($e->getMessage(), 'Duplicate entry') === false &&
                strpos($e->getMessage(), 'Duplicate key') === false) {
                echo "❌ خطأ في العبارة: " . substr($statement, 0, 50) . "...\n";
                echo "   الخطأ: " . $e->getMessage() . "\n";
            }
        }
    }
    
    echo "\n📊 ملخص التطبيق:\n";
    echo "   ✅ عبارات منفذة بنجاح: $executed\n";
    echo "   ❌ أخطاء تم تجاهلها: $errors\n";
    
    // التحقق من الجداول المنشأة
    echo "\n🔍 التحقق من الجداول المنشأة:\n";
    
    $tables = [
        'users' => 'المستخدمين',
        'admins' => 'المديرين', 
        'categories' => 'الفئات',
        'products' => 'المنتجات',
        'orders' => 'الطلبات',
        'wallet_transactions' => 'معاملات المحفظة',
        'payment_gateways' => 'بوابات الدفع',
        'payment_transactions' => 'معاملات الدفع',
        'charging_apis' => 'APIs الشحن',
        'api_logs' => 'سجلات API',
        'exchange_rates' => 'أسعار الصرف',
        'settings' => 'الإعدادات',
        'notifications' => 'الإشعارات',
        'user_sessions' => 'جلسات المستخدمين',
        'backups' => 'النسخ الاحتياطية'
    ];
    
    foreach ($tables as $table => $arabic_name) {
        try {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM `$table`");
            $result = $stmt->fetch();
            $count = $result['count'];
            echo "   ✅ $arabic_name ($table): $count سجل\n";
        } catch (Exception $e) {
            echo "   ❌ $arabic_name ($table): غير موجود - " . $e->getMessage() . "\n";
        }
    }
    
    // التحقق من المدير الافتراضي وإنشاؤه إذا لم يكن موجوداً
    echo "\n👤 التحقق من المدير الافتراضي:\n";
    try {
        $stmt = $pdo->query("SELECT username, email, role FROM admins WHERE username = 'admin'");
        $admin = $stmt->fetch();
        
        if ($admin) {
            echo "   ✅ المدير موجود:\n";
            echo "      اسم المستخدم: {$admin['username']}\n";
            echo "      البريد الإلكتروني: {$admin['email']}\n";
            echo "      الدور: {$admin['role']}\n";
            echo "      كلمة المرور: faststar2024\n";
        } else {
            echo "   ❌ المدير غير موجود - سيتم إنشاؤه...\n";
            
            $stmt = $pdo->prepare("INSERT INTO admins (username, email, password, full_name, role, status) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                'admin',
                'admin@faststarone.com',
                password_hash('faststar2024', PASSWORD_DEFAULT),
                'مدير النظام الرئيسي',
                'super_admin',
                'active'
            ]);
            
            echo "   ✅ تم إنشاء المدير بنجاح\n";
            echo "      اسم المستخدم: admin\n";
            echo "      كلمة المرور: faststar2024\n";
        }
    } catch (Exception $e) {
        echo "   ❌ خطأ في التحقق من المدير: " . $e->getMessage() . "\n";
    }
    
    // إنشاء مستخدم تجريبي إذا لم يكن موجوداً
    echo "\n👥 التحقق من المستخدم التجريبي:\n";
    try {
        $stmt = $pdo->query("SELECT username, email FROM users WHERE username = 'testuser'");
        $user = $stmt->fetch();
        
        if ($user) {
            echo "   ✅ المستخدم التجريبي موجود: {$user['username']}\n";
        } else {
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, full_name, phone, wallet_balance, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                'testuser',
                'test@example.com',
                password_hash('test123', PASSWORD_DEFAULT),
                'مستخدم تجريبي',
                '+966501234567',
                1000.00,
                'active'
            ]);
            
            echo "   ✅ تم إنشاء المستخدم التجريبي\n";
            echo "      اسم المستخدم: testuser\n";
            echo "      كلمة المرور: test123\n";
        }
    } catch (Exception $e) {
        echo "   ❌ خطأ في إنشاء المستخدم التجريبي: " . $e->getMessage() . "\n";
    }
    
    // إنشاء ملف الإعدادات المحدث
    echo "\n⚙️ إنشاء ملف الإعدادات المحدث...\n";
    
    $config_content = "<?php
/**
 * إعدادات قاعدة البيانات المحلية
 * Local Database Configuration
 */

// إعدادات قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'faststar_db');
define('DB_CHARSET', 'utf8mb4');

// إعدادات الموقع
define('SITE_NAME', 'فاست ستار');
define('SITE_URL', 'http://localhost');
define('ADMIN_EMAIL', 'admin@faststarone.com');
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('UPLOAD_URL', SITE_URL . '/uploads/');

// إعدادات الأمان
define('HASH_ALGO', 'sha256');
define('SESSION_TIMEOUT', 3600);
define('MAX_LOGIN_ATTEMPTS', 5);
define('CSRF_TOKEN_NAME', 'csrf_token');

// إعدادات العملة
define('DEFAULT_CURRENCY', 'YER');
define('SUPPORTED_CURRENCIES', ['YER', 'SAR', 'USD', 'AED']);

// معلومات المدير الافتراضي
define('DEFAULT_ADMIN_USERNAME', 'admin');
define('DEFAULT_ADMIN_PASSWORD', 'faststar2024');
define('DEFAULT_ADMIN_EMAIL', 'admin@faststarone.com');

// معلومات المستخدم التجريبي
define('TEST_USER_USERNAME', 'testuser');
define('TEST_USER_PASSWORD', 'test123');
define('TEST_USER_EMAIL', 'test@example.com');

/**
 * فئة قاعدة البيانات
 */
class Database {
    private static \$instance = null;
    private \$connection;
    
    private function __construct() {
        try {
            \$dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            \$this->connection = new PDO(\$dsn, DB_USERNAME, DB_PASSWORD, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES ' . DB_CHARSET,
                PDO::ATTR_EMULATE_PREPARES => false
            ]);
            
            // اختبار الاتصال
            \$this->connection->query('SELECT 1');
            
        } catch (PDOException \$e) {
            error_log('Database connection failed: ' . \$e->getMessage());
            die('خطأ في الاتصال بقاعدة البيانات. يرجى التحقق من الإعدادات.');
        }
    }
    
    public static function getInstance() {
        if (self::\$instance === null) {
            self::\$instance = new self();
        }
        return self::\$instance;
    }
    
    public function getConnection() {
        return \$this->connection;
    }
    
    public function testConnection() {
        try {
            \$stmt = \$this->connection->query('SELECT 1 as test');
            return \$stmt->fetch()['test'] === 1;
        } catch (Exception \$e) {
            return false;
        }
    }
}

// بدء الجلسة
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * وظائف مساعدة
 */
function sanitize_input(\$data) {
    return htmlspecialchars(strip_tags(trim(\$data)), ENT_QUOTES, 'UTF-8');
}

function redirect(\$url) {
    header('Location: ' . \$url);
    exit();
}

function is_logged_in() {
    return isset(\$_SESSION['user_id']) || isset(\$_SESSION['admin_id']);
}

function is_admin() {
    return isset(\$_SESSION['admin_id']);
}

function get_current_user() {
    if (isset(\$_SESSION['user_id'])) {
        \$db = Database::getInstance()->getConnection();
        \$stmt = \$db->prepare('SELECT * FROM users WHERE id = ? AND status = \"active\"');
        \$stmt->execute([\$_SESSION['user_id']]);
        return \$stmt->fetch();
    }
    return null;
}

function get_current_admin() {
    if (isset(\$_SESSION['admin_id'])) {
        \$db = Database::getInstance()->getConnection();
        \$stmt = \$db->prepare('SELECT * FROM admins WHERE id = ? AND status = \"active\"');
        \$stmt->execute([\$_SESSION['admin_id']]);
        return \$stmt->fetch();
    }
    return null;
}

function generate_csrf_token() {
    if (!isset(\$_SESSION[CSRF_TOKEN_NAME])) {
        \$_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return \$_SESSION[CSRF_TOKEN_NAME];
}

function verify_csrf_token(\$token) {
    return isset(\$_SESSION[CSRF_TOKEN_NAME]) && hash_equals(\$_SESSION[CSRF_TOKEN_NAME], \$token);
}

function format_currency(\$amount, \$currency = 'YER') {
    \$symbols = [
        'YER' => 'ر.ي',
        'SAR' => 'ر.س',
        'USD' => '\$',
        'AED' => 'د.إ'
    ];
    
    return number_format(\$amount, 2) . ' ' . (\$symbols[\$currency] ?? \$currency);
}

function get_setting(\$key, \$default = null) {
    static \$settings = null;
    
    if (\$settings === null) {
        try {
            \$db = Database::getInstance()->getConnection();
            \$stmt = \$db->query('SELECT `key`, `value` FROM settings');
            \$settings = [];
            while (\$row = \$stmt->fetch()) {
                \$settings[\$row['key']] = \$row['value'];
            }
        } catch (Exception \$e) {
            \$settings = [];
        }
    }
    
    return \$settings[\$key] ?? \$default;
}

function log_activity(\$user_id, \$action, \$details = null) {
    try {
        \$db = Database::getInstance()->getConnection();
        \$stmt = \$db->prepare('INSERT INTO activity_logs (user_id, action, details, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)');
        \$stmt->execute([
            \$user_id,
            \$action,
            \$details,
            \$_SERVER['REMOTE_ADDR'] ?? null,
            \$_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
    } catch (Exception \$e) {
        error_log('Failed to log activity: ' . \$e->getMessage());
    }
}

// اختبار الاتصال عند تحميل الملف
try {
    \$db_test = Database::getInstance();
    if (!\$db_test->testConnection()) {
        throw new Exception('Database connection test failed');
    }
} catch (Exception \$e) {
    error_log('Database initialization error: ' . \$e->getMessage());
}
?>";
    
    $config_file = dirname(__DIR__) . '/config/database.php';
    
    // إنشاء مجلد config إذا لم يكن موجوداً
    $config_dir = dirname($config_file);
    if (!is_dir($config_dir)) {
        mkdir($config_dir, 0755, true);
    }
    
    file_put_contents($config_file, $config_content);
    
    echo "   ✅ تم إنشاء ملف الإعدادات: $config_file\n";
    
    // إنشاء ملف اختبار سريع
    $test_file_content = "<?php
require_once __DIR__ . '/config/database.php';

echo '<h2>🧪 اختبار النظام - FastStar</h2>';

try {
    \$db = Database::getInstance()->getConnection();
    
    echo '<h3>✅ قاعدة البيانات</h3>';
    echo '<p>الاتصال: نجح</p>';
    echo '<p>قاعدة البيانات: ' . DB_NAME . '</p>';
    echo '<p>الخادم: ' . DB_HOST . '</p>';
    
    echo '<h3>📊 الجداول</h3>';
    \$stmt = \$db->query('SHOW TABLES');
    \$tables = \$stmt->fetchAll(PDO::FETCH_COLUMN);
    echo '<p>عدد الجداول: ' . count(\$tables) . '</p>';
    
    echo '<h3>👤 المديرين</h3>';
    \$stmt = \$db->query('SELECT COUNT(*) as count FROM admins');
    \$admin_count = \$stmt->fetch()['count'];
    echo '<p>عدد المديرين: ' . \$admin_count . '</p>';
    
    echo '<h3>👥 المستخدمين</h3>';
    \$stmt = \$db->query('SELECT COUNT(*) as count FROM users');
    \$user_count = \$stmt->fetch()['count'];
    echo '<p>عدد المستخدمين: ' . \$user_count . '</p>';
    
    echo '<h3>🛍️ المنتجات</h3>';
    \$stmt = \$db->query('SELECT COUNT(*) as count FROM products');
    \$product_count = \$stmt->fetch()['count'];
    echo '<p>عدد المنتجات: ' . \$product_count . '</p>';
    
    echo '<h3>🔗 روابط مهمة</h3>';
    echo '<p><a href=\"admin/login.php\">لوحة تحكم المدير</a></p>';
    echo '<p><a href=\"login.php\">تسجيل دخول المستخدم</a></p>';
    echo '<p><a href=\"register.php\">تسجيل مستخدم جديد</a></p>';
    
    echo '<h3>🔐 بيانات تسجيل الدخول</h3>';
    echo '<h4>المدير:</h4>';
    echo '<p>اسم المستخدم: admin</p>';
    echo '<p>كلمة المرور: faststar2024</p>';
    echo '<h4>مستخدم تجريبي:</h4>';
    echo '<p>اسم المستخدم: testuser</p>';
    echo '<p>كلمة المرور: test123</p>';
    
} catch (Exception \$e) {
    echo '<h3>❌ خطأ</h3>';
    echo '<p>' . \$e->getMessage() . '</p>';
}
?>";
    
    file_put_contents(dirname(__DIR__) . '/test_system.php', $test_file_content);
    
    echo "\n🎉 تم تطبيق قاعدة البيانات بنجاح!\n";
    echo "\n📋 معلومات النظام:\n";
    echo "   🗄️ قاعدة البيانات: faststar_db\n";
    echo "   🖥️ الخادم: localhost\n";
    echo "   👤 المستخدم: root\n";
    echo "   🔑 كلمة المرور: (فارغة)\n";
    
    echo "\n📋 معلومات تسجيل الدخول:\n";
    echo "   🔐 المدير:\n";
    echo "      الرابط: http://localhost/admin/login.php\n";
    echo "      اسم المستخدم: admin\n";
    echo "      كلمة المرور: faststar2024\n";
    echo "\n   👤 مستخدم تجريبي:\n";
    echo "      الرابط: http://localhost/login.php\n";
    echo "      اسم المستخدم: testuser\n";
    echo "      كلمة المرور: test123\n";
    
    echo "\n🧪 اختبار النظام:\n";
    echo "      الرابط: http://localhost/test_system.php\n";
    
} catch (Exception $e) {
    echo "❌ خطأ في تطبيق قاعدة البيانات: " . $e->getMessage() . "\n";
    echo "تفاصيل الخطأ:\n";
    echo $e->getTraceAsString() . "\n";
    exit(1);
}
?>
