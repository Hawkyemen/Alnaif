#!/usr/bin/env php
<?php
/**
 * Automated Backup Cron Job
 * مهمة النسخ الاحتياطي التلقائية
 * 
 * Add to crontab:
 * 0 2 * * * /usr/bin/php /path/to/your/project/scripts/backup_cron.php
 */

// Set execution time limit
set_time_limit(0);
ini_set('memory_limit', '512M');

// Include configuration
require_once dirname(__DIR__) . '/config/config.php';

class AutoBackup {
    private $db;
    private $backup_dir;
    private $log_file;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->backup_dir = dirname(__DIR__) . '/backups/';
        $this->log_file = dirname(__DIR__) . '/logs/backup_cron.log';
        
        // Create directories if they don't exist
        if (!is_dir($this->backup_dir)) {
            mkdir($this->backup_dir, 0755, true);
        }
        
        if (!is_dir(dirname($this->log_file))) {
            mkdir(dirname($this->log_file), 0755, true);
        }
    }
    
    public function run() {
        $this->log("Starting automated backup process");
        
        try {
            // Get scheduled backups that need to run
            $schedules = $this->getSchedulesToRun();
            
            foreach ($schedules as $schedule) {
                $this->processSchedule($schedule);
            }
            
            // Cleanup old backups
            $this->cleanupOldBackups();
            
            $this->log("Automated backup process completed successfully");
            
        } catch (Exception $e) {
            $this->log("Error in automated backup: " . $e->getMessage(), 'ERROR');
            $this->sendErrorNotification($e->getMessage());
        }
    }
    
    private function getSchedulesToRun() {
        $stmt = $this->db->prepare("
            SELECT * FROM backup_schedules 
            WHERE status = 'active' 
            AND (next_run IS NULL OR next_run <= NOW())
            ORDER BY id
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function processSchedule($schedule) {
        $this->log("Processing schedule ID: {$schedule['id']} - Type: {$schedule['type']} - Backup Type: {$schedule['backup_type']}");
        
        $start_time = microtime(true);
        
        try {
            // Create backup based on type
            $backup_result = $this->createBackup($schedule['backup_type']);
            
            if ($backup_result['success']) {
                $execution_time = round(microtime(true) - $start_time, 2);
                
                // Update schedule
                $this->updateSchedule($schedule['id'], true);
                
                // Log success
                $this->logBackupResult($schedule['id'], 'completed', $backup_result, $execution_time);
                
                $this->log("Backup completed successfully: {$backup_result['filename']} ({$execution_time}s)");
                
                // Send success notification if enabled
                $this->sendSuccessNotification($backup_result, $execution_time);
                
            } else {
                throw new Exception($backup_result['error']);
            }
            
        } catch (Exception $e) {
            $execution_time = round(microtime(true) - $start_time, 2);
            
            // Update schedule (still update next run time)
            $this->updateSchedule($schedule['id'], false);
            
            // Log failure
            $this->logBackupResult($schedule['id'], 'failed', ['error' => $e->getMessage()], $execution_time);
            
            $this->log("Backup failed: " . $e->getMessage(), 'ERROR');
            
            throw $e; // Re-throw to be caught by main try-catch
        }
    }
    
    private function createBackup($backup_type) {
        switch ($backup_type) {
            case 'database':
                return $this->createDatabaseBackup();
            case 'files':
                return $this->createFilesBackup();
            case 'full':
                return $this->createFullBackup();
            default:
                throw new Exception("Unknown backup type: $backup_type");
        }
    }
    
    private function createDatabaseBackup() {
        $timestamp = date('Y-m-d_H-i-s');
        $filename = "backup_database_{$timestamp}.sql";
        $filepath = $this->backup_dir . $filename;
        
        // Get database credentials
        $host = DB_HOST;
        $database = DB_NAME;
        $username = DB_USER;
        $password = DB_PASS;
        
        // Build mysqldump command
        $command = sprintf(
            'mysqldump --host=%s --user=%s --password=%s --single-transaction --routines --triggers %s > %s 2>&1',
            escapeshellarg($host),
            escapeshellarg($username),
            escapeshellarg($password),
            escapeshellarg($database),
            escapeshellarg($filepath)
        );
        
        // Execute backup
        $output = [];
        $return_code = 0;
        exec($command, $output, $return_code);
        
        if ($return_code !== 0) {
            return [
                'success' => false,
                'error' => 'mysqldump failed: ' . implode("\n", $output)
            ];
        }
        
        // Check if file was created and has content
        if (!file_exists($filepath) || filesize($filepath) < 1000) {
            return [
                'success' => false,
                'error' => 'Backup file was not created or is too small'
            ];
        }
        
        // Compress the backup
        $compressed_filename = $filename . '.gz';
        $compressed_filepath = $this->backup_dir . $compressed_filename;
        
        if ($this->compressFile($filepath, $compressed_filepath)) {
            unlink($filepath); // Remove uncompressed file
            $filename = $compressed_filename;
            $filepath = $compressed_filepath;
        }
        
        // Save backup record to database
        $file_size = filesize($filepath);
        $stmt = $this->db->prepare("
            INSERT INTO backups (filename, type, size, status, admin_id)
            VALUES (?, 'database', ?, 'completed', 1)
        ");
        $stmt->execute([$filename, $file_size]);
        
        return [
            'success' => true,
            'filename' => $filename,
            'filepath' => $filepath,
            'size' => $file_size,
            'type' => 'database'
        ];
    }
    
    private function createFilesBackup() {
        $timestamp = date('Y-m-d_H-i-s');
        $filename = "backup_files_{$timestamp}.tar.gz";
        $filepath = $this->backup_dir . $filename;
        
        // Directories to backup (exclude backups and logs)
        $source_dir = dirname(__DIR__);
        $exclude_dirs = ['backups', 'logs', 'tmp', '.git', 'node_modules'];
        
        // Build tar command with exclusions
        $exclude_params = '';
        foreach ($exclude_dirs as $exclude) {
            $exclude_params .= " --exclude='" . $exclude . "'";
        }
        
        $command = sprintf(
            'cd %s && tar -czf %s %s . 2>&1',
            escapeshellarg($source_dir),
            escapeshellarg($filepath),
            $exclude_params
        );
        
        $output = [];
        $return_code = 0;
        exec($command, $output, $return_code);
        
        if ($return_code !== 0) {
            return [
                'success' => false,
                'error' => 'tar command failed: ' . implode("\n", $output)
            ];
        }
        
        if (!file_exists($filepath)) {
            return [
                'success' => false,
                'error' => 'Files backup was not created'
            ];
        }
        
        // Save backup record
        $file_size = filesize($filepath);
        $stmt = $this->db->prepare("
            INSERT INTO backups (filename, type, size, status, admin_id)
            VALUES (?, 'files', ?, 'completed', 1)
        ");
        $stmt->execute([$filename, $file_size]);
        
        return [
            'success' => true,
            'filename' => $filename,
            'filepath' => $filepath,
            'size' => $file_size,
            'type' => 'files'
        ];
    }
    
    private function createFullBackup() {
        $timestamp = date('Y-m-d_H-i-s');
        $temp_dir = $this->backup_dir . "temp_full_backup_{$timestamp}/";
        $filename = "backup_full_{$timestamp}.tar.gz";
        $filepath = $this->backup_dir . $filename;
        
        // Create temporary directory
        if (!mkdir($temp_dir, 0755, true)) {
            return [
                'success' => false,
                'error' => 'Could not create temporary directory'
            ];
        }
        
        try {
            // Create database backup in temp directory
            $db_result = $this->createDatabaseBackup();
            if (!$db_result['success']) {
                throw new Exception('Database backup failed: ' . $db_result['error']);
            }
            
            // Move database backup to temp directory
            $temp_db_file = $temp_dir . 'database.sql.gz';
            if (!rename($db_result['filepath'], $temp_db_file)) {
                throw new Exception('Could not move database backup to temp directory');
            }
            
            // Create files archive in temp directory
            $source_dir = dirname(__DIR__);
            $exclude_dirs = ['backups', 'logs', 'tmp', '.git', 'node_modules'];
            
            $exclude_params = '';
            foreach ($exclude_dirs as $exclude) {
                $exclude_params .= " --exclude='" . $exclude . "'";
            }
            
            $temp_files_archive = $temp_dir . 'files.tar.gz';
            $command = sprintf(
                'cd %s && tar -czf %s %s . 2>&1',
                escapeshellarg($source_dir),
                escapeshellarg($temp_files_archive),
                $exclude_params
            );
            
            $output = [];
            $return_code = 0;
            exec($command, $output, $return_code);
            
            if ($return_code !== 0) {
                throw new Exception('Files backup failed: ' . implode("\n", $output));
            }
            
            // Create final archive containing both database and files
            $command = sprintf(
                'cd %s && tar -czf %s * 2>&1',
                escapeshellarg($temp_dir),
                escapeshellarg($filepath)
            );
            
            exec($command, $output, $return_code);
            
            if ($return_code !== 0) {
                throw new Exception('Final archive creation failed: ' . implode("\n", $output));
            }
            
            // Clean up temp directory
            $this->removeDirectory($temp_dir);
            
            if (!file_exists($filepath)) {
                throw new Exception('Full backup was not created');
            }
            
            // Save backup record
            $file_size = filesize($filepath);
            $stmt = $this->db->prepare("
                INSERT INTO backups (filename, type, size, status, admin_id)
                VALUES (?, 'full', ?, 'completed', 1)
            ");
            $stmt->execute([$filename, $file_size]);
            
            return [
                'success' => true,
                'filename' => $filename,
                'filepath' => $filepath,
                'size' => $file_size,
                'type' => 'full'
            ];
            
        } catch (Exception $e) {
            // Clean up temp directory on error
            if (is_dir($temp_dir)) {
                $this->removeDirectory($temp_dir);
            }
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    private function compressFile($source, $destination) {
        if (!function_exists('gzopen')) {
            return false;
        }
        
        $source_handle = fopen($source, 'rb');
        $dest_handle = gzopen($destination, 'wb9');
        
        if (!$source_handle || !$dest_handle) {
            return false;
        }
        
        while (!feof($source_handle)) {
            gzwrite($dest_handle, fread($source_handle, 8192));
        }
        
        fclose($source_handle);
        gzclose($dest_handle);
        
        return file_exists($destination);
    }
    
    private function removeDirectory($dir) {
        if (!is_dir($dir)) {
            return;
        }
        
        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            if (is_dir($path)) {
                $this->removeDirectory($path);
            } else {
                unlink($path);
            }
        }
        rmdir($dir);
    }
    
    private function updateSchedule($schedule_id, $success) {
        // Calculate next run time
        $stmt = $this->db->prepare("SELECT * FROM backup_schedules WHERE id = ?");
        $stmt->execute([$schedule_id]);
        $schedule = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$schedule) {
            return;
        }
        
        $next_run = $this->calculateNextRun($schedule);
        
        $stmt = $this->db->prepare("
            UPDATE backup_schedules 
            SET last_run = NOW(), next_run = ?
            WHERE id = ?
        ");
        $stmt->execute([$next_run, $schedule_id]);
    }
    
    private function calculateNextRun($schedule) {
        $now = new DateTime();
        $schedule_time = $schedule['schedule_time'];
        
        switch ($schedule['type']) {
            case 'daily':
                $next = clone $now;
                $next->modify('+1 day');
                $next->setTime(...explode(':', $schedule_time));
                break;
                
            case 'weekly':
                $next = clone $now;
                $next->modify('+1 week');
                $next->setTime(...explode(':', $schedule_time));
                break;
                
            case 'monthly':
                $next = clone $now;
                $next->modify('+1 month');
                $next->setTime(...explode(':', $schedule_time));
                break;
                
            default:
                $next = clone $now;
                $next->modify('+1 day');
        }
        
        return $next->format('Y-m-d H:i:s');
    }
    
    private function logBackupResult($schedule_id, $status, $result, $execution_time) {
        $details = json_encode([
            'execution_time' => $execution_time,
            'result' => $result
        ]);
        
        $stmt = $this->db->prepare("
            INSERT INTO backup_logs (schedule_id, action, status, details, execution_time)
            VALUES (?, 'create', ?, ?, ?)
        ");
        $stmt->execute([$schedule_id, $status, $details, $execution_time]);
    }
    
    private function cleanupOldBackups() {
        $this->log("Starting cleanup of old backups");
        
        // Get retention settings
        $stmt = $this->db->prepare("SELECT setting_value FROM backup_settings WHERE setting_key = 'backup_retention_days'");
        $stmt->execute();
        $retention_days = (int)($stmt->fetchColumn() ?: 30);
        
        // Get old backups
        $stmt = $this->db->prepare("
            SELECT * FROM backups 
            WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
            AND status = 'completed'
        ");
        $stmt->execute([$retention_days]);
        $old_backups = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $deleted_count = 0;
        $deleted_size = 0;
        
        foreach ($old_backups as $backup) {
            $filepath = $this->backup_dir . $backup['filename'];
            
            if (file_exists($filepath)) {
                $deleted_size += filesize($filepath);
                unlink($filepath);
            }
            
            // Remove from database
            $stmt = $this->db->prepare("DELETE FROM backups WHERE id = ?");
            $stmt->execute([$backup['id']]);
            
            $deleted_count++;
        }
        
        if ($deleted_count > 0) {
            $this->log("Cleaned up $deleted_count old backups (" . $this->formatBytes($deleted_size) . ")");
        } else {
            $this->log("No old backups to clean up");
        }
    }
    
    private function sendSuccessNotification($backup_result, $execution_time) {
        // Check if email notifications are enabled
        $stmt = $this->db->prepare("SELECT setting_value FROM backup_settings WHERE setting_key = 'email_notifications'");
        $stmt->execute();
        $notifications_enabled = (bool)($stmt->fetchColumn() ?: false);
        
        if (!$notifications_enabled) {
            return;
        }
        
        $stmt = $this->db->prepare("SELECT setting_value FROM backup_settings WHERE setting_key = 'notification_email'");
        $stmt->execute();
        $notification_email = $stmt->fetchColumn();
        
        if (!$notification_email) {
            return;
        }
        
        $subject = 'FastStar - Backup Completed Successfully';
        $message = "
        Backup completed successfully!
        
        Details:
        - Type: {$backup_result['type']}
        - Filename: {$backup_result['filename']}
        - Size: " . $this->formatBytes($backup_result['size']) . "
        - Execution Time: {$execution_time} seconds
        - Date: " . date('Y-m-d H:i:s') . "
        
        FastStar Backup System
        ";
        
        mail($notification_email, $subject, $message);
    }
    
    private function sendErrorNotification($error_message) {
        $stmt = $this->db->prepare("SELECT setting_value FROM backup_settings WHERE setting_key = 'notification_email'");
        $stmt->execute();
        $notification_email = $stmt->fetchColumn();
        
        if (!$notification_email) {
            return;
        }
        
        $subject = 'FastStar - Backup Failed';
        $message = "
        Backup process failed!
        
        Error: $error_message
        Date: " . date('Y-m-d H:i:s') . "
        
        Please check the system immediately.
        
        FastStar Backup System
        ";
        
        mail($notification_email, $subject, $message);
    }
    
    private function formatBytes($bytes, $precision = 2) {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, $precision) . ' ' . $units[$i];
    }
    
    private function log($message, $level = 'INFO') {
        $timestamp = date('Y-m-d H:i:s');
        $log_entry = "[$timestamp] [$level] $message" . PHP_EOL;
        
        file_put_contents($this->log_file, $log_entry, FILE_APPEND | LOCK_EX);
        
        // Also output to console if running from command line
        if (php_sapi_name() === 'cli') {
            echo $log_entry;
        }
    }
}

// Run the backup if called directly
if (php_sapi_name() === 'cli' && basename(__FILE__) === basename($_SERVER['SCRIPT_NAME'])) {
    $backup = new AutoBackup();
    $backup->run();
}
?>
