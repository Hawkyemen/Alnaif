-- إنشاء جداول نظام النسخ الاحتياطي والAPI المتقدم
-- Advanced Backup System and API Tables

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

-- جدول مفاتيح API
CREATE TABLE IF NOT EXISTS `api_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `api_key` varchar(128) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `permissions` text DEFAULT NULL,
  `rate_limit` int(11) DEFAULT 1000,
  `rate_window` int(11) DEFAULT 3600,
  `allowed_ips` text DEFAULT NULL,
  `allowed_domains` text DEFAULT NULL,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `last_used_at` timestamp NULL DEFAULT NULL,
  `requests_count` int(11) DEFAULT 0,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_key` (`api_key`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_status` (`status`),
  KEY `idx_expires_at` (`expires_at`),
  CONSTRAINT `fk_api_keys_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_api_keys_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول طلبات API
CREATE TABLE IF NOT EXISTS `api_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `api_key_id` int(11) DEFAULT NULL,
  `endpoint` varchar(255) NOT NULL,
  `method` varchar(10) NOT NULL,
  `request_data` longtext DEFAULT NULL,
  `response_data` longtext DEFAULT NULL,
  `response_code` int(11) DEFAULT NULL,
  `response_time` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_api_key_id` (`api_key_id`),
  KEY `idx_endpoint` (`endpoint`),
  KEY `idx_method` (`method`),
  KEY `idx_response_code` (`response_code`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_api_requests_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_api_requests_api_key` FOREIGN KEY (`api_key_id`) REFERENCES `api_keys` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول جدولة النسخ الاحتياطي
CREATE TABLE IF NOT EXISTS `backup_schedules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('daily','weekly','monthly') NOT NULL,
  `backup_type` enum('database','files','full') NOT NULL DEFAULT 'database',
  `schedule_time` time NOT NULL DEFAULT '02:00:00',
  `day_of_week` int(11) DEFAULT NULL COMMENT 'For weekly backups (0=Sunday, 6=Saturday)',
  `day_of_month` int(11) DEFAULT NULL COMMENT 'For monthly backups (1-31)',
  `status` enum('active','inactive') DEFAULT 'active',
  `last_run` timestamp NULL DEFAULT NULL,
  `next_run` timestamp NULL DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_schedule` (`type`,`backup_type`),
  KEY `idx_status` (`status`),
  KEY `idx_next_run` (`next_run`),
  KEY `idx_admin_id` (`admin_id`),
  CONSTRAINT `fk_backup_schedules_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول سجلات النسخ الاحتياطي
CREATE TABLE IF NOT EXISTS `backup_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `backup_id` int(11) DEFAULT NULL,
  `schedule_id` int(11) DEFAULT NULL,
  `action` enum('create','restore','delete','download','schedule') NOT NULL,
  `status` enum('started','completed','failed') DEFAULT 'started',
  `admin_id` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL COMMENT 'Execution time in seconds',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_backup_id` (`backup_id`),
  KEY `idx_schedule_id` (`schedule_id`),
  KEY `idx_action` (`action`),
  KEY `idx_status` (`status`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_backup_logs_backup` FOREIGN KEY (`backup_id`) REFERENCES `backups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_backup_logs_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `backup_schedules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_backup_logs_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول إعدادات النسخ الاحتياطي
CREATE TABLE IF NOT EXISTS `backup_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_updated_by` (`updated_by`),
  CONSTRAINT `fk_backup_settings_admin` FOREIGN KEY (`updated_by`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول Webhooks
CREATE TABLE IF NOT EXISTS `webhooks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `url` varchar(500) NOT NULL,
  `events` text NOT NULL COMMENT 'JSON array of events to listen for',
  `secret` varchar(255) DEFAULT NULL,
  `headers` text DEFAULT NULL COMMENT 'JSON object of custom headers',
  `timeout` int(11) DEFAULT 30,
  `retry_attempts` int(11) DEFAULT 3,
  `status` enum('active','inactive') DEFAULT 'active',
  `last_triggered` timestamp NULL DEFAULT NULL,
  `success_count` int(11) DEFAULT 0,
  `failure_count` int(11) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_last_triggered` (`last_triggered`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول سجلات Webhooks
CREATE TABLE IF NOT EXISTS `webhook_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `webhook_id` int(11) NOT NULL,
  `event_type` varchar(50) NOT NULL,
  `payload` longtext DEFAULT NULL,
  `response_code` int(11) DEFAULT NULL,
  `response_body` text DEFAULT NULL,
  `response_time` int(11) DEFAULT NULL,
  `status` enum('success','failed','pending') DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `attempt_number` int(11) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_webhook_id` (`webhook_id`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_webhook_logs_webhook` FOREIGN KEY (`webhook_id`) REFERENCES `webhooks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول محفظة المستخدمين (تحديث)
CREATE TABLE IF NOT EXISTS `wallets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `balance` decimal(15,2) DEFAULT 0.00,
  `currency` varchar(3) DEFAULT 'YER',
  `status` enum('active','frozen','suspended') DEFAULT 'active',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_currency` (`user_id`,`currency`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_currency` (`currency`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_wallets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج إعدادات النسخ الاحتياطي الافتراضية
INSERT INTO `backup_settings` (`setting_key`, `setting_value`, `description`) VALUES
('max_backup_files', '10', 'Maximum number of backup files to keep'),
('backup_retention_days', '30', 'Number of days to keep backup files'),
('compression_enabled', '1', 'Enable backup file compression'),
('email_notifications', '1', 'Send email notifications for backup events'),
('notification_email', 'admin@faststarone.com', 'Email address for backup notifications'),
('backup_directory', '/backups/', 'Directory to store backup files'),
('mysql_dump_path', '/usr/bin/mysqldump', 'Path to mysqldump binary'),
('auto_cleanup_enabled', '1', 'Automatically clean up old backup files'),
('backup_verification', '1', 'Verify backup integrity after creation'),
('parallel_backups', '0', 'Allow parallel backup operations')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- إدراج جدولة افتراضية للنسخ الاحتياطي
INSERT INTO `backup_schedules` (`type`, `backup_type`, `schedule_time`, `status`) VALUES
('daily', 'database', '02:00:00', 'active'),
('weekly', 'full', '03:00:00', 'active')
ON DUPLICATE KEY UPDATE status = VALUES(status);

-- إنشاء فهارس إضافية لتحسين الأداء
CREATE INDEX idx_api_requests_user_endpoint ON api_requests(user_id, endpoint);
CREATE INDEX idx_api_requests_created_endpoint ON api_requests(created_at, endpoint);
CREATE INDEX idx_backup_logs_action_status ON backup_logs(action, status);
CREATE INDEX idx_webhook_logs_webhook_status ON webhook_logs(webhook_id, status);

-- إنشاء Views مفيدة
CREATE OR REPLACE VIEW `api_usage_stats` AS
SELECT 
    DATE(created_at) as date,
    endpoint,
    method,
    COUNT(*) as request_count,
    AVG(response_time) as avg_response_time,
    COUNT(CASE WHEN response_code >= 400 THEN 1 END) as error_count,
    COUNT(CASE WHEN response_code < 400 THEN 1 END) as success_count
FROM api_requests
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY DATE(created_at), endpoint, method
ORDER BY date DESC, request_count DESC;

CREATE OR REPLACE VIEW `backup_summary` AS
SELECT 
    b.*,
    bl.action as last_action,
    bl.status as last_status,
    bl.created_at as last_activity,
    a.username as admin_name
FROM backups b
LEFT JOIN backup_logs bl ON b.id = bl.backup_id
LEFT JOIN admins a ON b.admin_id = a.id
WHERE bl.id = (
    SELECT MAX(id) FROM backup_logs WHERE backup_id = b.id
) OR bl.id IS NULL
ORDER BY b.created_at DESC;

-- إنشاء Stored Procedures للنسخ الاحتياطي
DELIMITER $$

CREATE PROCEDURE `CleanupOldBackups`()
BEGIN
    DECLARE retention_days INT DEFAULT 30;
    
    -- Get retention setting
    SELECT CAST(setting_value AS UNSIGNED) INTO retention_days
    FROM backup_settings 
    WHERE setting_key = 'backup_retention_days';
    
    -- Delete old backup records and files
    DELETE FROM backups 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL retention_days DAY)
    AND status = 'completed';
    
    -- Log cleanup action
    INSERT INTO backup_logs (action, status, details)
    VALUES ('cleanup', 'completed', CONCAT('Cleaned up backups older than ', retention_days, ' days'));
END$$

CREATE PROCEDURE `GetBackupStats`()
BEGIN
    SELECT 
        COUNT(*) as total_backups,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as successful_backups,
        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_backups,
        SUM(CASE WHEN DATE(created_at) = CURDATE() THEN 1 ELSE 0 END) as today_backups,
        SUM(size) as total_size,
        AVG(size) as avg_size,
        MAX(created_at) as last_backup_date
    FROM backups;
END$$

CREATE PROCEDURE `GetApiStats`()
BEGIN
    SELECT 
        COUNT(*) as total_requests,
        COUNT(DISTINCT user_id) as unique_users,
        COUNT(CASE WHEN response_code >= 400 THEN 1 END) as error_requests,
        COUNT(CASE WHEN DATE(created_at) = CURDATE() THEN 1 END) as today_requests,
        AVG(response_time) as avg_response_time,
        MAX(created_at) as last_request_date
    FROM api_requests
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY);
END$$

DELIMITER ;

-- إنشاء Events للصيانة التلقائية
CREATE EVENT IF NOT EXISTS `backup_cleanup_event`
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
  CALL CleanupOldBackups();

CREATE EVENT IF NOT EXISTS `api_logs_cleanup_event`
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
  DELETE FROM api_requests 
  WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);

-- إنشاء Triggers للتحديث التلقائي
DELIMITER $$

CREATE TRIGGER `update_api_key_usage` AFTER INSERT ON `api_requests`
FOR EACH ROW
BEGIN
    IF NEW.api_key_id IS NOT NULL THEN
        UPDATE api_keys 
        SET requests_count = requests_count + 1,
            last_used_at = NOW()
        WHERE id = NEW.api_key_id;
    END IF;
END$$

CREATE TRIGGER `backup_status_log` AFTER UPDATE ON `backups`
FOR EACH ROW
BEGIN
    IF OLD.status != NEW.status THEN
        INSERT INTO backup_logs (backup_id, action, status, details)
        VALUES (NEW.id, 'status_change', NEW.status, 
                CONCAT('Status changed from ', OLD.status, ' to ', NEW.status));
    END IF;
END$$

DELIMITER ;

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;

-- إنهاء إعداد جداول النسخ الاحتياطي والAPI
SELECT 'Backup system and API tables created successfully!' as message;
