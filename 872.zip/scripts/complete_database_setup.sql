-- إنشاء قاعدة البيانات
CREATE DATABASE IF NOT EXISTS faststar_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE faststar_db;

-- جدول المستخدمين
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    country VARCHAR(50) DEFAULT 'Yemen',
    wallet_balance_yer DECIMAL(15,2) DEFAULT 0.00,
    wallet_balance_sar DECIMAL(15,2) DEFAULT 0.00,
    wallet_balance_usd DECIMAL(15,2) DEFAULT 0.00,
    wallet_balance_aed DECIMAL(15,2) DEFAULT 0.00,
    wallet_status ENUM('active', 'frozen', 'suspended') DEFAULT 'active',
    status ENUM('active', 'inactive', 'banned') DEFAULT 'active',
    email_verified BOOLEAN DEFAULT FALSE,
    phone_verified BOOLEAN DEFAULT FALSE,
    two_factor_enabled BOOLEAN DEFAULT FALSE,
    two_factor_secret VARCHAR(32),
    last_login TIMESTAMP NULL,
    login_attempts INT DEFAULT 0,
    locked_until TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
);

-- جدول المديرين
CREATE TABLE admin_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('super_admin', 'admin', 'moderator') DEFAULT 'admin',
    permissions JSON,
    status ENUM('active', 'inactive') DEFAULT 'active',
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_role (role),
    INDEX idx_status (status)
);

-- جدول الفئات
CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    name_en VARCHAR(100),
    description TEXT,
    image VARCHAR(255),
    icon VARCHAR(100),
    sort_order INT DEFAULT 0,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_sort_order (sort_order)
);

-- جدول المنتجات
CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_id INT NOT NULL,
    name VARCHAR(200) NOT NULL,
    name_en VARCHAR(200),
    description TEXT,
    image VARCHAR(255),
    price_yer DECIMAL(10,2) NOT NULL,
    price_sar DECIMAL(10,2),
    price_usd DECIMAL(10,2),
    price_aed DECIMAL(10,2),
    discount_percentage DECIMAL(5,2) DEFAULT 0,
    stock_quantity INT DEFAULT 0,
    min_quantity INT DEFAULT 1,
    max_quantity INT DEFAULT 100,
    is_featured BOOLEAN DEFAULT FALSE,
    api_endpoint VARCHAR(255),
    api_method ENUM('GET', 'POST', 'PUT') DEFAULT 'POST',
    api_headers JSON,
    api_params JSON,
    delivery_time VARCHAR(50) DEFAULT 'فوري',
    status ENUM('active', 'inactive', 'out_of_stock') DEFAULT 'active',
    sort_order INT DEFAULT 0,
    views_count INT DEFAULT 0,
    sales_count INT DEFAULT 0,
    rating DECIMAL(3,2) DEFAULT 0.00,
    reviews_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    INDEX idx_category (category_id),
    INDEX idx_status (status),
    INDEX idx_featured (is_featured),
    INDEX idx_price_yer (price_yer),
    INDEX idx_rating (rating),
    INDEX idx_created_at (created_at)
);

-- جدول الطلبات
CREATE TABLE orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'YER',
    discount_amount DECIMAL(10,2) DEFAULT 0,
    coupon_code VARCHAR(50),
    payment_method VARCHAR(50),
    payment_gateway VARCHAR(50),
    transaction_id VARCHAR(100),
    customer_data JSON,
    delivery_data JSON,
    api_response JSON,
    status ENUM('pending', 'processing', 'completed', 'failed', 'cancelled', 'refunded') DEFAULT 'pending',
    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    notes TEXT,
    admin_notes TEXT,
    processed_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    INDEX idx_order_number (order_number),
    INDEX idx_user_id (user_id),
    INDEX idx_product_id (product_id),
    INDEX idx_status (status),
    INDEX idx_payment_status (payment_status),
    INDEX idx_created_at (created_at)
);

-- جدول معاملات المحفظة
CREATE TABLE wallet_transactions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    transaction_id VARCHAR(100) UNIQUE NOT NULL,
    type ENUM('deposit', 'withdrawal', 'purchase', 'refund', 'transfer_in', 'transfer_out', 'bonus') NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'YER',
    balance_before DECIMAL(15,2) NOT NULL,
    balance_after DECIMAL(15,2) NOT NULL,
    description TEXT,
    reference_type ENUM('order', 'payment', 'transfer', 'admin', 'system'),
    reference_id INT,
    payment_method VARCHAR(50),
    payment_gateway VARCHAR(50),
    gateway_transaction_id VARCHAR(100),
    gateway_response JSON,
    status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
    admin_id INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_transaction_id (transaction_id),
    INDEX idx_type (type),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
);

-- جدول بوابات الدفع
CREATE TABLE payment_gateways (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    type ENUM('card', 'wallet', 'bank', 'crypto') DEFAULT 'card',
    logo VARCHAR(255),
    description TEXT,
    supported_currencies JSON,
    min_amount DECIMAL(10,2) DEFAULT 1.00,
    max_amount DECIMAL(10,2) DEFAULT 100000.00,
    fee_percentage DECIMAL(5,2) DEFAULT 0.00,
    fee_fixed DECIMAL(10,2) DEFAULT 0.00,
    api_url VARCHAR(255),
    api_key VARCHAR(255),
    api_secret VARCHAR(255),
    webhook_url VARCHAR(255),
    test_mode BOOLEAN DEFAULT TRUE,
    config JSON,
    status ENUM('active', 'inactive', 'maintenance') DEFAULT 'active',
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_code (code),
    INDEX idx_status (status),
    INDEX idx_sort_order (sort_order)
);

-- جدول الإشعارات
CREATE TABLE notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    admin_id INT,
    type ENUM('info', 'success', 'warning', 'error', 'order', 'payment', 'wallet', 'system') DEFAULT 'info',
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    data JSON,
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP NULL,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_type (type),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at)
);

-- جدول سجل الأنشطة
CREATE TABLE activity_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    admin_id INT,
    action VARCHAR(100) NOT NULL,
    description TEXT,
    data JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (admin_id) REFERENCES admin_users(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_admin_id (admin_id),
    INDEX idx_action (action),
    INDEX idx_created_at (created_at)
);

-- جدول إعدادات النظام
CREATE TABLE system_settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category VARCHAR(50) NOT NULL DEFAULT 'general',
    setting_key VARCHAR(100) NOT NULL,
    setting_value TEXT,
    description TEXT,
    type ENUM('text', 'number', 'boolean', 'json', 'file') DEFAULT 'text',
    is_public BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_setting (category, setting_key),
    INDEX idx_category (category),
    INDEX idx_key (setting_key)
);

-- جدول مفاتيح API
CREATE TABLE api_keys (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    admin_id INT,
    name VARCHAR(100) NOT NULL,
    api_key VARCHAR(64) UNIQUE NOT NULL,
    api_secret VARCHAR(128),
    permissions JSON,
    rate_limit INT DEFAULT 1000,
    allowed_ips TEXT,
    last_used_at TIMESTAMP NULL,
    expires_at TIMESTAMP NULL,
    status ENUM('active', 'inactive', 'expired') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (admin_id) REFERENCES admin_users(id) ON DELETE CASCADE,
    INDEX idx_api_key (api_key),
    INDEX idx_user_id (user_id),
    INDEX idx_status (status)
);

-- جدول الكوبونات
CREATE TABLE coupons (
    id INT PRIMARY KEY AUTO_INCREMENT,
    code VARCHAR(50) UNIQUE NOT NULL,
    type ENUM('percentage', 'fixed') DEFAULT 'percentage',
    value DECIMAL(10,2) NOT NULL,
    min_amount DECIMAL(10,2) DEFAULT 0,
    max_discount DECIMAL(10,2),
    usage_limit INT,
    used_count INT DEFAULT 0,
    user_limit INT DEFAULT 1,
    applicable_products JSON,
    applicable_categories JSON,
    starts_at TIMESTAMP NULL,
    expires_at TIMESTAMP NULL,
    status ENUM('active', 'inactive', 'expired') DEFAULT 'active',
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES admin_users(id) ON DELETE SET NULL,
    INDEX idx_code (code),
    INDEX idx_status (status),
    INDEX idx_expires_at (expires_at)
);

-- جدول استخدام الكوبونات
CREATE TABLE coupon_usage (
    id INT PRIMARY KEY AUTO_INCREMENT,
    coupon_id INT NOT NULL,
    user_id INT NOT NULL,
    order_id INT,
    discount_amount DECIMAL(10,2) NOT NULL,
    used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (coupon_id) REFERENCES coupons(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
    INDEX idx_coupon_id (coupon_id),
    INDEX idx_user_id (user_id),
    INDEX idx_used_at (used_at)
);

-- جدول التقييمات
CREATE TABLE reviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    user_id INT NOT NULL,
    order_id INT,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    title VARCHAR(200),
    comment TEXT,
    is_verified BOOLEAN DEFAULT FALSE,
    is_approved BOOLEAN DEFAULT FALSE,
    admin_reply TEXT,
    replied_at TIMESTAMP NULL,
    replied_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
    FOREIGN KEY (replied_by) REFERENCES admin_users(id) ON DELETE SET NULL,
    UNIQUE KEY unique_user_product (user_id, product_id),
    INDEX idx_product_id (product_id),
    INDEX idx_user_id (user_id),
    INDEX idx_rating (rating),
    INDEX idx_approved (is_approved)
);

-- جدول الأسئلة الشائعة
CREATE TABLE faqs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category VARCHAR(100) DEFAULT 'عام',
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    sort_order INT DEFAULT 0,
    views_count INT DEFAULT 0,
    is_featured BOOLEAN DEFAULT FALSE,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES admin_users(id) ON DELETE SET NULL,
    INDEX idx_category (category),
    INDEX idx_status (status),
    INDEX idx_featured (is_featured),
    INDEX idx_sort_order (sort_order)
);

-- جدول تذاكر الدعم
CREATE TABLE support_tickets (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ticket_number VARCHAR(20) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    category ENUM('technical', 'payment', 'account', 'general', 'complaint') DEFAULT 'general',
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    subject VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('open', 'in_progress', 'waiting_user', 'resolved', 'closed') DEFAULT 'open',
    assigned_to INT,
    last_reply_by ENUM('user', 'admin'),
    last_reply_at TIMESTAMP NULL,
    resolved_at TIMESTAMP NULL,
    closed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_to) REFERENCES admin_users(id) ON DELETE SET NULL,
    INDEX idx_ticket_number (ticket_number),
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_priority (priority),
    INDEX idx_created_at (created_at)
);

-- جدول ردود تذاكر الدعم
CREATE TABLE support_ticket_replies (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ticket_id INT NOT NULL,
    user_id INT,
    admin_id INT,
    message TEXT NOT NULL,
    attachments JSON,
    is_internal BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES support_tickets(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (admin_id) REFERENCES admin_users(id) ON DELETE CASCADE,
    INDEX idx_ticket_id (ticket_id),
    INDEX idx_created_at (created_at)
);

-- جدول سجلات API
CREATE TABLE api_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    api_key_id INT,
    endpoint VARCHAR(255) NOT NULL,
    method VARCHAR(10) NOT NULL,
    request_data JSON,
    response_data JSON,
    response_code INT,
    response_time DECIMAL(8,3),
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (api_key_id) REFERENCES api_keys(id) ON DELETE SET NULL,
    INDEX idx_endpoint (endpoint),
    INDEX idx_method (method),
    INDEX idx_response_code (response_code),
    INDEX idx_created_at (created_at)
);

-- إدراج البيانات الأساسية

-- إدراج المدير الافتراضي
INSERT INTO admin_users (username, email, password, full_name, role, status) VALUES
('admin', 'admin@faststarone.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'مدير النظام', 'super_admin', 'active');

-- إدراج مستخدم تجريبي
INSERT INTO users (username, email, password, full_name, phone, wallet_balance_yer, status, email_verified) VALUES
('testuser', 'test@faststarone.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'مستخدم تجريبي', '+967771234567', 10000.00, 'active', TRUE);

-- إدراج الفئات
INSERT INTO categories (name, name_en, description, icon, sort_order, status) VALUES
('ألعاب الهاتف', 'Mobile Games', 'شحن ألعاب الهاتف المحمول', 'fas fa-mobile-alt', 1, 'active'),
('بطاقات الألعاب', 'Game Cards', 'بطاقات شحن الألعاب المختلفة', 'fas fa-gamepad', 2, 'active'),
('تطبيقات التواصل', 'Social Apps', 'شحن تطبيقات التواصل الاجتماعي', 'fas fa-comments', 3, 'active'),
('خدمات الترفيه', 'Entertainment', 'خدمات الترفيه والمحتوى', 'fas fa-play-circle', 4, 'active'),
('بطاقات الهدايا', 'Gift Cards', 'بطاقات الهدايا المختلفة', 'fas fa-gift', 5, 'active');

-- إدراج المنتجات
INSERT INTO products (category_id, name, name_en, description, price_yer, price_sar, price_usd, price_aed, is_featured, delivery_time, status) VALUES
-- ألعاب الهاتف
(1, 'شحن PUBG Mobile - 60 UC', 'PUBG Mobile 60 UC', 'شحن 60 UC لعبة ببجي موبايل', 750.00, 3.00, 2.00, 7.35, TRUE, 'فوري', 'active'),
(1, 'شحن PUBG Mobile - 325 UC', 'PUBG Mobile 325 UC', 'شحن 325 UC لعبة ببجي موبايل', 3750.00, 15.00, 10.00, 36.75, TRUE, 'فوري', 'active'),
(1, 'شحن PUBG Mobile - 660 UC', 'PUBG Mobile 660 UC', 'شحن 660 UC لعبة ببجي موبايل', 7500.00, 30.00, 20.00, 73.50, FALSE, 'فوري', 'active'),
(1, 'شحن Free Fire - 100 جوهرة', 'Free Fire 100 Diamonds', 'شحن 100 جوهرة لعبة فري فاير', 500.00, 2.00, 1.33, 4.90, TRUE, 'فوري', 'active'),
(1, 'شحن Free Fire - 520 جوهرة', 'Free Fire 520 Diamonds', 'شحن 520 جوهرة لعبة فري فاير', 2500.00, 10.00, 6.67, 24.50, FALSE, 'فوري', 'active'),

-- بطاقات الألعاب
(2, 'بطاقة Steam - 10 دولار', 'Steam Gift Card $10', 'بطاقة هدية ستيم بقيمة 10 دولار', 3750.00, 15.00, 10.00, 36.75, TRUE, '5-10 دقائق', 'active'),
(2, 'بطاقة Steam - 20 دولار', 'Steam Gift Card $20', 'بطاقة هدية ستيم بقيمة 20 دولار', 7500.00, 30.00, 20.00, 73.50, FALSE, '5-10 دقائق', 'active'),
(2, 'بطاقة PlayStation - 10 دولار', 'PlayStation Gift Card $10', 'بطاقة هدية بلايستيشن بقيمة 10 دولار', 3750.00, 15.00, 10.00, 36.75, FALSE, '5-10 دقائق', 'active'),

-- تطبيقات التواصل
(3, 'شحن TikTok - 100 عملة', 'TikTok 100 Coins', 'شحن 100 عملة تيك توك', 375.00, 1.50, 1.00, 3.68, TRUE, 'فوري', 'active'),
(3, 'شحن TikTok - 500 عملة', 'TikTok 500 Coins', 'شحن 500 عملة تيك توك', 1875.00, 7.50, 5.00, 18.38, FALSE, 'فوري', 'active'),
(3, 'شحن Snapchat+', 'Snapchat Plus', 'اشتراك سناب شات بلس شهري', 1125.00, 4.50, 3.00, 11.03, FALSE, 'فوري', 'active'),

-- خدمات الترفيه
(4, 'اشتراك Netflix - شهر', 'Netflix 1 Month', 'اشتراك نتفليكس لمدة شهر', 3750.00, 15.00, 10.00, 36.75, TRUE, '1-2 ساعة', 'active'),
(4, 'اشتراك Spotify - شهر', 'Spotify Premium 1 Month', 'اشتراك سبوتيفاي بريميوم لمدة شهر', 2250.00, 9.00, 6.00, 22.05, FALSE, '1-2 ساعة', 'active'),
(4, 'اشتراك YouTube Premium - شهر', 'YouTube Premium 1 Month', 'اشتراك يوتيوب بريميوم لمدة شهر', 2625.00, 10.50, 7.00, 25.73, FALSE, '1-2 ساعة', 'active'),

-- بطاقات الهدايا
(5, 'بطاقة Google Play - 10 دولار', 'Google Play Gift Card $10', 'بطاقة هدية جوجل بلاي بقيمة 10 دولار', 3750.00, 15.00, 10.00, 36.75, TRUE, '5-10 دقائق', 'active'),
(5, 'بطاقة iTunes - 10 دولار', 'iTunes Gift Card $10', 'بطاقة هدية آيتونز بقيمة 10 دولار', 3750.00, 15.00, 10.00, 36.75, FALSE, '5-10 دقائق', 'active'),
(5, 'بطاقة Amazon - 25 دولار', 'Amazon Gift Card $25', 'بطاقة هدية أمازون بقيمة 25 دولار', 9375.00, 37.50, 25.00, 91.88, FALSE, '10-30 دقيقة', 'active');

-- إدراج بوابات الدفع
INSERT INTO payment_gateways (name, code, type, description, supported_currencies, min_amount, max_amount, fee_percentage, status, sort_order) VALUES
('PayPal', 'paypal', 'card', 'الدفع عبر PayPal', '["USD", "EUR", "SAR"]', 1.00, 10000.00, 3.5, 'active', 1),
('Stripe', 'stripe', 'card', 'الدفع عبر Stripe', '["USD", "EUR", "AED", "SAR"]', 1.00, 50000.00, 2.9, 'active', 2),
('مدى', 'mada', 'card', 'الدفع عبر بطاقات مدى', '["SAR"]', 10.00, 10000.00, 2.0, 'active', 3),
('المحفظة اليمنية', 'yemen_wallet', 'wallet', 'الدفع عبر المحفظة اليمنية', '["YER"]', 100.00, 100000.00, 1.5, 'active', 4),
('STC Pay', 'stc_pay', 'wallet', 'الدفع عبر STC Pay', '["SAR"]', 5.00, 5000.00, 1.0, 'active', 5);

-- إدراج إعدادات النظام
INSERT INTO system_settings (category, setting_key, setting_value, description, type, is_public) VALUES
('general', 'site_name', 'فاست ستار', 'اسم الموقع', 'text', TRUE),
('general', 'site_description', 'منصة شحن الألعاب والتطبيقات', 'وصف الموقع', 'text', TRUE),
('general', 'site_keywords', 'شحن ألعاب, بطاقات هدايا, PUBG, Free Fire', 'كلمات مفتاحية', 'text', TRUE),
('general', 'contact_email', 'info@faststarone.com', 'بريد التواصل', 'text', TRUE),
('general', 'contact_phone', '+967-1-234567', 'رقم التواصل', 'text', TRUE),
('general', 'maintenance_mode', '0', 'وضع الصيانة', 'boolean', FALSE),
('general', 'registration_enabled', '1', 'تفعيل التسجيل', 'boolean', FALSE),
('general', 'email_verification_required', '1', 'تفعيل التحقق من الإيميل', 'boolean', FALSE),
('payment', 'min_wallet_topup', '100', 'أقل مبلغ لشحن المحفظة', 'number', FALSE),
('payment', 'max_wallet_topup', '100000', 'أكبر مبلغ لشحن المحفظة', 'number', FALSE),
('security', 'max_login_attempts', '5', 'عدد محاولات تسجيل الدخول', 'number', FALSE),
('security', 'lockout_duration', '30', 'مدة القفل بالدقائق', 'number', FALSE);

-- إدراج الأسئلة الشائعة
INSERT INTO faqs (category, question, answer, sort_order, is_featured, status) VALUES
('عام', 'كيف يمكنني إنشاء حساب جديد؟', 'يمكنك إنشاء حساب جديد من خلال النقر على زر "تسجيل" في أعلى الصفحة وملء البيانات المطلوبة.', 1, TRUE, 'active'),
('عام', 'كيف يمكنني شحن محفظتي؟', 'يمكنك شحن محفظتك من خلال الذهاب إلى صفحة المحفظة واختيار طريقة الدفع المناسبة.', 2, TRUE, 'active'),
('الدفع', 'ما هي طرق الدفع المتاحة؟', 'نوفر عدة طرق دفع منها: PayPal، Stripe، مدى، المحفظة اليمنية، وSTC Pay.', 3, TRUE, 'active'),
('الدفع', 'هل الدفع آمن؟', 'نعم، جميع المعاملات محمية بأحدث تقنيات التشفير والأمان.', 4, FALSE, 'active'),
('الطلبات', 'كم يستغرق تنفيذ الطلب؟', 'معظم الطلبات يتم تنفيذها فورياً، وبعضها قد يستغرق من 5-30 دقيقة حسب نوع الخدمة.', 5, TRUE, 'active'),
('الطلبات', 'ماذا لو لم أستلم طلبي؟', 'في حالة عدم استلام الطلب خلال المدة المحددة، يرجى التواصل مع الدعم الفني.', 6, FALSE, 'active');

-- إنشاء المشاهدات للتقارير
CREATE VIEW sales_summary AS
SELECT 
    DATE(created_at) as sale_date,
    COUNT(*) as total_orders,
    SUM(total_amount) as total_revenue,
    AVG(total_amount) as avg_order_value,
    COUNT(DISTINCT user_id) as unique_customers
FROM orders 
WHERE status = 'completed' 
GROUP BY DATE(created_at);

CREATE VIEW product_performance AS
SELECT 
    p.id,
    p.name,
    c.name as category_name,
    COUNT(o.id) as total_orders,
    SUM(o.total_amount) as total_revenue,
    AVG(o.total_amount) as avg_order_value,
    p.views_count,
    p.rating,
    p.reviews_count
FROM products p
LEFT JOIN orders o ON p.id = o.product_id AND o.status = 'completed'
LEFT JOIN categories c ON p.category_id = c.id
GROUP BY p.id;

CREATE VIEW user_statistics AS
SELECT 
    u.id,
    u.username,
    u.full_name,
    u.created_at as registration_date,
    COUNT(o.id) as total_orders,
    SUM(o.total_amount) as total_spent,
    (u.wallet_balance_yer + u.wallet_balance_sar + u.wallet_balance_usd + u.wallet_balance_aed) as total_wallet_balance,
    u.last_login
FROM users u
LEFT JOIN orders o ON u.id = o.user_id AND o.status = 'completed'
GROUP BY u.id;

-- إنشاء المحفزات
DELIMITER //

CREATE TRIGGER update_product_rating AFTER INSERT ON reviews
FOR EACH ROW
BEGIN
    UPDATE products 
    SET rating = (
        SELECT AVG(rating) 
        FROM reviews 
        WHERE product_id = NEW.product_id AND is_approved = TRUE
    ),
    reviews_count = (
        SELECT COUNT(*) 
        FROM reviews 
        WHERE product_id = NEW.product_id AND is_approved = TRUE
    )
    WHERE id = NEW.product_id;
END//

CREATE TRIGGER update_product_sales AFTER UPDATE ON orders
FOR EACH ROW
BEGIN
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        UPDATE products 
        SET sales_count = sales_count + NEW.quantity
        WHERE id = NEW.product_id;
    END IF;
END//

CREATE TRIGGER log_wallet_transaction AFTER UPDATE ON users
FOR EACH ROW
BEGIN
    IF NEW.wallet_balance_yer != OLD.wallet_balance_yer THEN
        INSERT INTO activity_logs (user_id, action, description, data)
        VALUES (NEW.id, 'wallet_update', 'تم تحديث رصيد المحفظة اليمنية', 
                JSON_OBJECT('old_balance', OLD.wallet_balance_yer, 'new_balance', NEW.wallet_balance_yer));
    END IF;
END//

DELIMITER ;

-- إنشاء الأحداث المجدولة
CREATE EVENT IF NOT EXISTS cleanup_old_logs
ON SCHEDULE EVERY 1 WEEK
DO
BEGIN
    DELETE FROM activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 3 MONTH);
    DELETE FROM api_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 MONTH);
END;

CREATE EVENT IF NOT EXISTS update_expired_coupons
ON SCHEDULE EVERY 1 HOUR
DO
BEGIN
    UPDATE coupons SET status = 'expired' WHERE expires_at < NOW() AND status = 'active';
END;

-- إنشاء الفهارس الإضافية للأداء
CREATE INDEX idx_orders_user_status ON orders(user_id, status);
CREATE INDEX idx_orders_created_status ON orders(created_at, status);
CREATE INDEX idx_wallet_transactions_user_type ON wallet_transactions(user_id, type);
CREATE INDEX idx_products_category_status ON products(category_id, status);
CREATE INDEX idx_notifications_user_read ON notifications(user_id, is_read);

-- تحسين إعدادات قاعدة البيانات
SET GLOBAL innodb_buffer_pool_size = 268435456; -- 256MB
SET GLOBAL query_cache_size = 67108864; -- 64MB
SET GLOBAL query_cache_type = ON;

COMMIT;
