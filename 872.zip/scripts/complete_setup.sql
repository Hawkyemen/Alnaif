-- إعداد قاعدة البيانات الكاملة لسبرة سوفت
-- Complete Database Setup for Sabrah Soft

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

-- إنشاء قاعدة البيانات
CREATE DATABASE IF NOT EXISTS `sabrahsoft` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `sabrahsoft`;

-- جدول المستخدمين
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `wallet_balance_yer` decimal(10,2) DEFAULT 0.00,
  `wallet_balance_sar` decimal(10,2) DEFAULT 0.00,
  `wallet_balance_usd` decimal(10,2) DEFAULT 0.00,
  `wallet_balance_aed` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `email_verified` tinyint(1) DEFAULT 0,
  `phone_verified` tinyint(1) DEFAULT 0,
  `last_login` timestamp NULL DEFAULT NULL,
  `login_attempts` int(11) DEFAULT 0,
  `locked_until` timestamp NULL DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول المديرين
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `role` enum('super_admin','admin','manager','support') DEFAULT 'admin',
  `permissions` text DEFAULT NULL,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `last_login` timestamp NULL DEFAULT NULL,
  `login_attempts` int(11) DEFAULT 0,
  `locked_until` timestamp NULL DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_role` (`role`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول الفئات
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('games','chat','social','entertainment','wallet','other') DEFAULT 'other',
  `icon` varchar(100) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول المنتجات
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `name_ar` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `description_ar` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `price_yer` decimal(10,2) DEFAULT 0.00,
  `price_sar` decimal(10,2) DEFAULT 0.00,
  `price_usd` decimal(10,2) DEFAULT 0.00,
  `price_aed` decimal(10,2) DEFAULT 0.00,
  `discount_percentage` decimal(5,2) DEFAULT 0.00,
  `min_amount` decimal(10,2) DEFAULT NULL,
  `max_amount` decimal(10,2) DEFAULT NULL,
  `customer_id_label` varchar(100) DEFAULT 'معرف العميل',
  `customer_id_placeholder` varchar(100) DEFAULT 'أدخل معرف العميل',
  `instructions` text DEFAULT NULL,
  `instructions_ar` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `status` enum('active','inactive','out_of_stock') DEFAULT 'active',
  `featured` tinyint(1) DEFAULT 0,
  `total_sales` int(11) DEFAULT 0,
  `rating` decimal(3,2) DEFAULT 0.00,
  `rating_count` int(11) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_status` (`status`),
  KEY `idx_featured` (`featured`),
  KEY `idx_sort_order` (`sort_order`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول الطلبات
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL DEFAULT 'YER',
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_gateway` varchar(50) DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `gateway_transaction_id` varchar(100) DEFAULT NULL,
  `status` enum('pending','processing','completed','failed','cancelled','refunded') DEFAULT 'pending',
  `payment_status` enum('pending','paid','failed','refunded') DEFAULT 'pending',
  `charging_status` enum('pending','processing','completed','failed') DEFAULT 'pending',
  `charging_response` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `admin_notes` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_status` (`status`),
  KEY `idx_payment_status` (`payment_status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_transaction_id` (`transaction_id`),
  CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_orders_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول معاملات المحفظة
CREATE TABLE IF NOT EXISTS `wallet_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` enum('deposit','withdrawal','purchase','refund','bonus','penalty') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL DEFAULT 'YER',
  `balance_before` decimal(10,2) DEFAULT 0.00,
  `balance_after` decimal(10,2) DEFAULT 0.00,
  `description` varchar(255) DEFAULT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `status` enum('pending','completed','failed','cancelled') DEFAULT 'pending',
  `admin_id` int(11) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_transaction_id` (`transaction_id`),
  CONSTRAINT `fk_wallet_transactions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول بوابات الدفع
CREATE TABLE IF NOT EXISTS `payment_gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `config` text DEFAULT NULL,
  `supported_currencies` varchar(255) DEFAULT 'YER,SAR,USD',
  `min_amount` decimal(10,2) DEFAULT 0.00,
  `max_amount` decimal(10,2) DEFAULT 0.00,
  `fees_percentage` decimal(5,2) DEFAULT 0.00,
  `fees_fixed` decimal(10,2) DEFAULT 0.00,
  `sort_order` int(11) DEFAULT 0,
  `status` enum('active','inactive','maintenance') DEFAULT 'active',
  `test_mode` tinyint(1) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_status` (`status`),
  KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول معاملات الدفع
CREATE TABLE IF NOT EXISTS `payment_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `gateway_id` int(11) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `gateway_transaction_id` varchar(100) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `fees` decimal(10,2) DEFAULT 0.00,
  `status` enum('pending','processing','completed','failed','cancelled','refunded') DEFAULT 'pending',
  `payment_method` varchar(50) DEFAULT NULL,
  `gateway_response` text DEFAULT NULL,
  `callback_data` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_gateway_id` (`gateway_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_payment_transactions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_payment_transactions_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_payment_transactions_gateway` FOREIGN KEY (`gateway_id`) REFERENCES `payment_gateways` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول APIs الشحن
CREATE TABLE IF NOT EXISTS `charging_apis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `api_url` varchar(500) NOT NULL,
  `method` enum('GET','POST','PUT','DELETE') DEFAULT 'POST',
  `headers` text DEFAULT NULL,
  `api_key` varchar(255) DEFAULT NULL,
  `request_template` text DEFAULT NULL,
  `response_mapping` text DEFAULT NULL,
  `success_indicators` text DEFAULT NULL,
  `error_indicators` text DEFAULT NULL,
  `timeout` int(11) DEFAULT 30,
  `retry_attempts` int(11) DEFAULT 3,
  `retry_delay` int(11) DEFAULT 5,
  `success_rate` decimal(5,2) DEFAULT 100.00,
  `last_used` timestamp NULL DEFAULT NULL,
  `total_requests` int(11) DEFAULT 0,
  `successful_requests` int(11) DEFAULT 0,
  `failed_requests` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `priority` int(11) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_priority` (`priority`),
  CONSTRAINT `fk_charging_apis_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_charging_apis_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول سجلات API
CREATE TABLE IF NOT EXISTS `api_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_type` varchar(50) NOT NULL,
  `endpoint` varchar(500) NOT NULL,
  `method` varchar(10) NOT NULL,
  `request_data` text DEFAULT NULL,
  `response_data` text DEFAULT NULL,
  `http_code` int(11) DEFAULT NULL,
  `response_time` int(11) DEFAULT NULL,
  `status` enum('success','error','timeout') DEFAULT 'success',
  `error_message` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_api_type` (`api_type`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول أسعار الصرف
CREATE TABLE IF NOT EXISTS `exchange_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_currency` varchar(3) NOT NULL,
  `to_currency` varchar(3) NOT NULL,
  `rate` decimal(10,6) NOT NULL,
  `source` varchar(50) DEFAULT 'manual',
  `last_updated` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `currency_pair` (`from_currency`,`to_currency`),
  KEY `idx_from_currency` (`from_currency`),
  KEY `idx_to_currency` (`to_currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول الإعدادات
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('string','number','boolean','json','text') DEFAULT 'string',
  `description` varchar(255) DEFAULT NULL,
  `group_name` varchar(50) DEFAULT 'general',
  `is_public` tinyint(1) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_group_name` (`group_name`),
  KEY `idx_is_public` (`is_public`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول الإشعارات
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `data` text DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_type` (`type`),
  KEY `idx_is_read` (`is_read`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_notifications_admin` FOREIGN KEY (`admin_id`) REFERENCES `admin_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج أسعار الصرف الافتراضية
INSERT INTO `exchange_rates` (`from_currency`, `to_currency`, `rate`) VALUES
('USD', 'YER', 375.00),
('SAR', 'YER', 100.00),
('AED', 'YER', 102.00),
('YER', 'USD', 0.00267),
('YER', 'SAR', 0.01),
('YER', 'AED', 0.0098),
('USD', 'SAR', 3.75),
('SAR', 'USD', 0.267),
('USD', 'AED', 3.67),
('AED', 'USD', 0.272),
('SAR', 'AED', 0.98),
('AED', 'SAR', 1.02);

-- إدراج الإعدادات الافتراضية
INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_type`, `description`, `group_name`) VALUES
('site_name', 'سبرة سوفت', 'string', 'اسم الموقع', 'general'),
('site_description', 'منصة شحن الألعاب والتطبيقات', 'text', 'وصف الموقع', 'general'),
('default_currency', 'YER', 'string', 'العملة الافتراضية', 'payment'),
('min_order_amount', '10', 'number', 'الحد الأدنى لمبلغ الطلب', 'payment'),
('max_order_amount', '100000', 'number', 'الحد الأقصى لمبلغ الطلب', 'payment'),
('payment_timeout', '300', 'number', 'مهلة الدفع بالثواني', 'payment'),
('api_rate_limit', '100', 'number', 'حد معدل API في الدقيقة', 'api'),
('api_timeout', '30', 'number', 'مهلة انتظار API بالثواني', 'api'),
('enable_api_logs', '1', 'boolean', 'تفعيل سجلات API', 'api'),
('log_retention_days', '30', 'number', 'مدة الاحتفاظ بالسجلات', 'api'),
('max_login_attempts', '5', 'number', 'الحد الأقصى لمحاولات تسجيل الدخول', 'security'),
('lockout_duration', '300', 'number', 'مدة الحظر بالثواني', 'security'),
('session_timeout', '3600', 'number', 'مهلة انتهاء الجلسة', 'security'),
('password_min_length', '8', 'number', 'الحد الأدنى لطول كلمة المرور', 'security'),
('maintenance_mode', '0', 'boolean', 'وضع الصيانة', 'general'),
('auto_complete_orders', '1', 'boolean', 'إكمال الطلبات تلقائياً', 'payment');

-- إنشاء مدير افتراضي
INSERT INTO `admin_users` (`username`, `email`, `password`, `full_name`, `role`, `status`) VALUES
('admin', 'admin@sabrahsoft.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'مدير النظام', 'super_admin', 'active');

-- إدراج الفئات الافتراضية
INSERT INTO `categories` (`name`, `name_ar`, `description`, `type`, `icon`, `sort_order`, `status`) VALUES
('Mobile Games', 'ألعاب الجوال', 'شحن ألعاب الهواتف الذكية الشائعة', 'games', 'fas fa-mobile-alt', 1, 'active'),
('PC Games', 'ألعاب الكمبيوتر', 'شحن ألعاب الكمبيوتر ومنصات الألعاب', 'games', 'fas fa-desktop', 2, 'active'),
('Console Games', 'ألعاب الكونسول', 'شحن ألعاب البلايستيشن والإكس بوكس', 'games', 'fas fa-gamepad', 3, 'active'),
('Chat Applications', 'تطبيقات الدردشة', 'شحن تطبيقات الدردشة والمراسلة الفورية', 'chat', 'fas fa-comments', 4, 'active'),
('Social Media', 'التواصل الاجتماعي', 'شحن منصات التواصل الاجتماعي', 'social', 'fas fa-share-alt', 5, 'active');

-- إدراج المنتجات الافتراضية
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(1, 'PUBG Mobile UC', 'شدات ببجي موبايل', 'PUBG Mobile Unknown Cash for in-game purchases', 'شدات ببجي موبايل للشراء داخل اللعبة', 375.00, 10.00, 1.00, 3.67, 'Player ID', 'معرف اللاعب', 'Enter your PUBG Mobile Player ID (found in game profile)', 'أدخل معرف اللاعب في ببجي موبايل (موجود في ملف اللاعب)', 1, 'active', 1),
(1, 'Free Fire Diamonds', 'جواهر فري فاير', 'Free Fire Diamonds for character upgrades and skins', 'جواهر فري فاير لترقية الشخصيات والأشكال', 750.00, 20.00, 2.00, 7.34, 'Player ID', 'معرف اللاعب', 'Enter your Free Fire Player ID (found in profile)', 'أدخل معرف اللاعب في فري فاير (موجود في الملف الشخصي)', 2, 'active', 1),
(1, 'Mobile Legends Diamonds', 'جواهر موبايل ليجندز', 'Mobile Legends Bang Bang Diamonds', 'جواهر موبايل ليجندز بانج بانج', 562.50, 15.00, 1.50, 5.51, 'User ID', 'معرف المستخدم', 'Enter your Mobile Legends User ID and Zone ID', 'أدخل معرف المستخدم ومعرف المنطقة في موبايل ليجندز', 3, 'active', 1),
(2, 'Steam Wallet', 'محفظة ستيم', 'Steam Wallet credit for game purchases', 'رصيد محفظة ستيم لشراء الألعاب', 1875.00, 50.00, 5.00, 18.35, 'Steam Username', 'اسم المستخدم في ستيم', 'Enter your Steam username or profile URL', 'أدخل اسم المستخدم أو رابط الملف الشخصي في ستيم', 1, 'active', 1),
(2, 'Fortnite V-Bucks', 'في-باكس فورتنايت', 'Fortnite V-Bucks for skins and items', 'في-باكس فورتنايت للأشكال والعناصر', 937.50, 25.00, 2.50, 9.18, 'Epic Games Username', 'اسم المستخدم في إيبك جيمز', 'Enter your Epic Games username', 'أدخل اسم المستخدم في إيبك جيمز', 2, 'active', 1),
(3, 'PlayStation Store', 'متجر بلايستيشن', 'PlayStation Store credit for games and DLC', 'رصيد متجر بلايستيشن للألعاب والمحتوى الإضافي', 1875.00, 50.00, 5.00, 18.35, 'PSN Email', 'البريد الإلكتروني لـ PSN', 'Enter your PlayStation Network email', 'أدخل البريد الإلكتروني لشبكة بلايستيشن', 1, 'active', 1),
(4, 'WhatsApp Business API Credits', 'رصيد واتساب بيزنس', 'WhatsApp Business API messaging credits for businesses', 'رصيد إرسال الرسائل عبر واتساب بيزنس للشركات', 1875.00, 50.00, 5.00, 18.35, 'Business Phone Number', 'رقم الهاتف التجاري', 'Enter your registered WhatsApp Business phone number', 'أدخل رقم هاتف واتساب بيزنس المسجل', 1, 'active', 1),
(4, 'Telegram Premium', 'تيليجرام بريميوم', 'Telegram Premium subscription with advanced features', 'اشتراك تيليجرام بريميوم مع الميزات المتقدمة', 1125.00, 30.00, 3.00, 11.01, 'Telegram Username', 'اسم المستخدم في تيليجرام', 'Enter your Telegram username (without @)', 'أدخل اسم المستخدم في تيليجرام (بدون @)', 2, 'active', 1),
(5, 'Facebook Ads Credit', 'رصيد إعلانات فيسبوك', 'Facebook advertising credits for business promotion', 'رصيد الإعلانات في فيسبوك للترويج التجاري', 3750.00, 100.00, 10.00, 36.70, 'Facebook Page ID', 'معرف صفحة فيسبوك', 'Enter your Facebook business page ID', 'أدخل معرف صفحة فيسبوك التجارية', 1, 'active', 1),
(5, 'YouTube Premium', 'يوتيوب بريميوم', 'YouTube Premium subscription without ads', 'اشتراك يوتيوب بريميوم بدون إعلانات', 4500.00, 120.00, 12.00, 44.04, 'YouTube Channel', 'قناة يوتيوب', 'Enter your YouTube channel URL or ID', 'أدخل رابط أو معرف قناة يوتيوب', 2, 'active', 1);

-- إدراج بوابات الدفع الافتراضية
INSERT INTO `payment_gateways` (`code`, `name`, `name_ar`, `description`, `supported_currencies`, `min_amount`, `max_amount`, `fees_percentage`, `fees_fixed`, `sort_order`, `status`, `test_mode`) VALUES
('paypal', 'PayPal', 'باي بال', 'PayPal payment gateway for international transactions', 'USD,EUR,SAR', 1.00, 10000.00, 3.49, 0.49, 1, 'active', 1),
('stripe', 'Stripe', 'سترايب', 'Stripe payment processing for cards', 'USD,EUR,SAR,AED', 0.50, 999999.99, 2.90, 0.30, 2, 'active', 1),
('mada', 'Mada', 'مدى', 'Saudi Mada payment system', 'SAR', 1.00, 50000.00, 1.75, 0.00, 3, 'active', 1),
('yemen_mobile', 'Yemen Mobile Money', 'المحفظة الإلكترونية اليمنية', 'Yemen mobile money services', 'YER', 100.00, 500000.00, 2.00, 5.00, 4, 'active', 1),
('bank_transfer', 'Bank Transfer', 'حوالة بنكية', 'Direct bank transfer', 'YER,SAR,USD', 1000.00, 1000000.00, 0.00, 0.00, 5, 'active', 0);

-- إنشاء الفهارس الإضافية لتحسين الأداء
CREATE INDEX idx_orders_user_status ON orders(user_id, status);
CREATE INDEX idx_orders_product_status ON orders(product_id, status);
CREATE INDEX idx_wallet_transactions_user_type ON wallet_transactions(user_id, type);
CREATE INDEX idx_payment_transactions_gateway_status ON payment_transactions(gateway_id, status);
CREATE INDEX idx_api_logs_type_status ON api_logs(api_type, status);

-- إنشاء Views مفيدة
CREATE VIEW `order_summary` AS
SELECT 
    o.id,
    o.user_id,
    u.username,
    o.product_id,
    p.name_ar as product_name,
    c.name_ar as category_name,
    o.amount,
    o.currency,
    o.status,
    o.payment_status,
    o.created_at
FROM orders o
JOIN users u ON o.user_id = u.id
JOIN products p ON o.product_id = p.id
JOIN categories c ON p.category_id = c.id;

CREATE VIEW `user_wallet_summary` AS
SELECT 
    u.id,
    u.username,
    u.email,
    u.wallet_balance_yer,
    u.wallet_balance_sar,
    u.wallet_balance_usd,
    u.wallet_balance_aed,
    COUNT(wt.id) as total_transactions,
    SUM(CASE WHEN wt.type = 'deposit' THEN wt.amount ELSE 0 END) as total_deposits,
    SUM(CASE WHEN wt.type = 'withdrawal' THEN wt.amount ELSE 0 END) as total_withdrawals
FROM users u
LEFT JOIN wallet_transactions wt ON u.id = wt.user_id
GROUP BY u.id;

-- إنشاء Triggers للتحديث التلقائي
DELIMITER $$

CREATE TRIGGER `update_wallet_balance` AFTER INSERT ON `wallet_transactions`
FOR EACH ROW
BEGIN
    CASE NEW.currency
        WHEN 'YER' THEN
            UPDATE users SET wallet_balance_yer = NEW.balance_after WHERE id = NEW.user_id;
        WHEN 'SAR' THEN
            UPDATE users SET wallet_balance_sar = NEW.balance_after WHERE id = NEW.user_id;
        WHEN 'USD' THEN
            UPDATE users SET wallet_balance_usd = NEW.balance_after WHERE id = NEW.user_id;
        WHEN 'AED' THEN
            UPDATE users SET wallet_balance_aed = NEW.balance_after WHERE id = NEW.user_id;
    END CASE;
END$$

CREATE TRIGGER `update_product_sales` AFTER UPDATE ON `orders`
FOR EACH ROW
BEGIN
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        UPDATE products SET total_sales = total_sales + 1 WHERE id = NEW.product_id;
    END IF;
END$$

DELIMITER ;

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;

-- إنهاء إعداد قاعدة البيانات
SELECT 'Database setup completed successfully!' as message;
SELECT 'Default admin: username=admin, password=admin' as admin_info;
