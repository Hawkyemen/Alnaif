-- إنشاء الجداول المفقودة للنظام

-- جدول المديرين
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `role` enum('admin','super_admin') DEFAULT 'admin',
  `status` enum('active','inactive') DEFAULT 'active',
  `login_attempts` int(11) DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول بوابات الدفع
CREATE TABLE IF NOT EXISTS `payment_gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` text,
  `config` json DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `is_sandbox` tinyint(1) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول APIs الشحن
CREATE TABLE IF NOT EXISTS `charging_apis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `config` json DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول معاملات الدفع
CREATE TABLE IF NOT EXISTS `payment_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `gateway_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `gateway_transaction_id` varchar(255) DEFAULT NULL,
  `gateway_response` json DEFAULT NULL,
  `status` enum('pending','completed','failed','cancelled') DEFAULT 'pending',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id` (`transaction_id`),
  KEY `user_id` (`user_id`),
  KEY `order_id` (`order_id`),
  KEY `gateway_id` (`gateway_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول المحافظ
CREATE TABLE IF NOT EXISTS `wallets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `balance_yer` decimal(10,2) DEFAULT 0.00,
  `balance_sar` decimal(10,2) DEFAULT 0.00,
  `balance_usd` decimal(10,2) DEFAULT 0.00,
  `balance_aed` decimal(10,2) DEFAULT 0.00,
  `is_frozen` tinyint(1) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول معاملات المحفظة
CREATE TABLE IF NOT EXISTS `wallet_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` enum('deposit','withdraw','transfer') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `balance_before` decimal(10,2) NOT NULL,
  `balance_after` decimal(10,2) NOT NULL,
  `description` text,
  `reference_id` varchar(100) DEFAULT NULL,
  `status` enum('pending','completed','failed') DEFAULT 'completed',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `reference_id` (`reference_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول الإشعارات
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `data` json DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `is_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول رموز API للتطبيق المحمول
CREATE TABLE IF NOT EXISTS `api_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `device_info` json DEFAULT NULL,
  `last_used` datetime DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `user_id` (`user_id`),
  KEY `expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول سجل النشاطات
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `description` text,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `data` json DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `admin_id` (`admin_id`),
  KEY `action` (`action`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- جدول إعدادات النظام
CREATE TABLE IF NOT EXISTS `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `value` text,
  `type` enum('string','number','boolean','json') DEFAULT 'string',
  `description` text,
  `is_public` tinyint(1) DEFAULT 0,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج بيانات افتراضية لبوابات الدفع
INSERT IGNORE INTO `payment_gateways` (`name`, `code`, `description`, `config`, `is_active`, `is_sandbox`) VALUES
('PayPal', 'paypal', 'PayPal Payment Gateway', '{"client_id": "", "client_secret": "", "webhook_id": ""}', 0, 1),
('Stripe', 'stripe', 'Stripe Payment Gateway', '{"public_key": "", "secret_key": "", "webhook_secret": ""}', 0, 1),
('مدى', 'mada', 'Mada Payment Gateway', '{"merchant_id": "", "api_key": "", "terminal_id": ""}', 0, 1),
('Apple Pay', 'apple_pay', 'Apple Pay Integration', '{"merchant_id": "", "certificate_path": ""}', 0, 1),
('Google Pay', 'google_pay', 'Google Pay Integration', '{"merchant_id": "", "api_key": ""}', 0, 1);

-- إدراج بيانات افتراضية لـ APIs الشحن
INSERT IGNORE INTO `charging_apis` (`name`, `code`, `config`, `is_active`) VALUES
('API الشحن الرئيسي', 'main_charging', '{"api_url": "", "api_key": "", "timeout": 30}', 0),
('API الألعاب', 'games_api', '{"api_url": "", "api_key": "", "timeout": 30}', 0),
('API التطبيقات', 'apps_api', '{"api_url": "", "api_key": "", "timeout": 30}', 0);

-- إدراج إعدادات النظام الافتراضية
INSERT IGNORE INTO `system_settings` (`key`, `value`, `type`, `description`, `is_public`) VALUES
('site_name', 'نظام الشحن الإلكتروني', 'string', 'اسم الموقع', 1),
('site_description', 'منصة شحن الألعاب والتطبيقات', 'string', 'وصف الموقع', 1),
('default_currency', 'YER', 'string', 'العملة الافتراضية', 1),
('min_wallet_deposit', '100', 'number', 'أقل مبلغ إيداع في المحفظة', 0),
('max_wallet_deposit', '100000', 'number', 'أكبر مبلغ إيداع في المحفظة', 0),
('email_notifications', 'true', 'boolean', 'تفعيل إشعارات البريد الإلكتروني', 0),
('sms_notifications', 'false', 'boolean', 'تفعيل إشعارات الرسائل النصية', 0),
('maintenance_mode', 'false', 'boolean', 'وضع الصيانة', 0),
('registration_enabled', 'true', 'boolean', 'تفعيل التسجيل الجديد', 0),
('api_rate_limit', '100', 'number', 'حد استخدام API في الساعة', 0);

-- إنشاء مدير افتراضي إذا لم يكن موجوداً
INSERT IGNORE INTO `admin_users` (`username`, `email`, `password`, `full_name`, `role`, `status`) VALUES
('admin', 'admin@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'مدير النظام', 'super_admin', 'active');

-- إضافة فهارس إضافية لتحسين الأداء
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at);
CREATE INDEX IF NOT EXISTS idx_users_status ON users(status);
CREATE INDEX IF NOT EXISTS idx_products_status ON products(status);
CREATE INDEX IF NOT EXISTS idx_products_featured ON products(is_featured);
CREATE INDEX IF NOT EXISTS idx_categories_status ON categories(status);

-- تحديث بنية الجداول الموجودة إذا لزم الأمر
ALTER TABLE `users` 
ADD COLUMN IF NOT EXISTS `phone_verified_at` datetime DEFAULT NULL,
ADD COLUMN IF NOT EXISTS `email_verified_at` datetime DEFAULT NULL,
ADD COLUMN IF NOT EXISTS `two_factor_enabled` tinyint(1) DEFAULT 0,
ADD COLUMN IF NOT EXISTS `two_factor_secret` varchar(255) DEFAULT NULL;

ALTER TABLE `orders` 
ADD COLUMN IF NOT EXISTS `delivery_status` enum('pending','processing','delivered','failed') DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS `delivery_details` json DEFAULT NULL,
ADD COLUMN IF NOT EXISTS `refund_status` enum('none','requested','approved','rejected','completed') DEFAULT 'none',
ADD COLUMN IF NOT EXISTS `refund_reason` text DEFAULT NULL;

ALTER TABLE `products` 
ADD COLUMN IF NOT EXISTS `min_quantity` int(11) DEFAULT 1,
ADD COLUMN IF NOT EXISTS `max_quantity` int(11) DEFAULT 1,
ADD COLUMN IF NOT EXISTS `stock_quantity` int(11) DEFAULT -1,
ADD COLUMN IF NOT EXISTS `auto_delivery` tinyint(1) DEFAULT 0;

-- إنشاء triggers للمحافظ
DELIMITER $$

CREATE TRIGGER IF NOT EXISTS `create_wallet_after_user_insert`
AFTER INSERT ON `users`
FOR EACH ROW
BEGIN
    INSERT INTO `wallets` (`user_id`) VALUES (NEW.id);
END$$

DELIMITER ;

-- إنشاء views مفيدة
CREATE OR REPLACE VIEW `user_wallet_summary` AS
SELECT 
    u.id as user_id,
    u.username,
    u.email,
    w.balance_yer,
    w.balance_sar,
    w.balance_usd,
    w.balance_aed,
    w.is_frozen,
    COUNT(wt.id) as transaction_count,
    MAX(wt.created_at) as last_transaction
FROM users u
LEFT JOIN wallets w ON u.id = w.user_id
LEFT JOIN wallet_transactions wt ON u.id = wt.user_id
GROUP BY u.id;

CREATE OR REPLACE VIEW `order_summary` AS
SELECT 
    o.id,
    o.order_number,
    u.username,
    p.name as product_name,
    o.total_amount,
    o.currency,
    o.status,
    o.delivery_status,
    o.created_at
FROM orders o
JOIN users u ON o.user_id = u.id
JOIN products p ON o.product_id = p.id;

-- إنشاء stored procedures مفيدة
DELIMITER $$

CREATE PROCEDURE IF NOT EXISTS `GetUserStats`(IN user_id INT)
BEGIN
    SELECT 
        COUNT(DISTINCT o.id) as total_orders,
        SUM(CASE WHEN o.status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
        SUM(CASE WHEN o.status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
        SUM(CASE WHEN o.status = 'completed' THEN o.total_amount ELSE 0 END) as total_spent,
        w.balance_yer,
        w.balance_sar,
        w.balance_usd,
        w.balance_aed
    FROM users u
    LEFT JOIN orders o ON u.id = o.user_id
    LEFT JOIN wallets w ON u.id = w.user_id
    WHERE u.id = user_id
    GROUP BY u.id;
END$$

DELIMITER ;

-- إنشاء events للتنظيف التلقائي
SET GLOBAL event_scheduler = ON;

DELIMITER $$

CREATE EVENT IF NOT EXISTS `cleanup_expired_tokens`
ON SCHEDULE EVERY 1 HOUR
DO
BEGIN
    DELETE FROM api_tokens WHERE expires_at < NOW();
END$$

CREATE EVENT IF NOT EXISTS `cleanup_old_logs`
ON SCHEDULE EVERY 1 DAY
DO
BEGIN
    DELETE FROM activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY);
END$$

DELIMITER ;

-- إنشاء functions مفيدة
DELIMITER $$

CREATE FUNCTION IF NOT EXISTS `GenerateOrderNumber`() RETURNS VARCHAR(20)
READS SQL DATA
DETERMINISTIC
BEGIN
    DECLARE order_num VARCHAR(20);
    DECLARE counter INT DEFAULT 1;
    
    REPEAT
        SET order_num = CONCAT('ORD', DATE_FORMAT(NOW(), '%Y%m%d'), LPAD(FLOOR(RAND() * 10000), 4, '0'));
        SELECT COUNT(*) INTO counter FROM orders WHERE order_number = order_num;
    UNTIL counter = 0 END REPEAT;
    
    RETURN order_num;
END$$

DELIMITER ;

-- إنشاء جدول للنسخ الاحتياطية
CREATE TABLE IF NOT EXISTS `backup_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `size` bigint(20) NOT NULL,
  `type` enum('full','incremental') DEFAULT 'full',
  `status` enum('success','failed') NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول لإحصائيات النظام
CREATE TABLE IF NOT EXISTS `system_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `total_users` int(11) DEFAULT 0,
  `total_orders` int(11) DEFAULT 0,
  `total_revenue` decimal(15,2) DEFAULT 0.00,
  `successful_orders` int(11) DEFAULT 0,
  `failed_orders` int(11) DEFAULT 0,
  `new_registrations` int(11) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء stored procedure لحساب الإحصائيات اليومية
DELIMITER $$

CREATE PROCEDURE IF NOT EXISTS `CalculateDailyStats`(IN target_date DATE)
BEGIN
    INSERT INTO system_stats (
        date, total_users, total_orders, total_revenue, 
        successful_orders, failed_orders, new_registrations
    ) VALUES (
        target_date,
        (SELECT COUNT(*) FROM users WHERE DATE(created_at) <= target_date),
        (SELECT COUNT(*) FROM orders WHERE DATE(created_at) = target_date),
        (SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE DATE(created_at) = target_date AND status = 'completed'),
        (SELECT COUNT(*) FROM orders WHERE DATE(created_at) = target_date AND status = 'completed'),
        (SELECT COUNT(*) FROM orders WHERE DATE(created_at) = target_date AND status = 'failed'),
        (SELECT COUNT(*) FROM users WHERE DATE(created_at) = target_date)
    ) ON DUPLICATE KEY UPDATE
        total_users = VALUES(total_users),
        total_orders = VALUES(total_orders),
        total_revenue = VALUES(total_revenue),
        successful_orders = VALUES(successful_orders),
        failed_orders = VALUES(failed_orders),
        new_registrations = VALUES(new_registrations);
END$$

DELIMITER ;

-- إنشاء event لحساب الإحصائيات اليومية تلقائياً
DELIMITER $$

CREATE EVENT IF NOT EXISTS `daily_stats_calculation`
ON SCHEDULE EVERY 1 DAY
STARTS TIMESTAMP(CURRENT_DATE + INTERVAL 1 DAY, '01:00:00')
DO
BEGIN
    CALL CalculateDailyStats(CURDATE() - INTERVAL 1 DAY);
END$$

DELIMITER ;

-- إنهاء السكريبت
SELECT 'تم إنشاء جميع الجداول والإعدادات بنجاح!' as message;
