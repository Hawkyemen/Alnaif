-- إنشاء قاعدة البيانات الأساسية لفاست ستار
-- FastStar Database Setup

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

-- إنشاء جدول المستخدمين
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `wallet_balance_yer` decimal(10,2) DEFAULT 0.00,
  `wallet_balance_sar` decimal(10,2) DEFAULT 0.00,
  `wallet_balance_usd` decimal(10,2) DEFAULT 0.00,
  `wallet_balance_aed` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `email_verified` tinyint(1) DEFAULT 0,
  `phone_verified` tinyint(1) DEFAULT 0,
  `last_login` timestamp NULL DEFAULT NULL,
  `login_attempts` int(11) DEFAULT 0,
  `locked_until` timestamp NULL DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول المديرين
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `role` enum('super_admin','admin','manager','support') DEFAULT 'admin',
  `permissions` text DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `last_login` timestamp NULL DEFAULT NULL,
  `login_attempts` int(11) DEFAULT 0,
  `locked_until` timestamp NULL DEFAULT NULL,
  `two_factor_secret` varchar(32) DEFAULT NULL,
  `two_factor_enabled` tinyint(1) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_role` (`role`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول الفئات
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('games','chat','social','entertainment','wallet','other') DEFAULT 'other',
  `icon` varchar(100) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول المنتجات
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `name_ar` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `description_ar` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `price_yer` decimal(10,2) DEFAULT 0.00,
  `price_sar` decimal(10,2) DEFAULT 0.00,
  `price_usd` decimal(10,2) DEFAULT 0.00,
  `price_aed` decimal(10,2) DEFAULT 0.00,
  `discount_percentage` decimal(5,2) DEFAULT 0.00,
  `min_amount` decimal(10,2) DEFAULT NULL,
  `max_amount` decimal(10,2) DEFAULT NULL,
  `customer_id_label` varchar(100) DEFAULT 'معرف العميل',
  `customer_id_placeholder` varchar(100) DEFAULT 'أدخل معرف العميل',
  `instructions` text DEFAULT NULL,
  `instructions_ar` text DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `status` enum('active','inactive','out_of_stock') DEFAULT 'active',
  `featured` tinyint(1) DEFAULT 0,
  `total_sales` int(11) DEFAULT 0,
  `rating` decimal(3,2) DEFAULT 0.00,
  `rating_count` int(11) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_status` (`status`),
  KEY `idx_featured` (`featured`),
  KEY `idx_sort_order` (`sort_order`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول الطلبات
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL DEFAULT 'YER',
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_gateway` varchar(50) DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `gateway_transaction_id` varchar(100) DEFAULT NULL,
  `status` enum('pending','processing','completed','failed','cancelled','refunded') DEFAULT 'pending',
  `payment_status` enum('pending','paid','failed','refunded') DEFAULT 'pending',
  `charging_status` enum('pending','processing','completed','failed') DEFAULT 'pending',
  `charging_response` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `admin_notes` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_status` (`status`),
  KEY `idx_payment_status` (`payment_status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_transaction_id` (`transaction_id`),
  CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_orders_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول معاملات المحفظة
CREATE TABLE IF NOT EXISTS `wallet_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` enum('deposit','withdrawal','purchase','refund','bonus','penalty') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL DEFAULT 'YER',
  `balance_before` decimal(10,2) DEFAULT 0.00,
  `balance_after` decimal(10,2) DEFAULT 0.00,
  `description` varchar(255) DEFAULT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `status` enum('pending','completed','failed','cancelled') DEFAULT 'pending',
  `admin_id` int(11) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_transaction_id` (`transaction_id`),
  CONSTRAINT `fk_wallet_transactions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول بوابات الدفع
CREATE TABLE IF NOT EXISTS `payment_gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `config` text DEFAULT NULL,
  `supported_currencies` varchar(255) DEFAULT 'YER,SAR,USD',
  `min_amount` decimal(10,2) DEFAULT 0.00,
  `max_amount` decimal(10,2) DEFAULT 0.00,
  `fees_percentage` decimal(5,2) DEFAULT 0.00,
  `fees_fixed` decimal(10,2) DEFAULT 0.00,
  `sort_order` int(11) DEFAULT 0,
  `status` enum('active','inactive','maintenance') DEFAULT 'active',
  `test_mode` tinyint(1) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `idx_status` (`status`),
  KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول معاملات الدفع
CREATE TABLE IF NOT EXISTS `payment_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `gateway_id` int(11) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `gateway_transaction_id` varchar(100) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) NOT NULL,
  `fees` decimal(10,2) DEFAULT 0.00,
  `status` enum('pending','processing','completed','failed','cancelled','refunded') DEFAULT 'pending',
  `payment_method` varchar(50) DEFAULT NULL,
  `gateway_response` text DEFAULT NULL,
  `callback_data` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_id` (`transaction_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_gateway_id` (`gateway_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_payment_transactions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_payment_transactions_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_payment_transactions_gateway` FOREIGN KEY (`gateway_id`) REFERENCES `payment_gateways` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول APIs الشحن
CREATE TABLE IF NOT EXISTS `charging_apis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `api_url` varchar(500) NOT NULL,
  `method` enum('GET','POST','PUT','DELETE') DEFAULT 'POST',
  `headers` text DEFAULT NULL,
  `api_key` varchar(255) DEFAULT NULL,
  `request_template` text DEFAULT NULL,
  `response_mapping` text DEFAULT NULL,
  `success_indicators` text DEFAULT NULL,
  `error_indicators` text DEFAULT NULL,
  `timeout` int(11) DEFAULT 30,
  `retry_attempts` int(11) DEFAULT 3,
  `retry_delay` int(11) DEFAULT 5,
  `success_rate` decimal(5,2) DEFAULT 100.00,
  `last_used` timestamp NULL DEFAULT NULL,
  `total_requests` int(11) DEFAULT 0,
  `successful_requests` int(11) DEFAULT 0,
  `failed_requests` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `priority` int(11) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_is_active` (`is_active`),
  KEY `idx_priority` (`priority`),
  CONSTRAINT `fk_charging_apis_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_charging_apis_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول سجلات API
CREATE TABLE IF NOT EXISTS `api_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_type` varchar(50) NOT NULL,
  `endpoint` varchar(500) NOT NULL,
  `method` varchar(10) NOT NULL,
  `request_data` text DEFAULT NULL,
  `response_data` text DEFAULT NULL,
  `http_code` int(11) DEFAULT NULL,
  `response_time` int(11) DEFAULT NULL,
  `status` enum('success','error','timeout') DEFAULT 'success',
  `error_message` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_api_type` (`api_type`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول أسعار الصرف
CREATE TABLE IF NOT EXISTS `exchange_rates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_currency` varchar(3) NOT NULL,
  `to_currency` varchar(3) NOT NULL,
  `rate` decimal(10,6) NOT NULL,
  `source` varchar(50) DEFAULT 'manual',
  `last_updated` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `currency_pair` (`from_currency`,`to_currency`),
  KEY `idx_from_currency` (`from_currency`),
  KEY `idx_to_currency` (`to_currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول الإعدادات
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('string','number','boolean','json','text') DEFAULT 'string',
  `description` varchar(255) DEFAULT NULL,
  `group_name` varchar(50) DEFAULT 'general',
  `is_public` tinyint(1) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_group_name` (`group_name`),
  KEY `idx_is_public` (`is_public`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول الإشعارات
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `data` text DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_type` (`type`),
  KEY `idx_is_read` (`is_read`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_notifications_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول جلسات المستخدمين
CREATE TABLE IF NOT EXISTS `user_sessions` (
  `id` varchar(128) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  `last_activity` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_last_activity` (`last_activity`),
  CONSTRAINT `fk_user_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_user_sessions_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول النسخ الاحتياطية
CREATE TABLE IF NOT EXISTS `backups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `type` enum('database','files','full') DEFAULT 'database',
  `size` bigint(20) DEFAULT NULL,
  `status` enum('pending','completed','failed') DEFAULT 'pending',
  `admin_id` int(11) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_backups_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج أسعار الصرف الافتراضية
INSERT INTO `exchange_rates` (`from_currency`, `to_currency`, `rate`) VALUES
('USD', 'YER', 375.00),
('SAR', 'YER', 100.00),
('AED', 'YER', 102.00),
('YER', 'USD', 0.00267),
('YER', 'SAR', 0.01),
('YER', 'AED', 0.0098),
('USD', 'SAR', 3.75),
('SAR', 'USD', 0.267),
('USD', 'AED', 3.67),
('AED', 'USD', 0.272),
('SAR', 'AED', 0.98),
('AED', 'SAR', 1.02);

-- إدراج الإعدادات الافتراضية
INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_type`, `description`, `group_name`) VALUES
('site_name', 'فاست ستار', 'string', 'اسم الموقع', 'general'),
('site_description', 'منصة شحن الألعاب والتطبيقات', 'text', 'وصف الموقع', 'general'),
('default_currency', 'YER', 'string', 'العملة الافتراضية', 'payment'),
('min_order_amount', '10', 'number', 'الحد الأدنى لمبلغ الطلب', 'payment'),
('max_order_amount', '100000', 'number', 'الحد الأقصى لمبلغ الطلب', 'payment'),
('payment_timeout', '300', 'number', 'مهلة الدفع بالثواني', 'payment'),
('api_rate_limit', '100', 'number', 'حد معدل API في الدقيقة', 'api'),
('api_timeout', '30', 'number', 'مهلة انتظار API بالثواني', 'api'),
('enable_api_logs', '1', 'boolean', 'تفعيل سجلات API', 'api'),
('log_retention_days', '30', 'number', 'مدة الاحتفاظ بالسجلات', 'api'),
('max_login_attempts', '5', 'number', 'الحد الأقصى لمحاولات تسجيل الدخول', 'security'),
('lockout_duration', '300', 'number', 'مدة الحظر بالثواني', 'security'),
('session_timeout', '3600', 'number', 'مهلة انتهاء الجلسة', 'security'),
('password_min_length', '8', 'number', 'الحد الأدنى لطول كلمة المرور', 'security'),
('maintenance_mode', '0', 'boolean', 'وضع الصيانة', 'general'),
('auto_complete_orders', '1', 'boolean', 'إكمال الطلبات تلقائياً', 'payment');

-- إنشاء مستخدم مدير افتراضي
INSERT INTO `admins` (`username`, `email`, `password`, `full_name`, `role`, `status`) VALUES
('admin', 'admin@faststar.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'مدير النظام', 'super_admin', 'active');

-- إنشاء الفهارس الإضافية لتحسين الأداء
CREATE INDEX idx_orders_user_status ON orders(user_id, status);
CREATE INDEX idx_orders_product_status ON orders(product_id, status);
CREATE INDEX idx_wallet_transactions_user_type ON wallet_transactions(user_id, type);
CREATE INDEX idx_payment_transactions_gateway_status ON payment_transactions(gateway_id, status);
CREATE INDEX idx_api_logs_type_status ON api_logs(api_type, status);

-- إنشاء Views مفيدة
CREATE VIEW `order_summary` AS
SELECT 
    o.id,
    o.user_id,
    u.username,
    o.product_id,
    p.name_ar as product_name,
    c.name_ar as category_name,
    o.amount,
    o.currency,
    o.status,
    o.payment_status,
    o.created_at
FROM orders o
JOIN users u ON o.user_id = u.id
JOIN products p ON o.product_id = p.id
JOIN categories c ON p.category_id = c.id;

CREATE VIEW `user_wallet_summary` AS
SELECT 
    u.id,
    u.username,
    u.email,
    u.wallet_balance_yer,
    u.wallet_balance_sar,
    u.wallet_balance_usd,
    u.wallet_balance_aed,
    COUNT(wt.id) as total_transactions,
    SUM(CASE WHEN wt.type = 'deposit' THEN wt.amount ELSE 0 END) as total_deposits,
    SUM(CASE WHEN wt.type = 'withdrawal' THEN wt.amount ELSE 0 END) as total_withdrawals
FROM users u
LEFT JOIN wallet_transactions wt ON u.id = wt.user_id
GROUP BY u.id;

-- إنشاء Triggers للتحديث التلقائي
DELIMITER $$

CREATE TRIGGER `update_wallet_balance` AFTER INSERT ON `wallet_transactions`
FOR EACH ROW
BEGIN
    CASE NEW.currency
        WHEN 'YER' THEN
            UPDATE users SET wallet_balance_yer = NEW.balance_after WHERE id = NEW.user_id;
        WHEN 'SAR' THEN
            UPDATE users SET wallet_balance_sar = NEW.balance_after WHERE id = NEW.user_id;
        WHEN 'USD' THEN
            UPDATE users SET wallet_balance_usd = NEW.balance_after WHERE id = NEW.user_id;
        WHEN 'AED' THEN
            UPDATE users SET wallet_balance_aed = NEW.balance_after WHERE id = NEW.user_id;
    END CASE;
END$$

CREATE TRIGGER `update_product_sales` AFTER UPDATE ON `orders`
FOR EACH ROW
BEGIN
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        UPDATE products SET total_sales = total_sales + 1 WHERE id = NEW.product_id;
    END IF;
END$$

CREATE TRIGGER `update_api_stats` AFTER INSERT ON `api_logs`
FOR EACH ROW
BEGIN
    IF NEW.api_type = 'charging' THEN
        UPDATE charging_apis 
        SET 
            total_requests = total_requests + 1,
            successful_requests = CASE WHEN NEW.status = 'success' THEN successful_requests + 1 ELSE successful_requests END,
            failed_requests = CASE WHEN NEW.status = 'error' THEN failed_requests + 1 ELSE failed_requests END,
            success_rate = (successful_requests / total_requests) * 100,
            last_used = NOW()
        WHERE id = (
            SELECT ca.id FROM charging_apis ca 
            JOIN products p ON ca.product_id = p.id 
            JOIN orders o ON p.id = o.product_id 
            WHERE o.id = NEW.order_id 
            LIMIT 1
        );
    END IF;
END$$

DELIMITER ;

-- إنشاء Events للصيانة التلقائية
SET GLOBAL event_scheduler = ON;

DELIMITER $$

CREATE EVENT `cleanup_old_logs`
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    DELETE FROM api_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
    DELETE FROM user_sessions WHERE last_activity < DATE_SUB(NOW(), INTERVAL 7 DAY);
END$$

CREATE EVENT `update_exchange_rates`
ON SCHEDULE EVERY 1 HOUR
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    -- يمكن إضافة كود لتحديث أسعار الصرف من مصدر خارجي
    UPDATE exchange_rates SET last_updated = NOW() WHERE source = 'auto';
END$$

DELIMITER ;

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;

-- إنهاء إعداد قاعدة البيانات
SELECT 'Database setup completed successfully!' as message;
