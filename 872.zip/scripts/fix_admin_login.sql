-- إصلاح مشاكل تسجيل دخول المدير وتحسين الأمان
-- Fix Admin Login Issues and Improve Security

-- التأكد من وجود جدول المديرين بالهيكل الصحيح
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `role` enum('super_admin','admin','manager','support') DEFAULT 'admin',
  `permissions` text DEFAULT NULL,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `last_login` timestamp NULL DEFAULT NULL,
  `login_attempts` int(11) DEFAULT 0,
  `locked_until` timestamp NULL DEFAULT NULL,
  `two_factor_secret` varchar(32) DEFAULT NULL,
  `two_factor_enabled` tinyint(1) DEFAULT 0,
  `password_reset_token` varchar(100) DEFAULT NULL,
  `password_reset_expires` timestamp NULL DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_role` (`role`),
  KEY `idx_status` (`status`),
  KEY `idx_last_login` (`last_login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- حذف المدير الافتراضي القديم إذا كان موجوداً
DELETE FROM admins WHERE username = 'admin' AND email = 'admin@faststar.com';

-- إنشاء مدير جديد بكلمة مرور قوية
-- كلمة المرور: FastStar@2024
INSERT INTO `admins` (`username`, `email`, `password`, `full_name`, `role`, `status`, `permissions`) VALUES
('admin', 'admin@faststar.com', '$2y$12$LQv3c1yqBz.hP4vBiiFMyOO0D2bV.wt0Hpj/EJiop6OMlAYu5O8m6', 'مدير النظام الرئيسي', 'super_admin', 'active', '{"all": true}'),
('manager', 'manager@faststar.com', '$2y$12$LQv3c1yqBz.hP4vBiiFMyOO0D2bV.wt0Hpj/EJiop6OMlAYu5O8m6', 'مدير العمليات', 'manager', 'active', '{"orders": true, "products": true, "users": true, "reports": true}'),
('support', 'support@faststar.com', '$2y$12$LQv3c1yqBz.hP4vBiiFMyOO0D2bV.wt0Hpj/EJiop6OMlAYu5O8m6', 'موظف الدعم الفني', 'support', 'active', '{"orders": true, "users": true, "api_logs": true}');

-- إنشاء جدول محاولات تسجيل الدخول
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `user_type` enum('admin','user') NOT NULL,
  `username` varchar(100) NOT NULL,
  `success` tinyint(1) DEFAULT 0,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ip_address` (`ip_address`),
  KEY `idx_user_type` (`user_type`),
  KEY `idx_username` (`username`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_success` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول الجلسات النشطة
CREATE TABLE IF NOT EXISTS `active_sessions` (
  `id` varchar(128) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `user_type` enum('admin','user') NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `last_activity` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `data` text DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_user_type` (`user_type`),
  KEY `idx_last_activity` (`last_activity`),
  CONSTRAINT `fk_active_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_active_sessions_admin` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول سجل أنشطة المديرين
CREATE TABLE IF NOT EXISTS `admin_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `target_type` varchar(50) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  `old_values` text DEFAULT NULL,
  `new_values` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_admin_id` (`admin_id`),
  KEY `idx_action` (`action`),
  KEY `idx_target_type` (`target_type`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `fk_admin_activity_log` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إنشاء جدول الأذونات المفصلة
CREATE TABLE IF NOT EXISTS `admin_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `permission` varchar(100) NOT NULL,
  `granted` tinyint(1) DEFAULT 1,
  `granted_by` int(11) DEFAULT NULL,
  `granted_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_permission` (`admin_id`,`permission`),
  KEY `idx_permission` (`permission`),
  KEY `idx_granted` (`granted`),
  KEY `idx_expires_at` (`expires_at`),
  CONSTRAINT `fk_admin_permissions` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_admin_permissions_granted_by` FOREIGN KEY (`granted_by`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج الأذونات الأساسية للمدير الرئيسي
INSERT INTO `admin_permissions` (`admin_id`, `permission`, `granted_by`) 
SELECT 
    (SELECT id FROM admins WHERE username = 'admin'),
    permission,
    (SELECT id FROM admins WHERE username = 'admin')
FROM (
    SELECT 'dashboard.view' as permission
    UNION ALL SELECT 'users.view'
    UNION ALL SELECT 'users.create'
    UNION ALL SELECT 'users.edit'
    UNION ALL SELECT 'users.delete'
    UNION ALL SELECT 'products.view'
    UNION ALL SELECT 'products.create'
    UNION ALL SELECT 'products.edit'
    UNION ALL SELECT 'products.delete'
    UNION ALL SELECT 'categories.view'
    UNION ALL SELECT 'categories.create'
    UNION ALL SELECT 'categories.edit'
    UNION ALL SELECT 'categories.delete'
    UNION ALL SELECT 'orders.view'
    UNION ALL SELECT 'orders.edit'
    UNION ALL SELECT 'orders.delete'
    UNION ALL SELECT 'orders.refund'
    UNION ALL SELECT 'wallets.view'
    UNION ALL SELECT 'wallets.edit'
    UNION ALL SELECT 'wallets.transactions'
    UNION ALL SELECT 'payments.view'
    UNION ALL SELECT 'payments.manage'
    UNION ALL SELECT 'api.view'
    UNION ALL SELECT 'api.manage'
    UNION ALL SELECT 'reports.view'
    UNION ALL SELECT 'reports.export'
    UNION ALL SELECT 'settings.view'
    UNION ALL SELECT 'settings.edit'
    UNION ALL SELECT 'admins.view'
    UNION ALL SELECT 'admins.create'
    UNION ALL SELECT 'admins.edit'
    UNION ALL SELECT 'admins.delete'
    UNION ALL SELECT 'logs.view'
    UNION ALL SELECT 'backup.create'
    UNION ALL SELECT 'backup.restore'
    UNION ALL SELECT 'system.maintenance'
) as permissions;

-- إدراج أذونات محدودة للمدير العادي
INSERT INTO `admin_permissions` (`admin_id`, `permission`, `granted_by`) 
SELECT 
    (SELECT id FROM admins WHERE username = 'manager'),
    permission,
    (SELECT id FROM admins WHERE username = 'admin')
FROM (
    SELECT 'dashboard.view' as permission
    UNION ALL SELECT 'users.view'
    UNION ALL SELECT 'users.edit'
    UNION ALL SELECT 'products.view'
    UNION ALL SELECT 'products.edit'
    UNION ALL SELECT 'categories.view'
    UNION ALL SELECT 'orders.view'
    UNION ALL SELECT 'orders.edit'
    UNION ALL SELECT 'wallets.view'
    UNION ALL SELECT 'payments.view'
    UNION ALL SELECT 'reports.view'
    UNION ALL SELECT 'logs.view'
) as permissions;

-- إدراج أذونات الدعم الفني
INSERT INTO `admin_permissions` (`admin_id`, `permission`, `granted_by`) 
SELECT 
    (SELECT id FROM admins WHERE username = 'support'),
    permission,
    (SELECT id FROM admins WHERE username = 'admin')
FROM (
    SELECT 'dashboard.view' as permission
    UNION ALL SELECT 'users.view'
    UNION ALL SELECT 'orders.view'
    UNION ALL SELECT 'orders.edit'
    UNION ALL SELECT 'wallets.view'
    UNION ALL SELECT 'api.view'
    UNION ALL SELECT 'logs.view'
) as permissions;

-- تحديث إعدادات الأمان
INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_type`, `description`, `group_name`) VALUES
('admin_session_timeout', '7200', 'number', 'مهلة انتهاء جلسة المدير (ثانية)', 'security'),
('admin_max_login_attempts', '3', 'number', 'الحد الأقصى لمحاولات تسجيل دخول المدير', 'security'),
('admin_lockout_duration', '900', 'number', 'مدة حظر المدير بعد المحاولات الفاشلة (ثانية)', 'security'),
('admin_require_strong_password', '1', 'boolean', 'إجبار كلمات مرور قوية للمديرين', 'security'),
('admin_password_expiry_days', '90', 'number', 'انتهاء صلاحية كلمة مرور المدير (أيام)', 'security'),
('admin_two_factor_required', '0', 'boolean', 'إجبار المصادقة الثنائية للمديرين', 'security'),
('admin_ip_whitelist', '', 'text', 'قائمة عناوين IP المسموحة للمديرين', 'security'),
('admin_activity_log_retention', '365', 'number', 'مدة الاحتفاظ بسجل أنشطة المديرين (أيام)', 'security')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- إنشاء Triggers لتسجيل أنشطة المديرين
DELIMITER $$

CREATE TRIGGER `log_admin_product_changes` AFTER UPDATE ON `products`
FOR EACH ROW
BEGIN
    IF @admin_id IS NOT NULL THEN
        INSERT INTO admin_activity_log (admin_id, action, description, target_type, target_id, old_values, new_values, ip_address)
        VALUES (
            @admin_id,
            'product.update',
            CONCAT('تم تحديث المنتج: ', NEW.name_ar),
            'product',
            NEW.id,
            JSON_OBJECT('name_ar', OLD.name_ar, 'price_yer', OLD.price_yer, 'status', OLD.status),
            JSON_OBJECT('name_ar', NEW.name_ar, 'price_yer', NEW.price_yer, 'status', NEW.status),
            @admin_ip
        );
    END IF;
END$$

CREATE TRIGGER `log_admin_user_changes` AFTER UPDATE ON `users`
FOR EACH ROW
BEGIN
    IF @admin_id IS NOT NULL THEN
        INSERT INTO admin_activity_log (admin_id, action, description, target_type, target_id, old_values, new_values, ip_address)
        VALUES (
            @admin_id,
            'user.update',
            CONCAT('تم تحديث المستخدم: ', NEW.username),
            'user',
            NEW.id,
            JSON_OBJECT('status', OLD.status, 'wallet_balance_yer', OLD.wallet_balance_yer),
            JSON_OBJECT('status', NEW.status, 'wallet_balance_yer', NEW.wallet_balance_yer),
            @admin_ip
        );
    END IF;
END$$

CREATE TRIGGER `log_admin_order_changes` AFTER UPDATE ON `orders`
FOR EACH ROW
BEGIN
    IF @admin_id IS NOT NULL THEN
        INSERT INTO admin_activity_log (admin_id, action, description, target_type, target_id, old_values, new_values, ip_address)
        VALUES (
            @admin_id,
            'order.update',
            CONCAT('تم تحديث الطلب رقم: ', NEW.id),
            'order',
            NEW.id,
            JSON_OBJECT('status', OLD.status, 'payment_status', OLD.payment_status),
            JSON_OBJECT('status', NEW.status, 'payment_status', NEW.payment_status),
            @admin_ip
        );
    END IF;
END$$

DELIMITER ;

-- إنشاء Views مفيدة للمديرين
CREATE VIEW `admin_dashboard_stats` AS
SELECT 
    (SELECT COUNT(*) FROM users WHERE status = 'active') as active_users,
    (SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE()) as today_orders,
    (SELECT COUNT(*) FROM orders WHERE status = 'pending') as pending_orders,
    (SELECT SUM(amount) FROM orders WHERE status = 'completed' AND DATE(created_at) = CURDATE()) as today_revenue,
    (SELECT COUNT(*) FROM products WHERE status = 'active') as active_products,
    (SELECT COUNT(*) FROM api_logs WHERE status = 'error' AND DATE(created_at) = CURDATE()) as today_api_errors;

CREATE VIEW `admin_recent_activities` AS
SELECT 
    aal.id,
    a.username as admin_username,
    aal.action,
    aal.description,
    aal.target_type,
    aal.target_id,
    aal.created_at
FROM admin_activity_log aal
JOIN admins a ON aal.admin_id = a.id
ORDER BY aal.created_at DESC
LIMIT 50;

-- إنشاء فهارس إضافية لتحسين الأداء
CREATE INDEX idx_login_attempts_ip_time ON login_attempts(ip_address, created_at);
CREATE INDEX idx_admin_activity_log_admin_time ON admin_activity_log(admin_id, created_at);
CREATE INDEX idx_active_sessions_type_activity ON active_sessions(user_type, last_activity);

-- إنشاء Event لتنظيف البيانات القديمة
DELIMITER $$

CREATE EVENT `cleanup_security_logs`
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    -- حذف محاولات تسجيل الدخول القديمة (أكثر من 30 يوم)
    DELETE FROM login_attempts WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    -- حذف الجلسات المنتهية الصلاحية (أكثر من 7 أيام)
    DELETE FROM active_sessions WHERE last_activity < DATE_SUB(NOW(), INTERVAL 7 DAY);
    
    -- حذف سجل أنشطة المديرين القديم (حسب الإعداد)
    DELETE FROM admin_activity_log 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL (
        SELECT CAST(setting_value AS UNSIGNED) 
        FROM settings 
        WHERE setting_key = 'admin_activity_log_retention'
    ) DAY);
END$$

DELIMITER ;

-- إنشاء إجراءات مخزنة مفيدة
DELIMITER $$

CREATE PROCEDURE `GetAdminPermissions`(IN admin_id INT)
BEGIN
    SELECT 
        ap.permission,
        ap.granted,
        ap.expires_at,
        a.username as granted_by_username
    FROM admin_permissions ap
    LEFT JOIN admins a ON ap.granted_by = a.id
    WHERE ap.admin_id = admin_id
    AND (ap.expires_at IS NULL OR ap.expires_at > NOW())
    ORDER BY ap.permission;
END$$

CREATE PROCEDURE `LogAdminActivity`(
    IN p_admin_id INT,
    IN p_action VARCHAR(100),
    IN p_description TEXT,
    IN p_target_type VARCHAR(50),
    IN p_target_id INT,
    IN p_ip_address VARCHAR(45)
)
BEGIN
    INSERT INTO admin_activity_log (admin_id, action, description, target_type, target_id, ip_address)
    VALUES (p_admin_id, p_action, p_description, p_target_type, p_target_id, p_ip_address);
END$$

CREATE PROCEDURE `CheckAdminSecurity`(IN admin_id INT)
BEGIN
    SELECT 
        a.username,
        a.last_login,
        a.login_attempts,
        a.locked_until,
        a.two_factor_enabled,
        CASE 
            WHEN a.locked_until > NOW() THEN 'locked'
            WHEN a.status != 'active' THEN 'inactive'
            ELSE 'active'
        END as security_status,
        (SELECT COUNT(*) FROM login_attempts 
         WHERE username = a.username 
         AND success = 0 
         AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)) as recent_failed_attempts
    FROM admins a
    WHERE a.id = admin_id;
END$$

DELIMITER ;

-- تحديث كلمات المرور للحسابات الافتراضية (للاختبار فقط)
-- كلمة المرور: FastStar@2024
UPDATE admins SET 
    password = '$2y$12$LQv3c1yqBz.hP4vBiiFMyOO0D2bV.wt0Hpj/EJiop6OMlAYu5O8m6',
    login_attempts = 0,
    locked_until = NULL,
    updated_at = NOW()
WHERE username IN ('admin', 'manager', 'support');

-- إضافة بيانات اختبار لسجل الأنشطة
INSERT INTO `admin_activity_log` (`admin_id`, `action`, `description`, `target_type`, `target_id`, `ip_address`, `created_at`) VALUES
((SELECT id FROM admins WHERE username = 'admin'), 'login', 'تسجيل دخول ناجح', 'admin', (SELECT id FROM admins WHERE username = 'admin'), '127.0.0.1', NOW() - INTERVAL 1 HOUR),
((SELECT id FROM admins WHERE username = 'admin'), 'product.create', 'إضافة منتج جديد', 'product', 1, '127.0.0.1', NOW() - INTERVAL 30 MINUTE),
((SELECT id FROM admins WHERE username = 'manager'), 'order.update', 'تحديث حالة الطلب', 'order', 1, '127.0.0.1', NOW() - INTERVAL 15 MINUTE);

SELECT 'Admin login system fixed and security enhanced!' as message;
SELECT 'Default admin credentials:' as info;
SELECT 'Username: admin, Password: FastStar@2024' as credentials;
SELECT COUNT(*) as total_admins FROM admins;
SELECT COUNT(*) as total_permissions FROM admin_permissions;
