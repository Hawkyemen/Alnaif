-- إصلاح هيكل جدول المديرين وإضافة الحقول المفقودة
-- Fix Admin Table Structure and Add Missing Fields

-- التحقق من وجود الجدول وإنشاؤه إذا لم يكن موجوداً
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `role` enum('super_admin','admin','manager','support') DEFAULT 'admin',
  `permissions` text DEFAULT NULL,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `last_login` timestamp NULL DEFAULT NULL,
  `login_attempts` int(11) DEFAULT 0,
  `locked_until` timestamp NULL DEFAULT NULL,
  `two_factor_secret` varchar(32) DEFAULT NULL,
  `two_factor_enabled` tinyint(1) DEFAULT 0,
  `password_reset_token` varchar(100) DEFAULT NULL,
  `password_reset_expires` timestamp NULL DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_role` (`role`),
  KEY `idx_status` (`status`),
  KEY `idx_last_login` (`last_login`),
  KEY `idx_department` (`department`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إضافة الحقول المفقودة إذا لم تكن موجودة
ALTER TABLE `admins` 
ADD COLUMN IF NOT EXISTS `avatar` varchar(255) DEFAULT NULL AFTER `password_reset_expires`,
ADD COLUMN IF NOT EXISTS `phone` varchar(20) DEFAULT NULL AFTER `avatar`,
ADD COLUMN IF NOT EXISTS `department` varchar(100) DEFAULT NULL AFTER `phone`,
ADD COLUMN IF NOT EXISTS `hire_date` date DEFAULT NULL AFTER `department`,
ADD COLUMN IF NOT EXISTS `salary` decimal(10,2) DEFAULT NULL AFTER `hire_date`,
ADD COLUMN IF NOT EXISTS `notes` text DEFAULT NULL AFTER `salary`;

-- إضافة فهارس جديدة
ALTER TABLE `admins` 
ADD INDEX IF NOT EXISTS `idx_department` (`department`),
ADD INDEX IF NOT EXISTS `idx_hire_date` (`hire_date`);

-- تحديث بيانات المديرين الموجودين
UPDATE `admins` SET 
    `department` = CASE 
        WHEN `role` = 'super_admin' THEN 'الإدارة العليا'
        WHEN `role` = 'admin' THEN 'إدارة النظام'
        WHEN `role` = 'manager' THEN 'إدارة العمليات'
        WHEN `role` = 'support' THEN 'الدعم الفني'
        ELSE 'عام'
    END,
    `hire_date` = CASE 
        WHEN `username` = 'admin' THEN '2024-01-01'
        WHEN `username` = 'manager' THEN '2024-01-15'
        WHEN `username` = 'support' THEN '2024-02-01'
        ELSE DATE(created_at)
    END,
    `phone` = CASE 
        WHEN `username` = 'admin' THEN '+967-1-234567'
        WHEN `username` = 'manager' THEN '+967-1-234568'
        WHEN `username` = 'support' THEN '+967-1-234569'
        ELSE NULL
    END
WHERE `department` IS NULL;

-- إنشاء جدول أقسام المديرين
CREATE TABLE IF NOT EXISTS `admin_departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `budget` decimal(15,2) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `idx_manager_id` (`manager_id`),
  KEY `idx_is_active` (`is_active`),
  CONSTRAINT `fk_admin_departments_manager` FOREIGN KEY (`manager_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج الأقسام الافتراضية
INSERT INTO `admin_departments` (`name`, `name_ar`, `description`, `manager_id`, `is_active`) VALUES
('Management', 'الإدارة العليا', 'الإدارة العليا والتخطيط الاستراتيجي', (SELECT id FROM admins WHERE username = 'admin' LIMIT 1), 1),
('Operations', 'إدارة العمليات', 'إدارة العمليات اليومية والمنتجات', (SELECT id FROM admins WHERE username = 'manager' LIMIT 1), 1),
('Technical Support', 'الدعم الفني', 'الدعم الفني وخدمة العملاء', (SELECT id FROM admins WHERE username = 'support' LIMIT 1), 1),
('Finance', 'المالية', 'الإدارة المالية والمحاسبة', NULL, 1),
('Marketing', 'التسويق', 'التسويق والعلاقات العامة', NULL, 1),
('IT', 'تقنية المعلومات', 'تطوير وصيانة الأنظمة', NULL, 1);

-- تحديث أقسام المديرين
UPDATE `admins` a 
JOIN `admin_departments` d ON a.department = d.name_ar 
SET a.department = d.name;

-- إنشاء جدول مناوبات المديرين
CREATE TABLE IF NOT EXISTS `admin_shifts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `shift_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `shift_type` enum('morning','evening','night','full_day') DEFAULT 'morning',
  `status` enum('scheduled','active','completed','cancelled') DEFAULT 'scheduled',
  `notes` text DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_date_shift` (`admin_id`,`shift_date`,`shift_type`),
  KEY `idx_shift_date` (`shift_date`),
  KEY `idx_shift_type` (`shift_type`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_admin_shifts` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج مناوبات افتراضية للأسبوع القادم
INSERT INTO `admin_shifts` (`admin_id`, `shift_date`, `start_time`, `end_time`, `shift_type`, `status`) 
SELECT 
    a.id,
    CURDATE() + INTERVAL day_offset DAY,
    CASE 
        WHEN a.role = 'super_admin' THEN '09:00:00'
        WHEN a.role = 'manager' THEN '08:00:00'
        WHEN a.role = 'support' THEN '10:00:00'
        ELSE '09:00:00'
    END,
    CASE 
        WHEN a.role = 'super_admin' THEN '17:00:00'
        WHEN a.role = 'manager' THEN '16:00:00'
        WHEN a.role = 'support' THEN '18:00:00'
        ELSE '17:00:00'
    END,
    'morning',
    'scheduled'
FROM admins a
CROSS JOIN (
    SELECT 0 as day_offset UNION ALL
    SELECT 1 UNION ALL
    SELECT 2 UNION ALL
    SELECT 3 UNION ALL
    SELECT 4 UNION ALL
    SELECT 5 UNION ALL
    SELECT 6
) days
WHERE a.status = 'active'
AND DAYOFWEEK(CURDATE() + INTERVAL day_offset DAY) BETWEEN 2 AND 6; -- الاثنين إلى الجمعة

-- إنشاء جدول تقييم أداء المديرين
CREATE TABLE IF NOT EXISTS `admin_performance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `evaluation_period` varchar(20) NOT NULL, -- 'YYYY-MM' for monthly
  `tasks_completed` int(11) DEFAULT 0,
  `tasks_assigned` int(11) DEFAULT 0,
  `response_time_avg` decimal(8,2) DEFAULT NULL, -- in minutes
  `customer_satisfaction` decimal(3,2) DEFAULT NULL, -- 0.00 to 5.00
  `orders_processed` int(11) DEFAULT 0,
  `errors_count` int(11) DEFAULT 0,
  `login_days` int(11) DEFAULT 0,
  `total_work_hours` decimal(8,2) DEFAULT 0.00,
  `performance_score` decimal(5,2) DEFAULT NULL, -- calculated score
  `notes` text DEFAULT NULL,
  `evaluated_by` int(11) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_period` (`admin_id`,`evaluation_period`),
  KEY `idx_evaluation_period` (`evaluation_period`),
  KEY `idx_performance_score` (`performance_score`),
  CONSTRAINT `fk_admin_performance` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_admin_performance_evaluator` FOREIGN KEY (`evaluated_by`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج تقييمات أداء وهمية للشهر الحالي
INSERT INTO `admin_performance` (`admin_id`, `evaluation_period`, `tasks_completed`, `tasks_assigned`, `response_time_avg`, `customer_satisfaction`, `orders_processed`, `errors_count`, `login_days`, `total_work_hours`, `performance_score`, `evaluated_by`) 
SELECT 
    a.id,
    DATE_FORMAT(NOW(), '%Y-%m'),
    FLOOR(RAND() * 50) + 20, -- 20-70 tasks completed
    FLOOR(RAND() * 60) + 25, -- 25-85 tasks assigned
    ROUND(RAND() * 30 + 5, 2), -- 5-35 minutes response time
    ROUND(RAND() * 2 + 3, 2), -- 3.00-5.00 satisfaction
    FLOOR(RAND() * 200) + 50, -- 50-250 orders processed
    FLOOR(RAND() * 5), -- 0-5 errors
    FLOOR(RAND() * 8) + 20, -- 20-28 login days
    ROUND(RAND() * 40 + 160, 2), -- 160-200 work hours
    NULL, -- will be calculated
    (SELECT id FROM admins WHERE role = 'super_admin' LIMIT 1)
FROM admins a
WHERE a.status = 'active';

-- حساب نقاط الأداء
UPDATE admin_performance 
SET performance_score = (
    (tasks_completed / GREATEST(tasks_assigned, 1) * 30) + -- 30% for task completion
    (GREATEST(0, 35 - response_time_avg) / 35 * 20) + -- 20% for response time
    (customer_satisfaction * 4) + -- 20% for satisfaction (5*4=20)
    (GREATEST(0, 100 - errors_count * 5) / 100 * 15) + -- 15% for error rate
    (login_days / 30 * 15) -- 15% for attendance
)
WHERE performance_score IS NULL;

-- إنشاء جدول مهام المديرين
CREATE TABLE IF NOT EXISTS `admin_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assigned_to` int(11) NOT NULL,
  `assigned_by` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `status` enum('pending','in_progress','completed','cancelled') DEFAULT 'pending',
  `due_date` datetime DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `estimated_hours` decimal(5,2) DEFAULT NULL,
  `actual_hours` decimal(5,2) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `attachments` text DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_assigned_to` (`assigned_to`),
  KEY `idx_assigned_by` (`assigned_by`),
  KEY `idx_priority` (`priority`),
  KEY `idx_status` (`status`),
  KEY `idx_due_date` (`due_date`),
  KEY `idx_category` (`category`),
  CONSTRAINT `fk_admin_tasks_assigned_to` FOREIGN KEY (`assigned_to`) REFERENCES `admins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_admin_tasks_assigned_by` FOREIGN KEY (`assigned_by`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج مهام عينة
INSERT INTO `admin_tasks` (`assigned_to`, `assigned_by`, `title`, `description`, `priority`, `status`, `due_date`, `estimated_hours`, `category`) VALUES
((SELECT id FROM admins WHERE username = 'manager'), (SELECT id FROM admins WHERE username = 'admin'), 'مراجعة المنتجات الجديدة', 'مراجعة وتفعيل المنتجات المضافة حديثاً', 'high', 'pending', DATE_ADD(NOW(), INTERVAL 2 DAY), 3.00, 'products'),
((SELECT id FROM admins WHERE username = 'support'), (SELECT id FROM admins WHERE username = 'manager'), 'الرد على استفسارات العملاء', 'الرد على الاستفسارات المعلقة في نظام الدعم', 'medium', 'in_progress', DATE_ADD(NOW(), INTERVAL 1 DAY), 2.00, 'support'),
((SELECT id FROM admins WHERE username = 'admin'), NULL, 'تحديث إعدادات الأمان', 'مراجعة وتحديث إعدادات الأمان للنظام', 'urgent', 'pending', DATE_ADD(NOW(), INTERVAL 3 DAY), 4.00, 'security'),
((SELECT id FROM admins WHERE username = 'manager'), (SELECT id FROM admins WHERE username = 'admin'), 'إعداد تقرير المبيعات الشهري', 'إعداد تقرير شامل لمبيعات الشهر الماضي', 'medium', 'pending', DATE_ADD(NOW(), INTERVAL 5 DAY), 6.00, 'reports');

-- إنشاء Views مفيدة للإدارة
CREATE VIEW `admin_dashboard_overview` AS
SELECT 
    a.id,
    a.username,
    a.full_name,
    a.role,
    a.department,
    a.status,
    a.last_login,
    d.name_ar as department_name,
    (SELECT COUNT(*) FROM admin_tasks WHERE assigned_to = a.id AND status = 'pending') as pending_tasks,
    (SELECT COUNT(*) FROM admin_tasks WHERE assigned_to = a.id AND status = 'in_progress') as active_tasks,
    (SELECT performance_score FROM admin_performance WHERE admin_id = a.id AND evaluation_period = DATE_FORMAT(NOW(), '%Y-%m')) as current_performance,
    (SELECT COUNT(*) FROM admin_activity_log WHERE admin_id = a.id AND DATE(created_at) = CURDATE()) as today_activities
FROM admins a
LEFT JOIN admin_departments d ON a.department = d.name
WHERE a.status = 'active';

CREATE VIEW `admin_workload_summary` AS
SELECT 
    a.id,
    a.username,
    a.full_name,
    COUNT(CASE WHEN at.status = 'pending' THEN 1 END) as pending_tasks,
    COUNT(CASE WHEN at.status = 'in_progress' THEN 1 END) as active_tasks,
    COUNT(CASE WHEN at.status = 'completed' THEN 1 END) as completed_tasks,
    SUM(CASE WHEN at.status = 'pending' THEN COALESCE(at.estimated_hours, 0) END) as pending_hours,
    SUM(CASE WHEN at.status = 'in_progress' THEN COALESCE(at.estimated_hours, 0) END) as active_hours,
    AVG(CASE WHEN at.status = 'completed' THEN at.actual_hours END) as avg_completion_time
FROM admins a
LEFT JOIN admin_tasks at ON a.id = at.assigned_to
WHERE a.status = 'active'
GROUP BY a.id;

-- إنشاء إجراءات مخزنة للإدارة
DELIMITER $$

CREATE PROCEDURE `GetAdminPerformanceReport`(IN admin_id INT, IN period_months INT)
BEGIN
    SELECT 
        ap.*,
        a.username,
        a.full_name,
        a.role,
        RANK() OVER (PARTITION BY ap.evaluation_period ORDER BY ap.performance_score DESC) as performance_rank
    FROM admin_performance ap
    JOIN admins a ON ap.admin_id = a.id
    WHERE (admin_id IS NULL OR ap.admin_id = admin_id)
    AND ap.evaluation_period >= DATE_FORMAT(DATE_SUB(NOW(), INTERVAL period_months MONTH), '%Y-%m')
    ORDER BY ap.evaluation_period DESC, ap.performance_score DESC;
END$$

CREATE PROCEDURE `AssignTask`(
    IN p_assigned_to INT,
    IN p_assigned_by INT,
    IN p_title VARCHAR(255),
    IN p_description TEXT,
    IN p_priority ENUM('low','medium','high','urgent'),
    IN p_due_date DATETIME,
    IN p_estimated_hours DECIMAL(5,2),
    IN p_category VARCHAR(100)
)
BEGIN
    INSERT INTO admin_tasks (assigned_to, assigned_by, title, description, priority, due_date, estimated_hours, category)
    VALUES (p_assigned_to, p_assigned_by, p_title, p_description, p_priority, p_due_date, p_estimated_hours, p_category);
    
    -- Log the task assignment
    INSERT INTO admin_activity_log (admin_id, action, description, target_type, target_id)
    VALUES (p_assigned_by, 'task.assign', CONCAT('تم تكليف مهمة: ', p_title), 'task', LAST_INSERT_ID());
END$$

CREATE PROCEDURE `UpdateAdminPerformance`(IN admin_id INT, IN period VARCHAR(20))
BEGIN
    DECLARE task_completion_rate DECIMAL(5,2) DEFAULT 0;
    DECLARE avg_response_time DECIMAL(8,2) DEFAULT 0;
    DECLARE orders_count INT DEFAULT 0;
    DECLARE errors_count INT DEFAULT 0;
    DECLARE login_days_count INT DEFAULT 0;
    
    -- Calculate task completion rate
    SELECT 
        COALESCE(SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0) * 100, 0)
    INTO task_completion_rate
    FROM admin_tasks 
    WHERE assigned_to = admin_id 
    AND DATE_FORMAT(created_at, '%Y-%m') = period;
    
    -- Calculate average response time (from activity logs)
    SELECT COALESCE(AVG(TIMESTAMPDIFF(MINUTE, created_at, updated_at)), 0)
    INTO avg_response_time
    FROM admin_activity_log
    WHERE admin_id = admin_id
    AND DATE_FORMAT(created_at, '%Y-%m') = period;
    
    -- Count orders processed
    SELECT COUNT(*)
    INTO orders_count
    FROM admin_activity_log
    WHERE admin_id = admin_id
    AND action LIKE 'order.%'
    AND DATE_FORMAT(created_at, '%Y-%m') = period;
    
    -- Count errors
    SELECT COUNT(*)
    INTO errors_count
    FROM admin_activity_log
    WHERE admin_id = admin_id
    AND action LIKE '%.error'
    AND DATE_FORMAT(created_at, '%Y-%m') = period;
    
    -- Count login days
    SELECT COUNT(DISTINCT DATE(created_at))
    INTO login_days_count
    FROM admin_activity_log
    WHERE admin_id = admin_id
    AND action = 'login'
    AND DATE_FORMAT(created_at, '%Y-%m') = period;
    
    -- Update or insert performance record
    INSERT INTO admin_performance (
        admin_id, evaluation_period, tasks_completed, response_time_avg, 
        orders_processed, errors_count, login_days
    )
    VALUES (admin_id, period, task_completion_rate, avg_response_time, orders_count, errors_count, login_days_count)
    ON DUPLICATE KEY UPDATE
        tasks_completed = task_completion_rate,
        response_time_avg = avg_response_time,
        orders_processed = orders_count,
        errors_count = errors_count,
        login_days = login_days_count,
        updated_at = NOW();
END$$

DELIMITER ;

-- إنشاء Event لتحديث الأداء تلقائياً
DELIMITER $$

CREATE EVENT `update_admin_performance_monthly`
ON SCHEDULE EVERY 1 MONTH
STARTS LAST_DAY(CURDATE()) + INTERVAL 1 DAY
DO
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE admin_id INT;
    DECLARE admin_cursor CURSOR FOR SELECT id FROM admins WHERE status = 'active';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN admin_cursor;
    
    admin_loop: LOOP
        FETCH admin_cursor INTO admin_id;
        IF done THEN
            LEAVE admin_loop;
        END IF;
        
        CALL UpdateAdminPerformance(admin_id, DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 MONTH), '%Y-%m'));
    END LOOP;
    
    CLOSE admin_cursor;
END$$

DELIMITER ;

-- تحديث الصلاحيات والأذونات
UPDATE admin_permissions SET permission = 'dashboard.view' WHERE permission = 'dashboard' AND admin_id IN (SELECT id FROM admins);
UPDATE admin_permissions SET permission = 'users.manage' WHERE permission = 'users' AND admin_id IN (SELECT id FROM admins);
UPDATE admin_permissions SET permission = 'products.manage' WHERE permission = 'products' AND admin_id IN (SELECT id FROM admins);
UPDATE admin_permissions SET permission = 'orders.manage' WHERE permission = 'orders' AND admin_id IN (SELECT id FROM admins);

-- إضافة أذونات جديدة للمديرين
INSERT INTO admin_permissions (admin_id, permission, granted_by)
SELECT 
    a.id,
    'tasks.manage',
    (SELECT id FROM admins WHERE role = 'super_admin' LIMIT 1)
FROM admins a
WHERE a.role IN ('super_admin', 'admin', 'manager')
AND NOT EXISTS (
    SELECT 1 FROM admin_permissions ap 
    WHERE ap.admin_id = a.id AND ap.permission = 'tasks.manage'
);

INSERT INTO admin_permissions (admin_id, permission, granted_by)
SELECT 
    a.id,
    'performance.view',
    (SELECT id FROM admins WHERE role = 'super_admin' LIMIT 1)
FROM admins a
WHERE a.role IN ('super_admin', 'admin')
AND NOT EXISTS (
    SELECT 1 FROM admin_permissions ap 
    WHERE ap.admin_id = a.id AND ap.permission = 'performance.view'
);

-- إنشاء فهارس إضافية لتحسين الأداء
CREATE INDEX idx_admin_tasks_assigned_status ON admin_tasks(assigned_to, status);
CREATE INDEX idx_admin_tasks_due_date_priority ON admin_tasks(due_date, priority);
CREATE INDEX idx_admin_performance_period_score ON admin_performance(evaluation_period, performance_score);
CREATE INDEX idx_admin_shifts_date_admin ON admin_shifts(shift_date, admin_id);

SELECT 'Admin table structure fixed and enhanced!' as message;
SELECT COUNT(*) as total_admins FROM admins;
SELECT COUNT(*) as total_departments FROM admin_departments;
SELECT COUNT(*) as total_tasks FROM admin_tasks;
SELECT COUNT(*) as total_performance_records FROM admin_performance;
