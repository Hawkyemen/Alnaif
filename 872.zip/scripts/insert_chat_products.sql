-- إدراج منتجات تطبيقات الدردشة والتواصل الاجتماعي
-- Chat and Social Media Products

-- إدراج فئة تطبيقات الدردشة
INSERT INTO `categories` (`name`, `name_ar`, `description`, `type`, `icon`, `sort_order`, `status`) VALUES
('Chat Applications', 'تطبيقات الدردشة', 'شحن تطبيقات الدردشة والمراسلة الفورية', 'chat', 'fas fa-comments', 2, 'active'),
('Social Media', 'التواصل الاجتماعي', 'شحن منصات التواصل الاجتماعي', 'social', 'fas fa-share-alt', 3, 'active');

-- الحصول على معرفات الفئات
SET @chat_category_id = (SELECT id FROM categories WHERE type = 'chat' LIMIT 1);
SET @social_category_id = (SELECT id FROM categories WHERE type = 'social' LIMIT 1);

-- إدراج منتجات WhatsApp Business
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@chat_category_id, 'WhatsApp Business API Credits', 'رصيد واتساب بيزنس', 'WhatsApp Business API messaging credits for businesses', 'رصيد إرسال الرسائل عبر واتساب بيزنس للشركات', 1875.00, 50.00, 5.00, 18.35, 'Business Phone Number', 'رقم الهاتف التجاري', 'Enter your registered WhatsApp Business phone number', 'أدخل رقم هاتف واتساب بيزنس المسجل', 1, 'active', 1),
(@chat_category_id, 'WhatsApp Business Premium', 'واتساب بيزنس بريميوم', 'Premium features for WhatsApp Business', 'الميزات المتقدمة لواتساب بيزنس', 3750.00, 100.00, 10.00, 36.70, 'Business Account ID', 'معرف الحساب التجاري', 'Enter your WhatsApp Business account ID', 'أدخل معرف حساب واتساب بيزنس', 2, 'active', 0);

-- إدراج منتجات Telegram
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@chat_category_id, 'Telegram Premium', 'تيليجرام بريميوم', 'Telegram Premium subscription with advanced features', 'اشتراك تيليجرام بريميوم مع الميزات المتقدمة', 1125.00, 30.00, 3.00, 11.01, 'Telegram Username', 'اسم المستخدم في تيليجرام', 'Enter your Telegram username (without @)', 'أدخل اسم المستخدم في تيليجرام (بدون @)', 3, 'active', 1),
(@chat_category_id, 'Telegram Bot API Credits', 'رصيد بوت تيليجرام', 'API credits for Telegram bots', 'رصيد API لبوتات تيليجرام', 750.00, 20.00, 2.00, 7.34, 'Bot Token', 'رمز البوت', 'Enter your Telegram bot token', 'أدخل رمز بوت تيليجرام', 4, 'active', 0);

-- إدراج منتجات Discord
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@chat_category_id, 'Discord Nitro', 'ديسكورد نيترو', 'Discord Nitro subscription for enhanced gaming communication', 'اشتراك ديسكورد نيترو للتواصل المحسن في الألعاب', 1875.00, 50.00, 5.00, 18.35, 'Discord Username', 'اسم المستخدم في ديسكورد', 'Enter your Discord username with discriminator (e.g., User#1234)', 'أدخل اسم المستخدم في ديسكورد مع الرقم المميز', 5, 'active', 1),
(@chat_category_id, 'Discord Server Boost', 'تعزيز خادم ديسكورد', 'Server boost for Discord communities', 'تعزيز الخادم لمجتمعات ديسكورد', 937.50, 25.00, 2.50, 9.18, 'Server ID', 'معرف الخادم', 'Enter your Discord server ID', 'أدخل معرف خادم ديسكورد', 6, 'active', 0);

-- إدراج منتجات Skype
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@chat_category_id, 'Skype Credit', 'رصيد سكايب', 'Skype calling and messaging credits', 'رصيد المكالمات والرسائل في سكايب', 1500.00, 40.00, 4.00, 14.68, 'Skype Name', 'اسم سكايب', 'Enter your Skype username or email', 'أدخل اسم المستخدم أو البريد الإلكتروني في سكايب', 7, 'active', 0),
(@chat_category_id, 'Skype Number', 'رقم سكايب', 'Get a local phone number for Skype', 'احصل على رقم هاتف محلي لسكايب', 2250.00, 60.00, 6.00, 22.02, 'Country Code', 'رمز البلد', 'Enter your preferred country code', 'أدخل رمز البلد المفضل', 8, 'active', 0);

-- إدراج منتجات Zoom
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@chat_category_id, 'Zoom Pro', 'زوم برو', 'Zoom Pro subscription for professional meetings', 'اشتراك زوم برو للاجتماعات المهنية', 5625.00, 150.00, 15.00, 55.05, 'Zoom Email', 'بريد زوم الإلكتروني', 'Enter your Zoom account email', 'أدخل البريد الإلكتروني لحساب زوم', 9, 'active', 1),
(@chat_category_id, 'Zoom Business', 'زوم بيزنس', 'Zoom Business subscription for teams', 'اشتراك زوم بيزنس للفرق', 7500.00, 200.00, 20.00, 73.40, 'Company Email', 'البريد الإلكتروني للشركة', 'Enter your company email for Zoom Business', 'أدخل البريد الإلكتروني للشركة لزوم بيزنس', 10, 'active', 0);

-- إدراج منتجات التواصل الاجتماعي

-- منتجات Facebook/Meta
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@social_category_id, 'Facebook Ads Credit', 'رصيد إعلانات فيسبوك', 'Facebook advertising credits for business promotion', 'رصيد الإعلانات في فيسبوك للترويج التجاري', 3750.00, 100.00, 10.00, 36.70, 'Facebook Page ID', 'معرف صفحة فيسبوك', 'Enter your Facebook business page ID', 'أدخل معرف صفحة فيسبوك التجارية', 1, 'active', 1),
(@social_category_id, 'Instagram Business Tools', 'أدوات إنستجرام التجارية', 'Instagram business and creator tools', 'أدوات إنستجرام التجارية والإبداعية', 2250.00, 60.00, 6.00, 22.02, 'Instagram Username', 'اسم المستخدم في إنستجرام', 'Enter your Instagram business username', 'أدخل اسم المستخدم التجاري في إنستجرام', 2, 'active', 1);

-- منتجات Twitter/X
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@social_category_id, 'Twitter Blue', 'تويتر الأزرق', 'Twitter Blue subscription with premium features', 'اشتراك تويتر الأزرق مع الميزات المتقدمة', 3000.00, 80.00, 8.00, 29.36, 'Twitter Handle', 'معرف تويتر', 'Enter your Twitter username (without @)', 'أدخل اسم المستخدم في تويتر (بدون @)', 3, 'active', 1),
(@social_category_id, 'Twitter Ads Credit', 'رصيد إعلانات تويتر', 'Twitter advertising credits for promoted content', 'رصيد الإعلانات في تويتر للمحتوى المروج', 4500.00, 120.00, 12.00, 44.04, 'Twitter Ads Account', 'حساب إعلانات تويتر', 'Enter your Twitter Ads account ID', 'أدخل معرف حساب إعلانات تويتر', 4, 'active', 0);

-- منتجات LinkedIn
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@social_category_id, 'LinkedIn Premium', 'لينكد إن بريميوم', 'LinkedIn Premium subscription for professionals', 'اشتراك لينكد إن بريميوم للمهنيين', 11250.00, 300.00, 30.00, 110.10, 'LinkedIn Email', 'البريد الإلكتروني للينكد إن', 'Enter your LinkedIn account email', 'أدخل البريد الإلكتروني لحساب لينكد إن', 5, 'active', 1),
(@social_category_id, 'LinkedIn Sales Navigator', 'لينكد إن للمبيعات', 'LinkedIn Sales Navigator for sales professionals', 'لينكد إن للمبيعات للمهنيين في المبيعات', 18750.00, 500.00, 50.00, 183.50, 'Company LinkedIn', 'لينكد إن الشركة', 'Enter your company LinkedIn page URL', 'أدخل رابط صفحة الشركة في لينكد إن', 6, 'active', 0);

-- منتجات TikTok
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@social_category_id, 'TikTok Ads Credit', 'رصيد إعلانات تيك توك', 'TikTok advertising credits for viral marketing', 'رصيد الإعلانات في تيك توك للتسويق الفيروسي', 3750.00, 100.00, 10.00, 36.70, 'TikTok Username', 'اسم المستخدم في تيك توك', 'Enter your TikTok business username', 'أدخل اسم المستخدم التجاري في تيك توك', 7, 'active', 1),
(@social_category_id, 'TikTok Creator Fund', 'صندوق منشئي تيك توك', 'TikTok Creator Fund participation', 'المشاركة في صندوق منشئي المحتوى في تيك توك', 1875.00, 50.00, 5.00, 18.35, 'Creator Profile', 'ملف المنشئ', 'Enter your TikTok creator profile link', 'أدخل رابط ملف منشئ المحتوى في تيك توك', 8, 'active', 0);

-- منتجات YouTube
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@social_category_id, 'YouTube Premium', 'يوتيوب بريميوم', 'YouTube Premium subscription without ads', 'اشتراك يوتيوب بريميوم بدون إعلانات', 4500.00, 120.00, 12.00, 44.04, 'YouTube Channel', 'قناة يوتيوب', 'Enter your YouTube channel URL or ID', 'أدخل رابط أو معرف قناة يوتيوب', 9, 'active', 1),
(@social_category_id, 'YouTube Music', 'يوتيوب ميوزيك', 'YouTube Music premium subscription', 'اشتراك يوتيوب ميوزيك المتقدم', 3000.00, 80.00, 8.00, 29.36, 'Google Account', 'حساب جوجل', 'Enter your Google account email', 'أدخل البريد الإلكتروني لحساب جوجل', 10, 'active', 0);

-- منتجات Snapchat
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@social_category_id, 'Snapchat Ads Credit', 'رصيد إعلانات سناب شات', 'Snapchat advertising credits for youth marketing', 'رصيد الإعلانات في سناب شات للتسويق للشباب', 2250.00, 60.00, 6.00, 22.02, 'Snapchat Username', 'اسم المستخدم في سناب شات', 'Enter your Snapchat business username', 'أدخل اسم المستخدم التجاري في سناب شات', 11, 'active', 0),
(@social_category_id, 'Snapchat Plus', 'سناب شات بلس', 'Snapchat Plus subscription with exclusive features', 'اشتراك سناب شات بلس مع الميزات الحصرية', 1125.00, 30.00, 3.00, 11.01, 'Snapchat Account', 'حساب سناب شات', 'Enter your Snapchat account username', 'أدخل اسم المستخدم لحساب سناب شات', 12, 'active', 1);

-- منتجات Pinterest
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@social_category_id, 'Pinterest Business', 'بينترست للأعمال', 'Pinterest Business account with analytics', 'حساب بينترست للأعمال مع التحليلات', 1875.00, 50.00, 5.00, 18.35, 'Pinterest Profile', 'ملف بينترست', 'Enter your Pinterest business profile URL', 'أدخل رابط ملف بينترست التجاري', 13, 'active', 0),
(@social_category_id, 'Pinterest Ads Credit', 'رصيد إعلانات بينترست', 'Pinterest advertising credits for visual marketing', 'رصيد الإعلانات في بينترست للتسويق المرئي', 3000.00, 80.00, 8.00, 29.36, 'Business Account', 'الحساب التجاري', 'Enter your Pinterest business account email', 'أدخل البريد الإلكتروني للحساب التجاري في بينترست', 14, 'active', 0);

-- إدراج APIs الشحن لتطبيقات الدردشة
INSERT INTO `charging_apis` (`product_id`, `name`, `api_url`, `method`, `headers`, `request_template`, `success_indicators`, `error_indicators`, `timeout`, `retry_attempts`, `is_active`, `priority`) VALUES
((SELECT id FROM products WHERE name LIKE '%WhatsApp Business API%' LIMIT 1), 'WhatsApp Business API', 'https://api.whatsapp.com/v1/credits/purchase', 'POST', '{"Content-Type": "application/json", "Authorization": "Bearer {api_key}"}', '{"phone_number": "{customer_id}", "amount": {amount}, "currency": "{currency}"}', '["success", "completed", "credited"]', '["error", "failed", "insufficient"]', 30, 3, 1, 1),
((SELECT id FROM products WHERE name LIKE '%Telegram Premium%' LIMIT 1), 'Telegram Premium API', 'https://api.telegram.org/premium/subscribe', 'POST', '{"Content-Type": "application/json", "X-API-Key": "{api_key}"}', '{"username": "{customer_id}", "duration": "monthly", "amount": {amount}}', '["success", "subscribed", "active"]', '["error", "failed", "invalid_user"]', 25, 2, 1, 1),
((SELECT id FROM products WHERE name LIKE '%Discord Nitro%' LIMIT 1), 'Discord Nitro API', 'https://discord.com/api/v10/nitro/gift', 'POST', '{"Content-Type": "application/json", "Authorization": "Bot {api_key}"}', '{"recipient": "{customer_id}", "type": "nitro", "duration": "monthly"}', '["success", "gifted", "redeemed"]', '["error", "failed", "user_not_found"]', 20, 2, 1, 1);

-- إدراج APIs الشحن لمنصات التواصل الاجتماعي
INSERT INTO `charging_apis` (`product_id`, `name`, `api_url`, `method`, `headers`, `request_template`, `success_indicators`, `error_indicators`, `timeout`, `retry_attempts`, `is_active`, `priority`) VALUES
((SELECT id FROM products WHERE name LIKE '%Facebook Ads Credit%' LIMIT 1), 'Facebook Ads API', 'https://graph.facebook.com/v18.0/act_{ad_account_id}/adcredits', 'POST', '{"Content-Type": "application/json", "Authorization": "Bearer {api_key}"}', '{"amount": {amount}, "currency": "{currency}", "funding_source": "credit_card"}', '["success", "credited", "available"]', '["error", "failed", "insufficient_permissions"]', 30, 3, 1, 1),
((SELECT id FROM products WHERE name LIKE '%Twitter Blue%' LIMIT 1), 'Twitter API v2', 'https://api.twitter.com/2/subscriptions/premium', 'POST', '{"Content-Type": "application/json", "Authorization": "Bearer {api_key}"}', '{"username": "{customer_id}", "subscription_type": "blue", "billing_period": "monthly"}', '["success", "subscribed", "active"]', '["error", "failed", "user_not_eligible"]', 25, 2, 1, 1),
((SELECT id FROM products WHERE name LIKE '%LinkedIn Premium%' LIMIT 1), 'LinkedIn API', 'https://api.linkedin.com/v2/premium/subscriptions', 'POST', '{"Content-Type": "application/json", "Authorization": "Bearer {api_key}"}', '{"member_email": "{customer_id}", "subscription_type": "premium", "duration": "monthly"}', '["success", "subscribed", "premium_active"]', '["error", "failed", "member_not_found"]', 30, 2, 1, 1);

-- تحديث إحصائيات المنتجات
UPDATE products SET 
    total_sales = FLOOR(RAND() * 100) + 10,
    rating = ROUND(3.5 + (RAND() * 1.5), 2),
    rating_count = FLOOR(RAND() * 50) + 5
WHERE category_id IN (@chat_category_id, @social_category_id);

-- إضافة خصومات موسمية لبعض المنتجات
UPDATE products SET 
    discount_percentage = 15.00
WHERE name_ar IN ('واتساب بيزنس', 'تيليجرام بريميوم', 'ديسكورد نيترو', 'فيسبوك إعلانات', 'تويتر الأزرق');

UPDATE products SET 
    discount_percentage = 10.00
WHERE name_ar IN ('زوم برو', 'لينكد إن بريميوم', 'يوتيوب بريميوم', 'سناب شات بلس');

-- إضافة تعليمات مفصلة للمنتجات
UPDATE products SET 
    instructions_ar = 'تأكد من أن رقم الهاتف مسجل في واتساب بيزنس ومفعل. سيتم إضافة الرصيد خلال 5-10 دقائق من تأكيد الدفع.'
WHERE name_ar LIKE '%واتساب%';

UPDATE products SET 
    instructions_ar = 'يجب أن يكون لديك حساب تيليجرام نشط. سيتم تفعيل الاشتراك فوراً بعد تأكيد الدفع.'
WHERE name_ar LIKE '%تيليجرام%';

UPDATE products SET 
    instructions_ar = 'تأكد من صحة اسم المستخدم في ديسكورد. سيتم إرسال هدية النيترو إلى حسابك خلال دقائق.'
WHERE name_ar LIKE '%ديسكورد%';

-- إنشاء فهارس إضافية لتحسين الأداء
CREATE INDEX idx_products_category_featured ON products(category_id, featured);
CREATE INDEX idx_products_status_sort ON products(status, sort_order);
CREATE INDEX idx_charging_apis_product_active ON charging_apis(product_id, is_active);

-- إضافة إحصائيات للفئات
UPDATE categories SET 
    description = CONCAT(description, ' - يحتوي على ', 
        (SELECT COUNT(*) FROM products WHERE category_id = categories.id AND status = 'active'), 
        ' منتج متاح')
WHERE type IN ('chat', 'social');

SELECT 'Chat and Social Media products inserted successfully!' as message;
SELECT COUNT(*) as total_chat_products FROM products p 
JOIN categories c ON p.category_id = c.id 
WHERE c.type = 'chat';

SELECT COUNT(*) as total_social_products FROM products p 
JOIN categories c ON p.category_id = c.id 
WHERE c.type = 'social';
