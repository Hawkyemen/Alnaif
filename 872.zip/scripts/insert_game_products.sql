-- إدراج منتجات الألعاب الشائعة
-- Popular Gaming Products

-- إدراج فئة الألعاب
INSERT INTO `categories` (`name`, `name_ar`, `description`, `type`, `icon`, `sort_order`, `status`) VALUES
('Mobile Games', 'ألعاب الجوال', 'شحن ألعاب الهواتف الذكية الشائعة', 'games', 'fas fa-mobile-alt', 1, 'active'),
('PC Games', 'ألعاب الكمبيوتر', 'شحن ألعاب الكمبيوتر ومنصات الألعاب', 'games', 'fas fa-desktop', 4, 'active'),
('Console Games', 'ألعاب الكونسول', 'شحن ألعاب البلايستيشن والإكس بوكس', 'games', 'fas fa-gamepad', 5, 'active');

-- الحصول على معرفات الفئات
SET @mobile_games_id = (SELECT id FROM categories WHERE name = 'Mobile Games' LIMIT 1);
SET @pc_games_id = (SELECT id FROM categories WHERE name = 'PC Games' LIMIT 1);
SET @console_games_id = (SELECT id FROM categories WHERE name = 'Console Games' LIMIT 1);

-- إدراج منتجات ألعاب الجوال الشائعة

-- منتجات PUBG Mobile
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@mobile_games_id, 'PUBG Mobile UC', 'شدات ببجي موبايل', 'PUBG Mobile Unknown Cash for in-game purchases', 'شدات ببجي موبايل للشراء داخل اللعبة', 375.00, 10.00, 1.00, 3.67, 'Player ID', 'معرف اللاعب', 'Enter your PUBG Mobile Player ID (found in game profile)', 'أدخل معرف اللاعب في ببجي موبايل (موجود في ملف اللاعب)', 1, 'active', 1),
(@mobile_games_id, 'PUBG Mobile UC 660', 'شدات ببجي 660', '660 UC for PUBG Mobile', '660 شدة لببجي موبايل', 2250.00, 60.00, 6.00, 22.02, 'Player ID', 'معرف اللاعب', 'Enter your PUBG Mobile Player ID', 'أدخل معرف اللاعب في ببجي موبايل', 2, 'active', 1),
(@mobile_games_id, 'PUBG Mobile UC 1800', 'شدات ببجي 1800', '1800 UC for PUBG Mobile', '1800 شدة لببجي موبايل', 5625.00, 150.00, 15.00, 55.05, 'Player ID', 'معرف اللاعب', 'Enter your PUBG Mobile Player ID', 'أدخل معرف اللاعب في ببجي موبايل', 3, 'active', 1);

-- منتجات Free Fire
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@mobile_games_id, 'Free Fire Diamonds', 'جواهر فري فاير', 'Free Fire Diamonds for character upgrades and skins', 'جواهر فري فاير لترقية الشخصيات والأشكال', 750.00, 20.00, 2.00, 7.34, 'Player ID', 'معرف اللاعب', 'Enter your Free Fire Player ID (found in profile)', 'أدخل معرف اللاعب في فري فاير (موجود في الملف الشخصي)', 4, 'active', 1),
(@mobile_games_id, 'Free Fire 520 Diamonds', 'جواهر فري فاير 520', '520 Diamonds for Free Fire', '520 جوهرة لفري فاير', 1875.00, 50.00, 5.00, 18.35, 'Player ID', 'معرف اللاعب', 'Enter your Free Fire Player ID', 'أدخل معرف اللاعب في فري فاير', 5, 'active', 1),
(@mobile_games_id, 'Free Fire 1080 Diamonds', 'جواهر فري فاير 1080', '1080 Diamonds for Free Fire', '1080 جوهرة لفري فاير', 3750.00, 100.00, 10.00, 36.70, 'Player ID', 'معرف اللاعب', 'Enter your Free Fire Player ID', 'أدخل معرف اللاعب في فري فاير', 6, 'active', 1);

-- منتجات Mobile Legends
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@mobile_games_id, 'Mobile Legends Diamonds', 'جواهر موبايل ليجندز', 'Mobile Legends Bang Bang Diamonds', 'جواهر موبايل ليجندز بانج بانج', 562.50, 15.00, 1.50, 5.51, 'User ID', 'معرف المستخدم', 'Enter your Mobile Legends User ID and Zone ID', 'أدخل معرف المستخدم ومعرف المنطقة في موبايل ليجندز', 7, 'active', 1),
(@mobile_games_id, 'Mobile Legends 408 Diamonds', 'جواهر موبايل ليجندز 408', '408 Diamonds for Mobile Legends', '408 جوهرة لموبايل ليجندز', 2250.00, 60.00, 6.00, 22.02, 'User ID', 'معرف المستخدم', 'Enter User ID and Zone ID separated by space', 'أدخل معرف المستخدم ومعرف المنطقة مفصولين بمسافة', 8, 'active', 1);

-- منتجات Call of Duty Mobile
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@mobile_games_id, 'COD Mobile CP', 'نقاط كول أوف ديوتي', 'Call of Duty Mobile COD Points', 'نقاط كول أوف ديوتي موبايل', 937.50, 25.00, 2.50, 9.18, 'Player ID', 'معرف اللاعب', 'Enter your COD Mobile Player ID', 'أدخل معرف اللاعب في كول أوف ديوتي موبايل', 9, 'active', 1),
(@mobile_games_id, 'COD Mobile 800 CP', 'نقاط كول أوف ديوتي 800', '800 COD Points for Call of Duty Mobile', '800 نقطة كول أوف ديوتي موبايل', 3000.00, 80.00, 8.00, 29.36, 'Player ID', 'معرف اللاعب', 'Enter your COD Mobile Player ID', 'أدخل معرف اللاعب في كول أوف ديوتي موبايل', 10, 'active', 1);

-- منتجات Clash of Clans
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@mobile_games_id, 'Clash of Clans Gems', 'جواهر كلاش أوف كلانز', 'Clash of Clans Gems for faster progression', 'جواهر كلاش أوف كلانز للتقدم السريع', 1125.00, 30.00, 3.00, 11.01, 'Player Tag', 'علامة اللاعب', 'Enter your Clash of Clans Player Tag (starts with #)', 'أدخل علامة اللاعب في كلاش أوف كلانز (تبدأ بـ #)', 11, 'active', 1),
(@mobile_games_id, 'Clash of Clans 500 Gems', 'جواهر كلاش أوف كلانز 500', '500 Gems for Clash of Clans', '500 جوهرة لكلاش أوف كلانز', 1875.00, 50.00, 5.00, 18.35, 'Player Tag', 'علامة اللاعب', 'Enter your Player Tag starting with #', 'أدخل علامة اللاعب التي تبدأ بـ #', 12, 'active', 1);

-- منتجات Clash Royale
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@mobile_games_id, 'Clash Royale Gems', 'جواهر كلاش رويال', 'Clash Royale Gems for chests and upgrades', 'جواهر كلاش رويال للصناديق والترقيات', 750.00, 20.00, 2.00, 7.34, 'Player Tag', 'علامة اللاعب', 'Enter your Clash Royale Player Tag', 'أدخل علامة اللاعب في كلاش رويال', 13, 'active', 1);

-- منتجات Genshin Impact
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@mobile_games_id, 'Genshin Impact Genesis Crystals', 'بلورات جينشين إمباكت', 'Genesis Crystals for Genshin Impact wishes', 'بلورات التكوين لأمنيات جينشين إمباكت', 1125.00, 30.00, 3.00, 11.01, 'UID', 'معرف المستخدم الفريد', 'Enter your Genshin Impact UID', 'أدخل معرف المستخدم الفريد في جينشين إمباكت', 14, 'active', 1),
(@mobile_games_id, 'Genshin Impact 980 Crystals', 'بلورات جينشين إمباكت 980', '980 Genesis Crystals for Genshin Impact', '980 بلورة تكوين لجينشين إمباكت', 3750.00, 100.00, 10.00, 36.70, 'UID', 'معرف المستخدم الفريد', 'Enter your Genshin Impact UID', 'أدخل معرف المستخدم الفريد في جينشين إمباكت', 15, 'active', 1);

-- منتجات ألعاب الكمبيوتر

-- منتجات Steam
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@pc_games_id, 'Steam Wallet', 'محفظة ستيم', 'Steam Wallet credit for game purchases', 'رصيد محفظة ستيم لشراء الألعاب', 1875.00, 50.00, 5.00, 18.35, 'Steam Username', 'اسم المستخدم في ستيم', 'Enter your Steam username or profile URL', 'أدخل اسم المستخدم أو رابط الملف الشخصي في ستيم', 1, 'active', 1),
(@pc_games_id, 'Steam Wallet $20', 'محفظة ستيم 20 دولار', '$20 Steam Wallet credit', 'رصيد محفظة ستيم 20 دولار', 7500.00, 200.00, 20.00, 73.40, 'Steam Username', 'اسم المستخدم في ستيم', 'Enter your Steam username', 'أدخل اسم المستخدم في ستيم', 2, 'active', 1),
(@pc_games_id, 'Steam Wallet $50', 'محفظة ستيم 50 دولار', '$50 Steam Wallet credit', 'رصيد محفظة ستيم 50 دولار', 18750.00, 500.00, 50.00, 183.50, 'Steam Username', 'اسم المستخدم في ستيم', 'Enter your Steam username', 'أدخل اسم المستخدم في ستيم', 3, 'active', 1);

-- منتجات Epic Games
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@pc_games_id, 'Epic Games Wallet', 'محفظة إيبك جيمز', 'Epic Games Store wallet credit', 'رصيد محفظة متجر إيبك جيمز', 1875.00, 50.00, 5.00, 18.35, 'Epic Games Email', 'البريد الإلكتروني لإيبك جيمز', 'Enter your Epic Games account email', 'أدخل البريد الإلكتروني لحساب إيبك جيمز', 4, 'active', 1);

-- منتجات Fortnite
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@pc_games_id, 'Fortnite V-Bucks', 'في-باكس فورتنايت', 'Fortnite V-Bucks for skins and items', 'في-باكس فورتنايت للأشكال والعناصر', 937.50, 25.00, 2.50, 9.18, 'Epic Games Username', 'اسم المستخدم في إيبك جيمز', 'Enter your Epic Games username', 'أدخل اسم المستخدم في إيبك جيمز', 5, 'active', 1),
(@pc_games_id, 'Fortnite 1000 V-Bucks', 'في-باكس فورتنايت 1000', '1000 V-Bucks for Fortnite', '1000 في-باكس لفورتنايت', 3000.00, 80.00, 8.00, 29.36, 'Epic Games Username', 'اسم المستخدم في إيبك جيمز', 'Enter your Epic Games username', 'أدخل اسم المستخدم في إيبك جيمز', 6, 'active', 1);

-- منتجات Valorant
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@pc_games_id, 'Valorant Points', 'نقاط فالورانت', 'Valorant Points for weapon skins and agents', 'نقاط فالورانت لأشكال الأسلحة والعملاء', 1125.00, 30.00, 3.00, 11.01, 'Riot ID', 'معرف رايوت', 'Enter your Riot ID (Username#Tag)', 'أدخل معرف رايوت (اسم المستخدم#العلامة)', 7, 'active', 1),
(@pc_games_id, 'Valorant 1375 Points', 'نقاط فالورانت 1375', '1375 Valorant Points', '1375 نقطة فالورانت', 3750.00, 100.00, 10.00, 36.70, 'Riot ID', 'معرف رايوت', 'Enter your Riot ID with tag', 'أدخل معرف رايوت مع العلامة', 8, 'active', 1);

-- منتجات League of Legends
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@pc_games_id, 'League of Legends RP', 'نقاط ليج أوف ليجندز', 'Riot Points for League of Legends champions and skins', 'نقاط رايوت لأبطال وأشكال ليج أوف ليجندز', 750.00, 20.00, 2.00, 7.34, 'Summoner Name', 'اسم المستدعي', 'Enter your League of Legends Summoner Name', 'أدخل اسم المستدعي في ليج أوف ليجندز', 9, 'active', 1);

-- منتجات ألعاب الكونسول

-- منتجات PlayStation
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@console_games_id, 'PlayStation Store', 'متجر بلايستيشن', 'PlayStation Store credit for games and DLC', 'رصيد متجر بلايستيشن للألعاب والمحتوى الإضافي', 1875.00, 50.00, 5.00, 18.35, 'PSN Email', 'البريد الإلكتروني لـ PSN', 'Enter your PlayStation Network email', 'أدخل البريد الإلكتروني لشبكة بلايستيشن', 1, 'active', 1),
(@console_games_id, 'PlayStation Plus', 'بلايستيشن بلس', 'PlayStation Plus subscription for online gaming', 'اشتراك بلايستيشن بلس للألعاب الجماعية', 22500.00, 600.00, 60.00, 220.20, 'PSN Email', 'البريد الإلكتروني لـ PSN', 'Enter your PSN account email', 'أدخل البريد الإلكتروني لحساب PSN', 2, 'active', 1);

-- منتجات Xbox
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@console_games_id, 'Xbox Gift Card', 'بطاقة هدايا إكس بوكس', 'Xbox Gift Card for Microsoft Store purchases', 'بطاقة هدايا إكس بوكس لمشتريات متجر مايكروسوفت', 1875.00, 50.00, 5.00, 18.35, 'Xbox Gamertag', 'اسم اللاعب في إكس بوكس', 'Enter your Xbox Gamertag', 'أدخل اسم اللاعب في إكس بوكس', 3, 'active', 1),
(@console_games_id, 'Xbox Game Pass', 'إكس بوكس جيم باس', 'Xbox Game Pass Ultimate subscription', 'اشتراك إكس بوكس جيم باس الشامل', 56250.00, 1500.00, 150.00, 550.50, 'Microsoft Email', 'البريد الإلكتروني لمايكروسوفت', 'Enter your Microsoft account email', 'أدخل البريد الإلكتروني لحساب مايكروسوفت', 4, 'active', 1);

-- منتجات Nintendo
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `price_yer`, `price_sar`, `price_usd`, `price_aed`,  `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`) VALUES
(@console_games_id, 'Nintendo eShop', 'متجر نينتندو الإلكتروني', 'Nintendo eShop credit for Switch games', 'رصيد متجر نينتندو الإلكتروني لألعاب السويتش', 1875.00, 50.00, 5.00, 18.35, 'Nintendo Account', 'حساب نينتندو', 'Enter your Nintendo Account email', 'أدخل البريد الإلكتروني لحساب نينتندو', 5, 'active', 1);

-- إدراج APIs الشحن للألعاب
INSERT INTO `charging_apis` (`product_id`, `name`, `api_url`, `method`, `headers`, `request_template`, `success_indicators`, `error_indicators`, `timeout`, `retry_attempts`, `is_active`, `priority`) VALUES
((SELECT id FROM products WHERE name LIKE '%PUBG Mobile UC%' LIMIT 1), 'PUBG Mobile API', 'https://api.pubgmobile.com/v1/purchase', 'POST', '{"Content-Type": "application/json", "X-API-Key": "{api_key}"}', '{"player_id": "{customer_id}", "item": "uc", "amount": {amount}, "currency": "{currency}"}', '["success", "completed", "delivered"]', '["error", "failed", "invalid_player"]', 30, 3, 1, 1),
((SELECT id FROM products WHERE name LIKE '%Free Fire Diamonds%' LIMIT 1), 'Free Fire API', 'https://api.freefire.com/v2/diamonds/purchase', 'POST', '{"Content-Type": "application/json", "Authorization": "Bearer {api_key}"}', '{"player_id": "{customer_id}", "diamonds": {amount}, "server": "global"}', '["success", "purchased", "credited"]', '["error", "failed", "player_not_found"]', 25, 3, 1, 1),
((SELECT id FROM products WHERE name LIKE '%Mobile Legends%' LIMIT 1), 'Mobile Legends API', 'https://api.mobilelegends.com/recharge', 'POST', '{"Content-Type": "application/json", "X-Auth-Token": "{api_key}"}', '{"user_id": "{customer_id}", "diamonds": {amount}, "zone_id": "auto"}', '["success", "recharged", "completed"]', '["error", "failed", "invalid_user_id"]', 30, 2, 1, 1),
((SELECT id FROM products WHERE name LIKE '%Steam Wallet%' LIMIT 1), 'Steam API', 'https://api.steampowered.com/wallet/add', 'POST', '{"Content-Type": "application/json", "X-Steam-Key": "{api_key}"}', '{"steamid": "{customer_id}", "amount": {amount}, "currency": "{currency}"}', '["success", "added", "wallet_updated"]', '["error", "failed", "invalid_steamid"]', 35, 2, 1, 1),
((SELECT id FROM products WHERE name LIKE '%Fortnite V-Bucks%' LIMIT 1), 'Epic Games API', 'https://api.epicgames.com/fortnite/vbucks', 'POST', '{"Content-Type": "application/json", "Authorization": "Bearer {api_key}"}', '{"account_id": "{customer_id}", "vbucks": {amount}, "platform": "pc"}', '["success", "granted", "vbucks_added"]', '["error", "failed", "account_not_found"]', 30, 2, 1, 1);

-- تحديث إحصائيات المنتجات
UPDATE products SET 
    total_sales = FLOOR(RAND() * 500) + 50,
    rating = ROUND(4.0 + (RAND() * 1.0), 2),
    rating_count = FLOOR(RAND() * 200) + 20
WHERE category_id IN (@mobile_games_id, @pc_games_id, @console_games_id);

-- إضافة خصومات للمنتجات الشائعة
UPDATE products SET 
    discount_percentage = 20.00
WHERE name_ar IN ('شدات ببجي موبايل', 'جواهر فري فاير', 'محفظة ستيم', 'في-باكس فورتنايت');

UPDATE products SET 
    discount_percentage = 15.00
WHERE name_ar IN ('جواهر موبايل ليجندز', 'نقاط كول أوف ديوتي', 'نقاط فالورانت', 'متجر بلايستيشن');

UPDATE products SET 
    discount_percentage = 10.00
WHERE name_ar IN ('جواهر كلاش أوف كلانز', 'بلورات جينشين إمباكت', 'بلايستيشن بلس', 'إكس بوكس جيم باس');

-- إضافة تعليمات مفصلة للمنتجات
UPDATE products SET 
    instructions_ar = 'تأكد من صحة معرف اللاعب. يمكن العثور عليه في إعدادات اللعبة. سيتم إضافة الشدات خلال 5-15 دقيقة.'
WHERE name_ar LIKE '%ببجي%';

UPDATE products SET 
    instructions_ar = 'أدخل معرف اللاعب الصحيح. سيتم إضافة الجواهر فوراً بعد تأكيد الدفع.'
WHERE name_ar LIKE '%فري فاير%';

UPDATE products SET 
    instructions_ar = 'تأكد من أن حساب ستيم الخاص بك مفعل ومتاح للتداول. سيتم إضافة الرصيد خلال ساعة واحدة.'
WHERE name_ar LIKE '%ستيم%';

-- إنشاء فهارس إضافية لتحسين الأداء
CREATE INDEX idx_products_game_category ON products(category_id) WHERE category_id IN (SELECT id FROM categories WHERE type = 'games');
CREATE INDEX idx_products_featured_games ON products(featured, category_id) WHERE featured = 1;

-- إضافة معلومات إضافية للفئات
UPDATE categories SET 
    description = CONCAT(description, ' - متوفر ', 
        (SELECT COUNT(*) FROM products WHERE category_id = categories.id AND status = 'active'), 
        ' منتج')
WHERE type = 'games';

-- إضافة حدود للمبالغ
UPDATE products SET 
    min_amount = 1.00,
    max_amount = 1000.00
WHERE category_id = @mobile_games_id;

UPDATE products SET 
    min_amount = 5.00,
    max_amount = 500.00
WHERE category_id = @pc_games_id;

UPDATE products SET 
    min_amount = 10.00,
    max_amount = 200.00
WHERE category_id = @console_games_id;

SELECT 'Gaming products inserted successfully!' as message;
SELECT COUNT(*) as total_mobile_games FROM products p 
JOIN categories c ON p.category_id = c.id 
WHERE c.name = 'Mobile Games';

SELECT COUNT(*) as total_pc_games FROM products p 
JOIN categories c ON p.category_id = c.id 
WHERE c.name = 'PC Games';

SELECT COUNT(*) as total_console_games FROM products p 
JOIN categories c ON p.category_id = c.id 
WHERE c.name = 'Console Games';
