#!/usr/bin/env php
<?php
/**
 * Database Setup Runner
 * تشغيل إعداد قاعدة البيانات
 */

require_once dirname(__DIR__) . '/config/config.php';

class DatabaseSetup {
    private $db;
    private $scripts_dir;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->scripts_dir = __DIR__;
        
        echo "🗄️ بدء إعداد قاعدة البيانات...\n\n";
        $this->runSetup();
    }
    
    private function runSetup() {
        $scripts = [
            'database_setup.sql' => 'إعداد الجداول الأساسية',
            'backup_system_tables.sql' => 'إعداد جداول النسخ الاحتياطي والAPI',
            'insert_chat_products.sql' => 'إدراج منتجات التشات',
            'insert_game_products.sql' => 'إدراج منتجات الألعاب',
            'add_payment_tables.sql' => 'إضافة جداول الدفع',
            'update_product_images.sql' => 'تحديث صور المنتجات',
            'fix_admin_login.sql' => 'إصلاح تسجيل دخول المدير',
            'add_new_payment_gateways.sql' => 'إضافة بوابات دفع جديدة',
            'fix_admin_table_structure.sql' => 'إصلاح هيكل جدول المديرين'
        ];
        
        foreach ($scripts as $script => $description) {
            $this->runScript($script, $description);
        }
        
        // Create default admin if not exists
        $this->createDefaultAdmin();
        
        // Create test data
        $this->createTestData();
        
        echo "\n✅ تم إعداد قاعدة البيانات بنجاح!\n";
        echo "📊 إحصائيات قاعدة البيانات:\n";
        $this->showDatabaseStats();
    }
    
    private function runScript($script_name, $description) {
        $script_path = $this->scripts_dir . '/' . $script_name;
        
        if (!file_exists($script_path)) {
            echo "⚠️ الملف غير موجود: $script_name\n";
            return;
        }
        
        echo "📝 تشغيل: $description ($script_name)...\n";
        
        try {
            $sql = file_get_contents($script_path);
            
            // Split SQL into individual statements
            $statements = $this->splitSQLStatements($sql);
            
            foreach ($statements as $statement) {
                $statement = trim($statement);
                if (empty($statement) || strpos($statement, '--') === 0) {
                    continue;
                }
                
                $this->db->exec($statement);
            }
            
            echo "✅ تم بنجاح\n";
            
        } catch (Exception $e) {
            echo "❌ خطأ: " . $e->getMessage() . "\n";
        }
        
        echo "\n";
    }
    
    private function splitSQLStatements($sql) {
        // Remove comments and split by semicolon
        $sql = preg_replace('/--.*$/m', '', $sql);
        $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
        
        $statements = explode(';', $sql);
        
        return array_filter($statements, function($stmt) {
            return !empty(trim($stmt));
        });
    }
    
    private function createDefaultAdmin() {
        echo "👤 إنشاء مدير افتراضي...\n";
        
        try {
            // Check if admin exists
            $stmt = $this->db->prepare("SELECT id FROM admins WHERE username = 'admin'");
            $stmt->execute();
            
            if ($stmt->fetch()) {
                echo "✅ المدير الافتراضي موجود مسبقاً\n";
                return;
            }
            
            // Create default admin
            $stmt = $this->db->prepare("
                INSERT INTO admins (username, email, password, role, status) 
                VALUES ('admin', 'admin@faststarone.com', ?, 'super_admin', 'active')
            ");
            $stmt->execute([password_hash('admin123', PASSWORD_DEFAULT)]);
            
            echo "✅ تم إنشاء المدير الافتراضي\n";
            echo "   اسم المستخدم: admin\n";
            echo "   كلمة المرور: admin123\n";
            echo "   ⚠️ يرجى تغيير كلمة المرور فوراً!\n";
            
        } catch (Exception $e) {
            echo "❌ خطأ في إنشاء المدير: " . $e->getMessage() . "\n";
        }
        
        echo "\n";
    }
    
    private function createTestData() {
        echo "🧪 إنشاء بيانات تجريبية...\n";
        
        try {
            // Create test user
            $stmt = $this->db->prepare("SELECT id FROM users WHERE username = 'testuser'");
            $stmt->execute();
            
            if (!$stmt->fetch()) {
                $stmt = $this->db->prepare("
                    INSERT INTO users (username, email, password, phone, status) 
                    VALUES ('testuser', 'test@example.com', ?, '+966501234567', 'active')
                ");
                $stmt->execute([password_hash('testpass123', PASSWORD_DEFAULT)]);
                
                $user_id = $this->db->lastInsertId();
                
                // Create wallet for test user
                $stmt = $this->db->prepare("
                    INSERT INTO wallets (user_id, balance, currency) 
                    VALUES (?, 1000.00, 'YER')
                ");
                $stmt->execute([$user_id]);
                
                echo "✅ تم إنشاء مستخدم تجريبي (testuser/testpass123)\n";
            }
            
            // Create test categories if not exist
            $categories = [
                ['name' => 'ألعاب', 'description' => 'شحن الألعاب والتطبيقات'],
                ['name' => 'تطبيقات التواصل', 'description' => 'شحن تطبيقات التواصل الاجتماعي'],
                ['name' => 'خدمات رقمية', 'description' => 'خدمات رقمية متنوعة']
            ];
            
            foreach ($categories as $category) {
                $stmt = $this->db->prepare("SELECT id FROM categories WHERE name = ?");
                $stmt->execute([$category['name']]);
                
                if (!$stmt->fetch()) {
                    $stmt = $this->db->prepare("
                        INSERT INTO categories (name, description, status) 
                        VALUES (?, ?, 'active')
                    ");
                    $stmt->execute([$category['name'], $category['description']]);
                }
            }
            
            echo "✅ تم إنشاء الفئات التجريبية\n";
            
        } catch (Exception $e) {
            echo "❌ خطأ في إنشاء البيانات التجريبية: " . $e->getMessage() . "\n";
        }
        
        echo "\n";
    }
    
    private function showDatabaseStats() {
        try {
            $tables = [
                'users' => 'المستخدمين',
                'admins' => 'المديرين',
                'categories' => 'الفئات',
                'products' => 'المنتجات',
                'orders' => 'الطلبات',
                'wallets' => 'المحافظ',
                'api_keys' => 'مفاتيح API',
                'backups' => 'النسخ الاحتياطية',
                'payment_gateways' => 'بوابات الدفع'
            ];
            
            foreach ($tables as $table => $arabic_name) {
                try {
                    $stmt = $this->db->prepare("SELECT COUNT(*) FROM $table");
                    $stmt->execute();
                    $count = $stmt->fetchColumn();
                    echo "   $arabic_name ($table): $count\n";
                } catch (Exception $e) {
                    echo "   $arabic_name ($table): غير موجود\n";
                }
            }
            
        } catch (Exception $e) {
            echo "❌ خطأ في عرض الإحصائيات: " . $e->getMessage() . "\n";
        }
    }
}

// Run setup if called directly
if (php_sapi_name() === 'cli') {
    new DatabaseSetup();
} else {
    echo "<pre>";
    new DatabaseSetup();
    echo "</pre>";
}
?>
