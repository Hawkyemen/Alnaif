-- إنشاء المدير الافتراضي
INSERT INTO admin_users (username, password, email, full_name, role, status, created_at) 
VALUES (
    'admin', 
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- password: admin
    'admin@sabrahsoft.com', 
    'مدير النظام', 
    'super_admin', 
    'active', 
    NOW()
) ON DUPLICATE KEY UPDATE 
    password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    status = 'active';

-- إنشاء بعض الفئات الافتراضية
INSERT INTO categories (name, name_ar, description, icon, status) VALUES
('Games', 'الألعاب', 'شحن الألعاب المختلفة', 'gamepad', 'active'),
('Apps', 'التطبيقات', 'شحن التطبيقات والخدمات', 'mobile-alt', 'active'),
('Social', 'التواصل الاجتماعي', 'شحن تطبيقات التواصل', 'comments', 'active')
ON DUPLICATE KEY UPDATE status = 'active';

-- إنشاء بعض المنتجات التجريبية
INSERT INTO products (category_id, name, name_ar, description, price_yer, price_sar, price_usd, status) VALUES
(1, 'PUBG Mobile UC', 'شدات ببجي موبايل', 'شحن شدات لعبة ببجي موبايل', 2000, 8, 2, 'active'),
(1, 'Free Fire Diamonds', 'جواهر فري فاير', 'شحن جواهر لعبة فري فاير', 1500, 6, 1.5, 'active'),
(2, 'Netflix Subscription', 'اشتراك نتفليكس', 'اشتراك شهري في نتفليكس', 3750, 15, 4, 'active'),
(3, 'WhatsApp Business', 'واتساب بزنس', 'تفعيل واتساب للأعمال', 1250, 5, 1.25, 'active')
ON DUPLICATE KEY UPDATE status = 'active';
