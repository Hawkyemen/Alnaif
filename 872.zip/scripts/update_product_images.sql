-- تحديث صور المنتجات وإضافة محتوى إضافي
-- Update Product Images and Additional Content

-- تحديث صور منتجات الألعاب
UPDATE products SET 
    image = '/images/products/pubg-mobile.jpg'
WHERE name_ar LIKE '%ببجي%';

UPDATE products SET 
    image = '/images/products/free-fire.jpg'
WHERE name_ar LIKE '%فري فاير%';

UPDATE products SET 
    image = '/images/products/mobile-legends.jpg'
WHERE name_ar LIKE '%موبايل ليجندز%';

UPDATE products SET 
    image = '/images/products/cod-mobile.jpg'
WHERE name_ar LIKE '%كول أوف ديوتي%';

UPDATE products SET 
    image = '/images/products/clash-of-clans.jpg'
WHERE name_ar LIKE '%كلاش أوف كلانز%';

UPDATE products SET 
    image = '/images/products/clash-royale.jpg'
WHERE name_ar LIKE '%كلاش رويال%';

UPDATE products SET 
    image = '/images/products/genshin-impact.jpg'
WHERE name_ar LIKE '%جينشين إمباكت%';

UPDATE products SET 
    image = '/images/products/steam.jpg'
WHERE name_ar LIKE '%ستيم%';

UPDATE products SET 
    image = '/images/products/fortnite.jpg'
WHERE name_ar LIKE '%فورتنايت%';

UPDATE products SET 
    image = '/images/products/valorant.jpg'
WHERE name_ar LIKE '%فالورانت%';

UPDATE products SET 
    image = '/images/products/league-of-legends.jpg'
WHERE name_ar LIKE '%ليج أوف ليجندز%';

UPDATE products SET 
    image = '/images/products/playstation.jpg'
WHERE name_ar LIKE '%بلايستيشن%';

UPDATE products SET 
    image = '/images/products/xbox.jpg'
WHERE name_ar LIKE '%إكس بوكس%';

UPDATE products SET 
    image = '/images/products/nintendo.jpg'
WHERE name_ar LIKE '%نينتندو%';

-- تحديث صور منتجات التواصل الاجتماعي
UPDATE products SET 
    image = '/images/products/whatsapp-business.jpg'
WHERE name_ar LIKE '%واتساب%';

UPDATE products SET 
    image = '/images/products/telegram.jpg'
WHERE name_ar LIKE '%تيليجرام%';

UPDATE products SET 
    image = '/images/products/discord.jpg'
WHERE name_ar LIKE '%ديسكورد%';

UPDATE products SET 
    image = '/images/products/skype.jpg'
WHERE name_ar LIKE '%سكايب%';

UPDATE products SET 
    image = '/images/products/zoom.jpg'
WHERE name_ar LIKE '%زوم%';

UPDATE products SET 
    image = '/images/products/facebook.jpg'
WHERE name_ar LIKE '%فيسبوك%';

UPDATE products SET 
    image = '/images/products/instagram.jpg'
WHERE name_ar LIKE '%إنستجرام%';

UPDATE products SET 
    image = '/images/products/twitter.jpg'
WHERE name_ar LIKE '%تويتر%';

UPDATE products SET 
    image = '/images/products/linkedin.jpg'
WHERE name_ar LIKE '%لينكد إن%';

UPDATE products SET 
    image = '/images/products/tiktok.jpg'
WHERE name_ar LIKE '%تيك توك%';

UPDATE products SET 
    image = '/images/products/youtube.jpg'
WHERE name_ar LIKE '%يوتيوب%';

UPDATE products SET 
    image = '/images/products/snapchat.jpg'
WHERE name_ar LIKE '%سناب شات%';

UPDATE products SET 
    image = '/images/products/pinterest.jpg'
WHERE name_ar LIKE '%بينترست%';

-- تحديث صور الفئات
UPDATE categories SET 
    image = '/images/categories/mobile-games.jpg'
WHERE name = 'Mobile Games';

UPDATE categories SET 
    image = '/images/categories/pc-games.jpg'
WHERE name = 'PC Games';

UPDATE categories SET 
    image = '/images/categories/console-games.jpg'
WHERE name = 'Console Games';

UPDATE categories SET 
    image = '/images/categories/chat-apps.jpg'
WHERE name = 'Chat Applications';

UPDATE categories SET 
    image = '/images/categories/social-media.jpg'
WHERE name = 'Social Media';

-- إضافة وصف مفصل للمنتجات الشائعة
UPDATE products SET 
    description_ar = 'شدات ببجي موبايل هي العملة الرسمية داخل لعبة PUBG Mobile. يمكن استخدامها لشراء الأزياء، الأسلحة، والعناصر التجميلية. احصل على شداتك بسرعة وأمان من خلال منصتنا.',
    instructions_ar = '1. أدخل معرف اللاعب الخاص بك (Player ID)\n2. اختر كمية الشدات المطلوبة\n3. أكمل عملية الدفع\n4. ستصل الشدات خلال 5-15 دقيقة\n\nملاحظة: تأكد من صحة معرف اللاعب لتجنب أي تأخير'
WHERE name_ar LIKE '%شدات ببجي%' AND sort_order = 1;

UPDATE products SET 
    description_ar = 'جواهر فري فاير هي العملة المميزة في لعبة Free Fire. استخدمها لشراء الشخصيات، الأسلحة، والأشكال الحصرية. تسليم فوري وآمن مضمون.',
    instructions_ar = '1. أدخل معرف اللاعب (Player ID) من إعدادات اللعبة\n2. حدد عدد الجواهر المطلوبة\n3. ادفع بالطريقة المفضلة لديك\n4. الجواهر ستظهر في حسابك فوراً\n\nنصيحة: يمكن العثور على معرف اللاعب في الملف الشخصي داخل اللعبة'
WHERE name_ar LIKE '%جواهر فري فاير%' AND sort_order = 4;

UPDATE products SET 
    description_ar = 'رصيد محفظة ستيم يتيح لك شراء الألعاب، المحتوى الإضافي، والعناصر من متجر ستيم. طريقة آمنة ومريحة للتسوق في أكبر منصة ألعاب في العالم.',
    instructions_ar = '1. أدخل اسم المستخدم في ستيم أو رابط الملف الشخصي\n2. اختر مبلغ الرصيد المطلوب\n3. أكمل الدفع\n4. سيتم إضافة الرصيد خلال ساعة واحدة\n\nمهم: تأكد من أن حسابك مفعل وقابل للتداول'
WHERE name_ar LIKE '%محفظة ستيم%' AND sort_order = 1;

UPDATE products SET 
    description_ar = 'اشتراك واتساب بيزنس يوفر ميزات متقدمة للشركات والأعمال التجارية. يشمل الرسائل الجماعية، التحليلات، والدعم المتقدم.',
    instructions_ar = '1. أدخل رقم الهاتف التجاري المسجل في واتساب بيزنس\n2. تأكد من تفعيل الحساب التجاري\n3. أكمل عملية الدفع\n4. سيتم تفعيل الاشتراك خلال 10 دقائق\n\nملاحظة: يجب أن يكون الرقم مسجل مسبقاً كحساب تجاري'
WHERE name_ar LIKE '%واتساب بيزنس%';

-- إضافة معلومات إضافية للمنتجات
UPDATE products SET 
    min_amount = 60.00,
    max_amount = 18000.00
WHERE name_ar LIKE '%شدات ببجي%';

UPDATE products SET 
    min_amount = 100.00,
    max_amount = 10800.00
WHERE name_ar LIKE '%جواهر فري فاير%';

UPDATE products SET 
    min_amount = 86.00,
    max_amount = 4080.00
WHERE name_ar LIKE '%جواهر موبايل ليجندز%';

UPDATE products SET 
    min_amount = 80.00,
    max_amount = 8000.00
WHERE name_ar LIKE '%نقاط كول أوف ديوتي%';

UPDATE products SET 
    min_amount = 500.00,
    max_amount = 50000.00
WHERE name_ar LIKE '%جواهر كلاش%';

UPDATE products SET 
    min_amount = 330.00,
    max_amount = 19800.00
WHERE name_ar LIKE '%بلورات جينشين%';

-- تحديث تقييمات المنتجات بشكل واقعي
UPDATE products SET 
    rating = 4.8,
    rating_count = 1247
WHERE name_ar LIKE '%شدات ببجي موبايل%' AND sort_order = 1;

UPDATE products SET 
    rating = 4.7,
    rating_count = 892
WHERE name_ar LIKE '%جواهر فري فاير%' AND sort_order = 4;

UPDATE products SET 
    rating = 4.6,
    rating_count = 634
WHERE name_ar LIKE '%جواهر موبايل ليجندز%' AND sort_order = 7;

UPDATE products SET 
    rating = 4.9,
    rating_count = 2156
WHERE name_ar LIKE '%محفظة ستيم%' AND sort_order = 1;

UPDATE products SET 
    rating = 4.5,
    rating_count = 743
WHERE name_ar LIKE '%في-باكس فورتنايت%' AND sort_order = 5;

UPDATE products SET 
    rating = 4.7,
    rating_count = 456
WHERE name_ar LIKE '%نقاط فالورانت%' AND sort_order = 7;

UPDATE products SET 
    rating = 4.8,
    rating_count = 1834
WHERE name_ar LIKE '%بلايستيشن بلس%';

UPDATE products SET 
    rating = 4.6,
    rating_count = 567
WHERE name_ar LIKE '%واتساب بيزنس%';

UPDATE products SET 
    rating = 4.7,
    rating_count = 423
WHERE name_ar LIKE '%تيليجرام بريميوم%';

UPDATE products SET 
    rating = 4.5,
    rating_count = 789
WHERE name_ar LIKE '%ديسكورد نيترو%';

-- تحديث إحصائيات المبيعات
UPDATE products SET 
    total_sales = 3247
WHERE name_ar LIKE '%شدات ببجي موبايل%' AND sort_order = 1;

UPDATE products SET 
    total_sales = 2156
WHERE name_ar LIKE '%جواهر فري فاير%' AND sort_order = 4;

UPDATE products SET 
    total_sales = 1834
WHERE name_ar LIKE '%محفظة ستيم%' AND sort_order = 1;

UPDATE products SET 
    total_sales = 1567
WHERE name_ar LIKE '%في-باكس فورتنايت%' AND sort_order = 5;

UPDATE products SET 
    total_sales = 1234
WHERE name_ar LIKE '%جواهر موبايل ليجندز%' AND sort_order = 7;

UPDATE products SET 
    total_sales = 987
WHERE name_ar LIKE '%نقاط كول أوف ديوتي%' AND sort_order = 9;

UPDATE products SET 
    total_sales = 856
WHERE name_ar LIKE '%جواهر كلاش أوف كلانز%' AND sort_order = 11;

UPDATE products SET 
    total_sales = 743
WHERE name_ar LIKE '%بلورات جينشين إمباكت%' AND sort_order = 14;

UPDATE products SET 
    total_sales = 1456
WHERE name_ar LIKE '%بلايستيشن بلس%';

UPDATE products SET 
    total_sales = 892
WHERE name_ar LIKE '%إكس بوكس جيم باس%';

UPDATE products SET 
    total_sales = 1123
WHERE name_ar LIKE '%واتساب بيزنس%';

UPDATE products SET 
    total_sales = 678
WHERE name_ar LIKE '%تيليجرام بريميوم%';

UPDATE products SET 
    total_sales = 534
WHERE name_ar LIKE '%ديسكورد نيترو%';

UPDATE products SET 
    total_sales = 789
WHERE name_ar LIKE '%زوم برو%';

-- إضافة خصومات موسمية إضافية
UPDATE products SET 
    discount_percentage = 25.00
WHERE name_ar IN ('شدات ببجي موبايل', 'جواهر فري فاير', 'محفظة ستيم') AND sort_order <= 3;

UPDATE products SET 
    discount_percentage = 20.00
WHERE name_ar IN ('في-باكس فورتنايت', 'نقاط فالورانت', 'جواهر موبايل ليجندز') AND sort_order <= 8;

UPDATE products SET 
    discount_percentage = 15.00
WHERE name_ar IN ('جواهر كلاش أوف كلانز', 'بلورات جينشين إمباكت', 'نقاط كول أوف ديوتي');

UPDATE products SET 
    discount_percentage = 30.00
WHERE name_ar IN ('بلايستيشن بلس', 'إكس بوكس جيم باس') AND MONTH(NOW()) IN (11, 12, 1); -- خصم الشتاء

-- تحديث حالة المنتجات
UPDATE products SET 
    status = 'active',
    featured = 1
WHERE total_sales > 1000;

UPDATE products SET 
    featured = 0
WHERE total_sales < 500;

-- إضافة منتجات جديدة شائعة
INSERT INTO `products` (`category_id`, `name`, `name_ar`, `description`, `description_ar`, `image`, `price_yer`, `price_sar`, `price_usd`, `price_aed`, `discount_percentage`, `customer_id_label`, `customer_id_placeholder`, `instructions`, `instructions_ar`, `sort_order`, `status`, `featured`, `total_sales`, `rating`, `rating_count`) VALUES
((SELECT id FROM categories WHERE name = 'Mobile Games'), 'Roblox Robux', 'روبوكس روبلوكس', 'Roblox Robux for avatar customization and game passes', 'روبوكس لتخصيص الشخصية وتمريرات الألعاب في روبلوكس', '/images/products/roblox.jpg', 750.00, 20.00, 2.00, 7.34, 15.00, 'Roblox Username', 'اسم المستخدم في روبلوكس', 'Enter your Roblox username exactly as it appears', 'أدخل اسم المستخدم في روبلوكس كما يظهر تماماً', 16, 'active', 1, 1456, 4.6, 892),
((SELECT id FROM categories WHERE name = 'Mobile Games'), 'Minecraft Minecoins', 'عملات ماين كرافت', 'Minecraft Minecoins for marketplace content', 'عملات ماين كرافت لمحتوى السوق', '/images/products/minecraft.jpg', 937.50, 25.00, 2.50, 9.18, 10.00, 'Xbox Gamertag', 'اسم اللاعب في إكس بوكس', 'Enter your Xbox Gamertag or Minecraft username', 'أدخل اسم اللاعب في إكس بوكس أو اسم المستخدم في ماين كرافت', 17, 'active', 1, 987, 4.7, 567),
((SELECT id FROM categories WHERE name = 'PC Games'), 'Apex Legends Coins', 'عملات أبيكس ليجندز', 'Apex Coins for legends, skins, and battle passes', 'عملات أبيكس للأساطير والأشكال وتمريرات المعركة', '/images/products/apex-legends.jpg', 1125.00, 30.00, 3.00, 11.01, 20.00, 'Origin Username', 'اسم المستخدم في أوريجن', 'Enter your Origin/EA username', 'أدخل اسم المستخدم في أوريجن/EA', 10, 'active', 1, 743, 4.5, 423);

-- تحديث APIs الشحن مع معلومات إضافية
UPDATE charging_apis SET 
    success_rate = 98.5,
    total_requests = 15420,
    successful_requests = 15189,
    failed_requests = 231,
    last_used = NOW() - INTERVAL FLOOR(RAND() * 60) MINUTE
WHERE name LIKE '%PUBG%';

UPDATE charging_apis SET 
    success_rate = 97.8,
    total_requests = 12340,
    successful_requests = 12069,
    failed_requests = 271,
    last_used = NOW() - INTERVAL FLOOR(RAND() * 120) MINUTE
WHERE name LIKE '%Free Fire%';

UPDATE charging_apis SET 
    success_rate = 99.2,
    total_requests = 8765,
    successful_requests = 8695,
    failed_requests = 70,
    last_used = NOW() - INTERVAL FLOOR(RAND() * 30) MINUTE
WHERE name LIKE '%Steam%';

UPDATE charging_apis SET 
    success_rate = 96.5,
    total_requests = 6543,
    successful_requests = 6314,
    failed_requests = 229,
    last_used = NOW() - INTERVAL FLOOR(RAND() * 90) MINUTE
WHERE name LIKE '%Mobile Legends%';

-- إضافة معلومات SEO للمنتجات
ALTER TABLE products ADD COLUMN `seo_title` varchar(255) DEFAULT NULL AFTER `instructions_ar`;
ALTER TABLE products ADD COLUMN `seo_description` text DEFAULT NULL AFTER `seo_title`;
ALTER TABLE products ADD COLUMN `seo_keywords` varchar(500) DEFAULT NULL AFTER `seo_description`;

UPDATE products SET 
    seo_title = CONCAT('شراء ', name_ar, ' - أفضل الأسعار والتسليم الفوري'),
    seo_description = CONCAT('احصل على ', name_ar, ' بأفضل الأسعار وأسرع تسليم. دفع آمن وخدمة عملاء 24/7. ', SUBSTRING(description_ar, 1, 100), '...'),
    seo_keywords = CONCAT(name_ar, ',', name, ',شحن,ألعاب,تطبيقات,فاست ستار')
WHERE seo_title IS NULL;

-- إنشاء جدول تقييمات المنتجات
CREATE TABLE IF NOT EXISTS `product_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `rating` tinyint(1) NOT NULL CHECK (rating >= 1 AND rating <= 5),
  `review_text` text DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT 0,
  `is_approved` tinyint(1) DEFAULT 1,
  `admin_reply` text DEFAULT NULL,
  `helpful_count` int(11) DEFAULT 0,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_product_order` (`user_id`,`product_id`,`order_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_rating` (`rating`),
  KEY `idx_is_approved` (`is_approved`),
  CONSTRAINT `fk_product_reviews_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_product_reviews_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_product_reviews_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- إدراج تقييمات وهمية للمنتجات الشائعة
INSERT INTO `product_reviews` (`product_id`, `user_id`, `rating`, `review_text`, `is_verified`, `is_approved`, `helpful_count`) 
SELECT 
    p.id,
    1, -- assuming admin user exists
    FLOOR(4 + RAND() * 2), -- rating between 4-5
    CASE 
        WHEN p.name_ar LIKE '%ببجي%' THEN 'خدمة ممتازة وتسليم سريع. الشدات وصلت خلال دقائق قليلة.'
        WHEN p.name_ar LIKE '%فري فاير%' THEN 'أفضل موقع لشحن فري فاير. أسعار منافسة وخدمة موثوقة.'
        WHEN p.name_ar LIKE '%ستيم%' THEN 'رصيد ستيم وصل بسرعة. موقع آمن وموثوق.'
        WHEN p.name_ar LIKE '%فورتنايت%' THEN 'في-باكس فورتنايت بأفضل سعر. تسليم فوري ومضمون.'
        ELSE 'خدمة ممتازة وأسعار مناسبة. أنصح بالتعامل مع الموقع.'
    END,
    1,
    1,
    FLOOR(RAND() * 20) + 5
FROM products p
WHERE p.featured = 1 AND p.total_sales > 500
LIMIT 20;

SELECT 'Product images and content updated successfully!' as message;
SELECT COUNT(*) as total_products_with_images FROM products WHERE image IS NOT NULL;
SELECT COUNT(*) as total_featured_products FROM products WHERE featured = 1;
SELECT AVG(rating) as average_rating FROM products WHERE rating > 0;
