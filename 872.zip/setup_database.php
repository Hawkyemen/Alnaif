<?php
/**
 * Database Setup Script
 * إعداد قاعدة البيانات
 */

// تضمين ملف الإعدادات
require_once 'config/config.php';

// بدء HTML
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إعداد قاعدة البيانات - فاست ستار</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
            min-height: 100vh;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        .header {
            background: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .content {
            padding: 30px;
        }
        .step {
            margin: 20px 0;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid #3498db;
            background: #f8f9fa;
        }
        .step.success {
            border-left-color: #27ae60;
            background: #d4edda;
        }
        .step.error {
            border-left-color: #e74c3c;
            background: #f8d7da;
        }
        .step.warning {
            border-left-color: #f39c12;
            background: #fff3cd;
        }
        .btn {
            display: inline-block;
            padding: 12px 24px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            margin: 10px 5px;
        }
        .btn:hover {
            background: #2980b9;
        }
        .btn.success {
            background: #27ae60;
        }
        .btn.danger {
            background: #e74c3c;
        }
        .log {
            background: #2c3e50;
            color: #ecf0f1;
            padding: 15px;
            border-radius: 5px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
            max-height: 400px;
            overflow-y: auto;
            margin: 20px 0;
        }
        .progress {
            width: 100%;
            height: 20px;
            background: #ecf0f1;
            border-radius: 10px;
            overflow: hidden;
            margin: 20px 0;
        }
        .progress-bar {
            height: 100%;
            background: linear-gradient(90deg, #3498db, #2ecc71);
            transition: width 0.3s ease;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🗄️ إعداد قاعدة البيانات</h1>
            <p>نظام فاست ستار للشحن الإلكتروني</p>
        </div>
        
        <div class="content">
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['setup'])) {
                setupDatabase();
            } else {
                showSetupForm();
            }
            ?>
        </div>
    </div>
</body>
</html>

<?php
function showSetupForm() {
    ?>
    <div class="step">
        <h3>🚀 مرحباً بك في معالج إعداد قاعدة البيانات</h3>
        <p>سيقوم هذا المعالج بإنشاء جميع الجداول والبيانات الأساسية المطلوبة لتشغيل النظام.</p>
    </div>
    
    <div class="step warning">
        <h4>⚠️ تحذير مهم</h4>
        <p>تأكد من صحة إعدادات قاعدة البيانات في ملف <code>config/config.php</code> قبل المتابعة.</p>
        <ul>
            <li>اسم الخادم: <strong><?php echo DB_HOST; ?></strong></li>
            <li>اسم قاعدة البيانات: <strong><?php echo DB_NAME; ?></strong></li>
            <li>اسم المستخدم: <strong><?php echo DB_USER; ?></strong></li>
        </ul>
    </div>
    
    <form method="POST">
        <button type="submit" name="setup" class="btn success">
            🔧 بدء إعداد قاعدة البيانات
        </button>
    </form>
    <?php
}

function setupDatabase() {
    echo '<div class="progress"><div class="progress-bar" style="width: 0%" id="progressBar"></div></div>';
    echo '<div class="log" id="setupLog">';
    
    $steps = [
        'إنشاء قاعدة البيانات',
        'إنشاء جدول المستخدمين',
        'إنشاء جدول المديرين',
        'إنشاء جدول الفئات',
        'إنشاء جدول المنتجات',
        'إنشاء جدول الطلبات',
        'إنشاء جدول المحافظ',
        'إنشاء جدول معاملات المحفظة',
        'إنشاء جدول بوابات الدفع',
        'إنشاء جدول الإعدادات',
        'إدراج البيانات الأساسية',
        'إنشاء المدير الافتراضي',
        'إنهاء الإعداد'
    ];
    
    $totalSteps = count($steps);
    $currentStep = 0;
    
    try {
        // الاتصال بقاعدة البيانات
        $pdo = new PDO("mysql:host=" . DB_HOST . ";charset=utf8mb4", DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
        
        logStep("✅ تم الاتصال بخادم قاعدة البيانات بنجاح");
        updateProgress(++$currentStep, $totalSteps);
        
        // إنشاء قاعدة البيانات
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `" . DB_NAME . "`");
        logStep("✅ تم إنشاء قاعدة البيانات: " . DB_NAME);
        updateProgress(++$currentStep, $totalSteps);
        
        // إنشاء جدول المستخدمين
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `users` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `username` varchar(50) NOT NULL,
                `email` varchar(100) NOT NULL,
                `password` varchar(255) NOT NULL,
                `full_name` varchar(100) NOT NULL,
                `phone` varchar(20) DEFAULT NULL,
                `country` varchar(50) DEFAULT 'Yemen',
                `wallet_balance_yer` decimal(15,2) DEFAULT 0.00,
                `wallet_balance_sar` decimal(15,2) DEFAULT 0.00,
                `wallet_balance_usd` decimal(15,2) DEFAULT 0.00,
                `wallet_balance_aed` decimal(15,2) DEFAULT 0.00,
                `status` enum('active','inactive','banned') DEFAULT 'active',
                `email_verified` tinyint(1) DEFAULT 0,
                `phone_verified` tinyint(1) DEFAULT 0,
                `last_login` timestamp NULL DEFAULT NULL,
                `login_attempts` int(11) DEFAULT 0,
                `locked_until` timestamp NULL DEFAULT NULL,
                `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
                `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `username` (`username`),
                UNIQUE KEY `email` (`email`),
                KEY `idx_status` (`status`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        logStep("✅ تم إنشاء جدول المستخدمين");
        updateProgress(++$currentStep, $totalSteps);
        
        // إنشاء جدول المديرين
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `admin_users` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `username` varchar(50) NOT NULL,
                `email` varchar(100) NOT NULL,
                `password` varchar(255) NOT NULL,
                `full_name` varchar(100) NOT NULL,
                `role` enum('admin','super_admin') DEFAULT 'admin',
                `status` enum('active','inactive') DEFAULT 'active',
                `login_attempts` int(11) DEFAULT 0,
                `locked_until` datetime DEFAULT NULL,
                `last_login` datetime DEFAULT NULL,
                `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
                `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `username` (`username`),
                UNIQUE KEY `email` (`email`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        logStep("✅ تم إنشاء جدول المديرين");
        updateProgress(++$currentStep, $totalSteps);
        
        // إنشاء جدول الفئات
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `categories` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(100) NOT NULL,
                `name_en` varchar(100) DEFAULT NULL,
                `description` text DEFAULT NULL,
                `image` varchar(255) DEFAULT NULL,
                `icon` varchar(100) DEFAULT NULL,
                `sort_order` int(11) DEFAULT 0,
                `status` enum('active','inactive') DEFAULT 'active',
                `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
                `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `idx_status` (`status`),
                KEY `idx_sort_order` (`sort_order`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        logStep("✅ تم إنشاء جدول الفئات");
        updateProgress(++$currentStep, $totalSteps);
        
        // إنشاء جدول المنتجات
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `products` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `category_id` int(11) NOT NULL,
                `name` varchar(200) NOT NULL,
                `name_en` varchar(200) DEFAULT NULL,
                `description` text DEFAULT NULL,
                `image` varchar(255) DEFAULT NULL,
                `price_yer` decimal(10,2) NOT NULL,
                `price_sar` decimal(10,2) DEFAULT NULL,
                `price_usd` decimal(10,2) DEFAULT NULL,
                `price_aed` decimal(10,2) DEFAULT NULL,
                `discount_percentage` decimal(5,2) DEFAULT 0,
                `min_quantity` int(11) DEFAULT 1,
                `max_quantity` int(11) DEFAULT 100,
                `is_featured` tinyint(1) DEFAULT 0,
                `delivery_time` varchar(50) DEFAULT 'فوري',
                `status` enum('active','inactive','out_of_stock') DEFAULT 'active',
                `sort_order` int(11) DEFAULT 0,
                `sales_count` int(11) DEFAULT 0,
                `rating` decimal(3,2) DEFAULT 0.00,
                `reviews_count` int(11) DEFAULT 0,
                `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
                `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `idx_category_id` (`category_id`),
                KEY `idx_status` (`status`),
                KEY `idx_featured` (`is_featured`),
                CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        logStep("✅ تم إنشاء جدول المنتجات");
        updateProgress(++$currentStep, $totalSteps);
        
        // إنشاء جدول الطلبات
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `orders` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `order_number` varchar(50) UNIQUE NOT NULL,
                `user_id` int(11) NOT NULL,
                `product_id` int(11) NOT NULL,
                `quantity` int(11) NOT NULL DEFAULT 1,
                `unit_price` decimal(10,2) NOT NULL,
                `total_amount` decimal(10,2) NOT NULL,
                `currency` varchar(3) DEFAULT 'YER',
                `customer_data` json DEFAULT NULL,
                `payment_method` varchar(50) DEFAULT NULL,
                `payment_gateway` varchar(50) DEFAULT NULL,
                `transaction_id` varchar(100) DEFAULT NULL,
                `status` enum('pending','processing','completed','failed','cancelled','refunded') DEFAULT 'pending',
                `payment_status` enum('pending','paid','failed','refunded') DEFAULT 'pending',
                `notes` text DEFAULT NULL,
                `admin_notes` text DEFAULT NULL,
                `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
                `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `order_number` (`order_number`),
                KEY `idx_user_id` (`user_id`),
                KEY `idx_product_id` (`product_id`),
                KEY `idx_status` (`status`),
                CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
                CONSTRAINT `fk_orders_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        logStep("✅ تم إنشاء جدول الطلبات");
        updateProgress(++$currentStep, $totalSteps);
        
        // إنشاء جدول المحافظ
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `wallets` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `user_id` int(11) NOT NULL,
                `balance` decimal(15,2) DEFAULT 0.00,
                `currency` varchar(3) DEFAULT 'YER',
                `is_frozen` tinyint(1) DEFAULT 0,
                `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
                `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `user_currency` (`user_id`, `currency`),
                CONSTRAINT `fk_wallets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        logStep("✅ تم إنشاء جدول المحافظ");
        updateProgress(++$currentStep, $totalSteps);
        
        // إنشاء جدول معاملات المحفظة
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `wallet_transactions` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `user_id` int(11) NOT NULL,
                `type` enum('deposit','withdrawal','purchase','refund','transfer') NOT NULL,
                `amount` decimal(15,2) NOT NULL,
                `currency` varchar(3) NOT NULL DEFAULT 'YER',
                `balance_before` decimal(15,2) NOT NULL,
                `balance_after` decimal(15,2) NOT NULL,
                `description` text DEFAULT NULL,
                `reference_type` varchar(50) DEFAULT NULL,
                `reference_id` int(11) DEFAULT NULL,
                `transaction_id` varchar(100) DEFAULT NULL,
                `status` enum('pending','completed','failed','cancelled') DEFAULT 'completed',
                `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `idx_user_id` (`user_id`),
                KEY `idx_type` (`type`),
                KEY `idx_status` (`status`),
                CONSTRAINT `fk_wallet_transactions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        logStep("✅ تم إنشاء جدول معاملات المحفظة");
        updateProgress(++$currentStep, $totalSteps);
        
        // إنشاء جدول بوابات الدفع
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `payment_gateways` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `name` varchar(100) NOT NULL,
                `code` varchar(50) NOT NULL,
                `description` text DEFAULT NULL,
                `config` json DEFAULT NULL,
                `is_active` tinyint(1) DEFAULT 0,
                `is_sandbox` tinyint(1) DEFAULT 1,
                `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
                `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `code` (`code`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        logStep("✅ تم إنشاء جدول بوابات الدفع");
        updateProgress(++$currentStep, $totalSteps);
        
        // إنشاء جدول إعدادات النظام
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS `system_settings` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `category` varchar(50) NOT NULL DEFAULT 'general',
                `setting_key` varchar(100) NOT NULL,
                `setting_value` text DEFAULT NULL,
                `description` text DEFAULT NULL,
                `type` enum('text','number','boolean','json','file') DEFAULT 'text',
                `is_public` tinyint(1) DEFAULT 0,
                `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
                `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `unique_setting` (`category`, `setting_key`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        logStep("✅ تم إنشاء جدول إعدادات النظام");
        updateProgress(++$currentStep, $totalSteps);
        
        // إدراج البيانات الأساسية
        insertBasicData($pdo);
        logStep("✅ تم إدراج البيانات الأساسية");
        updateProgress(++$currentStep, $totalSteps);
        
        // إنشاء المدير الافتراضي
        createDefaultAdmin($pdo);
        logStep("✅ تم إنشاء المدير الافتراضي");
        updateProgress(++$currentStep, $totalSteps);
        
        logStep("🎉 تم إعداد قاعدة البيانات بنجاح!");
        updateProgress($totalSteps, $totalSteps);
        
        echo '</div>';
        
        echo '<div class="step success">';
        echo '<h3>✅ تم الإعداد بنجاح!</h3>';
        echo '<p>تم إنشاء جميع الجداول والبيانات الأساسية بنجاح.</p>';
        echo '<h4>بيانات تسجيل الدخول للمدير:</h4>';
        echo '<ul>';
        echo '<li><strong>اسم المستخدم:</strong> admin</li>';
        echo '<li><strong>كلمة المرور:</strong> admin123</li>';
        echo '</ul>';
        echo '<p><strong>⚠️ يرجى تغيير كلمة المرور فوراً بعد تسجيل الدخول!</strong></p>';
        echo '</div>';
        
        echo '<a href="admin/login.php" class="btn success">🔐 تسجيل دخول المدير</a>';
        echo '<a href="index.php" class="btn">🏠 الصفحة الرئيسية</a>';
        
    } catch (Exception $e) {
        logStep("❌ خطأ: " . $e->getMessage());
        echo '</div>';
        echo '<div class="step error">';
        echo '<h3>❌ حدث خطأ أثناء الإعداد</h3>';
        echo '<p>' . htmlspecialchars($e->getMessage()) . '</p>';
        echo '</div>';
    }
}

function insertBasicData($pdo) {
    // إدراج الفئات الأساسية
    $categories = [
        ['ألعاب الهاتف', 'Mobile Games', 'شحن ألعاب الهاتف المحمول', 'fas fa-mobile-alt', 1],
        ['بطاقات الألعاب', 'Game Cards', 'بطاقات شحن الألعاب المختلفة', 'fas fa-gamepad', 2],
        ['تطبيقات التواصل', 'Social Apps', 'شحن تطبيقات التواصل الاجتماعي', 'fas fa-comments', 3],
        ['خدمات الترفيه', 'Entertainment', 'خدمات الترفيه والمحتوى', 'fas fa-play-circle', 4],
        ['بطاقات الهدايا', 'Gift Cards', 'بطاقات الهدايا المختلفة', 'fas fa-gift', 5]
    ];
    
    $stmt = $pdo->prepare("INSERT IGNORE INTO categories (name, name_en, description, icon, sort_order, status) VALUES (?, ?, ?, ?, ?, 'active')");
    foreach ($categories as $category) {
        $stmt->execute($category);
    }
    
    // إدراج بوابات الدفع الأساسية
    $gateways = [
        ['PayPal', 'paypal', 'PayPal Payment Gateway'],
        ['Stripe', 'stripe', 'Stripe Payment Gateway'],
        ['مدى', 'mada', 'Mada Payment Gateway'],
        ['Apple Pay', 'apple_pay', 'Apple Pay Integration'],
        ['Google Pay', 'google_pay', 'Google Pay Integration']
    ];
    
    $stmt = $pdo->prepare("INSERT IGNORE INTO payment_gateways (name, code, description, is_active, is_sandbox) VALUES (?, ?, ?, 0, 1)");
    foreach ($gateways as $gateway) {
        $stmt->execute($gateway);
    }
    
    // إدراج إعدادات النظام الأساسية
    $settings = [
        ['general', 'site_name', 'فاست ستار', 'اسم الموقع', 'text', 1],
        ['general', 'site_description', 'منصة شحن الألعاب والتطبيقات', 'وصف الموقع', 'text', 1],
        ['general', 'maintenance_mode', '0', 'وضع الصيانة', 'boolean', 0],
        ['payment', 'min_wallet_deposit', '100', 'أقل مبلغ إيداع في المحفظة', 'number', 0],
        ['payment', 'max_wallet_deposit', '100000', 'أكبر مبلغ إيداع في المحفظة', 'number', 0],
        ['security', 'max_login_attempts', '5', 'عدد محاولات تسجيل الدخول', 'number', 0]
    ];
    
    $stmt = $pdo->prepare("INSERT IGNORE INTO system_settings (category, setting_key, setting_value, description, type, is_public) VALUES (?, ?, ?, ?, ?, ?)");
    foreach ($settings as $setting) {
        $stmt->execute($setting);
    }
}

function createDefaultAdmin($pdo) {
    // التحقق من وجود مدير
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM admin_users WHERE username = 'admin'");
    $stmt->execute();
    
    if ($stmt->fetchColumn() == 0) {
        // إنشاء مدير افتراضي
        $stmt = $pdo->prepare("INSERT INTO admin_users (username, email, password, full_name, role, status) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            'admin',
            'admin@faststarone.com',
            password_hash('admin123', PASSWORD_DEFAULT),
            'مدير النظام',
            'super_admin',
            'active'
        ]);
    }
}

function logStep($message) {
    echo "<div style='margin: 5px 0; color: #2ecc71;'>" . htmlspecialchars($message) . "</div>";
    echo "<script>
        var log = document.getElementById('setupLog');
        if (log) {
            log.scrollTop = log.scrollHeight;
        }
    </script>";
    flush();
    ob_flush();
}

function updateProgress($current, $total) {
    $percentage = ($current / $total) * 100;
    echo "<script>
        var bar = document.getElementById('progressBar');
        if (bar) {
            bar.style.width = '{$percentage}%';
        }
    </script>";
    flush();
    ob_flush();
}
?>
