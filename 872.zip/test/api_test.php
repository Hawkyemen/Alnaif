<?php
/**
 * API Testing Script
 * سكريبت اختبار API
 */

require_once '../config/config.php';
require_once '../config/api_config.php';

class APITester {
    private $base_url;
    private $api_key;
    private $jwt_token;
    
    public function __construct() {
        $this->base_url = 'http://localhost/api/v1';
        $this->runAllTests();
    }
    
    public function runAllTests() {
        echo "🚀 بدء اختبار API...\n\n";
        
        // Test 1: Authentication
        $this->testAuthentication();
        
        // Test 2: API Key Generation
        $this->testApiKeyGeneration();
        
        // Test 3: Products API
        $this->testProductsAPI();
        
        // Test 4: Orders API
        $this->testOrdersAPI();
        
        // Test 5: Wallet API
        $this->testWalletAPI();
        
        // Test 6: Payment API
        $this->testPaymentAPI();
        
        // Test 7: Rate Limiting
        $this->testRateLimiting();
        
        echo "\n✅ انتهاء اختبار API\n";
    }
    
    private function testAuthentication() {
        echo "🔐 اختبار المصادقة...\n";
        
        // Test login
        $login_data = [
            'username' => 'testuser',
            'password' => 'testpass123'
        ];
        
        $response = $this->makeRequest('POST', '/auth/login', $login_data);
        
        if ($response && isset($response['data']['token'])) {
            $this->jwt_token = $response['data']['token'];
            echo "✅ تم تسجيل الدخول بنجاح\n";
            echo "🔑 JWT Token: " . substr($this->jwt_token, 0, 20) . "...\n";
        } else {
            echo "❌ فشل تسجيل الدخول\n";
            // Create test user for testing
            $this->createTestUser();
        }
        
        echo "\n";
    }
    
    private function createTestUser() {
        echo "👤 إنشاء مستخدم تجريبي...\n";
        
        $db = Database::getInstance()->getConnection();
        
        // Check if test user exists
        $stmt = $db->prepare("SELECT id FROM users WHERE username = 'testuser'");
        $stmt->execute();
        
        if (!$stmt->fetch()) {
            $stmt = $db->prepare("
                INSERT INTO users (username, email, password, status) 
                VALUES ('testuser', 'test@example.com', ?, 'active')
            ");
            $stmt->execute([password_hash('testpass123', PASSWORD_DEFAULT)]);
            echo "✅ تم إنشاء المستخدم التجريبي\n";
        }
        
        // Try login again
        $login_data = [
            'username' => 'testuser',
            'password' => 'testpass123'
        ];
        
        $response = $this->makeRequest('POST', '/auth/login', $login_data);
        
        if ($response && isset($response['data']['token'])) {
            $this->jwt_token = $response['data']['token'];
            echo "✅ تم تسجيل الدخول بنجاح\n";
        }
    }
    
    private function testApiKeyGeneration() {
        echo "🔑 اختبار إنشاء مفتاح API...\n";
        
        if (!$this->jwt_token) {
            echo "❌ لا يوجد JWT token\n\n";
            return;
        }
        
        // Generate API key
        $api_key_data = [
            'name' => 'Test API Key',
            'permissions' => ['read', 'write']
        ];
        
        $response = $this->makeRequest('POST', '/auth/api-key', $api_key_data, [
            'Authorization: Bearer ' . $this->jwt_token
        ]);
        
        if ($response && isset($response['data']['api_key'])) {
            $this->api_key = $response['data']['api_key'];
            echo "✅ تم إنشاء مفتاح API بنجاح\n";
            echo "🔑 API Key: " . substr($this->api_key, 0, 20) . "...\n";
        } else {
            echo "❌ فشل إنشاء مفتاح API\n";
            // Create API key directly in database for testing
            $this->createTestApiKey();
        }
        
        echo "\n";
    }
    
    private function createTestApiKey() {
        $db = Database::getInstance()->getConnection();
        
        // Get test user ID
        $stmt = $db->prepare("SELECT id FROM users WHERE username = 'testuser'");
        $stmt->execute();
        $user = $stmt->fetch();
        
        if ($user) {
            $api_key = 'fsk_' . bin2hex(random_bytes(32));
            
            $stmt = $db->prepare("
                INSERT INTO api_keys (user_id, api_key, name, permissions, status)
                VALUES (?, ?, 'Test API Key', ?, 'active')
            ");
            $stmt->execute([$user['id'], $api_key, json_encode(['read', 'write'])]);
            
            $this->api_key = $api_key;
            echo "✅ تم إنشاء مفتاح API في قاعدة البيانات\n";
        }
    }
    
    private function testProductsAPI() {
        echo "🛍️ اختبار API المنتجات...\n";
        
        // Test get products (public endpoint)
        $response = $this->makeRequest('GET', '/products');
        
        if ($response && isset($response['data']['products'])) {
            echo "✅ تم جلب المنتجات بنجاح (" . count($response['data']['products']) . " منتج)\n";
        } else {
            echo "❌ فشل جلب المنتجات\n";
        }
        
        // Test get specific product
        $response = $this->makeRequest('GET', '/products/1');
        
        if ($response && isset($response['data'])) {
            echo "✅ تم جلب تفاصيل المنتج بنجاح\n";
        } else {
            echo "❌ فشل جلب تفاصيل المنتج\n";
        }
        
        echo "\n";
    }
    
    private function testOrdersAPI() {
        echo "📦 اختبار API الطلبات...\n";
        
        if (!$this->api_key) {
            echo "❌ لا يوجد API key\n\n";
            return;
        }
        
        // Test get orders
        $response = $this->makeRequest('GET', '/orders', null, [
            'X-API-Key: ' . $this->api_key
        ]);
        
        if ($response) {
            echo "✅ تم جلب الطلبات بنجاح\n";
        } else {
            echo "❌ فشل جلب الطلبات\n";
        }
        
        // Test create order
        $order_data = [
            'product_id' => 1,
            'quantity' => 1,
            'player_id' => '123456789',
            'payment_method' => 'wallet'
        ];
        
        $response = $this->makeRequest('POST', '/orders', $order_data, [
            'X-API-Key: ' . $this->api_key
        ]);
        
        if ($response && isset($response['data']['order_id'])) {
            echo "✅ تم إنشاء الطلب بنجاح (ID: " . $response['data']['order_id'] . ")\n";
        } else {
            echo "❌ فشل إنشاء الطلب\n";
            if ($response && isset($response['error'])) {
                echo "   السبب: " . $response['error']['message'] . "\n";
            }
        }
        
        echo "\n";
    }
    
    private function testWalletAPI() {
        echo "💰 اختبار API المحفظة...\n";
        
        if (!$this->api_key) {
            echo "❌ لا يوجد API key\n\n";
            return;
        }
        
        // Test get wallet info
        $response = $this->makeRequest('GET', '/wallet', null, [
            'X-API-Key: ' . $this->api_key
        ]);
        
        if ($response && isset($response['data'])) {
            echo "✅ تم جلب معلومات المحفظة بنجاح\n";
            echo "   الرصيد: " . ($response['data']['balance'] ?? 0) . " " . ($response['data']['currency'] ?? 'YER') . "\n";
        } else {
            echo "❌ فشل جلب معلومات المحفظة\n";
        }
        
        // Test wallet history
        $response = $this->makeRequest('GET', '/wallet/history', null, [
            'X-API-Key: ' . $this->api_key
        ]);
        
        if ($response) {
            echo "✅ تم جلب تاريخ المحفظة بنجاح\n";
        } else {
            echo "❌ فشل جلب تاريخ المحفظة\n";
        }
        
        echo "\n";
    }
    
    private function testPaymentAPI() {
        echo "💳 اختبار API الدفع...\n";
        
        if (!$this->api_key) {
            echo "❌ لا يوجد API key\n\n";
            return;
        }
        
        // Test create payment
        $payment_data = [
            'amount' => 100.0,
            'currency' => 'YER',
            'payment_method' => 'paypal',
            'return_url' => 'http://localhost/payment/success',
            'cancel_url' => 'http://localhost/payment/cancel'
        ];
        
        $response = $this->makeRequest('POST', '/payment/create', $payment_data, [
            'X-API-Key: ' . $this->api_key
        ]);
        
        if ($response && isset($response['data']['payment_id'])) {
            echo "✅ تم إنشاء عملية الدفع بنجاح\n";
            echo "   معرف الدفع: " . $response['data']['payment_id'] . "\n";
        } else {
            echo "❌ فشل إنشاء عملية الدفع\n";
            if ($response && isset($response['error'])) {
                echo "   السبب: " . $response['error']['message'] . "\n";
            }
        }
        
        echo "\n";
    }
    
    private function testRateLimiting() {
        echo "⏱️ اختبار حدود المعدل...\n";
        
        if (!$this->api_key) {
            echo "❌ لا يوجد API key\n\n";
            return;
        }
        
        $requests_made = 0;
        $max_requests = 10; // Test with small number
        
        for ($i = 0; $i < $max_requests; $i++) {
            $response = $this->makeRequest('GET', '/products', null, [
                'X-API-Key: ' . $this->api_key
            ], false); // Don't show individual responses
            
            if ($response) {
                $requests_made++;
            } else {
                break;
            }
            
            usleep(100000); // 0.1 second delay
        }
        
        echo "✅ تم إجراء $requests_made طلب بنجاح\n";
        echo "\n";
    }
    
    private function makeRequest($method, $endpoint, $data = null, $headers = [], $show_response = true) {
        $url = $this->base_url . $endpoint;
        
        $ch = curl_init();
        
        $default_headers = [
            'Content-Type: application/json',
            'Accept: application/json'
        ];
        
        $all_headers = array_merge($default_headers, $headers);
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $all_headers,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => $method
        ]);
        
        if ($data && in_array($method, ['POST', 'PUT', 'PATCH'])) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            if ($show_response) {
                echo "❌ خطأ في الاتصال: $error\n";
            }
            return false;
        }
        
        $decoded_response = json_decode($response, true);
        
        if ($show_response) {
            echo "📡 $method $endpoint - HTTP $http_code\n";
            if ($decoded_response && isset($decoded_response['error'])) {
                echo "   خطأ: " . $decoded_response['error']['message'] . "\n";
            }
        }
        
        return $decoded_response;
    }
}

// Run tests if called directly
if (php_sapi_name() === 'cli') {
    new APITester();
} else {
    echo "<pre>";
    new APITester();
    echo "</pre>";
}
?>
