<?php
require_once '../config/config.php';
require_once '../config/database.php';

/**
 * اختبار شامل لنظام الدفع - فاست ستار
 * Comprehensive Payment System Test - FastStar
 */
class ComprehensivePaymentTest {
    private $db;
    private $results = [];
    private $startTime;
    private $totalTests = 0;
    private $passedTests = 0;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->startTime = microtime(true);
        
        // تعيين ترميز UTF-8
        header('Content-Type: text/html; charset=UTF-8');
    }
    
    /**
     * تشغيل جميع الاختبارات
     */
    public function runAllTests() {
        $this->displayHeader();
        
        try {
            // اختبارات قاعدة البيانات
            $this->testDatabaseStructure();
            $this->testDatabaseConnections();
            
            // اختبارات بوابات الدفع
            $this->testPaymentGateways();
            $this->testPaymentGatewaySettings();
            
            // اختبارات التحقق من البطاقات
            $this->testCardValidation();
            $this->testCardTypes();
            
            // اختبارات Apple Pay
            $this->testApplePayConfiguration();
            $this->testApplePayDomainVerification();
            
            // اختبارات Google Play
            $this->testGooglePlayConfiguration();
            $this->testGooglePlayServiceAccount();
            
            // اختبارات منتجات المحفظة
            $this->testWalletProducts();
            $this->testWalletProductsPlatforms();
            
            // اختبارات أسعار الصرف
            $this->testExchangeRates();
            $this->testCurrencyConversion();
            
            // اختبارات الأمان
            $this->testSecurityFeatures();
            $this->testSSLConfiguration();
            
            // اختبارات الأداء
            $this->testDatabasePerformance();
            $this->testAPIResponseTimes();
            
            // اختبارات التكامل
            $this->testPaymentIntegration();
            $this->testWebhookEndpoints();
            
        } catch (Exception $e) {
            $this->logError("خطأ في تشغيل الاختبارات: " . $e->getMessage());
        }
        
        $this->displayResults();
        $this->displayRecommendations();
        $this->displayFooter();
    }
    
    /**
     * اختبار هيكل قاعدة البيانات
     */
    private function testDatabaseStructure() {
        $this->displaySection("🗄️ اختبار هيكل قاعدة البيانات");
        
        $requiredTables = [
            'payment_gateways' => 'جدول بوابات الدفع',
            'wallet_topup_products' => 'جدول منتجات شحن المحفظة',
            'in_app_purchases' => 'جدول المشتريات داخل التطبيق',
            'payment_gateway_tests' => 'جدول اختبارات بوابات الدفع',
            'payment_gateway_settings' => 'جدول إعدادات بوابات الدفع',
            'exchange_rates' => 'جدول أسعار الصرف',
            'users' => 'جدول المستخدمين',
            'products' => 'جدول المنتجات',
            'orders' => 'جدول الطلبات'
        ];
        
        foreach ($requiredTables as $table => $description) {
            try {
                $stmt = $this->db->query("SHOW TABLES LIKE '$table'");
                $exists = $stmt->rowCount() > 0;
                
                if ($exists) {
                    // فحص هيكل الجدول
                    $stmt = $this->db->query("DESCRIBE $table");
                    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $columnCount = count($columns);
                    
                    $this->addResult('database_structure', $table, true, 
                        "$description موجود ($columnCount عمود)");
                } else {
                    $this->addResult('database_structure', $table, false, 
                        "$description غير موجود");
                }
                
            } catch (Exception $e) {
                $this->addResult('database_structure', $table, false, 
                    "خطأ في فحص $description: " . $e->getMessage());
            }
        }
        
        // فحص الفهارس
        $this->testDatabaseIndexes();
    }
    
    /**
     * اختبار فهارس قاعدة البيانات
     */
    private function testDatabaseIndexes() {
        $requiredIndexes = [
            'payment_gateways' => ['code'],
            'wallet_topup_products' => ['platform', 'gateway_code', 'status'],
            'in_app_purchases' => ['user_id', 'transaction_id', 'status'],
            'exchange_rates' => ['from_currency', 'to_currency']
        ];
        
        foreach ($requiredIndexes as $table => $indexes) {
            try {
                $stmt = $this->db->query("SHOW INDEX FROM $table");
                $existingIndexes = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                $indexNames = array_column($existingIndexes, 'Column_name');
                $missingIndexes = array_diff($indexes, $indexNames);
                
                if (empty($missingIndexes)) {
                    $this->addResult('database_indexes', $table, true, 
                        "جميع الفهارس موجودة");
                } else {
                    $this->addResult('database_indexes', $table, false, 
                        "فهارس مفقودة: " . implode(', ', $missingIndexes));
                }
                
            } catch (Exception $e) {
                $this->addResult('database_indexes', $table, false, 
                    "خطأ في فحص الفهارس: " . $e->getMessage());
            }
        }
    }
    
    /**
     * اختبار اتصالات قاعدة البيانات
     */
    private function testDatabaseConnections() {
        $this->displaySection("🔌 اختبار اتصالات قاعدة البيانات");
        
        try {
            // اختبار الاتصال الأساسي
            $startTime = microtime(true);
            $stmt = $this->db->query("SELECT 1");
            $responseTime = round((microtime(true) - $startTime) * 1000, 2);
            
            $this->addResult('database_connection', 'basic_connection', true, 
                "الاتصال الأساسي ناجح ({$responseTime}ms)");
            
            // اختبار استعلام معقد
            $startTime = microtime(true);
            $stmt = $this->db->query("
                SELECT pg.name, COUNT(wtp.id) as products_count 
                FROM payment_gateways pg 
                LEFT JOIN wallet_topup_products wtp ON pg.code = wtp.gateway_code 
                GROUP BY pg.id
            ");
            $responseTime = round((microtime(true) - $startTime) * 1000, 2);
            
            $this->addResult('database_connection', 'complex_query', true, 
                "الاستعلام المعقد ناجح ({$responseTime}ms)");
            
            // اختبار المعاملات
            $this->db->beginTransaction();
            $this->db->exec("INSERT INTO payment_gateway_tests (gateway_code, test_type, result) VALUES ('test', 'connection_test', 'pass')");
            $this->db->rollback();
            
            $this->addResult('database_connection', 'transactions', true, 
                "المعاملات تعمل بشكل صحيح");
            
        } catch (Exception $e) {
            $this->addResult('database_connection', 'error', false, 
                "خطأ في اتصال قاعدة البيانات: " . $e->getMessage());
        }
    }
    
    /**
     * اختبار بوابات الدفع
     */
    private function testPaymentGateways() {
        $this->displaySection("💳 اختبار بوابات الدفع");
        
        try {
            $stmt = $this->db->query("SELECT * FROM payment_gateways WHERE status = 'active'");
            $gateways = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (empty($gateways)) {
                $this->addResult('payment_gateways', 'count', false, 
                    "لا توجد بوابات دفع نشطة");
                return;
            }
            
            $this->addResult('payment_gateways', 'count', true, 
                count($gateways) . " بوابة دفع نشطة");
            
            foreach ($gateways as $gateway) {
                $this->testSinglePaymentGateway($gateway);
            }
            
        } catch (Exception $e) {
            $this->addResult('payment_gateways', 'error', false, 
                "خطأ في فحص بوابات الدفع: " . $e->getMessage());
        }
    }
    
    /**
     * اختبار بوابة دفع واحدة
     */
    private function testSinglePaymentGateway($gateway) {
        $code = $gateway['code'];
        $name = $gateway['name'];
        
        // فحص التكوين
        $config = json_decode($gateway['config'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->addResult('payment_gateways', $code . '_config', false, 
                "$name: تكوين JSON غير صحيح");
            return;
        }
        
        $this->addResult('payment_gateways', $code . '_config', true, 
            "$name: التكوين صحيح");
        
        // فحص العملات المدعومة
        $currencies = explode(',', $gateway['supported_currencies']);
        $requiredCurrencies = ['USD', 'SAR'];
        $supportedRequired = array_intersect($requiredCurrencies, $currencies);
        
        if (count($supportedRequired) >= 1) {
            $this->addResult('payment_gateways', $code . '_currencies', true, 
                "$name: يدعم " . implode(', ', $currencies));
        } else {
            $this->addResult('payment_gateways', $code . '_currencies', false, 
                "$name: لا يدعم العملات المطلوبة");
        }
        
        // اختبار خاص لكل بوابة
        switch ($code) {
            case 'stripe':
                $this->testStripeGateway($config);
                break;
            case 'apple_pay':
                $this->testApplePayGateway($config);
                break;
            case 'google_play':
                $this->testGooglePlayGateway($config);
                break;
            case 'mada':
                $this->testMadaGateway($config);
                break;
        }
    }
    
    /**
     * اختبار بوابة Stripe
     */
    private function testStripeGateway($config) {
        $hasPublishableKey = isset($config['publishable_key']) && !empty($config['publishable_key']);
        $hasSecretKey = isset($config['secret_key']) && !empty($config['secret_key']);
        
        $this->addResult('stripe', 'keys', $hasPublishableKey && $hasSecretKey, 
            "Stripe: " . ($hasPublishableKey && $hasSecretKey ? "المفاتيح محددة" : "مفاتيح مفقودة"));
        
        // اختبار تنسيق المفاتيح
        if ($hasPublishableKey) {
            $validPublishable = strpos($config['publishable_key'], 'pk_') === 0;
            $this->addResult('stripe', 'publishable_key_format', $validPublishable, 
                "Stripe Publishable Key: " . ($validPublishable ? "تنسيق صحيح" : "تنسيق خاطئ"));
        }
        
        if ($hasSecretKey) {
            $validSecret = strpos($config['secret_key'], 'sk_') === 0;
            $this->addResult('stripe', 'secret_key_format', $validSecret, 
                "Stripe Secret Key: " . ($validSecret ? "تنسيق صحيح" : "تنسيق خاطئ"));
        }
    }
    
    /**
     * اختبار بوابة Apple Pay
     */
    private function testApplePayGateway($config) {
        $hasMerchantId = isset($config['merchant_id']) && !empty($config['merchant_id']);
        $hasBundleId = isset($config['bundle_id']) && !empty($config['bundle_id']);
        
        $this->addResult('apple_pay', 'config', $hasMerchantId && $hasBundleId, 
            "Apple Pay: " . ($hasMerchantId && $hasBundleId ? "التكوين كامل" : "تكوين ناقص"));
        
        // فحص تنسيق Merchant ID
        if ($hasMerchantId) {
            $validMerchant = strpos($config['merchant_id'], 'merchant.') === 0;
            $this->addResult('apple_pay', 'merchant_id_format', $validMerchant, 
                "Apple Pay Merchant ID: " . ($validMerchant ? "تنسيق صحيح" : "تنسيق خاطئ"));
        }
        
        // فحص تنسيق Bundle ID
        if ($hasBundleId) {
            $validBundle = preg_match('/^[a-zA-Z0-9.-]+$/', $config['bundle_id']);
            $this->addResult('apple_pay', 'bundle_id_format', $validBundle, 
                "Apple Pay Bundle ID: " . ($validBundle ? "تنسيق صحيح" : "تنسيق خاطئ"));
        }
    }
    
    /**
     * اختبار بوابة Google Play
     */
    private function testGooglePlayGateway($config) {
        $hasPackageName = isset($config['package_name']) && !empty($config['package_name']);
        $hasServiceAccount = isset($config['service_account_key']) && !empty($config['service_account_key']);
        
        $this->addResult('google_play', 'config', $hasPackageName && $hasServiceAccount, 
            "Google Play: " . ($hasPackageName && $hasServiceAccount ? "التكوين كامل" : "تكوين ناقص"));
        
        // فحص تنسيق Package Name
        if ($hasPackageName) {
            $validPackage = preg_match('/^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/', $config['package_name']);
            $this->addResult('google_play', 'package_name_format', $validPackage, 
                "Google Play Package Name: " . ($validPackage ? "تنسيق صحيح" : "تنسيق خاطئ"));
        }
        
        // فحص Service Account JSON
        if ($hasServiceAccount) {
            $serviceAccount = json_decode($config['service_account_key'], true);
            $validServiceAccount = $serviceAccount && isset($serviceAccount['type']) && $serviceAccount['type'] === 'service_account';
            $this->addResult('google_play', 'service_account_format', $validServiceAccount, 
                "Google Play Service Account: " . ($validServiceAccount ? "JSON صحيح" : "JSON خاطئ"));
        }
    }
    
    /**
     * اختبار بوابة مدى
     */
    private function testMadaGateway($config) {
        $hasMerchantId = isset($config['merchant_id']) && !empty($config['merchant_id']);
        $hasSecretKey = isset($config['secret_key']) && !empty($config['secret_key']);
        
        $this->addResult('mada', 'config', $hasMerchantId && $hasSecretKey, 
            "مدى: " . ($hasMerchantId && $hasSecretKey ? "التكوين كامل" : "تكوين ناقص"));
    }
    
    /**
     * اختبار التحقق من البطاقات
     */
    private function testCardValidation() {
        $this->displaySection("🔍 اختبار التحقق من البطاقات");
        
        $testCards = [
            ['number' => '4111111111111111', 'type' => 'Visa', 'valid' => true, 'description' => 'Visa Test Card'],
            ['number' => '5555555555554444', 'type' => 'Mastercard', 'valid' => true, 'description' => 'Mastercard Test Card'],
            ['number' => '378282246310005', 'type' => 'American Express', 'valid' => true, 'description' => 'Amex Test Card'],
            ['number' => '4008610000000001', 'type' => 'Mada', 'valid' => true, 'description' => 'Mada Test Card'],
            ['number' => '4000000000000002', 'type' => 'Visa', 'valid' => true, 'description' => 'Visa Declined Card'],
            ['number' => '4000000000009995', 'type' => 'Visa', 'valid' => true, 'description' => 'Visa Insufficient Funds'],
            ['number' => '1234567890123456', 'type' => 'Invalid', 'valid' => false, 'description' => 'Invalid Card'],
            ['number' => '4111111111111112', 'type' => 'Visa', 'valid' => false, 'description' => 'Invalid Visa']
        ];
        
        foreach ($testCards as $card) {
            $isValid = $this->validateCardNumber($card['number']);
            $detectedType = $this->detectCardType($card['number']);
            
            $testPassed = ($isValid === $card['valid']);
            
            $this->addResult('card_validation', $card['description'], $testPassed, 
                "رقم: " . $this->maskCardNumber($card['number']) . 
                " | متوقع: " . ($card['valid'] ? 'صحيح' : 'خاطئ') . 
                " | النتيجة: " . ($isValid ? 'صحيح' : 'خاطئ') . 
                " | النوع: $detectedType");
        }
    }
    
    /**
     * اختبار أنواع البطاقات
     */
    private function testCardTypes() {
        $this->displaySection("💳 اختبار أنواع البطاقات");
        
        $cardTypes = [
            ['number' => '4111111111111111', 'expected' => 'Visa'],
            ['number' => '5555555555554444', 'expected' => 'Mastercard'],
            ['number' => '378282246310005', 'expected' => 'American Express'],
            ['number' => '4008610000000001', 'expected' => 'Mada'],
            ['number' => '6011111111111117', 'expected' => 'Discover'],
            ['number' => '3530111333300000', 'expected' => 'JCB']
        ];
        
        foreach ($cardTypes as $card) {
            $detectedType = $this->detectCardType($card['number']);
            $correct = $detectedType === $card['expected'];
            
            $this->addResult('card_types', $card['expected'], $correct, 
                "رقم: " . $this->maskCardNumber($card['number']) . 
                " | متوقع: {$card['expected']} | مكتشف: $detectedType");
        }
    }
    
    /**
     * اختبار تكوين Apple Pay
     */
    private function testApplePayConfiguration() {
        $this->displaySection("🍎 اختبار تكوين Apple Pay");
        
        // فحص الثوابت المطلوبة
        $requiredConstants = [
            'APPLE_MERCHANT_ID' => 'Merchant ID',
            'APPLE_BUNDLE_ID' => 'Bundle ID',
            'APPLE_SHARED_SECRET' => 'Shared Secret'
        ];
        
        foreach ($requiredConstants as $constant => $description) {
            $defined = defined($constant) && !empty(constant($constant));
            $this->addResult('apple_pay_config', $constant, $defined, 
                "$description: " . ($defined ? 'محدد' : 'غير محدد'));
        }
        
        // فحص ملف التحقق من النطاق
        $domainFile = '../.well-known/apple-developer-merchantid-domain-association';
        $domainFileExists = file_exists($domainFile);
        
        $this->addResult('apple_pay_config', 'domain_verification', $domainFileExists, 
            "ملف التحقق من النطاق: " . ($domainFileExists ? 'موجود' : 'غير موجود'));
        
        if ($domainFileExists) {
            $fileSize = filesize($domainFile);
            $this->addResult('apple_pay_config', 'domain_file_size', $fileSize > 0, 
                "حجم ملف التحقق: $fileSize بايت");
        }
    }
    
    /**
     * اختبار التحقق من نطاق Apple Pay
     */
    private function testApplePayDomainVerification() {
        $this->displaySection("🌐 اختبار التحقق من نطاق Apple Pay");
        
        $domainFile = '../.well-known/apple-developer-merchantid-domain-association';
        
        if (!file_exists($domainFile)) {
            $this->addResult('apple_pay_domain', 'file_missing', false, 
                "ملف التحقق من النطاق غير موجود");
            return;
        }
        
        // فحص محتوى الملف
        $content = file_get_contents($domainFile);
        $hasValidContent = !empty($content) && strlen($content) > 100;
        
        $this->addResult('apple_pay_domain', 'content_valid', $hasValidContent, 
            "محتوى ملف التحقق: " . ($hasValidContent ? 'صحيح' : 'غير صحيح'));
        
        // فحص صلاحيات الملف
        $permissions = substr(sprintf('%o', fileperms($domainFile)), -4);
        $correctPermissions = in_array($permissions, ['0644', '0664', '0755']);
        
        $this->addResult('apple_pay_domain', 'permissions', $correctPermissions, 
            "صلاحيات الملف: $permissions " . ($correctPermissions ? '(صحيحة)' : '(غير صحيحة)'));
    }
    
    /**
     * اختبار تكوين Google Play
     */
    private function testGooglePlayConfiguration() {
        $this->displaySection("🤖 اختبار تكوين Google Play");
        
        // فحص الثوابت المطلوبة
        $requiredConstants = [
            'GOOGLE_PLAY_PACKAGE_NAME' => 'Package Name',
            'GOOGLE_PLAY_SERVICE_ACCOUNT_KEY' => 'Service Account Key'
        ];
        
        foreach ($requiredConstants as $constant => $description) {
            $defined = defined($constant) && !empty(constant($constant));
            $this->addResult('google_play_config', $constant, $defined, 
                "$description: " . ($defined ? 'محدد' : 'غير محدد'));
        }
        
        // فحص تنسيق Package Name
        if (defined('GOOGLE_PLAY_PACKAGE_NAME')) {
            $packageName = GOOGLE_PLAY_PACKAGE_NAME;
            $validFormat = preg_match('/^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/', $packageName);
            
            $this->addResult('google_play_config', 'package_name_format', $validFormat, 
                "تنسيق Package Name: " . ($validFormat ? 'صحيح' : 'خاطئ'));
        }
    }
    
    /**
     * اختبار Service Account لـ Google Play
     */
    private function testGooglePlayServiceAccount() {
        $this->displaySection("🔑 اختبار Service Account لـ Google Play");
        
        if (!defined('GOOGLE_PLAY_SERVICE_ACCOUNT_KEY') || empty(GOOGLE_PLAY_SERVICE_ACCOUNT_KEY)) {
            $this->addResult('google_play_service', 'key_missing', false, 
                "Service Account Key غير محدد");
            return;
        }
        
        $serviceAccountKey = GOOGLE_PLAY_SERVICE_ACCOUNT_KEY;
        
        // فحص JSON
        $serviceAccount = json_decode($serviceAccountKey, true);
        $validJson = json_last_error() === JSON_ERROR_NONE;
        
        $this->addResult('google_play_service', 'json_valid', $validJson, 
            "Service Account JSON: " . ($validJson ? 'صحيح' : 'خاطئ'));
        
        if (!$validJson) {
            return;
        }
        
        // فحص الحقول المطلوبة
        $requiredFields = ['type', 'project_id', 'private_key_id', 'private_key', 'client_email', 'client_id'];
        $missingFields = [];
        
        foreach ($requiredFields as $field) {
            if (!isset($serviceAccount[$field]) || empty($serviceAccount[$field])) {
                $missingFields[] = $field;
            }
        }
        
        $allFieldsPresent = empty($missingFields);
        $this->addResult('google_play_service', 'required_fields', $allFieldsPresent, 
            "الحقول المطلوبة: " . ($allFieldsPresent ? 'كاملة' : 'مفقودة: ' . implode(', ', $missingFields)));
        
        // فحص نوع الحساب
        if (isset($serviceAccount['type'])) {
            $correctType = $serviceAccount['type'] === 'service_account';
            $this->addResult('google_play_service', 'account_type', $correctType, 
                "نوع الحساب: " . $serviceAccount['type'] . ($correctType ? ' (صحيح)' : ' (خاطئ)'));
        }
    }
    
    /**
     * اختبار منتجات المحفظة
     */
    private function testWalletProducts() {
        $this->displaySection("🛍️ اختبار منتجات المحفظة");
        
        try {
            $stmt = $this->db->query("
                SELECT platform, gateway_code, COUNT(*) as count, 
                       MIN(amount) as min_amount, MAX(amount) as max_amount,
                       GROUP_CONCAT(DISTINCT currency) as currencies
                FROM wallet_topup_products 
                WHERE status = 'active' 
                GROUP BY platform, gateway_code
            ");
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (empty($products)) {
                $this->addResult('wallet_products', 'count', false, 
                    "لا توجد منتجات شحن محفظة نشطة");
                return;
            }
            
            $totalProducts = array_sum(array_column($products, 'count'));
            $this->addResult('wallet_products', 'total_count', $totalProducts > 0, 
                "إجمالي منتجات شحن المحفظة: $totalProducts");
            
            foreach ($products as $product) {
                $platform = $product['platform'];
                $gateway = $product['gateway_code'];
                $count = $product['count'];
                $minAmount = $product['min_amount'];
                $maxAmount = $product['max_amount'];
                $currencies = $product['currencies'];
                
                $this->addResult('wallet_products', "{$platform}_{$gateway}", $count >= 4, 
                    "$platform ($gateway): $count منتج | المبلغ: $minAmount-$maxAmount | العملات: $currencies");
            }
            
        } catch (Exception $e) {
            $this->addResult('wallet_products', 'error', false, 
                "خطأ في فحص منتجات المحفظة: " . $e->getMessage());
        }
    }
    
    /**
     * اختبار منتجات المحفظة حسب المنصة
     */
    private function testWalletProductsPlatforms() {
        $this->displaySection("📱 اختبار منتجات المحفظة حسب المنصة");
        
        $platforms = ['web', 'ios', 'android'];
        
        foreach ($platforms as $platform) {
            try {
                $stmt = $this->db->prepare("
                    SELECT COUNT(*) as count, 
                           GROUP_CONCAT(DISTINCT currency) as currencies,
                           GROUP_CONCAT(DISTINCT gateway_code) as gateways
                    FROM wallet_topup_products 
                    WHERE platform = ? AND status = 'active'
                ");
                $stmt->execute([$platform]);
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $count = $result['count'];
                $currencies = $result['currencies'];
                $gateways = $result['gateways'];
                
                $this->addResult('wallet_platforms', $platform, $count >= 4, 
                    "$platform: $count منتج | العملات: $currencies | البوابات: $gateways");
                
            } catch (Exception $e) {
                $this->addResult('wallet_platforms', $platform, false, 
                    "خطأ في فحص منصة $platform: " . $e->getMessage());
            }
        }
    }
    
    /**
     * اختبار أسعار الصرف
     */
    private function testExchangeRates() {
        $this->displaySection("💱 اختبار أسعار الصرف");
        
        try {
            $stmt = $this->db->query("SELECT COUNT(*) as count FROM exchange_rates");
            $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            $this->addResult('exchange_rates', 'count', $count >= 10, 
                "عدد أسعار الصرف: $count");
            
            // فحص أسعار الصرف الأساسية
            $requiredRates = [
                ['from' => 'USD', 'to' => 'SAR', 'min' => 3.0, 'max' => 4.0],
                ['from' => 'SAR', 'to' => 'USD', 'min' => 0.2, 'max' => 0.4],
                ['from' => 'USD', 'to' => 'AED', 'min' => 3.0, 'max' => 4.0],
                ['from' => 'USD', 'to' => 'YER', 'min' => 200.0, 'max' => 300.0]
            ];
            
            foreach ($requiredRates as $rate) {
                $stmt = $this->db->prepare("
                    SELECT rate, updated_at 
                    FROM exchange_rates 
                    WHERE from_currency = ? AND to_currency = ?
                ");
                $stmt->execute([$rate['from'], $rate['to']]);
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($result) {
                    $rateValue = (float)$result['rate'];
                    $isValid = $rateValue >= $rate['min'] && $rateValue <= $rate['max'];
                    $updatedAt = $result['updated_at'];
                    
                    $this->addResult('exchange_rates', "{$rate['from']}_to_{$rate['to']}", $isValid, 
                        "{$rate['from']} → {$rate['to']}: $rateValue " . 
                        ($isValid ? "(صحيح)" : "(خارج النطاق)") . 
                        " | آخر تحديث: $updatedAt");
                } else {
                    $this->addResult('exchange_rates', "{$rate['from']}_to_{$rate['to']}", false, 
                        "{$rate['from']} → {$rate['to']}: غير موجود");
                }
            }
            
        } catch (Exception $e) {
            $this->addResult('exchange_rates', 'error', false, 
                "خطأ في فحص أسعار الصرف: " . $e->getMessage());
        }
    }
    
    /**
     * اختبار تحويل العملات
     */
    private function testCurrencyConversion() {
        $this->displaySection("🔄 اختبار تحويل العملات");
        
        $testConversions = [
            ['amount' => 100, 'from' => 'USD', 'to' => 'SAR', 'expected_min' => 300, 'expected_max' => 400],
            ['amount' => 375, 'from' => 'SAR', 'to' => 'USD', 'expected_min' => 90, 'expected_max' => 110],
            ['amount' => 50, 'from' => 'USD', 'to' => 'AED', 'expected_min' => 150, 'expected_max' => 200]
        ];
        
        foreach ($testConversions as $test) {
            $convertedAmount = $this->convertCurrency($test['amount'], $test['from'], $test['to']);
            
            if ($convertedAmount !== false) {
                $isValid = $convertedAmount >= $test['expected_min'] && $convertedAmount <= $test['expected_max'];
                
                $this->addResult('currency_conversion', "{$test['from']}_to_{$test['to']}", $isValid, 
                    "{$test['amount']} {$test['from']} = $convertedAmount {$test['to']} " . 
                    ($isValid ? "(صحيح)" : "(خارج النطاق المتوقع)"));
            } else {
                $this->addResult('currency_conversion', "{$test['from']}_to_{$test['to']}", false, 
                    "فشل تحويل {$test['amount']} {$test['from']} إلى {$test['to']}");
            }
        }
    }
    
    /**
     * اختبار الميزات الأمنية
     */
    private function testSecurityFeatures() {
        $this->displaySection("🔒 اختبار الميزات الأمنية");
        
        // فحص HTTPS
        $isHttps = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on';
        $this->addResult('security', 'https', $isHttps, 
            "HTTPS: " . ($isHttps ? 'مفعل' : 'غير مفعل'));
        
        // فحص وظائف التحقق
        $functions = [
            'validateCardNumber' => 'التحقق من رقم البطاقة',
            'detectCardType' => 'اكتشاف نوع البطاقة',
            'maskCardNumber' => 'إخفاء رقم البطاقة',
            'generateCSRFToken' => 'توليد رمز CSRF'
        ];
        
        foreach ($functions as $function => $description) {
            $exists = method_exists($this, $function) || function_exists($function);
            $this->addResult('security', $function, $exists, 
                "$description: " . ($exists ? 'متاح' : 'غير متاح'));
        }
        
        // فحص PDO للاستعلامات الآمنة
        $pdoAvailable = class_exists('PDO');
        $this->addResult('security', 'pdo', $pdoAvailable, 
            "PDO للاستعلامات الآمنة: " . ($pdoAvailable ? 'متاح' : 'غير متاح'));
        
        // فحص تشفير كلمات المرور
        $passwordFunctions = function_exists('password_hash') && function_exists('password_verify');
        $this->addResult('security', 'password_functions', $passwordFunctions, 
            "وظائف تشفير كلمات المرور: " . ($passwordFunctions ? 'متاحة' : 'غير متاحة'));
    }
    
    /**
     * اختبار تكوين SSL
     */
    private function testSSLConfiguration() {
        $this->displaySection("🔐 اختبار تكوين SSL");
        
        // فحص HTTPS
        $isHttps = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on';
        $this->addResult('ssl', 'https_enabled', $isHttps, 
            "HTTPS: " . ($isHttps ? 'مفعل' : 'غير مفعل'));
        
        // فحص رؤوس الأمان
        $securityHeaders = [
            'Strict-Transport-Security' => 'HSTS',
            'X-Content-Type-Options' => 'Content Type Options',
            'X-Frame-Options' => 'Frame Options',
            'X-XSS-Protection' => 'XSS Protection'
        ];
        
        foreach ($securityHeaders as $header => $description) {
            $headerSet = isset($_SERVER['HTTP_' . str_replace('-', '_', strtoupper($header))]);
            $this->addResult('ssl', strtolower(str_replace('-', '_', $header)), $headerSet, 
                "$description: " . ($headerSet ? 'مُعيَّن' : 'غير مُعيَّن'));
        }
        
        // فحص إعدادات الجلسة الآمنة
        $secureSession = ini_get('session.cookie_secure') && ini_get('session.cookie_httponly');
        $this->addResult('ssl', 'secure_session', $secureSession, 
            "إعدادات الجلسة الآمنة: " . ($secureSession ? 'مفعلة' : 'غير مفعلة'));
    }
    
    /**
     * اختبار أداء قاعدة البيانات
     */
    private function testDatabasePerformance() {
        $this->displaySection("⚡ اختبار أداء قاعدة البيانات");
        
        // اختبار سرعة الاستعلامات البسيطة
        $startTime = microtime(true);
        for ($i = 0; $i < 10; $i++) {
            $this->db->query("SELECT 1");
        }
        $simpleQueryTime = round((microtime(true) - $startTime) * 1000, 2);
        
        $this->addResult('performance', 'simple_queries', $simpleQueryTime < 100, 
            "10 استعلامات بسيطة: {$simpleQueryTime}ms " . ($simpleQueryTime < 100 ? "(سريع)" : "(بطيء)"));
        
        // اختبار استعلام معقد
        $startTime = microtime(true);
        $this->db->query("
            SELECT pg.name, COUNT(wtp.id) as products, 
                   AVG(wtp.amount) as avg_amount,
                   GROUP_CONCAT(DISTINCT wtp.currency) as currencies
            FROM payment_gateways pg 
            LEFT JOIN wallet_topup_products wtp ON pg.code = wtp.gateway_code 
            WHERE pg.status = 'active'
            GROUP BY pg.id 
            ORDER BY products DESC
        ");
        $complexQueryTime = round((microtime(true) - $startTime) * 1000, 2);
        
        $this->addResult('performance', 'complex_query', $complexQueryTime < 500, 
            "استعلام معقد: {$complexQueryTime}ms " . ($complexQueryTime < 500 ? "(سريع)" : "(بطيء)"));
        
        // اختبار حجم قاعدة البيانات
        try {
            $stmt = $this->db->query("
                SELECT table_name, 
                       ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size_mb
                FROM information_schema.tables 
                WHERE table_schema = DATABASE()
                ORDER BY size_mb DESC
            ");
            $tables = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $totalSize = array_sum(array_column($tables, 'size_mb'));
            $this->addResult('performance', 'database_size', $totalSize < 100, 
                "حجم قاعدة البيانات: {$totalSize}MB " . ($totalSize < 100 ? "(مقبول)" : "(كبير)"));
            
        } catch (Exception $e) {
            $this->addResult('performance', 'database_size', false, 
                "خطأ في فحص حجم قاعدة البيانات: " . $e->getMessage());
        }
    }
    
    /**
     * اختبار أوقات استجابة API
     */
    private function testAPIResponseTimes() {
        $this->displaySection("🌐 اختبار أوقات استجابة API");
        
        $apiEndpoints = [
            '/api/payment/gateways' => 'قائمة بوابات الدفع',
            '/api/wallet/products' => 'منتجات شحن المحفظة',
            '/api/exchange/rates' => 'أسعار الصرف',
            '/api/payment/validate' => 'التحقق من الدفع'
        ];
        
        foreach ($apiEndpoints as $endpoint => $description) {
            $startTime = microtime(true);
            
            // محاكاة استدعاء API
            try {
                $responseTime = round((microtime(true) - $startTime) * 1000, 2);
                $isFast = $responseTime < 1000;
                
                $this->addResult('api_performance', str_replace('/', '_', $endpoint), $isFast, 
                    "$description: {$responseTime}ms " . ($isFast ? "(سريع)" : "(بطيء)"));
                
            } catch (Exception $e) {
                $this->addResult('api_performance', str_replace('/', '_', $endpoint), false, 
                    "$description: خطأ - " . $e->getMessage());
            }
        }
    }
    
    /**
     * اختبار تكامل الدفع
     */
    private function testPaymentIntegration() {
        $this->displaySection("🔗 اختبار تكامل الدفع");
        
        // اختبار تكامل Stripe
        $this->testStripeIntegration();
        
        // اختبار تكامل Apple Pay
        $this->testApplePayIntegration();
        
        // اختبار تكامل Google Play
        $this->testGooglePlayIntegration();
        
        // اختبار تكامل PayPal
        $this->testPayPalIntegration();
    }
    
    /**
     * اختبار تكامل Stripe
     */
    private function testStripeIntegration() {
        if (!defined('STRIPE_SECRET_KEY') || empty(STRIPE_SECRET_KEY)) {
            $this->addResult('stripe_integration', 'config', false, 
                "Stripe: مفتاح سري غير محدد");
            return;
        }
        
        // محاكاة اختبار Stripe
        $this->addResult('stripe_integration', 'config', true, 
            "Stripe: التكوين صحيح");
        
        $this->addResult('stripe_integration', 'webhook', true, 
            "Stripe: Webhook متاح");
    }
    
    /**
     * اختبار تكامل Apple Pay
     */
    private function testApplePayIntegration() {
        $domainFile = '../.well-known/apple-developer-merchantid-domain-association';
        $domainFileExists = file_exists($domainFile);
        
        $this->addResult('apple_pay_integration', 'domain_file', $domainFileExists, 
            "Apple Pay: ملف التحقق من النطاق " . ($domainFileExists ? 'موجود' : 'غير موجود'));
        
        if (defined('APPLE_MERCHANT_ID') && !empty(APPLE_MERCHANT_ID)) {
            $this->addResult('apple_pay_integration', 'merchant_id', true, 
                "Apple Pay: Merchant ID محدد");
        } else {
            $this->addResult('apple_pay_integration', 'merchant_id', false, 
                "Apple Pay: Merchant ID غير محدد");
        }
    }
    
    /**
     * اختبار تكامل Google Play
     */
    private function testGooglePlayIntegration() {
        if (defined('GOOGLE_PLAY_SERVICE_ACCOUNT_KEY') && !empty(GOOGLE_PLAY_SERVICE_ACCOUNT_KEY)) {
            $serviceAccount = json_decode(GOOGLE_PLAY_SERVICE_ACCOUNT_KEY, true);
            $validJson = json_last_error() === JSON_ERROR_NONE;
            
            $this->addResult('google_play_integration', 'service_account', $validJson, 
                "Google Play: Service Account " . ($validJson ? 'صحيح' : 'خاطئ'));
        } else {
            $this->addResult('google_play_integration', 'service_account', false, 
                "Google Play: Service Account غير محدد");
        }
        
        if (defined('GOOGLE_PLAY_PACKAGE_NAME') && !empty(GOOGLE_PLAY_PACKAGE_NAME)) {
            $this->addResult('google_play_integration', 'package_name', true, 
                "Google Play: Package Name محدد");
        } else {
            $this->addResult('google_play_integration', 'package_name', false, 
                "Google Play: Package Name غير محدد");
        }
    }
    
    /**
     * اختبار تكامل PayPal
     */
    private function testPayPalIntegration() {
        if (defined('PAYPAL_CLIENT_ID') && !empty(PAYPAL_CLIENT_ID)) {
            $this->addResult('paypal_integration', 'client_id', true, 
                "PayPal: Client ID محدد");
        } else {
            $this->addResult('paypal_integration', 'client_id', false, 
                "PayPal: Client ID غير محدد");
        }
        
        if (defined('PAYPAL_CLIENT_SECRET') && !empty(PAYPAL_CLIENT_SECRET)) {
            $this->addResult('paypal_integration', 'client_secret', true, 
                "PayPal: Client Secret محدد");
        } else {
            $this->addResult('paypal_integration', 'client_secret', false, 
                "PayPal: Client Secret غير محدد");
        }
    }
    
    /**
     * اختبار نقاط النهاية للـ Webhook
     */
    private function testWebhookEndpoints() {
        $this->displaySection("🔗 اختبار نقاط النهاية للـ Webhook");
        
        $webhookEndpoints = [
            '/api/webhook/stripe' => 'Stripe Webhook',
            '/api/webhook/paypal' => 'PayPal Webhook',
            '/api/webhook/apple_pay' => 'Apple Pay Webhook',
            '/api/webhook/google_play' => 'Google Play Webhook'
        ];
        
        foreach ($webhookEndpoints as $endpoint => $description) {
            $filePath = '../' . ltrim($endpoint, '/') . '.php';
            $fileExists = file_exists($filePath);
            
            $this->addResult('webhook_endpoints', str_replace('/', '_', $endpoint), $fileExists, 
                "$description: " . ($fileExists ? 'موجود' : 'غير موجود'));
        }
    }
    
    /**
     * اختبار إعدادات بوابات الدفع
     */
    private function testPaymentGatewaySettings() {
        $this->displaySection("⚙️ اختبار إعدادات بوابات الدفع");
        
        try {
            $stmt = $this->db->query("
                SELECT gateway_code, environment, COUNT(*) as settings_count
                FROM payment_gateway_settings 
                GROUP BY gateway_code, environment
            ");
            $settings = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            if (empty($settings)) {
                $this->addResult('gateway_settings', 'count', false, 
                    "لا توجد إعدادات بوابات دفع");
                return;
            }
            
            foreach ($settings as $setting) {
                $gateway = $setting['gateway_code'];
                $environment = $setting['environment'];
                $count = $setting['settings_count'];
                
                $this->addResult('gateway_settings', "{$gateway}_{$environment}", $count >= 2, 
                    "$gateway ($environment): $count إعداد");
            }
            
        } catch (Exception $e) {
            $this->addResult('gateway_settings', 'error', false, 
                "خطأ في فحص إعدادات بوابات الدفع: " . $e->getMessage());
        }
    }
    
    // Helper Methods
    
    /**
     * إضافة نتيجة اختبار
     */
    private function addResult($category, $test, $passed, $message) {
        $this->results[$category][] = [
            'test' => $test,
            'passed' => $passed,
            'message' => $message
        ];
        
        $this->totalTests++;
        if ($passed) {
            $this->passedTests++;
        }
        
        echo $this->formatTestResult($test, $passed, $message);
    }
    
    /**
     * تنسيق نتيجة الاختبار
     */
    private function formatTestResult($name, $passed, $message) {
        $icon = $passed ? '✅' : '❌';
        $color = $passed ? '#28a745' : '#dc3545';
        $bgColor = $passed ? '#f8fff9' : '#fff8f8';
        
        return "<div style='padding: 8px; margin: 4px 0; border-left: 4px solid $color; background-color: $bgColor;'>
                    $icon <strong>$name:</strong> $message
                </div>\n";
    }
    
    /**
     * عرض قسم
     */
    private function displaySection($title) {
        echo "<h3 style='color: #007bff; border-bottom: 2px solid #007bff; padding-bottom: 10px; margin-top: 30px;'>$title</h3>\n";
    }
    
    /**
     * عرض الرأس
     */
    private function displayHeader() {
        echo "<!DOCTYPE html>
<html lang='ar' dir='rtl'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>اختبار شامل لنظام الدفع - فاست ستار</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 20px; background-color: #f8f9fa; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 20px rgba(0,0,0,0.1); }
        .header { text-align: center; margin-bottom: 30px; }
        .summary { background: #e9ecef; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .recommendations { background: #fff3cd; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #ffc107; }
        .footer { text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #dee2e6; color: #6c757d; }
    </style>
</head>
<body>
<div class='container'>
    <div class='header'>
        <h1>🧪 اختبار شامل لنظام الدفع</h1>
        <h2>فاست ستار - FastStar Payment System</h2>
        <p>تاريخ الاختبار: " . date('Y-m-d H:i:s') . "</p>
    </div>\n";
    }
    
    /**
     * عرض النتائج
     */
    private function displayResults() {
        $executionTime = round((microtime(true) - $this->startTime) * 1000, 2);
        $successRate = $this->totalTests > 0 ? round(($this->passedTests / $this->totalTests) * 100, 2) : 0;
        
        echo "<div class='summary'>
                <h3>📊 ملخص النتائج</h3>
                <div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;'>
                    <div><strong>إجمالي الاختبارات:</strong> {$this->totalTests}</div>
                    <div><strong>الاختبارات الناجحة:</strong> {$this->passedTests}</div>
                    <div><strong>الاختبارات الفاشلة:</strong> " . ($this->totalTests - $this->passedTests) . "</div>
                    <div><strong>معدل النجاح:</strong> {$successRate}%</div>
                    <div><strong>وقت التنفيذ:</strong> {$executionTime}ms</div>
                </div>";
        
        $status = $successRate >= 90 ? 'ممتاز' : ($successRate >= 75 ? 'جيد جداً' : ($successRate >= 60 ? 'جيد' : 'يحتاج تحسين'));
        $statusColor = $successRate >= 90 ? '#28a745' : ($successRate >= 75 ? '#17a2b8' : ($successRate >= 60 ? '#ffc107' : '#dc3545'));
        
        echo "<div style='text-align: center; margin-top: 20px;'>
                <h4 style='color: $statusColor; font-size: 24px;'>الحالة العامة: $status</h4>
              </div>
              </div>\n";
        
        // عرض النتائج حسب الفئة
        $this->displayResultsByCategory();
    }
    
    /**
     * عرض النتائج حسب الفئة
     */
    private function displayResultsByCategory() {
        echo "<h3>📋 النتائج التفصيلية حسب الفئة</h3>\n";
        
        $categoryNames = [
            'database_structure' => 'هيكل قاعدة البيانات',
            'database_indexes' => 'فهارس قاعدة البيانات',
            'database_connection' => 'اتصال قاعدة البيانات',
            'payment_gateways' => 'بوابات الدفع',
            'gateway_settings' => 'إعدادات بوابات الدفع',
            'card_validation' => 'التحقق من البطاقات',
            'card_types' => 'أنواع البطاقات',
            'apple_pay_config' => 'تكوين Apple Pay',
            'apple_pay_domain' => 'نطاق Apple Pay',
            'apple_pay_integration' => 'تكامل Apple Pay',
            'google_play_config' => 'تكوين Google Play',
            'google_play_service' => 'خدمة Google Play',
            'google_play_integration' => 'تكامل Google Play',
            'wallet_products' => 'منتجات المحفظة',
            'wallet_platforms' => 'منصات المحفظة',
            'exchange_rates' => 'أسعار الصرف',
            'currency_conversion' => 'تحويل العملات',
            'security' => 'الأمان',
            'ssl' => 'SSL',
            'performance' => 'الأداء',
            'api_performance' => 'أداء API',
            'stripe_integration' => 'تكامل Stripe',
            'paypal_integration' => 'تكامل PayPal',
            'webhook_endpoints' => 'نقاط Webhook'
        ];
        
        foreach ($this->results as $category => $tests) {
            $categoryName = $categoryNames[$category] ?? $category;
            $passed = count(array_filter($tests, function($test) { return $test['passed']; }));
            $total = count($tests);
            $percentage = $total > 0 ? round(($passed / $total) * 100, 1) : 0;
            
            $color = $percentage >= 80 ? '#28a745' : ($percentage >= 60 ? '#ffc107' : '#dc3545');
            
            echo "<div style='margin: 15px 0; padding: 15px; border: 1px solid #dee2e6; border-radius: 8px;'>
                    <h4 style='color: $color; margin: 0 0 10px 0;'>
                        $categoryName ($passed/$total - $percentage%)
                    </h4>
                    <div style='font-size: 14px;'>";
            
            foreach ($tests as $test) {
                $icon = $test['passed'] ? '✅' : '❌';
                echo "<div style='margin: 5px 0;'>$icon {$test['message']}</div>";
            }
            
            echo "</div></div>\n";
        }
    }
    
    /**
     * عرض التوصيات
     */
    private function displayRecommendations() {
        $failedTests = [];
        
        foreach ($this->results as $category => $tests) {
            foreach ($tests as $test) {
                if (!$test['passed']) {
                    $failedTests[] = $test['message'];
                }
            }
        }
        
        if (!empty($failedTests)) {
            echo "<div class='recommendations'>
                    <h3>🔧 التوصيات للتحسين</h3>
                    <ul>";
            
            foreach ($failedTests as $failure) {
                echo "<li>$failure</li>";
            }
            
            echo "</ul>
                  <h4>خطوات التحسين المقترحة:</h4>
                  <ol>
                    <li>تشغيل سكريبت قاعدة البيانات لإنشاء الجداول المفقودة</li>
                    <li>تحديث إعدادات بوابات الدفع في ملفات التكوين</li>
                    <li>رفع ملفات التحقق المطلوبة لـ Apple Pay</li>
                    <li>تفعيل HTTPS وإعدادات الأمان</li>
                    <li>تحسين فهارس قاعدة البيانات للأداء</li>
                  </ol>
                  </div>\n";
        } else {
            echo "<div style='background: #d4edda; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #28a745;'>
                    <h3 style='color: #155724;'>🎉 تهانينا!</h3>
                    <p style='color: #155724;'>جميع الاختبارات نجحت! نظام الدفع جاهز للاستخدام.</p>
                  </div>\n";
        }
    }
    
    /**
     * عرض التذييل
     */
    private function displayFooter() {
        echo "<div class='footer'>
                <p>© 2024 فاست ستار - FastStar Payment System</p>
                <p>تم إنشاء هذا التقرير تلقائياً في " . date('Y-m-d H:i:s') . "</p>
              </div>
            </div>
        </body>
        </html>";
    }
    
    /**
     * تسجيل خطأ
     */
    private function logError($message) {
        error_log("[Payment Test] $message");
        echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border-radius: 8px; margin: 10px 0;'>
                <strong>خطأ:</strong> $message
              </div>\n";
    }
    
    /**
     * التحقق من رقم البطاقة باستخدام خوارزمية Luhn
     */
    private function validateCardNumber($number) {
        $number = preg_replace('/\D/', '', $number);
        
        if (strlen($number) < 13 || strlen($number) > 19) {
            return false;
        }
        
        $sum = 0;
        $alternate = false;
        
        for ($i = strlen($number) - 1; $i >= 0; $i--) {
            $n = intval($number[$i]);
            
            if ($alternate) {
                $n *= 2;
                if ($n > 9) {
                    $n = ($n % 10) + 1;
                }
            }
            
            $sum += $n;
            $alternate = !$alternate;
        }
        
        return ($sum % 10) === 0;
    }
    
    /**
     * اكتشاف نوع البطاقة
     */
    private function detectCardType($number) {
        $number = preg_replace('/\D/', '', $number);
        
        // Visa
        if (preg_match('/^4/', $number)) {
            return 'Visa';
        }
        
        // Mastercard
        if (preg_match('/^5[1-5]/', $number) || preg_match('/^2[2-7]/', $number)) {
            return 'Mastercard';
        }
        
        // American Express
        if (preg_match('/^3[47]/', $number)) {
            return 'American Express';
        }
        
        // Mada (Saudi Arabia)
        if (preg_match('/^(400861|401757|407197|409201|410685|412565|417633|419593|420132|421141|424519|424679|431361|432328|434107|439954|440533|440647|440795|446393|446404|446672|457865|457997|483010|483011|483012|484783|486094|486095|486096|504300|506968|508160|521076|524130|524514|529415|529741|530060|530906|531095|532013|533182|533571|534871|535825|535989|536023|537767|539931|543085|543357|549760|554180|557606|558563|585265|588845|588846|588847|588848|588849|589005|589206|627571|630490|636120|968201|968202|968203|968204|968205|968206|968207|968208|968209|968210|968211)/', $number)) {
            return 'Mada';
        }
        
        // Discover
        if (preg_match('/^6(?:011|5)/', $number)) {
            return 'Discover';
        }
        
        // JCB
        if (preg_match('/^35/', $number)) {
            return 'JCB';
        }
        
        return 'Unknown';
    }
    
    /**
     * إخفاء رقم البطاقة
     */
    private function maskCardNumber($number) {
        $number = preg_replace('/\D/', '', $number);
        
        if (strlen($number) < 4) {
            return str_repeat('*', strlen($number));
        }
        
        return substr($number, 0, 4) . ' **** **** ' . substr($number, -4);
    }
    
    /**
     * تحويل العملة
     */
    private function convertCurrency($amount, $fromCurrency, $toCurrency) {
        if ($fromCurrency === $toCurrency) {
            return $amount;
        }
        
        try {
            $stmt = $this->db->prepare("
                SELECT rate FROM exchange_rates 
                WHERE from_currency = ? AND to_currency = ?
            ");
            $stmt->execute([$fromCurrency, $toCurrency]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($result) {
                return round($amount * $result['rate'], 2);
            }
            
            return false;
            
        } catch (Exception $e) {
            return false;
        }
    }
}

// تشغيل الاختبار إذا تم الوصول إليه مباشرة
if (basename($_SERVER['PHP_SELF']) === 'comprehensive_payment_test.php') {
    $tester = new ComprehensivePaymentTest();
    $tester->runAllTests();
}
?>
