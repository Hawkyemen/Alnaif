<?php
/**
 * Payment Gateway Testing Script
 * سكريبت اختبار بوابات الدفع
 */

require_once '../config/config.php';
require_once '../config/api_config.php';

class PaymentGatewayTester {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->runAllTests();
    }
    
    public function runAllTests() {
        echo "💳 بدء اختبار بوابات الدفع...\n\n";
        
        // Test 1: PayPal
        $this->testPayPal();
        
        // Test 2: Stripe
        $this->testStripe();
        
        // Test 3: Mada
        $this->testMada();
        
        // Test 4: Apple Pay Configuration
        $this->testApplePayConfig();
        
        // Test 5: Google Pay Configuration
        $this->testGooglePayConfig();
        
        // Test 6: Yemen Mobile Money
        $this->testYemenMobileMoney();
        
        echo "\n✅ انتهاء اختبار بوابات الدفع\n";
    }
    
    private function testPayPal() {
        echo "🅿️ اختبار PayPal...\n";
        
        $config = APIConfig::getPaymentGatewayConfig('paypal');
        
        if (!$config) {
            echo "❌ إعدادات PayPal غير موجودة\n\n";
            return;
        }
        
        // Test getting access token
        $token_result = $this->getPayPalAccessToken($config);
        
        if ($token_result['success']) {
            echo "✅ تم الحصول على PayPal access token بنجاح\n";
            
            // Test creating payment
            $payment_result = $this->createPayPalPayment($config, $token_result['token']);
            
            if ($payment_result['success']) {
                echo "✅ تم إنشاء PayPal payment بنجاح\n";
                echo "   Payment ID: " . $payment_result['payment_id'] . "\n";
                echo "   Approval URL: " . $payment_result['approval_url'] . "\n";
            } else {
                echo "❌ فشل إنشاء PayPal payment: " . $payment_result['error'] . "\n";
            }
        } else {
            echo "❌ فشل الحصول على PayPal access token: " . $token_result['error'] . "\n";
        }
        
        echo "\n";
    }
    
    private function getPayPalAccessToken($config) {
        $url = $config['api_url'] . '/v1/oauth2/token';
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => 'grant_type=client_credentials',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Basic ' . base64_encode($config['client_id'] . ':' . $config['client_secret']),
                'Content-Type: application/x-www-form-urlencoded'
            ],
            CURLOPT_TIMEOUT => 30
        ]);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 200) {
            $data = json_decode($response, true);
            return [
                'success' => true,
                'token' => $data['access_token']
            ];
        } else {
            return [
                'success' => false,
                'error' => "HTTP $http_code: $response"
            ];
        }
    }
    
    private function createPayPalPayment($config, $access_token) {
        $url = $config['api_url'] . '/v1/payments/payment';
        
        $payment_data = [
            'intent' => 'sale',
            'payer' => ['payment_method' => 'paypal'],
            'transactions' => [[
                'amount' => [
                    'total' => '10.00',
                    'currency' => 'USD'
                ],
                'description' => 'FastStar Test Payment'
            ]],
            'redirect_urls' => [
                'return_url' => 'http://localhost/payment/success',
                'cancel_url' => 'http://localhost/payment/cancel'
            ]
        ];
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payment_data),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $access_token,
                'Content-Type: application/json'
            ],
            CURLOPT_TIMEOUT => 30
        ]);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 201) {
            $data = json_decode($response, true);
            $approval_url = '';
            
            foreach ($data['links'] as $link) {
                if ($link['rel'] === 'approval_url') {
                    $approval_url = $link['href'];
                    break;
                }
            }
            
            return [
                'success' => true,
                'payment_id' => $data['id'],
                'approval_url' => $approval_url
            ];
        } else {
            return [
                'success' => false,
                'error' => "HTTP $http_code: $response"
            ];
        }
    }
    
    private function testStripe() {
        echo "💳 اختبار Stripe...\n";
        
        $config = APIConfig::getPaymentGatewayConfig('stripe');
        
        if (!$config) {
            echo "❌ إعدادات Stripe غير موجودة\n\n";
            return;
        }
        
        // Test creating payment intent
        $payment_result = $this->createStripePaymentIntent($config);
        
        if ($payment_result['success']) {
            echo "✅ تم إنشاء Stripe Payment Intent بنجاح\n";
            echo "   Payment Intent ID: " . $payment_result['payment_intent_id'] . "\n";
            echo "   Client Secret: " . substr($payment_result['client_secret'], 0, 20) . "...\n";
        } else {
            echo "❌ فشل إنشاء Stripe Payment Intent: " . $payment_result['error'] . "\n";
        }
        
        echo "\n";
    }
    
    private function createStripePaymentIntent($config) {
        $url = 'https://api.stripe.com/v1/payment_intents';
        
        $payment_data = [
            'amount' => 1000, // $10.00 in cents
            'currency' => 'usd',
            'description' => 'FastStar Test Payment',
            'metadata' => [
                'test' => 'true'
            ]
        ];
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($payment_data),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $config['secret_key'],
                'Content-Type: application/x-www-form-urlencoded'
            ],
            CURLOPT_TIMEOUT => 30
        ]);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 200) {
            $data = json_decode($response, true);
            return [
                'success' => true,
                'payment_intent_id' => $data['id'],
                'client_secret' => $data['client_secret']
            ];
        } else {
            return [
                'success' => false,
                'error' => "HTTP $http_code: $response"
            ];
        }
    }
    
    private function testMada() {
        echo "🏦 اختبار مدى...\n";
        
        $config = APIConfig::getPaymentGatewayConfig('mada');
        
        if (!$config) {
            echo "❌ إعدادات مدى غير موجودة\n\n";
            return;
        }
        
        // Test Mada configuration
        $required_fields = ['merchant_id', 'terminal_id', 'secret_key'];
        $missing_fields = [];
        
        foreach ($required_fields as $field) {
            if (empty($config[$field])) {
                $missing_fields[] = $field;
            }
        }
        
        if (empty($missing_fields)) {
            echo "✅ إعدادات مدى مكتملة\n";
            
            // Test creating Mada payment request
            $payment_result = $this->createMadaPayment($config);
            
            if ($payment_result['success']) {
                echo "✅ تم إنشاء طلب دفع مدى بنجاح\n";
                echo "   Transaction ID: " . $payment_result['transaction_id'] . "\n";
            } else {
                echo "❌ فشل إنشاء طلب دفع مدى: " . $payment_result['error'] . "\n";
            }
        } else {
            echo "❌ إعدادات مدى ناقصة: " . implode(', ', $missing_fields) . "\n";
        }
        
        echo "\n";
    }
    
    private function createMadaPayment($config) {
        $transaction_id = 'test_' . uniqid();
        $amount = 100.00;
        
        // Create hash for Mada
        $hash_string = $config['merchant_id'] . $amount . $transaction_id . $config['secret_key'];
        $hash = hash('sha256', $hash_string);
        
        $payment_data = [
            'merchant_id' => $config['merchant_id'],
            'terminal_id' => $config['terminal_id'],
            'amount' => $amount,
            'currency' => 'SAR',
            'transaction_id' => $transaction_id,
            'return_url' => 'http://localhost/payment/success',
            'hash' => $hash
        ];
        
        // In a real scenario, this would be sent to Mada's API
        // For testing, we just validate the data structure
        
        return [
            'success' => true,
            'transaction_id' => $transaction_id,
            'payment_data' => $payment_data
        ];
    }
    
    private function testApplePayConfig() {
        echo "🍎 اختبار إعداد Apple Pay...\n";
        
        $config = APIConfig::getPaymentGatewayConfig('apple_pay');
        
        if (!$config) {
            echo "❌ إعدادات Apple Pay غير موجودة\n\n";
            return;
        }
        
        $required_fields = ['merchant_id', 'bundle_id', 'shared_secret'];
        $missing_fields = [];
        
        foreach ($required_fields as $field) {
            if (empty($config[$field])) {
                $missing_fields[] = $field;
            }
        }
        
        if (empty($missing_fields)) {
            echo "✅ إعدادات Apple Pay مكتملة\n";
            echo "   Merchant ID: " . $config['merchant_id'] . "\n";
            echo "   Bundle ID: " . $config['bundle_id'] . "\n";
            echo "   Environment: " . $config['environment'] . "\n";
            
            // Check domain verification file
            $domain_file = '../.well-known/apple-developer-merchantid-domain-association';
            if (file_exists($domain_file)) {
                echo "✅ ملف التحقق من النطاق موجود\n";
            } else {
                echo "⚠️ ملف التحقق من النطاق غير موجود\n";
                echo "   يجب إنشاء الملف: .well-known/apple-developer-merchantid-domain-association\n";
            }
        } else {
            echo "❌ إعدادات Apple Pay ناقصة: " . implode(', ', $missing_fields) . "\n";
        }
        
        echo "\n";
    }
    
    private function testGooglePayConfig() {
        echo "🤖 اختبار إعداد Google Pay...\n";
        
        $config = APIConfig::getPaymentGatewayConfig('google_pay');
        
        if (!$config) {
            echo "❌ إعدادات Google Pay غير موجودة\n\n";
            return;
        }
        
        $required_fields = ['merchant_id'];
        $missing_fields = [];
        
        foreach ($required_fields as $field) {
            if (empty($config[$field])) {
                $missing_fields[] = $field;
            }
        }
        
        if (empty($missing_fields)) {
            echo "✅ إعدادات Google Pay مكتملة\n";
            echo "   Merchant ID: " . $config['merchant_id'] . "\n";
            echo "   Environment: " . $config['environment'] . "\n";
        } else {
            echo "❌ إعدادات Google Pay ناقصة: " . implode(', ', $missing_fields) . "\n";
        }
        
        echo "\n";
    }
    
    private function testYemenMobileMoney() {
        echo "📱 اختبار Yemen Mobile Money...\n";
        
        $config = APIConfig::getPaymentGatewayConfig('ymm');
        
        if (!$config) {
            echo "❌ إعدادات Yemen Mobile Money غير موجودة\n\n";
            return;
        }
        
        $required_fields = ['merchant_code', 'api_key'];
        $missing_fields = [];
        
        foreach ($required_fields as $field) {
            if (empty($config[$field])) {
                $missing_fields[] = $field;
            }
        }
        
        if (empty($missing_fields)) {
            echo "✅ إعدادات Yemen Mobile Money مكتملة\n";
            
            // Test API connection
            $connection_result = $this->testYMMConnection($config);
            
            if ($connection_result['success']) {
                echo "✅ تم الاتصال بـ Yemen Mobile Money API بنجاح\n";
            } else {
                echo "❌ فشل الاتصال بـ Yemen Mobile Money API: " . $connection_result['error'] . "\n";
            }
        } else {
            echo "❌ إعدادات Yemen Mobile Money ناقصة: " . implode(', ', $missing_fields) . "\n";
        }
        
        echo "\n";
    }
    
    private function testYMMConnection($config) {
        // Test connection to Yemen Mobile Money API
        $test_data = [
            'merchant_code' => $config['merchant_code'],
            'amount' => 100,
            'currency' => 'YER',
            'transaction_id' => 'test_' . uniqid(),
            'description' => 'FastStar Test Payment'
        ];
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $config['api_url'] . '/test',
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($test_data),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $config['api_key'],
                'Content-Type: application/json'
            ],
            CURLOPT_TIMEOUT => 10,
            CURLOPT_CONNECTTIMEOUT => 5
        ]);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            return [
                'success' => false,
                'error' => "Connection error: $error"
            ];
        }
        
        if ($http_code === 200 || $http_code === 404) { // 404 is OK for test endpoint
            return ['success' => true];
        } else {
            return [
                'success' => false,
                'error' => "HTTP $http_code: $response"
            ];
        }
    }
}

// Run tests if called directly
if (php_sapi_name() === 'cli') {
    new PaymentGatewayTester();
} else {
    echo "<pre>";
    new PaymentGatewayTester();
    echo "</pre>";
}
?>
