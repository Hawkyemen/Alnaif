<?php
require_once '../config/config.php';
require_once '../config/payment_config.php';

// Test comprehensive payment system
class PaymentSystemTest {
    private $db;
    private $results = [];
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function runAllTests() {
        echo "<h1>🧪 اختبار شامل لنظام الدفع</h1>\n";
        echo "<div style='font-family: Arial; margin: 20px;'>\n";
        
        $this->testDatabaseStructure();
        $this->testPaymentGateways();
        $this->testCardValidation();
        $this->testApplePaySetup();
        $this->testGooglePlaySetup();
        $this->testWalletProducts();
        $this->testExchangeRates();
        $this->testSecurityFeatures();
        
        $this->displayResults();
        echo "</div>\n";
    }
    
    private function testDatabaseStructure() {
        echo "<h2>🗄️ اختبار هيكل قاعدة البيانات</h2>\n";
        
        $tables = [
            'payment_gateways' => 'جدول بوابات الدفع',
            'wallet_topup_products' => 'جدول منتجات شحن المحفظة',
            'in_app_purchases' => 'جدول المشتريات داخل التطبيق',
            'payment_gateway_tests' => 'جدول اختبارات بوابات الدفع',
            'payment_gateway_settings' => 'جدول إعدادات بوابات الدفع',
            'exchange_rates' => 'جدول أسعار الصرف'
        ];
        
        foreach ($tables as $table => $description) {
            $stmt = $this->db->query("SHOW TABLES LIKE '$table'");
            $exists = $stmt->rowCount() > 0;
            
            $this->results['database'][$table] = [
                'name' => $description,
                'status' => $exists ? 'pass' : 'fail',
                'message' => $exists ? 'الجدول موجود' : 'الجدول غير موجود'
            ];
            
            echo $this->formatTestResult($description, $exists, $exists ? 'الجدول موجود' : 'الجدول غير موجود');
        }
    }
    
    private function testPaymentGateways() {
        echo "<h2>💳 اختبار بوابات الدفع</h2>\n";
        
        $gateways = [
            'paypal' => ['name' => 'PayPal', 'config' => ['PAYPAL_CLIENT_ID', 'PAYPAL_CLIENT_SECRET']],
            'stripe' => ['name' => 'Stripe', 'config' => ['STRIPE_PUBLISHABLE_KEY', 'STRIPE_SECRET_KEY']],
            'apple_pay' => ['name' => 'Apple Pay', 'config' => ['APPLE_SHARED_SECRET', 'APPLE_BUNDLE_ID']],
            'google_play' => ['name' => 'Google Play', 'config' => ['GOOGLE_PLAY_PACKAGE_NAME', 'GOOGLE_PLAY_SERVICE_ACCOUNT_KEY']],
            'mada' => ['name' => 'مدى', 'config' => ['MADA_MERCHANT_ID', 'MADA_SECRET_KEY']],
            'ymm' => ['name' => 'Yemen Mobile Money', 'config' => ['YMM_MERCHANT_CODE', 'YMM_API_KEY']]
        ];
        
        foreach ($gateways as $code => $gateway) {
            $configured = true;
            $missing = [];
            
            foreach ($gateway['config'] as $constant) {
                if (!defined($constant) || empty(constant($constant))) {
                    $configured = false;
                    $missing[] = $constant;
                }
            }
            
            $this->results['gateways'][$code] = [
                'name' => $gateway['name'],
                'status' => $configured ? 'pass' : 'fail',
                'message' => $configured ? 'مكونة بالكامل' : 'إعدادات مفقودة: ' . implode(', ', $missing)
            ];
            
            echo $this->formatTestResult($gateway['name'], $configured, 
                $configured ? 'مكونة بالكامل' : 'إعدادات مفقودة: ' . implode(', ', $missing));
        }
    }
    
    private function testCardValidation() {
        echo "<h2>🔍 اختبار التحقق من البطاقات</h2>\n";
        
        $testCards = [
            ['number' => '4111111111111111', 'type' => 'Visa', 'valid' => true],
            ['number' => '5555555555554444', 'type' => 'Mastercard', 'valid' => true],
            ['number' => '378282246310005', 'type' => 'American Express', 'valid' => true],
            ['number' => '4008610000000001', 'type' => 'Mada', 'valid' => true],
            ['number' => '1234567890123456', 'type' => 'Invalid', 'valid' => false]
        ];
        
        foreach ($testCards as $card) {
            $isValid = $this->validateCardNumber($card['number']);
            $detectedType = $this->detectCardType($card['number']);
            
            $testPassed = ($isValid === $card['valid']);
            
            $this->results['card_validation'][] = [
                'card' => $card['type'] . ' (' . $this->maskCardNumber($card['number']) . ')',
                'status' => $testPassed ? 'pass' : 'fail',
                'message' => $testPassed ? 'التحقق صحيح' : 'التحقق خاطئ'
            ];
            
            echo $this->formatTestResult(
                $card['type'] . ' (' . $this->maskCardNumber($card['number']) . ')',
                $testPassed,
                "متوقع: " . ($card['valid'] ? 'صحيح' : 'خاطئ') . ", النتيجة: " . ($isValid ? 'صحيح' : 'خاطئ')
            );
        }
    }
    
    private function testApplePaySetup() {
        echo "<h2>🍎 اختبار إعداد Apple Pay</h2>\n";
        
        $tests = [
            'merchant_id' => [
                'name' => 'Merchant ID',
                'check' => defined('APPLE_BUNDLE_ID') && !empty(APPLE_BUNDLE_ID),
                'value' => defined('APPLE_BUNDLE_ID') ? APPLE_BUNDLE_ID : 'غير محدد'
            ],
            'shared_secret' => [
                'name' => 'Shared Secret',
                'check' => defined('APPLE_SHARED_SECRET') && !empty(APPLE_SHARED_SECRET),
                'value' => defined('APPLE_SHARED_SECRET') ? '***محدد***' : 'غير محدد'
            ],
            'domain_verification' => [
                'name' => 'Domain Verification File',
                'check' => file_exists('../.well-known/apple-developer-merchantid-domain-association'),
                'value' => file_exists('../.well-known/apple-developer-merchantid-domain-association') ? 'موجود' : 'غير موجود'
            ]
        ];
        
        foreach ($tests as $key => $test) {
            $this->results['apple_pay'][$key] = [
                'name' => $test['name'],
                'status' => $test['check'] ? 'pass' : 'fail',
                'message' => $test['value']
            ];
            
            echo $this->formatTestResult($test['name'], $test['check'], $test['value']);
        }
    }
    
    private function testGooglePlaySetup() {
        echo "<h2>🤖 اختبار إعداد Google Play</h2>\n";
        
        $tests = [
            'package_name' => [
                'name' => 'Package Name',
                'check' => defined('GOOGLE_PLAY_PACKAGE_NAME') && !empty(GOOGLE_PLAY_PACKAGE_NAME),
                'value' => defined('GOOGLE_PLAY_PACKAGE_NAME') ? GOOGLE_PLAY_PACKAGE_NAME : 'غير محدد'
            ],
            'service_account' => [
                'name' => 'Service Account Key',
                'check' => defined('GOOGLE_PLAY_SERVICE_ACCOUNT_KEY') && !empty(GOOGLE_PLAY_SERVICE_ACCOUNT_KEY),
                'value' => defined('GOOGLE_PLAY_SERVICE_ACCOUNT_KEY') ? '***محدد***' : 'غير محدد'
            ]
        ];
        
        if (defined('GOOGLE_PLAY_SERVICE_ACCOUNT_KEY') && !empty(GOOGLE_PLAY_SERVICE_ACCOUNT_KEY)) {
            $serviceAccount = json_decode(GOOGLE_PLAY_SERVICE_ACCOUNT_KEY, true);
            $tests['service_account_valid'] = [
                'name' => 'Service Account JSON Valid',
                'check' => $serviceAccount && isset($serviceAccount['client_email']),
                'value' => $serviceAccount && isset($serviceAccount['client_email']) ? 
                    $serviceAccount['client_email'] : 'JSON غير صحيح'
            ];
        }
        
        foreach ($tests as $key => $test) {
            $this->results['google_play'][$key] = [
                'name' => $test['name'],
                'status' => $test['check'] ? 'pass' : 'fail',
                'message' => $test['value']
            ];
            
            echo $this->formatTestResult($test['name'], $test['check'], $test['value']);
        }
    }
    
    private function testWalletProducts() {
        echo "<h2>🛍️ اختبار منتجات شحن المحفظة</h2>\n";
        
        try {
            $stmt = $this->db->query("SELECT platform, COUNT(*) as count FROM wallet_topup_products WHERE status = 'active' GROUP BY platform");
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $platforms = ['web' => 0, 'ios' => 0, 'android' => 0];
            foreach ($products as $product) {
                $platforms[$product['platform']] = $product['count'];
            }
            
            foreach ($platforms as $platform => $count) {
                $this->results['wallet_products'][$platform] = [
                    'name' => ucfirst($platform) . ' Products',
                    'status' => $count > 0 ? 'pass' : 'fail',
                    'message' => "$count منتج متاح"
                ];
                
                echo $this->formatTestResult(ucfirst($platform) . ' Products', $count > 0, "$count منتج متاح");
            }
            
        } catch (Exception $e) {
            echo $this->formatTestResult('Wallet Products', false, 'خطأ في قاعدة البيانات: ' . $e->getMessage());
        }
    }
    
    private function testExchangeRates() {
        echo "<h2>💱 اختبار أسعار الصرف</h2>\n";
        
        try {
            $stmt = $this->db->query("SELECT COUNT(*) as count FROM exchange_rates");
            $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            $this->results['exchange_rates']['count'] = [
                'name' => 'Exchange Rates Count',
                'status' => $count >= 12 ? 'pass' : 'fail',
                'message' => "$count سعر صرف محفوظ"
            ];
            
            echo $this->formatTestResult('Exchange Rates Count', $count >= 12, "$count سعر صرف محفوظ");
            
            // Test specific rates
            $testRates = [
                ['from' => 'USD', 'to' => 'SAR', 'expected_min' => 3.0, 'expected_max' => 4.0],
                ['from' => 'SAR', 'to' => 'USD', 'expected_min' => 0.2, 'expected_max' => 0.4]
            ];
            
            foreach ($testRates as $test) {
                $stmt = $this->db->prepare("SELECT rate FROM exchange_rates WHERE from_currency = ? AND to_currency = ?");
                $stmt->execute([$test['from'], $test['to']]);
                $rate = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($rate) {
                    $rateValue = (float)$rate['rate'];
                    $isValid = $rateValue >= $test['expected_min'] && $rateValue <= $test['expected_max'];
                    
                    echo $this->formatTestResult(
                        "{$test['from']} to {$test['to']}",
                        $isValid,
                        "السعر: $rateValue"
                    );
                }
            }
            
        } catch (Exception $e) {
            echo $this->formatTestResult('Exchange Rates', false, 'خطأ في قاعدة البيانات: ' . $e->getMessage());
        }
    }
    
    private function testSecurityFeatures() {
        echo "<h2>🔒 اختبار الميزات الأمنية</h2>\n";
        
        $securityTests = [
            'ssl_enabled' => [
                'name' => 'SSL/HTTPS',
                'check' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
                'message' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'SSL مفعل' : 'SSL غير مفعل'
            ],
            'csrf_protection' => [
                'name' => 'CSRF Protection',
                'check' => function_exists('generateCSRFToken'),
                'message' => function_exists('generateCSRFToken') ? 'حماية CSRF متاحة' : 'حماية CSRF غير متاحة'
            ],
            'input_validation' => [
                'name' => 'Input Validation Functions',
                'check' => function_exists('validateCardNumber') || method_exists('PaymentGateway', 'validateCardNumber'),
                'message' => 'وظائف التحقق من المدخلات متاحة'
            ],
            'database_prepared_statements' => [
                'name' => 'Prepared Statements',
                'check' => class_exists('PDO'),
                'message' => 'PDO متاح للاستعلامات الآمنة'
            ]
        ];
        
        foreach ($securityTests as $key => $test) {
            $this->results['security'][$key] = [
                'name' => $test['name'],
                'status' => $test['check'] ? 'pass' : 'fail',
                'message' => $test['message']
            ];
            
            echo $this->formatTestResult($test['name'], $test['check'], $test['message']);
        }
    }
    
    private function displayResults() {
        echo "<h2>📊 ملخص النتائج</h2>\n";
        
        $totalTests = 0;
        $passedTests = 0;
        
        foreach ($this->results as $category => $tests) {
            if (is_array($tests)) {
                foreach ($tests as $test) {
                    if (isset($test['status'])) {
                        $totalTests++;
                        if ($test['status'] === 'pass') {
                            $passedTests++;
                        }
                    }
                }
            }
        }
        
        $successRate = $totalTests > 0 ? round(($passedTests / $totalTests) * 100, 2) : 0;
        
        echo "<div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;'>\n";
        echo "<h3>النتيجة الإجمالية</h3>\n";
        echo "<p><strong>إجمالي الاختبارات:</strong> $totalTests</p>\n";
        echo "<p><strong>الاختبارات الناجحة:</strong> $passedTests</p>\n";
        echo "<p><strong>معدل النجاح:</strong> $successRate%</p>\n";
        
        $status = $successRate >= 80 ? 'ممتاز' : ($successRate >= 60 ? 'جيد' : 'يحتاج تحسين');
        $color = $successRate >= 80 ? 'green' : ($successRate >= 60 ? 'orange' : 'red');
        
        echo "<p style='color: $color; font-weight: bold; font-size: 18px;'>الحالة: $status</p>\n";
        echo "</div>\n";
        
        // Recommendations
        if ($successRate < 100) {
            echo "<h3>🔧 التوصيات للتحسين</h3>\n";
            echo "<ul>\n";
            
            foreach ($this->results as $category => $tests) {
                if (is_array($tests)) {
                    foreach ($tests as $test) {
                        if (isset($test['status']) && $test['status'] === 'fail') {
                            echo "<li><strong>{$test['name']}:</strong> {$test['message']}</li>\n";
                        }
                    }
                }
            }
            
            echo "</ul>\n";
        }
    }
    
    private function formatTestResult($name, $passed, $message) {
        $icon = $passed ? '✅' : '❌';
        $color = $passed ? 'green' : 'red';
        return "<p style='color: $color;'>$icon <strong>$name:</strong> $message</p>\n";
    }
    
    // Helper functions
    private function validateCardNumber($number) {
        $number = preg_replace('/\D/', '', $number);
        $sum = 0;
        $alternate = false;
        
        for ($i = strlen($number) - 1; $i >= 0; $i--) {
            $n = intval($number[$i]);
            if ($alternate) {
                $n *= 2;
                if ($n > 9) $n = ($n % 10) + 1;
            }
            $sum += $n;
            $alternate = !$alternate;
        }
        
        return ($sum % 10) === 0;
    }
    
    private function detectCardType($number) {
        $number = preg_replace('/\D/', '', $number);
        
        if (preg_match('/^4/', $number)) return 'Visa';
        if (preg_match('/^5[1-5]/', $number)) return 'Mastercard';
        if (preg_match('/^3[47]/', $number)) return 'American Express';
        if (preg_match('/^(400861|401757|407197)/', $number)) return 'Mada';
        
        return 'Unknown';
    }
    
    private function maskCardNumber($number) {
        $number = preg_replace('/\D/', '', $number);
        return substr($number, 0, 4) . ' **** **** ' . substr($number, -4);
    }
}

// Run tests if accessed directly
if (basename($_SERVER['PHP_SELF']) === 'payment_test.php') {
    $tester = new PaymentSystemTest();
    $tester->runAllTests();
}
?>
