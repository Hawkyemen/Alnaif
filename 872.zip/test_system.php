<?php
require_once __DIR__ . '/config/database.php';

echo '<h2>🧪 اختبار النظام - FastStar</h2>';

try {
    $db = Database::getInstance()->getConnection();
    
    echo '<h3>✅ قاعدة البيانات</h3>';
    echo '<p>الاتصال: نجح</p>';
    echo '<p>قاعدة البيانات: ' . DB_NAME . '</p>';
    echo '<p>الخادم: ' . DB_HOST . '</p>';
    
    echo '<h3>📊 الجداول</h3>';
    $stmt = $db->query('SHOW TABLES');
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo '<p>عدد الجداول: ' . count($tables) . '</p>';
    
    echo '<h3>👤 المديرين</h3>';
    $stmt = $db->query('SELECT COUNT(*) as count FROM admins');
    $admin_count = $stmt->fetch()['count'];
    echo '<p>عدد المديرين: ' . $admin_count . '</p>';
    
    echo '<h3>👥 المستخدمين</h3>';
    $stmt = $db->query('SELECT COUNT(*) as count FROM users');
    $user_count = $stmt->fetch()['count'];
    echo '<p>عدد المستخدمين: ' . $user_count . '</p>';
    
    echo '<h3>🛍️ المنتجات</h3>';
    $stmt = $db->query('SELECT COUNT(*) as count FROM products');
    $product_count = $stmt->fetch()['count'];
    echo '<p>عدد المنتجات: ' . $product_count . '</p>';
    
    echo '<h3>🔗 روابط مهمة</h3>';
    echo '<p><a href="admin/login.php">لوحة تحكم المدير</a></p>';
    echo '<p><a href="login.php">تسجيل دخول المستخدم</a></p>';
    echo '<p><a href="register.php">تسجيل مستخدم جديد</a></p>';
    
    echo '<h3>🔐 بيانات تسجيل الدخول</h3>';
    echo '<h4>المدير:</h4>';
    echo '<p>اسم المستخدم: admin</p>';
    echo '<p>كلمة المرور: faststar2024</p>';
    echo '<h4>مستخدم تجريبي:</h4>';
    echo '<p>اسم المستخدم: testuser</p>';
    echo '<p>كلمة المرور: test123</p>';
    
} catch (Exception $e) {
    echo '<h3>❌ خطأ</h3>';
    echo '<p>' . $e->getMessage() . '</p>';
}
?>
