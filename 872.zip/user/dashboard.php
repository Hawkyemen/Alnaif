<?php
require_once '../config/config.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

$user = getCurrentUser();
$db = Database::getInstance()->getConnection();

// Get user statistics
$stats = [];

// Recent orders
$stmt = $db->prepare("SELECT COUNT(*) as count FROM orders WHERE user_id = ?");
$stmt->execute([$user['id']]);
$stats['total_orders'] = $stmt->fetch()['count'];

// Completed orders
$stmt = $db->prepare("SELECT COUNT(*) as count FROM orders WHERE user_id = ? AND status = 'completed'");
$stmt->execute([$user['id']]);
$stats['completed_orders'] = $stmt->fetch()['count'];

// Total spent
$stmt = $db->prepare("SELECT SUM(amount) as total FROM orders WHERE user_id = ? AND status = 'completed'");
$stmt->execute([$user['id']]);
$stats['total_spent'] = $stmt->fetch()['total'] ?? 0;

// Recent orders
$stmt = $db->prepare("SELECT o.*, p.name_ar as product_name FROM orders o JOIN products p ON o.product_id = p.id WHERE o.user_id = ? ORDER BY o.created_at DESC LIMIT 5");
$stmt->execute([$user['id']]);
$recent_orders = $stmt->fetchAll();

// Wallet balances
$wallet_balances = [
    'YER' => $user['wallet_balance_yer'] ?? 0,
    'SAR' => $user['wallet_balance_sar'] ?? 0,
    'USD' => $user['wallet_balance_usd'] ?? 0
];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - <?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(45deg, #f39c12, #e67e22) !important;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            margin-bottom: 24px;
        }
        .stat-card {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
        }
        .wallet-card {
            background: linear-gradient(45deg, #11998e, #38ef7d);
            color: white;
        }
        .quick-action {
            transition: all 0.3s ease;
        }
        .quick-action:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-star me-2"></i>
                <?= SITE_NAME ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="fas fa-home me-1"></i>الرئيسية
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="products.php">
                            <i class="fas fa-box me-1"></i>المنتجات
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="orders.php">
                            <i class="fas fa-shopping-cart me-1"></i>طلباتي
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="wallet.php">
                            <i class="fas fa-wallet me-1"></i>المحفظة
                        </a>
                    </li>
                </ul>
                
                <div class="navbar-nav">
                    <div class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user me-1"></i>
                            <?= htmlspecialchars($user['full_name']) ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php">
                                <i class="fas fa-user me-2"></i>الملف الشخصي
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i>تسجيل الخروج
                            </a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="container mt-4">
        <!-- Welcome Section -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h2 class="mb-1">مرحباً، <?= htmlspecialchars($user['full_name']) ?>! 👋</h2>
                        <p class="text-muted mb-0">نتمنى لك تجربة ممتعة في <?= SITE_NAME ?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="card stat-card">
                    <div class="card-body text-center">
                        <i class="fas fa-shopping-cart fa-2x mb-3"></i>
                        <h4><?= number_format($stats['total_orders']) ?></h4>
                        <p class="mb-0">إجمالي الطلبات</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="card stat-card">
                    <div class="card-body text-center">
                        <i class="fas fa-check-circle fa-2x mb-3"></i>
                        <h4><?= number_format($stats['completed_orders']) ?></h4>
                        <p class="mb-0">طلبات مكتملة</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="card stat-card">
                    <div class="card-body text-center">
                        <i class="fas fa-dollar-sign fa-2x mb-3"></i>
                        <h4><?= formatCurrency($stats['total_spent'], 'YER') ?></h4>
                        <p class="mb-0">إجمالي الإنفاق</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="card wallet-card">
                    <div class="card-body text-center">
                        <i class="fas fa-wallet fa-2x mb-3"></i>
                        <h6>أرصدة المحفظة</h6>
                        <small>
                            <?= formatCurrency($wallet_balances['YER'], 'YER') ?><br>
                            <?= formatCurrency($wallet_balances['SAR'], 'SAR') ?><br>
                            <?= formatCurrency($wallet_balances['USD'], 'USD') ?>
                        </small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-bolt me-2"></i>
                            إجراءات سريعة
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-3 col-md-6 mb-3">
                                <a href="products.php" class="btn btn-outline-primary w-100 quick-action">
                                    <i class="fas fa-shopping-cart fa-2x d-block mb-2"></i>
                                    تصفح المنتجات
                                </a>
                            </div>
                            <div class="col-lg-3 col-md-6 mb-3">
                                <a href="wallet.php" class="btn btn-outline-success w-100 quick-action">
                                    <i class="fas fa-plus-circle fa-2x d-block mb-2"></i>
                                    شحن المحفظة
                                </a>
                            </div>
                            <div class="col-lg-3 col-md-6 mb-3">
                                <a href="orders.php" class="btn btn-outline-info w-100 quick-action">
                                    <i class="fas fa-history fa-2x d-block mb-2"></i>
                                    سجل الطلبات
                                </a>
                            </div>
                            <div class="col-lg-3 col-md-6 mb-3">
                                <a href="profile.php" class="btn btn-outline-warning w-100 quick-action">
                                    <i class="fas fa-user-cog fa-2x d-block mb-2"></i>
                                    إعدادات الحساب
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Recent Orders -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-clock me-2"></i>
                            آخر الطلبات
                        </h5>
                        <a href="orders.php" class="btn btn-sm btn-outline-primary">
                            عرض الكل
                        </a>
                    </div>
                    <div class="card-body">
                        <?php if (empty($recent_orders)): ?>
                            <div class="text-center py-4">
                                <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">لا توجد طلبات بعد</h5>
                                <p class="text-muted">ابدأ بتصفح منتجاتنا واطلب ما تحتاجه</p>
                                <a href="products.php" class="btn btn-primary">
                                    تصفح المنتجات
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>رقم الطلب</th>
                                            <th>المنتج</th>
                                            <th>المبلغ</th>
                                            <th>الحالة</th>
                                            <th>التاريخ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recent_orders as $order): ?>
                                        <tr>
                                            <td>#<?= $order['id'] ?></td>
                                            <td><?= htmlspecialchars($order['product_name']) ?></td>
                                            <td><?= formatCurrency($order['amount'], $order['currency']) ?></td>
                                            <td>
                                                <?php
                                                $status_colors = [
                                                    'pending' => 'warning',
                                                    'processing' => 'info',
                                                    'completed' => 'success',
                                                    'failed' => 'danger',
                                                    'cancelled' => 'secondary'
                                                ];
                                                $status_names = [
                                                    'pending' => 'في الانتظار',
                                                    'processing' => 'قيد المعالجة',
                                                    'completed' => 'مكتمل',
                                                    'failed' => 'فشل',
                                                    'cancelled' => 'ملغي'
                                                ];
                                                ?>
                                                <span class="badge bg-<?= $status_colors[$order['status']] ?>">
                                                    <?= $status_names[$order['status']] ?>
                                                </span>
                                            </td>
                                            <td><?= date('Y-m-d H:i', strtotime($order['created_at'])) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
