<?php
require_once '../config/config.php';

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    logActivity($user_id, 'logout', 'تسجيل خروج المستخدم');
}

// Clear all session data
session_unset();
session_destroy();

// Redirect to login page
redirect('../login.php');
?>
