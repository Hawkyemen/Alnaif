<?php
require_once '../config/config.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

$user = getCurrentUser();
$db = Database::getInstance()->getConnection();

// Get filter parameters
$status_filter = $_GET['status'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;

// Build query
$where_conditions = ["o.user_id = ?"];
$params = [$user['id']];

if ($status_filter) {
    $where_conditions[] = "o.status = ?";
    $params[] = $status_filter;
}

$where_clause = 'WHERE ' . implode(' AND ', $where_conditions);

// Get orders
$orders_query = "
    SELECT o.*, p.name_ar as product_name, p.description as product_description,
           c.name_ar as category_name
    FROM orders o 
    JOIN products p ON o.product_id = p.id 
    JOIN categories c ON p.category_id = c.id
    $where_clause
    ORDER BY o.created_at DESC 
    LIMIT $limit OFFSET $offset
";

$stmt = $db->prepare($orders_query);
$stmt->execute($params);
$orders = $stmt->fetchAll();

// Get total count
$count_query = "SELECT COUNT(*) as total FROM orders o $where_clause";
$stmt = $db->prepare($count_query);
$stmt->execute($params);
$total_orders = $stmt->fetch()['total'];
$total_pages = ceil($total_orders / $limit);

// Get order statistics
$stats_query = "
    SELECT 
        COUNT(*) as total_orders,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_orders,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_orders,
        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_orders,
        SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as total_spent
    FROM orders 
    WHERE user_id = ?
";
$stmt = $db->prepare($stats_query);
$stmt->execute([$user['id']]);
$stats = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>طلباتي - <?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(45deg, #f39c12, #e67e22) !important;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            margin-bottom: 24px;
        }
        .order-card {
            transition: all 0.3s ease;
        }
        .order-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .status-badge {
            font-size: 0.8rem;
            padding: 0.5rem 1rem;
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-star me-2"></i>
                <?= SITE_NAME ?>
            </a>
            
            <div class="navbar-nav ms-auto">
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user me-1"></i>
                        <?= htmlspecialchars($user['full_name']) ?>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="dashboard.php"><i class="fas fa-home me-2"></i>الرئيسية</a></li>
                        <li><a class="dropdown-item" href="products.php"><i class="fas fa-box me-2"></i>المنتجات</a></li>
                        <li><a class="dropdown-item" href="wallet.php"><i class="fas fa-wallet me-2"></i>المحفظة</a></li>
                        <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>الملف الشخصي</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>تسجيل الخروج</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="container mt-4">
        <!-- Page Header -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h2 class="mb-1">
                            <i class="fas fa-shopping-cart me-2"></i>
                            طلباتي
                        </h2>
                        <p class="text-muted mb-0">تتبع جميع طلباتك وحالتها</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fas fa-shopping-cart fa-2x text-primary mb-2"></i>
                        <h4><?= number_format($stats['total_orders']) ?></h4>
                        <small class="text-muted">إجمالي الطلبات</small>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fas fa-check-circle fa-2x text-success mb-2"></i>
                        <h4><?= number_format($stats['completed_orders']) ?></h4>
                        <small class="text-muted">طلبات مكتملة</small>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fas fa-clock fa-2x text-warning mb-2"></i>
                        <h4><?= number_format($stats['pending_orders']) ?></h4>
                        <small class="text-muted">طلبات معلقة</small>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fas fa-dollar-sign fa-2x text-info mb-2"></i>
                        <h4><?= formatCurrency($stats['total_spent'], 'YER') ?></h4>
                        <small class="text-muted">إجمالي الإنفاق</small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Filters -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form method="GET" class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">فلترة حسب الحالة</label>
                                <select name="status" class="form-select">
                                    <option value="">جميع الحالات</option>
                                    <option value="pending" <?= $status_filter === 'pending' ? 'selected' : '' ?>>في الانتظار</option>
                                    <option value="processing" <?= $status_filter === 'processing' ? 'selected' : '' ?>>قيد المعالجة</option>
                                    <option value="completed" <?= $status_filter === 'completed' ? 'selected' : '' ?>>مكتمل</option>
                                    <option value="failed" <?= $status_filter === 'failed' ? 'selected' : '' ?>>فشل</option>
                                    <option value="cancelled" <?= $status_filter === 'cancelled' ? 'selected' : '' ?>>ملغي</option>
                                </select>
                            </div>
                            <div class="col-md-4 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary me-2">
                                    <i class="fas fa-filter me-1"></i>تطبيق
                                </button>
                                <a href="orders.php" class="btn btn-outline-secondary">
                                    <i class="fas fa-times me-1"></i>مسح
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Orders List -->
        <div class="row">
            <?php if (empty($orders)): ?>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body text-center py-5">
                            <i class="fas fa-shopping-cart fa-5x text-muted mb-4"></i>
                            <h4 class="text-muted">لا توجد طلبات</h4>
                            <p class="text-muted">لم تقم بأي طلبات بعد</p>
                            <a href="products.php" class="btn btn-primary">
                                <i class="fas fa-shopping-cart me-2"></i>
                                تصفح المنتجات
                            </a>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <?php foreach ($orders as $order): ?>
                <div class="col-lg-6 mb-4">
                    <div class="card order-card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <h6 class="card-title mb-0">
                                    طلب #<?= $order['id'] ?>
                                </h6>
                                <?php
                                $status_colors = [
                                    'pending' => 'warning',
                                    'processing' => 'info',
                                    'completed' => 'success',
                                    'failed' => 'danger',
                                    'cancelled' => 'secondary'
                                ];
                                $status_names = [
                                    'pending' => 'في الانتظار',
                                    'processing' => 'قيد المعالجة',
                                    'completed' => 'مكتمل',
                                    'failed' => 'فشل',
                                    'cancelled' => 'ملغي'
                                ];
                                ?>
                                <span class="badge bg-<?= $status_colors[$order['status']] ?> status-badge">
                                    <?= $status_names[$order['status']] ?>
                                </span>
                            </div>
                            
                            <div class="mb-3">
                                <h6 class="text-primary"><?= htmlspecialchars($order['product_name']) ?></h6>
                                <small class="text-muted"><?= htmlspecialchars($order['category_name']) ?></small>
                            </div>
                            
                            <div class="row mb-3">
                                <div class="col-6">
                                    <small class="text-muted">معرف اللاعب:</small><br>
                                    <strong><?= htmlspecialchars($order['player_id']) ?></strong>
                                </div>
                                <div class="col-6">
                                    <small class="text-muted">المبلغ:</small><br>
                                    <strong class="text-success"><?= formatCurrency($order['amount'], $order['currency']) ?></strong>
                                </div>
                            </div>
                            
                            <?php if ($order['player_name']): ?>
                            <div class="mb-3">
                                <small class="text-muted">اسم اللاعب:</small><br>
                                <strong><?= htmlspecialchars($order['player_name']) ?></strong>
                            </div>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">
                                    <?= date('Y-m-d H:i', strtotime($order['created_at'])) ?>
                                </small>
                                
                                <?php if ($order['status'] === 'pending'): ?>
                                <a href="payment.php?order=<?= $order['id'] ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-credit-card me-1"></i>دفع
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="row">
            <div class="col-12">
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $page - 1 ?>&status=<?= urlencode($status_filter) ?>">السابق</a>
                        </li>
                        <?php endif; ?>
                        
                        <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>&status=<?= urlencode($status_filter) ?>"><?= $i ?></a>
                        </li>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?= $page + 1 ?>&status=<?= urlencode($status_filter) ?>">التالي</a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
