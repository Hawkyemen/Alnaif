<?php
require_once '../config/config.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

$user = getCurrentUser();
$db = Database::getInstance()->getConnection();

$order_id = $_GET['order'] ?? 0;

// جلب بيانات الطلب
$stmt = $db->prepare("SELECT o.*, p.name_ar as product_name, p.description FROM orders o JOIN products p ON o.product_id = p.id WHERE o.id = ? AND o.user_id = ?");
$stmt->execute([$order_id, $user['id']]);
$order = $stmt->fetch();

if (!$order) {
    redirect('orders.php');
}

// معالجة الدفع
if ($_POST) {
    $payment_method = $_POST['payment_method'] ?? '';
    
    if ($payment_method === 'wallet') {
        // الدفع من المحفظة
        $wallet_field = 'wallet_balance_' . strtolower($order['currency']);
        $current_balance = $user[$wallet_field] ?? 0;
        
        if ($current_balance >= $order['amount']) {
            // خصم المبلغ من المحفظة
            $new_balance = $current_balance - $order['amount'];
            $stmt = $db->prepare("UPDATE users SET $wallet_field = ? WHERE id = ?");
            $stmt->execute([$new_balance, $user['id']]);
            
            // تحديث حالة الطلب
            $stmt = $db->prepare("UPDATE orders SET status = 'completed', payment_method = 'wallet', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$order_id]);
            
            // إضافة معاملة المحفظة
            $stmt = $db->prepare("INSERT INTO wallet_transactions (user_id, type, amount, currency, description, reference_id, status) VALUES (?, 'purchase', ?, ?, ?, ?, 'completed')");
            $stmt->execute([$user['id'], $order['amount'], $order['currency'], "شراء: " . $order['product_name'], $order_id]);
            
            logActivity($user['id'], 'payment_completed', "تم الدفع للطلب #$order_id من المحفظة");
            redirect("payment_success.php?order=$order_id");
        } else {
            $error = 'رصيد المحفظة غير كافي';
        }
    } else {
        // طرق دفع أخرى (ستتم إضافتها لاحقاً)
        $error = 'طريقة الدفع غير متاحة حالياً';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الدفع - <?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .navbar { background: linear-gradient(45deg, #f39c12, #e67e22); }
        .card { border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .payment-method {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 20px;
            margin: 10px 0;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .payment-method:hover {
            border-color: #f39c12;
            background: #fff8f0;
        }
        .payment-method.selected {
            border-color: #f39c12;
            background: #fff8f0;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-star me-2"></i><?= SITE_NAME ?>
            </a>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i><?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>

                <!-- تفاصيل الطلب -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><i class="fas fa-receipt me-2"></i>تفاصيل الطلب #<?= $order['id'] ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>المنتج:</strong> <?= htmlspecialchars($order['product_name']) ?></p>
                                <p><strong>معرف اللاعب:</strong> <?= htmlspecialchars($order['player_id']) ?></p>
                                <?php if ($order['player_name']): ?>
                                    <p><strong>اسم اللاعب:</strong> <?= htmlspecialchars($order['player_name']) ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <p><strong>المبلغ:</strong> <?= formatCurrency($order['amount'], $order['currency']) ?></p>
                                <p><strong>العملة:</strong> <?= $order['currency'] ?></p>
                                <p><strong>الحالة:</strong> 
                                    <span class="badge bg-warning">في انتظار الدفع</span>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- طرق الدفع -->
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-credit-card me-2"></i>اختر طريقة الدفع</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <!-- الدفع من المحفظة -->
                            <div class="payment-method" onclick="selectPaymentMethod('wallet')">
                                <input type="radio" name="payment_method" value="wallet" id="wallet" style="display: none;">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-wallet fa-2x text-primary me-3"></i>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1">المحفظة الإلكترونية</h6>
                                        <p class="mb-0 text-muted">
                                            الرصيد المتاح: <?= formatCurrency($user['wallet_balance_' . strtolower($order['currency'])] ?? 0, $order['currency']) ?>
                                        </p>
                                    </div>
                                    <div class="form-check">
                                        <i class="fas fa-check-circle text-success" style="display: none;"></i>
                                    </div>
                                </div>
                            </div>

                            <!-- طرق دفع أخرى (معطلة مؤقتاً) -->
                            <div class="payment-method" style="opacity: 0.5;">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-credit-card fa-2x text-secondary me-3"></i>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1">البطاقة الائتمانية</h6>
                                        <p class="mb-0 text-muted">قريباً...</p>
                                    </div>
                                </div>
                            </div>

                            <div class="payment-method" style="opacity: 0.5;">
                                <div class="d-flex align-items-center">
                                    <i class="fab fa-paypal fa-2x text-secondary me-3"></i>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1">PayPal</h6>
                                        <p class="mb-0 text-muted">قريباً...</p>
                                    </div>
                                </div>
                            </div>

                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-primary btn-lg" id="payButton" disabled>
                                    <i class="fas fa-lock me-2"></i>دفع آمن
                                </button>
                                <a href="orders.php" class="btn btn-secondary btn-lg ms-2">إلغاء</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function selectPaymentMethod(method) {
            // إزالة التحديد من جميع الطرق
            document.querySelectorAll('.payment-method').forEach(el => {
                el.classList.remove('selected');
                el.querySelector('.fa-check-circle').style.display = 'none';
            });
            
            // تحديد الطريقة المختارة
            const selectedMethod = document.querySelector(`input[value="${method}"]`).closest('.payment-method');
            selectedMethod.classList.add('selected');
            selectedMethod.querySelector('.fa-check-circle').style.display = 'inline';
            
            // تفعيل زر الدفع
            document.getElementById('payButton').disabled = false;
            document.querySelector(`input[value="${method}"]`).checked = true;
        }
    </script>
</body>
</html>
