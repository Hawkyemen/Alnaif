<?php
require_once '../config/config.php';

if (!isset($_SESSION['user_id'])) {
    redirect('../login.php');
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إلغاء الدفع - فاست ستار</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .result-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .result-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            padding: 3rem;
            text-align: center;
            max-width: 500px;
            width: 100%;
        }
        .warning-icon {
            color: #ffc107;
            font-size: 4rem;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <div class="result-container">
        <div class="result-card">
            <i class="fas fa-exclamation-triangle warning-icon"></i>
            <h2 class="text-warning mb-3">تم إلغاء الدفع</h2>
            <p class="lead">لقد قمت بإلغاء عملية الدفع. لم يتم خصم أي مبلغ من حسابك.</p>
            <a href="wallet.php" class="btn btn-primary btn-lg me-2">
                <i class="fas fa-redo me-2"></i>
                المحاولة مرة أخرى
            </a>
            <a href="dashboard.php" class="btn btn-outline-primary btn-lg">
                <i class="fas fa-home me-2"></i>
                الرئيسية
            </a>
        </div>
    </div>
</body>
</html>
