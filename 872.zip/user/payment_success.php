<?php
require_once '../config/config.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

$user = getCurrentUser();
$db = Database::getInstance()->getConnection();

$order_id = $_GET['order'] ?? 0;

// جلب بيانات الطلب
$stmt = $db->prepare("SELECT o.*, p.name_ar as product_name FROM orders o JOIN products p ON o.product_id = p.id WHERE o.id = ? AND o.user_id = ? AND o.status = 'completed'");
$stmt->execute([$order_id, $user['id']]);
$order = $stmt->fetch();

if (!$order) {
    redirect('orders.php');
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تم الدفع بنجاح - <?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .success-card {
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card success-card">
                    <div class="card-body text-center py-5">
                        <i class="fas fa-check-circle fa-5x mb-4" style="color: #28a745;"></i>
                        <h2 class="mb-4">تم الدفع بنجاح!</h2>
                        <p class="lead mb-4">تم إتمام عملية الشراء بنجاح</p>
                        
                        <div class="bg-white text-dark rounded p-4 mb-4">
                            <h5 class="mb-3">تفاصيل الطلب</h5>
                            <div class="row">
                                <div class="col-6 text-end">
                                    <strong>رقم الطلب:</strong><br>
                                    <strong>المنتج:</strong><br>
                                    <strong>معرف اللاعب:</strong><br>
                                    <strong>المبلغ المدفوع:</strong><br>
                                    <strong>طريقة الدفع:</strong>
                                </div>
                                <div class="col-6 text-start">
                                    #<?= $order['id'] ?><br>
                                    <?= htmlspecialchars($order['product_name']) ?><br>
                                    <?= htmlspecialchars($order['player_id']) ?><br>
                                    <?= formatCurrency($order['amount'], $order['currency']) ?><br>
                                    المحفظة الإلكترونية
                                </div>
                            </div>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            سيتم تنفيذ طلبك خلال 5-15 دقيقة
                        </div>
                        
                        <div class="d-flex justify-content-center gap-3">
                            <a href="orders.php" class="btn btn-light btn-lg">
                                <i class="fas fa-list me-2"></i>طلباتي
                            </a>
                            <a href="products.php" class="btn btn-outline-light btn-lg">
                                <i class="fas fa-shopping-cart me-2"></i>شراء المزيد
                            </a>
                            <a href="dashboard.php" class="btn btn-outline-light btn-lg">
                                <i class="fas fa-home me-2"></i>الرئيسية
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
