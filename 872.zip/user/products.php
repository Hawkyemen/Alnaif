<?php
require_once '../config/config.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

$user = getCurrentUser();
$db = Database::getInstance()->getConnection();

$category_id = $_GET['category'] ?? 0;
$search = $_GET['search'] ?? '';

// جلب الفئات
$stmt = $db->query("SELECT * FROM categories WHERE status = 'active' ORDER BY name_ar");
$categories = $stmt->fetchAll();

// جلب المنتجات
$where_conditions = ["p.status = 'active'"];
$params = [];

if ($category_id) {
    $where_conditions[] = "p.category_id = ?";
    $params[] = $category_id;
}

if ($search) {
    $where_conditions[] = "(p.name LIKE ? OR p.name_ar LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$where_clause = 'WHERE ' . implode(' AND ', $where_conditions);

$stmt = $db->prepare("SELECT p.*, c.name_ar as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id $where_clause ORDER BY p.name_ar");
$stmt->execute($params);
$products = $stmt->fetchAll();

// جلب الفئة المحددة
$selected_category = null;
if ($category_id) {
    $stmt = $db->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->execute([$category_id]);
    $selected_category = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>المنتجات - <?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .navbar { background: linear-gradient(45deg, #f39c12, #e67e22); }
        .product-card {
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        .category-btn {
            border-radius: 25px;
            margin: 5px;
            transition: all 0.3s ease;
        }
        .category-btn.active {
            background: linear-gradient(45deg, #f39c12, #e67e22);
            color: white;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-star me-2"></i><?= SITE_NAME ?>
            </a>
            <div class="navbar-nav ms-auto">
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user me-2"></i><?= htmlspecialchars($user['full_name']) ?>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="dashboard.php"><i class="fas fa-home me-2"></i>الرئيسية</a></li>
                        <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>الملف الشخصي</a></li>
                        <li><a class="dropdown-item" href="orders.php"><i class="fas fa-shopping-cart me-2"></i>طلباتي</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>تسجيل الخروج</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- عنوان الصفحة -->
        <div class="row mb-4">
            <div class="col-12">
                <h2>
                    <i class="fas fa-box me-2"></i>
                    <?= $selected_category ? htmlspecialchars($selected_category['name_ar']) : 'جميع المنتجات' ?>
                </h2>
                <p class="text-muted">
                    <?= $selected_category ? htmlspecialchars($selected_category['description']) : 'تصفح جميع المنتجات المتاحة' ?>
                </p>
            </div>
        </div>

        <!-- فلاتر الفئات -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title">الفئات:</h6>
                        <div class="d-flex flex-wrap">
                            <a href="products.php" class="btn category-btn <?= !$category_id ? 'active' : 'btn-outline-primary' ?>">
                                <i class="fas fa-th me-2"></i>الكل
                            </a>
                            <?php foreach ($categories as $category): ?>
                                <a href="products.php?category=<?= $category['id'] ?>" 
                                   class="btn category-btn <?= $category_id == $category['id'] ? 'active' : 'btn-outline-primary' ?>">
                                    <i class="fas fa-<?= $category['icon'] ?> me-2"></i>
                                    <?= htmlspecialchars($category['name_ar']) ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- شريط البحث -->
        <div class="row mb-4">
            <div class="col-12">
                <form method="GET" class="d-flex">
                    <?php if ($category_id): ?>
                        <input type="hidden" name="category" value="<?= $category_id ?>">
                    <?php endif; ?>
                    <input type="text" name="search" class="form-control me-2" placeholder="البحث في المنتجات..." value="<?= htmlspecialchars($search) ?>">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i>
                    </button>
                </form>
            </div>
        </div>

        <!-- المنتجات -->
        <div class="row">
            <?php if (empty($products)): ?>
                <div class="col-12">
                    <div class="text-center py-5">
                        <i class="fas fa-box-open fa-5x text-muted mb-3"></i>
                        <h4 class="text-muted">لا توجد منتجات</h4>
                        <p class="text-muted">لم يتم العثور على منتجات في هذه الفئة</p>
                        <a href="products.php" class="btn btn-primary">عرض جميع المنتجات</a>
                    </div>
                </div>
            <?php else: ?>
                <?php foreach ($products as $product): ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card product-card h-100" onclick="openPurchaseModal(<?= htmlspecialchars(json_encode($product)) ?>)">
                        <div class="card-body">
                            <div class="text-center mb-3">
                                <i class="fas fa-gamepad fa-3x text-primary"></i>
                            </div>
                            <h5 class="card-title text-center"><?= htmlspecialchars($product['name_ar']) ?></h5>
                            <p class="card-text text-muted text-center"><?= htmlspecialchars($product['description']) ?></p>
                            
                            <div class="row text-center">
                                <div class="col-4">
                                    <small class="text-muted">ريال يمني</small><br>
                                    <strong><?= formatCurrency($product['price_yer'], 'YER') ?></strong>
                                </div>
                                <div class="col-4">
                                    <small class="text-muted">ريال سعودي</small><br>
                                    <strong><?= formatCurrency($product['price_sar'], 'SAR') ?></strong>
                                </div>
                                <div class="col-4">
                                    <small class="text-muted">دولار</small><br>
                                    <strong><?= formatCurrency($product['price_usd'], 'USD') ?></strong>
                                </div>
                            </div>
                            
                            <div class="text-center mt-3">
                                <button class="btn btn-primary w-100">
                                    <i class="fas fa-shopping-cart me-2"></i>اشتري الآن
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- نافذة الشراء -->
    <div class="modal fade" id="purchaseModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">شراء المنتج</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="purchase.php">
                    <div class="modal-body">
                        <input type="hidden" name="product_id" id="modal_product_id">
                        
                        <div class="text-center mb-3">
                            <h6 id="modal_product_name"></h6>
                            <p class="text-muted" id="modal_product_description"></p>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">العملة</label>
                            <select name="currency" class="form-select" id="modal_currency" onchange="updatePrice()">
                                <option value="YER">ريال يمني</option>
                                <option value="SAR">ريال سعودي</option>
                                <option value="USD">دولار أمريكي</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">السعر</label>
                            <input type="text" class="form-control" id="modal_price" readonly>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">معرف اللاعب *</label>
                            <input type="text" name="player_id" class="form-control" required placeholder="أدخل معرف اللاعب">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">اسم اللاعب</label>
                            <input type="text" name="player_name" class="form-control" placeholder="اسم اللاعب (اختياري)">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary">تأكيد الشراء</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let currentProduct = null;
        
        function openPurchaseModal(product) {
            currentProduct = product;
            document.getElementById('modal_product_id').value = product.id;
            document.getElementById('modal_product_name').textContent = product.name_ar;
            document.getElementById('modal_product_description').textContent = product.description;
            updatePrice();
            new bootstrap.Modal(document.getElementById('purchaseModal')).show();
        }
        
        function updatePrice() {
            if (!currentProduct) return;
            
            const currency = document.getElementById('modal_currency').value;
            let price = 0;
            let symbol = '';
            
            switch(currency) {
                case 'YER':
                    price = currentProduct.price_yer;
                    symbol = 'ر.ي';
                    break;
                case 'SAR':
                    price = currentProduct.price_sar;
                    symbol = 'ر.س';
                    break;
                case 'USD':
                    price = currentProduct.price_usd;
                    symbol = '$';
                    break;
            }
            
            document.getElementById('modal_price').value = parseFloat(price).toFixed(2) + ' ' + symbol;
        }
    </script>
</body>
</html>
