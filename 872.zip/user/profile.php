<?php
require_once '../config/config.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

$user = getCurrentUser();
$db = Database::getInstance()->getConnection();
$success = '';
$error = '';

// معالجة تحديث البيانات
if ($_POST) {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_profile') {
        $full_name = trim($_POST['full_name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        
        if (empty($full_name)) {
            $error = 'الاسم الكامل مطلوب';
        } else {
            $stmt = $db->prepare("UPDATE users SET full_name = ?, phone = ? WHERE id = ?");
            if ($stmt->execute([$full_name, $phone, $user['id']])) {
                $success = 'تم تحديث البيانات بنجاح';
                // تحديث بيانات الجلسة
                $_SESSION['user_name'] = $full_name;
                // إعادة جلب بيانات المستخدم
                $user = getCurrentUser();
            } else {
                $error = 'حدث خطأ أثناء تحديث البيانات';
            }
        }
    }
    
    if ($action === 'change_password') {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($current_password) || empty($new_password)) {
            $error = 'يرجى ملء جميع حقول كلمة المرور';
        } elseif (strlen($new_password) < 6) {
            $error = 'كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل';
        } elseif ($new_password !== $confirm_password) {
            $error = 'كلمة المرور الجديدة وتأكيدها غير متطابقتين';
        } elseif (!password_verify($current_password, $user['password'])) {
            $error = 'كلمة المرور الحالية غير صحيحة';
        } else {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
            if ($stmt->execute([$hashed_password, $user['id']])) {
                $success = 'تم تغيير كلمة المرور بنجاح';
                logActivity($user['id'], 'password_changed', 'تم تغيير كلمة المرور');
            } else {
                $error = 'حدث خطأ أثناء تغيير كلمة المرور';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الملف الشخصي - <?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .navbar { background: linear-gradient(45deg, #f39c12, #e67e22); }
        .card { border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .profile-avatar {
            width: 100px;
            height: 100px;
            background: linear-gradient(45deg, #f39c12, #e67e22);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
            margin: 0 auto 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-star me-2"></i><?= SITE_NAME ?>
            </a>
            <div class="navbar-nav ms-auto">
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user me-2"></i><?= htmlspecialchars($user['full_name']) ?>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="dashboard.php"><i class="fas fa-home me-2"></i>الرئيسية</a></li>
                        <li><a class="dropdown-item" href="products.php"><i class="fas fa-box me-2"></i>المنتجات</a></li>
                        <li><a class="dropdown-item" href="orders.php"><i class="fas fa-shopping-cart me-2"></i>طلباتي</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>تسجيل الخروج</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle me-2"></i><?= $success ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <!-- معلومات الملف الشخصي -->
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body text-center">
                        <div class="profile-avatar">
                            <i class="fas fa-user"></i>
                        </div>
                        <h5><?= htmlspecialchars($user['full_name']) ?></h5>
                        <p class="text-muted">@<?= htmlspecialchars($user['username']) ?></p>
                        <p class="text-muted"><?= htmlspecialchars($user['email']) ?></p>
                        
                        <div class="row text-center mt-4">
                            <div class="col-12">
                                <h6>أرصدة المحفظة</h6>
                                <div class="mb-2">
                                    <small class="text-muted">ريال يمني:</small>
                                    <strong><?= formatCurrency($user['wallet_balance_yer'] ?? 0, 'YER') ?></strong>
                                </div>
                                <div class="mb-2">
                                    <small class="text-muted">ريال سعودي:</small>
                                    <strong><?= formatCurrency($user['wallet_balance_sar'] ?? 0, 'SAR') ?></strong>
                                </div>
                                <div class="mb-2">
                                    <small class="text-muted">دولار:</small>
                                    <strong><?= formatCurrency($user['wallet_balance_usd'] ?? 0, 'USD') ?></strong>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-3">
                            <small class="text-muted">عضو منذ: <?= date('Y-m-d', strtotime($user['created_at'])) ?></small>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- تحديث البيانات -->
            <div class="col-lg-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5><i class="fas fa-edit me-2"></i>تحديث البيانات الشخصية</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="update_profile">
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">اسم المستخدم</label>
                                    <input type="text" class="form-control" value="<?= htmlspecialchars($user['username']) ?>" readonly>
                                    <small class="text-muted">لا يمكن تغيير اسم المستخدم</small>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">البريد الإلكتروني</label>
                                    <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" readonly>
                                    <small class="text-muted">لا يمكن تغيير البريد الإلكتروني</small>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">الاسم الكامل *</label>
                                    <input type="text" name="full_name" class="form-control" required value="<?= htmlspecialchars($user['full_name']) ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">رقم الهاتف</label>
                                    <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>حفظ التغييرات
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- تغيير كلمة المرور -->
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-lock me-2"></i>تغيير كلمة المرور</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="change_password">
                            
                            <div class="mb-3">
                                <label class="form-label">كلمة المرور الحالية *</label>
                                <input type="password" name="current_password" class="form-control" required>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">كلمة المرور الجديدة *</label>
                                    <input type="password" name="new_password" class="form-control" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">تأكيد كلمة المرور الجديدة *</label>
                                    <input type="password" name="confirm_password" class="form-control" required>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-warning">
                                <i class="fas fa-key me-2"></i>تغيير كلمة المرور
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
