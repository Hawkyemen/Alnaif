<?php
require_once '../config/config.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

$user = getCurrentUser();
$db = Database::getInstance()->getConnection();

if ($_POST) {
    $product_id = $_POST['product_id'] ?? 0;
    $currency = $_POST['currency'] ?? 'YER';
    $player_id = trim($_POST['player_id'] ?? '');
    $player_name = trim($_POST['player_name'] ?? '');
    
    if (empty($player_id) || !$product_id) {
        $error = 'يرجى ملء جميع الحقول المطلوبة';
    } else {
        try {
            // جلب بيانات المنتج
            $stmt = $db->prepare("SELECT * FROM products WHERE id = ? AND status = 'active'");
            $stmt->execute([$product_id]);
            $product = $stmt->fetch();
            
            if (!$product) {
                $error = 'المنتج غير موجود';
            } else {
                // تحديد السعر حسب العملة
                $amount = 0;
                switch($currency) {
                    case 'YER':
                        $amount = $product['price_yer'];
                        break;
                    case 'SAR':
                        $amount = $product['price_sar'];
                        break;
                    case 'USD':
                        $amount = $product['price_usd'];
                        break;
                }
                
                // إنشاء الطلب
                $stmt = $db->prepare("INSERT INTO orders (user_id, product_id, amount, currency, player_id, player_name, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
                if ($stmt->execute([$user['id'], $product_id, $amount, $currency, $player_id, $player_name])) {
                    $order_id = $db->lastInsertId();
                    logActivity($user['id'], 'order_created', "تم إنشاء طلب جديد #$order_id");
                    redirect("payment.php?order=$order_id");
                } else {
                    $error = 'حدث خطأ أثناء إنشاء الطلب';
                }
            }
        } catch (Exception $e) {
            $error = 'خطأ في قاعدة البيانات: ' . $e->getMessage();
        }
    }
}

// إعادة توجيه إذا لم يكن هناك POST
if (!$_POST) {
    redirect('products.php');
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>معالجة الطلب - <?= SITE_NAME ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body text-center">
                        <?php if (isset($error)): ?>
                            <i class="fas fa-exclamation-triangle fa-3x text-danger mb-3"></i>
                            <h4 class="text-danger">خطأ في الطلب</h4>
                            <p><?= htmlspecialchars($error) ?></p>
                            <a href="products.php" class="btn btn-primary">العودة للمنتجات</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
