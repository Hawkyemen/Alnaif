<?php
session_start();
require_once '../config/config.php';

// Check user authentication
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$db = Database::getInstance()->getConnection();

// Get user info
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Test cards data
$testCards = [
    'visa_success' => [
        'name' => 'Visa - نجح',
        'number' => '4111111111111111',
        'cvv' => '123',
        'expiry' => '12/25',
        'type' => 'visa',
        'expected' => 'success',
        'description' => 'بطاقة اختبار Visa للمعاملات الناجحة'
    ],
    'visa_declined' => [
        'name' => 'Visa - مرفوض',
        'number' => '4000000000000002',
        'cvv' => '123',
        'expiry' => '12/25',
        'type' => 'visa',
        'expected' => 'declined',
        'description' => 'بطاقة اختبار Visa للمعاملات المرفوضة'
    ],
    'mastercard_success' => [
        'name' => 'Mastercard - نجح',
        'number' => '5555555555554444',
        'cvv' => '123',
        'expiry' => '12/25',
        'type' => 'mastercard',
        'expected' => 'success',
        'description' => 'بطاقة اختبار Mastercard للمعاملات الناجحة'
    ],
    'mastercard_declined' => [
        'name' => 'Mastercard - مرفوض',
        'number' => '5000000000000009',
        'cvv' => '123',
        'expiry' => '12/25',
        'type' => 'mastercard',
        'expected' => 'declined',
        'description' => 'بطاقة اختبار Mastercard للمعاملات المرفوضة'
    ],
    'mada_success' => [
        'name' => 'مدى - نجح',
        'number' => '4008610000000001',
        'cvv' => '123',
        'expiry' => '12/25',
        'type' => 'mada',
        'expected' => 'success',
        'description' => 'بطاقة اختبار مدى للمعاملات الناجحة'
    ],
    'amex_success' => [
        'name' => 'American Express - نجح',
        'number' => '378282246310005',
        'cvv' => '1234',
        'expiry' => '12/25',
        'type' => 'amex',
        'expected' => 'success',
        'description' => 'بطاقة اختبار American Express للمعاملات الناجحة'
    ],
    'insufficient_funds' => [
        'name' => 'رصيد غير كافي',
        'number' => '4000000000009995',
        'cvv' => '123',
        'expiry' => '12/25',
        'type' => 'visa',
        'expected' => 'insufficient_funds',
        'description' => 'بطاقة اختبار لحالة الرصيد غير الكافي'
    ],
    'expired_card' => [
        'name' => 'بطاقة منتهية الصلاحية',
        'number' => '4000000000000069',
        'cvv' => '123',
        'expiry' => '01/20',
        'type' => 'visa',
        'expected' => 'expired',
        'description' => 'بطاقة اختبار منتهية الصلاحية'
    ]
];

// Handle test execution
$testResults = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['run_tests'])) {
    foreach ($testCards as $cardKey => $card) {
        $testResults[$cardKey] = runCardTest($card);
    }
}

function runCardTest($card) {
    $result = [
        'card_name' => $card['name'],
        'validation' => [],
        'processing' => [],
        'overall_status' => 'pass'
    ];
    
    // Test 1: Card number validation (Luhn algorithm)
    $luhnValid = validateLuhn($card['number']);
    $result['validation']['luhn'] = [
        'test' => 'Luhn Algorithm',
        'status' => $luhnValid ? 'pass' : 'fail',
        'message' => $luhnValid ? 'رقم البطاقة صحيح' : 'رقم البطاقة غير صحيح'
    ];
    
    // Test 2: CVV validation
    $cvvValid = validateCVV($card['cvv'], $card['type']);
    $result['validation']['cvv'] = [
        'test' => 'CVV Validation',
        'status' => $cvvValid ? 'pass' : 'fail',
        'message' => $cvvValid ? 'CVV صحيح' : 'CVV غير صحيح'
    ];
    
    // Test 3: Expiry date validation
    $expiryValid = validateExpiry($card['expiry']);
    $result['validation']['expiry'] = [
        'test' => 'Expiry Date',
        'status' => $expiryValid ? 'pass' : 'fail',
        'message' => $expiryValid ? 'تاريخ الانتهاء صحيح' : 'تاريخ الانتهاء غير صحيح'
    ];
    
    // Test 4: Card type detection
    $detectedType = detectCardType($card['number']);
    $typeCorrect = $detectedType === $card['type'] || 
                   ($card['type'] === 'mada' && $detectedType === 'visa') ||
                   ($card['type'] === 'amex' && $detectedType === 'american_express');
    $result['validation']['type'] = [
        'test' => 'Card Type Detection',
        'status' => $typeCorrect ? 'pass' : 'fail',
        'message' => "نوع البطاقة المكتشف: $detectedType"
    ];
    
    // Test 5: Simulate payment processing
    $processingResult = simulatePaymentProcessing($card);
    $result['processing']['simulation'] = [
        'test' => 'Payment Processing Simulation',
        'status' => $processingResult['success'] ? 'pass' : 'fail',
        'message' => $processingResult['message']
    ];
    
    // Determine overall status
    foreach ($result['validation'] as $test) {
        if ($test['status'] === 'fail') {
            $result['overall_status'] = 'fail';
            break;
        }
    }
    
    if ($result['processing']['simulation']['status'] === 'fail' && $card['expected'] === 'success') {
        $result['overall_status'] = 'fail';
    }
    
    return $result;
}

function validateLuhn($number) {
    $number = preg_replace('/\D/', '', $number);
    $sum = 0;
    $alternate = false;
    
    for ($i = strlen($number) - 1; $i >= 0; $i--) {
        $n = intval($number[$i]);
        if ($alternate) {
            $n *= 2;
            if ($n > 9) $n = ($n % 10) + 1;
        }
        $sum += $n;
        $alternate = !$alternate;
    }
    
    return ($sum % 10) === 0;
}

function validateCVV($cvv, $cardType) {
    if ($cardType === 'amex') {
        return preg_match('/^\d{4}$/', $cvv);
    } else {
        return preg_match('/^\d{3}$/', $cvv);
    }
}

function validateExpiry($expiry) {
    if (!preg_match('/^(0[1-9]|1[0-2])\/\d{2}$/', $expiry)) {
        return false;
    }
    
    list($month, $year) = explode('/', $expiry);
    $expiryDate = new DateTime('20' . $year . '-' . $month . '-01');
    return $expiryDate >= new DateTime();
}

function detectCardType($number) {
    $number = preg_replace('/\D/', '', $number);
    
    if (preg_match('/^4/', $number)) return 'visa';
    if (preg_match('/^5[1-5]/', $number)) return 'mastercard';
    if (preg_match('/^3[47]/', $number)) return 'american_express';
    if (preg_match('/^(400861|401757|407197)/', $number)) return 'mada';
    
    return 'unknown';
}

function simulatePaymentProcessing($card) {
    // Simulate different scenarios based on card number
    switch ($card['expected']) {
        case 'success':
            return [
                'success' => true,
                'message' => 'المعاملة تمت بنجاح',
                'transaction_id' => 'test_' . uniqid()
            ];
            
        case 'declined':
            return [
                'success' => false,
                'message' => 'تم رفض المعاملة من قبل البنك',
                'error_code' => 'card_declined'
            ];
            
        case 'insufficient_funds':
            return [
                'success' => false,
                'message' => 'رصيد غير كافي',
                'error_code' => 'insufficient_funds'
            ];
            
        case 'expired':
            return [
                'success' => false,
                'message' => 'البطاقة منتهية الصلاحية',
                'error_code' => 'expired_card'
            ];
            
        default:
            return [
                'success' => false,
                'message' => 'خطأ غير معروف',
                'error_code' => 'unknown_error'
            ];
    }
}

function maskCardNumber($number) {
    $number = preg_replace('/\D/', '', $number);
    return substr($number, 0, 4) . ' **** **** ' . substr($number, -4);
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>اختبار البطاقات البنكية - فاست ستار</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .test-card { transition: all 0.3s ease; }
        .test-card:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        .status-pass { color: #28a745; }
        .status-fail { color: #dc3545; }
        .card-number { font-family: 'Courier New', monospace; font-weight: bold; }
        .test-result { margin-top: 10px; padding: 10px; border-radius: 5px; }
        .test-result.pass { background-color: #d4edda; border: 1px solid #c3e6cb; }
        .test-result.fail { background-color: #f8d7da; border: 1px solid #f5c6cb; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="dashboard.php">
            <i class="fas fa-star"></i> فاست ستار
        </a>
        <div class="navbar-nav ms-auto">
            <a class="nav-link" href="dashboard.php">لوحة التحكم</a>
            <a class="nav-link" href="wallet.php">المحفظة</a>
            <a class="nav-link" href="logout.php">تسجيل الخروج</a>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h3 class="card-title mb-0">
                        <i class="fas fa-credit-card"></i> اختبار البطاقات البنكية
                    </h3>
                </div>
                <div class="card-body">
                    
                    <div class="alert alert-info">
                        <h5><i class="fas fa-info-circle"></i> معلومات مهمة</h5>
                        <p>هذه الصفحة تحتوي على بطاقات اختبار لفحص نظام الدفع. جميع البطاقات المعروضة هنا هي بطاقات وهمية للاختبار فقط ولا تمثل بطاقات حقيقية.</p>
                        <p><strong>ملاحظة:</strong> لا تستخدم بطاقات حقيقية في بيئة الاختبار.</p>
                    </div>
                    
                    <form method="POST" class="mb-4">
                        <button type="submit" name="run_tests" class="btn btn-success btn-lg">
                            <i class="fas fa-play"></i> تشغيل جميع الاختبارات
                        </button>
                    </form>
                    
                    <?php if (!empty($testResults)): ?>
                    <div class="alert alert-success">
                        <h5><i class="fas fa-check-circle"></i> تم تشغيل الاختبارات بنجاح</h5>
                        <p>تم اختبار <?php echo count($testResults); ?> بطاقة. راجع النتائج أدناه.</p>
                    </div>
                    <?php endif; ?>
                    
                    <div class="row">
                        <?php foreach ($testCards as $cardKey => $card): ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="card test-card h-100">
                                <div class="card-header bg-light">
                                    <h6 class="card-title mb-0">
                                        <i class="fas fa-credit-card"></i> <?php echo htmlspecialchars($card['name']); ?>
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <strong>رقم البطاقة:</strong><br>
                                        <span class="card-number"><?php echo maskCardNumber($card['number']); ?></span>
                                    </div>
                                    
                                    <div class="row mb-3">
                                        <div class="col-6">
                                            <strong>CVV:</strong> <?php echo $card['cvv']; ?>
                                        </div>
                                        <div class="col-6">
                                            <strong>انتهاء:</strong> <?php echo $card['expiry']; ?>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <strong>النوع:</strong> 
                                        <span class="badge bg-secondary"><?php echo ucfirst($card['type']); ?></span>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <strong>النتيجة المتوقعة:</strong>
                                        <span class="badge bg-<?php echo $card['expected'] === 'success' ? 'success' : 'warning'; ?>">
                                            <?php 
                                            switch($card['expected']) {
                                                case 'success': echo 'نجح'; break;
                                                case 'declined': echo 'مرفوض'; break;
                                                case 'insufficient_funds': echo 'رصيد غير كافي'; break;
                                                case 'expired': echo 'منتهية الصلاحية'; break;
                                                default: echo $card['expected'];
                                            }
                                            ?>
                                        </span>
                                    </div>
                                    
                                    <p class="text-muted small"><?php echo htmlspecialchars($card['description']); ?></p>
                                    
                                    <?php if (isset($testResults[$cardKey])): ?>
                                    <div class="test-result <?php echo $testResults[$cardKey]['overall_status']; ?>">
                                        <h6>
                                            <i class="fas fa-<?php echo $testResults[$cardKey]['overall_status'] === 'pass' ? 'check-circle status-pass' : 'times-circle status-fail'; ?>"></i>
                                            نتيجة الاختبار: <?php echo $testResults[$cardKey]['overall_status'] === 'pass' ? 'نجح' : 'فشل'; ?>
                                        </h6>
                                        
                                        <div class="mt-3">
                                            <strong>اختبارات التحقق:</strong>
                                            <ul class="list-unstyled mt-2">
                                                <?php foreach ($testResults[$cardKey]['validation'] as $test): ?>
                                                <li>
                                                    <i class="fas fa-<?php echo $test['status'] === 'pass' ? 'check text-success' : 'times text-danger'; ?>"></i>
                                                    <?php echo $test['test']; ?>: <?php echo $test['message']; ?>
                                                </li>
                                                <?php endforeach; ?>
                                            </ul>
                                        </div>
                                        
                                        <div class="mt-3">
                                            <strong>محاكاة المعالجة:</strong>
                                            <p class="mb-0">
                                                <i class="fas fa-<?php echo $testResults[$cardKey]['processing']['simulation']['status'] === 'pass' ? 'check text-success' : 'times text-danger'; ?>"></i>
                                                <?php echo $testResults[$cardKey]['processing']['simulation']['message']; ?>
                                            </p>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Test Summary -->
                    <?php if (!empty($testResults)): ?>
                    <div class="card mt-4">
                        <div class="card-header bg-info text-white">
                            <h5 class="mb-0"><i class="fas fa-chart-bar"></i> ملخص النتائج</h5>
                        </div>
                        <div class="card-body">
                            <?php
                            $totalTests = count($testResults);
                            $passedTests = 0;
                            $failedTests = 0;
                            
                            foreach ($testResults as $result) {
                                if ($result['overall_status'] === 'pass') {
                                    $passedTests++;
                                } else {
                                    $failedTests++;
                                }
                            }
                            
                            $successRate = $totalTests > 0 ? round(($passedTests / $totalTests) * 100, 2) : 0;
                            ?>
                            
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="text-center">
                                        <h4 class="text-primary"><?php echo $totalTests; ?></h4>
                                        <p class="mb-0">إجمالي الاختبارات</p>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="text-center">
                                        <h4 class="text-success"><?php echo $passedTests; ?></h4>
                                        <p class="mb-0">اختبارات ناجحة</p>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="text-center">
                                        <h4 class="text-danger"><?php echo $failedTests; ?></h4>
                                        <p class="mb-0">اختبارات فاشلة</p>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="text-center">
                                        <h4 class="text-info"><?php echo $successRate; ?>%</h4>
                                        <p class="mb-0">معدل النجاح</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="progress mt-3">
                                <div class="progress-bar bg-success" style="width: <?php echo $successRate; ?>%"></div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Reference Guide -->
                    <div class="card mt-4">
                        <div class="card-header bg-secondary text-white">
                            <h5 class="mb-0"><i class="fas fa-book"></i> مرجع بطاقات الاخ��بار</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>النوع</th>
                                            <th>الرقم</th>
                                            <th>CVV</th>
                                            <th>الانتهاء</th>
                                            <th>النتيجة المتوقعة</th>
                                            <th>الاستخدام</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($testCards as $card): ?>
                                        <tr>
                                            <td><span class="badge bg-primary"><?php echo ucfirst($card['type']); ?></span></td>
                                            <td class="card-number"><?php echo maskCardNumber($card['number']); ?></td>
                                            <td><?php echo $card['cvv']; ?></td>
                                            <td><?php echo $card['expiry']; ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $card['expected'] === 'success' ? 'success' : 'warning'; ?>">
                                                    <?php 
                                                    switch($card['expected']) {
                                                        case 'success': echo 'نجح'; break;
                                                        case 'declined': echo 'مرفوض'; break;
                                                        case 'insufficient_funds': echo 'رصيد غير كافي'; break;
                                                        case 'expired': echo 'منتهية'; break;
                                                        default: echo $card['expected'];
                                                    }
                                                    ?>
                                                </span>
                                            </td>
                                            <td class="small"><?php echo htmlspecialchars($card['description']); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
