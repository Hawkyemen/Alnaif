<?php
require_once '../config/config.php';
require_once '../config/payment_config.php';

if (!isset($_SESSION['user_id'])) {
    redirect('../login.php');
}

$db = Database::getInstance()->getConnection();
$message = '';

// Get user data
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Handle wallet top-up
if ($_POST && isset($_POST['action']) && $_POST['action'] === 'topup') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $message = '<div class="alert alert-danger">رمز الأمان غير صحيح</div>';
    } else {
        $amount = (float)($_POST['amount'] ?? 0);
        $currency = $_POST['currency'] ?? 'YER';
        $gateway = $_POST['gateway'] ?? 'paypal';
        
        if ($amount > 0) {
            try {
                if ($gateway === 'bank_cards') {
                    // Handle bank card payment separately
                    $message = '<div class="alert alert-info">يرجى استخدام نموذج البطاقة البنكية</div>';
                } elseif ($gateway === 'apple_pay') {
                    $message = '<div class="alert alert-info">يرجى استخدام Apple Pay من التطبيق</div>';
                } elseif ($gateway === 'google_play') {
                    $message = '<div class="alert alert-info">يرجى استخدام Google Play من التطبيق</div>';
                } else {
                    $payment_gateway = new PaymentGateway();
                    $result = $payment_gateway->processPayment($gateway, $amount, $currency, $_SESSION['user_id']);
                    
                    if ($result['success']) {
                        if (isset($result['redirect_url'])) {
                            redirect($result['redirect_url']);
                        } elseif (isset($result['client_secret'])) {
                            $_SESSION['stripe_client_secret'] = $result['client_secret'];
                            $_SESSION['payment_amount'] = $amount;
                            $_SESSION['payment_currency'] = $currency;
                        } elseif (isset($result['form_data'])) {
                            $_SESSION['mada_form_data'] = $result['form_data'];
                            $_SESSION['mada_action_url'] = $result['action_url'];
                        }
                    }
                }
            } catch (Exception $e) {
                $message = '<div class="alert alert-danger">خطأ في الدفع: ' . htmlspecialchars($e->getMessage()) . '</div>';
            }
        } else {
            $message = '<div class="alert alert-danger">يرجى إدخال مبلغ صحيح</div>';
        }
    }
}

// Get wallet transactions
$stmt = $db->prepare("SELECT * FROM wallet_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 20");
$stmt->execute([$_SESSION['user_id']]);
$transactions = $stmt->fetchAll();

// Get payment gateways
$stmt = $db->query("SELECT * FROM payment_gateways WHERE is_active = 1");
$gateways = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>المحفظة - فاست ستار</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://js.stripe.com/v3/"></script>
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(45deg, #f39c12, #e67e22) !important;
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            margin-bottom: 24px;
        }
        .wallet-card {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
        }
        .btn-primary {
            background: linear-gradient(45deg, #f39c12, #e67e22);
            border: none;
        }
        .payment-method {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .payment-method:hover {
            border-color: #f39c12;
            background-color: #fff8f0;
        }
        .payment-method.selected {
            border-color: #f39c12;
            background-color: #fff8f0;
        }
        .card-input {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 12px;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }
        .card-input:focus {
            border-color: #f39c12;
            outline: none;
            box-shadow: 0 0 0 2px rgba(243, 156, 18, 0.2);
        }
        .card-icon {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 24px;
            color: #666;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-star me-2"></i>
                فاست ستار
            </a>
            
            <div class="navbar-nav ms-auto">
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user me-1"></i>
                        <?= htmlspecialchars($user['full_name']) ?>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="dashboard.php"><i class="fas fa-home me-2"></i>الرئيسية</a></li>
                        <li><a class="dropdown-item" href="products.php"><i class="fas fa-box me-2"></i>المنتجات</a></li>
                        <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user me-2"></i>الملف الشخصي</a></li>
                        <li><a class="dropdown-item" href="orders.php"><i class="fas fa-shopping-cart me-2"></i>الطلبات</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>تسجيل الخروج</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="container mt-4">
        <?= $message ?>
        
        <!-- Wallet Balance -->
        <div class="row mb-4">
            <div class="col-md-4 mb-3">
                <div class="card wallet-card">
                    <div class="card-body text-center">
                        <i class="fas fa-wallet fa-2x mb-3"></i>
                        <h5>الريال اليمني</h5>
                        <h3><?= formatCurrency($user['wallet_balance_yer'], 'YER') ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card wallet-card">
                    <div class="card-body text-center">
                        <i class="fas fa-wallet fa-2x mb-3"></i>
                        <h5>الريال السعودي</h5>
                        <h3><?= formatCurrency($user['wallet_balance_sar'], 'SAR') ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card wallet-card">
                    <div class="card-body text-center">
                        <i class="fas fa-wallet fa-2x mb-3"></i>
                        <h5>الدولار الأمريكي</h5>
                        <h3><?= formatCurrency($user['wallet_balance_usd'], 'USD') ?></h3>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Top-up Section -->
        <div class="row">
            <div class="col-lg-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-plus-circle me-2"></i>
                            شحن المحفظة
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="topupForm">
                            <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                            <input type="hidden" name="action" value="topup">
                            
                            <div class="mb-3">
                                <label class="form-label">المبلغ *</label>
                                <input type="number" name="amount" class="form-control" step="0.01" min="1" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">العملة *</label>
                                <select name="currency" class="form-select" required>
                                    <option value="YER">ريال يمني</option>
                                    <option value="SAR">ريال سعودي</option>
                                    <option value="USD">دولار أمريكي</option>
                                </select>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">طريقة الدفع *</label>
                                
                                <!-- PayPal -->
                                <div class="payment-method" onclick="selectPaymentMethod('paypal')">
                                    <input type="radio" name="gateway" value="paypal" id="gateway_paypal" style="display: none;">
                                    <div class="d-flex align-items-center">
                                        <i class="fab fa-paypal fa-2x me-3 text-primary"></i>
                                        <div>
                                            <h6 class="mb-0">PayPal</h6>
                                            <small class="text-muted">يدعم: USD, SAR, YER</small>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Stripe -->
                                <div class="payment-method" onclick="selectPaymentMethod('stripe')">
                                    <input type="radio" name="gateway" value="stripe" id="gateway_stripe" style="display: none;">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-credit-card fa-2x me-3 text-info"></i>
                                        <div>
                                            <h6 class="mb-0">Stripe</h6>
                                            <small class="text-muted">يدعم: USD, SAR</small>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Apple Pay -->
                                <div class="payment-method" onclick="selectPaymentMethod('apple_pay')">
                                    <input type="radio" name="gateway" value="apple_pay" id="gateway_apple_pay" style="display: none;">
                                    <div class="d-flex align-items-center">
                                        <i class="fab fa-apple fa-2x me-3 text-dark"></i>
                                        <div>
                                            <h6 class="mb-0">Apple Pay</h6>
                                            <small class="text-muted">يدعم: USD, SAR (من التطبيق)</small>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Google Play -->
                                <div class="payment-method" onclick="selectPaymentMethod('google_play')">
                                    <input type="radio" name="gateway" value="google_play" id="gateway_google_play" style="display: none;">
                                    <div class="d-flex align-items-center">
                                        <i class="fab fa-google-play fa-2x me-3 text-success"></i>
                                        <div>
                                            <h6 class="mb-0">Google Play</h6>
                                            <small class="text-muted">يدعم: USD, SAR (من التطبيق)</small>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Bank Cards -->
                                <div class="payment-method" onclick="selectPaymentMethod('bank_cards')">
                                    <input type="radio" name="gateway" value="bank_cards" id="gateway_bank_cards" style="display: none;">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-credit-card fa-2x me-3 text-warning"></i>
                                        <div>
                                            <h6 class="mb-0">البطاقات البنكية</h6>
                                            <small class="text-muted">فيزا، ماستركارد، مدى</small>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Mada -->
                                <div class="payment-method" onclick="selectPaymentMethod('mada')">
                                    <input type="radio" name="gateway" value="mada" id="gateway_mada" style="display: none;">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-mobile-alt fa-2x me-3 text-success"></i>
                                        <div>
                                            <h6 class="mb-0">مدى</h6>
                                            <small class="text-muted">يدعم: SAR</small>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Yemen Mobile Money -->
                                <div class="payment-method" onclick="selectPaymentMethod('ymm')">
                                    <input type="radio" name="gateway" value="ymm" id="gateway_ymm" style="display: none;">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-mobile-alt fa-2x me-3 text-danger"></i>
                                        <div>
                                            <h6 class="mb-0">Yemen Mobile Money</h6>
                                            <small class="text-muted">يدعم: YER</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-credit-card me-2"></i>
                                شحن المحفظة
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Transaction History -->
            <div class="col-lg-6 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="fas fa-history me-2"></i>
                            سجل المعاملات
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($transactions)): ?>
                            <p class="text-muted text-center">لا توجد معاملات</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>النوع</th>
                                            <th>المبلغ</th>
                                            <th>الحالة</th>
                                            <th>التاريخ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($transactions as $transaction): ?>
                                        <tr>
                                            <td>
                                                <i class="fas fa-<?= $transaction['type'] === 'deposit' ? 'plus' : ($transaction['type'] === 'withdrawal' ? 'minus' : 'shopping-cart') ?> me-1"></i>
                                                <?= $transaction['type'] === 'deposit' ? 'إيداع' : ($transaction['type'] === 'withdrawal' ? 'سحب' : 'شراء') ?>
                                            </td>
                                            <td><?= formatCurrency($transaction['amount'], $transaction['currency']) ?></td>
                                            <td>
                                                <span class="badge bg-<?= $transaction['status'] === 'completed' ? 'success' : ($transaction['status'] === 'pending' ? 'warning' : 'danger') ?>">
                                                    <?= $transaction['status'] === 'completed' ? 'مكتمل' : ($transaction['status'] === 'pending' ? 'معلق' : 'فاشل') ?>
                                                </span>
                                            </td>
                                            <td><?= date('m/d H:i', strtotime($transaction['created_at'])) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bank Card Modal -->
    <div class="modal fade" id="bankCardModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">الدفع بالبطاقة البنكية</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="error_message" class="alert alert-danger" style="display: none;"></div>
                    
                    <form id="bankCardForm">
                        <div class="mb-3 position-relative">
                            <label class="form-label">رقم البطاقة *</label>
                            <input type="text" id="card_number" class="form-control card-input" placeholder="1234 5678 9012 3456" maxlength="19" required>
                            <i id="card_icon" class="fas fa-credit-card card-icon"></i>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">تاريخ الانتهاء *</label>
                                <div class="row">
                                    <div class="col-6">
                                        <select id="expiry_month" class="form-select" required>
                                            <option value="">الشهر</option>
                                            <option value="01">01</option>
                                            <option value="02">02</option>
                                            <option value="03">03</option>
                                            <option value="04">04</option>
                                            <option value="05">05</option>
                                            <option value="06">06</option>
                                            <option value="07">07</option>
                                            <option value="08">08</option>
                                            <option value="09">09</option>
                                            <option value="10">10</option>
                                            <option value="11">11</option>
                                            <option value="12">12</option>
                                        </select>
                                    </div>
                                    <div class="col-6">
                                        <select id="expiry_year" class="form-select" required>
                                            <option value="">السنة</option>
                                            <option value="24">2024</option>
                                            <option value="25">2025</option>
                                            <option value="26">2026</option>
                                            <option value="27">2027</option>
                                            <option value="28">2028</option>
                                            <option value="29">2029</option>
                                            <option value="30">2030</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">CVV *</label>
                                <input type="text" id="cvv" class="form-control card-input" placeholder="123" maxlength="4" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">اسم حامل البطاقة *</label>
                            <input type="text" id="card_holder" class="form-control card-input" placeholder="الاسم كما هو مكتوب على البطاقة" required>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-shield-alt me-2"></i>
                            جميع المعاملات محمية بتشفير SSL
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button type="button" class="btn btn-primary" onclick="processBankCardPayment()">
                        <i class="fas fa-credit-card me-2"></i>
                        دفع الآن
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Stripe Payment Modal -->
    <?php if (isset($_SESSION['stripe_client_secret'])): ?>
    <div class="modal fade" id="stripeModal" tabindex="-1" data-bs-backdrop="static">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">إكمال الدفع</h5>
                </div>
                <div class="modal-body">
                    <div id="card-element">
                        <!-- Stripe Elements will create form elements here -->
                    </div>
                    <div id="card-errors" role="alert"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="cancelStripePayment()">إلغاء</button>
                    <button type="button" class="btn btn-primary" id="submit-payment">
                        دفع <?= formatCurrency($_SESSION['payment_amount'], $_SESSION['payment_currency']) ?>
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Mada Payment Form -->
    <?php if (isset($_SESSION['mada_form_data'])): ?>
    <form id="madaForm" method="POST" action="<?= $_SESSION['mada_action_url'] ?>" style="display: none;">
        <?php foreach ($_SESSION['mada_form_data'] as $key => $value): ?>
        <input type="hidden" name="<?= $key ?>" value="<?= $value ?>">
        <?php endforeach; ?>
    </form>
    <script>
        document.getElementById('madaForm').submit();
    </script>
    <?php 
    unset($_SESSION['mada_form_data']);
    unset($_SESSION['mada_action_url']);
    endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function selectPaymentMethod(gateway) {
            document.querySelectorAll('.payment-method').forEach(el => el.classList.remove('selected'));
            event.currentTarget.classList.add('selected');
            document.getElementById('gateway_' + gateway).checked = true;
            
            // Handle special payment methods
            if (gateway === 'bank_cards') {
                event.preventDefault();
                showBankCardModal();
                return false;
            } else if (gateway === 'apple_pay') {
                event.preventDefault();
                processApplePay();
                return false;
            } else if (gateway === 'google_play') {
                event.preventDefault();
                processGooglePlay();
                return false;
            }
        }

        function showBankCardModal() {
            new bootstrap.Modal(document.getElementById('bankCardModal')).show();
        }

        function processBankCardPayment() {
            const formData = {
                user_id: <?= $_SESSION['user_id'] ?>,
                amount: parseFloat(document.querySelector('[name="amount"]').value),
                currency: document.querySelector('[name="currency"]').value,
                card_number: document.getElementById('card_number').value.replace(/\s/g, ''),
                expiry_month: document.getElementById('expiry_month').value,
                expiry_year: document.getElementById('expiry_year').value,
                cvv: document.getElementById('cvv').value,
                card_holder: document.getElementById('card_holder').value
            };
            
            if (!validateCardData(formData)) {
                return;
            }
            
            fetch('/api/payment/bank_cards.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = 'payment_success.php?transaction_id=' + data.transaction_id;
                } else {
                    showError(data.error);
                }
            })
            .catch(error => {
                showError('حدث خطأ أثناء معالجة الدفع');
            });
        }

        function processApplePay() {
            if (window.ApplePaySession && ApplePaySession.canMakePayments()) {
                const request = {
                    countryCode: 'SA',
                    currencyCode: document.querySelector('[name="currency"]').value,
                    supportedNetworks: ['visa', 'masterCard', 'amex', 'mada'],
                    merchantCapabilities: ['supports3DS'],
                    total: {
                        label: 'فاست ستار - شحن المحفظة',
                        amount: document.querySelector('[name="amount"]').value
                    }
                };
                
                const session = new ApplePaySession(3, request);
                
                session.onvalidatemerchant = function(event) {
                    // Validate merchant with Apple Pay
                };
                
                session.onpaymentauthorized = function(event) {
                    const payment = event.payment;
                    
                    fetch('/api/payment/apple_pay.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            user_id: <?= $_SESSION['user_id'] ?>,
                            amount: parseFloat(document.querySelector('[name="amount"]').value),
                            currency: document.querySelector('[name="currency"]').value,
                            receipt_data: payment.token.paymentData
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            session.completePayment(ApplePaySession.STATUS_SUCCESS);
                            window.location.href = 'payment_success.php?transaction_id=' + data.transaction_id;
                        } else {
                            session.completePayment(ApplePaySession.STATUS_FAILURE);
                            alert('خطأ: ' + data.error);
                        }
                    });
                };
                
                session.begin();
            } else {
                alert('Apple Pay غير متاح على هذا الجهاز');
            }
        }

        function processGooglePlay() {
            if (typeof Android !== 'undefined' && Android.purchaseItem) {
                const amount = document.querySelector('[name="amount"]').value;
                const currency = document.querySelector('[name="currency"]').value;
                const productId = 'wallet_topup_' + amount + '_' + currency.toLowerCase();
                
                Android.purchaseItem(productId, amount, currency);
            } else {
                alert('Google Play غير متاح على هذا الجهاز');
            }
        }

        function validateCardData(data) {
            if (!isValidCardNumber(data.card_number)) {
                showError('رقم البطاقة غير صحيح');
                return false;
            }
            
            if (!isValidExpiryDate(data.expiry_month, data.expiry_year)) {
                showError('تاريخ انتهاء البطاقة غير صحيح');
                return false;
            }
            
            if (!isValidCVV(data.cvv)) {
                showError('رمز CVV غير صحيح');
                return false;
            }
            
            return true;
        }

        function isValidCardNumber(cardNumber) {
            let sum = 0;
            let alternate = false;
            
            for (let i = cardNumber.length - 1; i >= 0; i--) {
                let n = parseInt(cardNumber.charAt(i), 10);
                
                if (alternate) {
                    n *= 2;
                    if (n > 9) {
                        n = (n % 10) + 1;
                    }
                }
                
                sum += n;
                alternate = !alternate;
            }
            
            return (sum % 10) === 0;
        }

        function isValidExpiryDate(month, year) {
            const now = new Date();
            const currentYear = now.getFullYear() % 100;
            const currentMonth = now.getMonth() + 1;
            
            const expYear = parseInt(year, 10);
            const expMonth = parseInt(month, 10);
            
            if (expYear < currentYear) return false;
            if (expYear === currentYear && expMonth < currentMonth) return false;
            
            return true;
        }

        function isValidCVV(cvv) {
            return /^\d{3,4}$/.test(cvv);
        }

        function showError(message) {
            const errorDiv = document.getElementById('error_message');
            errorDiv.textContent = message;
            errorDiv.style.display = 'block';
            
            setTimeout(() => {
                errorDiv.style.display = 'none';
            }, 5000);
        }

        // Format card number input
        document.addEventListener('DOMContentLoaded', function() {
            const cardNumberInput = document.getElementById('card_number');
            if (cardNumberInput) {
                cardNumberInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\s/g, '');
                    let formattedValue = value.replace(/(.{4})/g, '$1 ').trim();
                    if (formattedValue.length > 19) {
                        formattedValue = formattedValue.substring(0, 19);
                    }
                    e.target.value = formattedValue;
                    
                    detectCardType(value);
                });
            }
            
            const cvvInput = document.getElementById('cvv');
            if (cvvInput) {
                cvvInput.addEventListener('input', function(e) {
                    e.target.value = e.target.value.replace(/\D/g, '').substring(0, 4);
                });
            }
        });

        function detectCardType(cardNumber) {
            const cardTypes = {
                visa: /^4/,
                mastercard: /^5[1-5]/,
                mada: /^(400861|401757|407197|407395|409201|410685|412565)/
            };
            
            const iconElement = document.getElementById('card_icon');
            const icons = {
                visa: 'fab fa-cc-visa text-primary',
                mastercard: 'fab fa-cc-mastercard text-warning', 
                mada: 'fas fa-credit-card text-success'
            };
            
            for (let [type, pattern] of Object.entries(cardTypes)) {
                if (pattern.test(cardNumber)) {
                    iconElement.className = icons[type] + ' card-icon';
                    return;
                }
            }
            
            iconElement.className = 'fas fa-credit-card card-icon';
        }
        
        <?php if (isset($_SESSION['stripe_client_secret'])): ?>
        // Stripe integration
        const stripe = Stripe('<?= STRIPE_PUBLISHABLE_KEY ?>');
        const elements = stripe.elements();
        const cardElement = elements.create('card');
        cardElement.mount('#card-element');
        
        document.getElementById('submit-payment').addEventListener('click', async () => {
            const {error, paymentIntent} = await stripe.confirmCardPayment('<?= $_SESSION['stripe_client_secret'] ?>', {
                payment_method: {
                    card: cardElement
                }
            });
            
            if (error) {
                document.getElementById('card-errors').textContent = error.message;
            } else {
                window.location.href = 'payment_success.php?payment_intent=' + paymentIntent.id;
            }
        });
        
        function cancelStripePayment() {
            window.location.href = 'wallet.php';
        }
        
        // Show Stripe modal
        new bootstrap.Modal(document.getElementById('stripeModal')).show();
        <?php 
        unset($_SESSION['stripe_client_secret']);
        unset($_SESSION['payment_amount']);
        unset($_SESSION['payment_currency']);
        endif; ?>
    </script>
</body>
</html>
